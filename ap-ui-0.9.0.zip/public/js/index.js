import { ALanguageManager } from './a/index.js';
import { TradingManager } from './managers/TradingManager.js';
import { Trading } from './Trading.js';
let lm = ALanguageManager.instance;
let tm = TradingManager.instance;
document.body.appendChild(new Trading());
