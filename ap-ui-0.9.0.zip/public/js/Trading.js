import { AApplication, AMenuData, AMenuDataItem, ARenderManager, ARenderManagerEvent, AMenuEvent, AMenuBar, AMenuBarEvent, AFooter, AHeader, AMenuDataDividerItem, AMenu, AButtonBar, AButtonBarEvent, AFontAwesomeIcon, AText, AMenuButton, AMenuButtonEvent, ALanguageManager, ALanguageManagerEvent } from './a/index.js';
import { MastheadWidget } from './MastheadWidget.js';
import { TradingManager } from './managers/TradingManager.js';
import { TradingPanelContainer } from './components/TradingPanelContainer.js';
import { NotificationsWidget } from './NotificationsWidget.js';
import { OrderWidget } from './OrderWidget.js';
import { OrderBookWidget } from './OrderBookWidget.js';
import { ChartsWidget } from './ChartsWidget.js';
import { InstrumentsWidget } from './InstrumentsWidget.js';
import { AccountOrdersWidget } from './AccountOrdersWidget.js';
import { PublicTradesWidget } from './PublicTradesWidget.js';
import { AccountBalancesWidget } from './AccountBalancesWidget.js';
import { AccountTradesWidget } from './AccountTradesWidget.js';
import { MobileTradeWidget } from './MobileTradeWidget.js';
export class Trading extends AApplication {
    constructor() {
        super();
    }
    _build() {
        super._build();
        let tm = TradingManager.instance;
        tm.SetConnectMarketData(true);
        tm.SetConnectAccount(true);
        this._accountMenuAuthenticateItem = new AMenuDataItem(null, 'Sign In', 'authenticate');
        this._accountMenuRegisterItem = new AMenuDataItem(null, 'Register', 'register');
        this._accountMenuItem = new AMenuData(null, 'Account', [
            this._accountMenuAuthenticateItem,
            this._accountMenuRegisterItem
        ]);
        this._themeMenuItem = new AMenuData(null, 'Theme');
        this._layoutMenuItem = new AMenuData(null, 'Layout');
        this._helpMenuItem = new AMenuData(null, 'Help');
        this._termsConditionsMenuItem = new AMenuDataItem(null, 'Terms & Conditions', null);
        this._privacyPolicyMenuItem = new AMenuDataItem(null, 'Privacy Policy', null);
        this._aboutMenuItem = new AMenuDataItem(null, 'About', null);
        this._helpMenuItem.items = [
            this._termsConditionsMenuItem,
            this._privacyPolicyMenuItem,
            new AMenuDataDividerItem(),
            this._aboutMenuItem
        ];
        this._menuBar = new AMenuBar();
        this._menuBar.data = [];
        this._menuBar.data.push(this._accountMenuItem);
        this._menuBar.data.push(this._themeMenuItem);
        if (!tm.isMobile) {
            this._menuBar.data.push(this._layoutMenuItem);
        }
        this._menuBar.data.push(this._helpMenuItem);
        this.appendChild(this._menuBar);
        this._dateTimeText = new AText();
        this._dateTimeText.addClass('date-time');
        this._menuBar.appendChild(this._dateTimeText);
        this._settingsIcon = new AFontAwesomeIcon();
        this._settingsIcon.addClass('settings');
        this._settingsIcon.title = 'Settings';
        this._settingsIcon.value = ['fal', 'fa-cog'];
        this._settingsIcon.visible = false;
        this._menuBar.appendChild(this._settingsIcon);
        this._languageMenuButton = new AMenuButton();
        this._languageMenuButton.title = 'Language';
        this._languageMenuButton.defaultText = 'Language';
        this._menuBar.appendChild(this._languageMenuButton);
        this._systemHealthIcon = new AFontAwesomeIcon();
        this._systemHealthIcon.addClass('system-health');
        this._systemHealthIcon.visible = false;
        this._menuBar.appendChild(this._systemHealthIcon);
        this._header = new AHeader();
        this.appendChild(this._header);
        this._masthead = new MastheadWidget();
        this._header.appendChild(this._masthead);
        this._notifications = new NotificationsWidget();
        this._header.appendChild(this._notifications);
        this._panelGrid = new TradingPanelContainer();
        this._panelGrid.arePanelsLocked = true;
        this.appendChild(this._panelGrid);
        InstrumentsWidget;
        OrderWidget;
        MobileTradeWidget;
        OrderBookWidget;
        ChartsWidget;
        PublicTradesWidget;
        AccountBalancesWidget;
        AccountOrdersWidget;
        AccountTradesWidget;
        this._footer = new AFooter();
        this.appendChild(this._footer);
        this._mobileViewButtons = new AButtonBar();
        this._mobileViewButtons.selectedIndex = 0;
        this._footer.appendChild(this._mobileViewButtons);
        this._mobileViewLabels = [];
        this._mobileViewClasses = [];
        this._contextMenu = new AMenu();
        this._contextMenu.visible = false;
        this.appendChild(this._contextMenu);
    }
    _registerListeners() {
        super._registerListeners();
        this._onLanguageChanged = this._onLanguageChanged.bind(this);
        ALanguageManager.instance.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        this._onSettingsIconClicked = this._onSettingsIconClicked.bind(this);
        this._settingsIcon.addEventListener('click', this._onSettingsIconClicked);
        this._onLanguageMenuButtonChanged = this._onLanguageMenuButtonChanged.bind(this);
        this._languageMenuButton.addEventListener(AMenuButtonEvent.ITEM_SELECTED, this._onLanguageMenuButtonChanged);
        let tm = TradingManager.instance;
        this._onUIConfigReady = this._onUIConfigReady.bind(this);
        tm.UIConfigReady.SubscribeEvent(this._onUIConfigReady);
        this._onTradingManagerReadyStateChanged = this._onTradingManagerReadyStateChanged.bind(this);
        tm.ReadyState.StateChanged.SubscribeEvent(this._onTradingManagerReadyStateChanged);
        this._onMenuItemMousedOver = this._onMenuItemMousedOver.bind(this);
        this._menuBar.addEventListener(AMenuBarEvent.ITEM_MOUSED_OVER, this._onMenuItemMousedOver);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menuBar.addEventListener(AMenuBarEvent.ITEM_CLICKED, this._onMenuItemClicked);
        this._onMenuClosed = this._onMenuClosed.bind(this);
        this._menuBar.addEventListener(AMenuBarEvent.CLOSED, this._onMenuClosed);
        this._onContextMenuItemClicked = this._onContextMenuItemClicked.bind(this);
        this._contextMenu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onContextMenuItemClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onRenderManagerResize = this._onRenderManagerResize.bind(this);
        ARenderManager.instance.addEventListener(ARenderManagerEvent.RESIZE, this._onRenderManagerResize);
        this._onThemeChanged = this._onThemeChanged.bind(this);
        TradingManager.instance.ThemeChanged.SubscribeEvent(this._onThemeChanged);
        this._onLayoutChanged = this._onLayoutChanged.bind(this);
        TradingManager.instance.LayoutChanged.SubscribeEvent(this._onLayoutChanged);
        this._onMobileViewButtonsChanged = this._onMobileViewButtonsChanged.bind(this);
        this._mobileViewButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onMobileViewButtonsChanged);
        setInterval(() => {
            if (tm.isMobile) {
                this._dateTimeText.text = '';
            }
            else {
                let timestamp = new Date();
                this._dateTimeText.text = `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`;
            }
        }, 1000);
        if (tm.isMobile) {
            this._dateTimeText.text = '';
        }
        else {
            let timestamp = new Date();
            this._dateTimeText.text = `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onRenderManagerResize(null);
    }
    _render() {
        if (super._render()) {
            this._menuBar.invalidate();
            this._notifications.invalidate();
            return true;
        }
        else {
            return false;
        }
    }
    _onUIConfigReady() {
        let tm = TradingManager.instance;
        this._accountMenuAuthenticateItem.enabled = tm.UIConfig.AllowUserAuthentication;
        this._accountMenuRegisterItem.enabled = tm.UIConfig.AllowUserRegistration;
        tm.themes.forEach((theme) => {
            this._themeMenuItem.items.push(new AMenuDataItem(null, theme.Name, 'theme', true, tm.theme === theme.Name));
        });
        if (!tm.isMobile) {
            tm.layouts.forEach((layout) => {
                this._layoutMenuItem.items.push(new AMenuDataItem(null, layout.Name, 'layout', true, tm.layout === layout.Name));
            });
        }
        (!tm.isMobile ? tm.UIConfig.DesktopWidgets : tm.UIConfig.MobileWidgets).forEach((widget) => {
            window.customElements.whenDefined(widget.Tag).then(() => {
                let widgetConstructor = window.customElements.get(widget.Tag);
                if (widgetConstructor) {
                    this._panelGrid.addPanel(new widgetConstructor());
                    this._panelGrid.invalidateLayout();
                }
            }).catch((error) => {
            });
        });
        if (tm.isMobile) {
            this._mobileViewLabels = [];
            this._mobileViewClasses = [];
            tm.UIConfig.MobileViews.forEach((view) => {
                this._mobileViewLabels.push(ALanguageManager.instance.get('MobileViews', view.LabelLanguageID));
                this._mobileViewClasses.push(view.CSSClass);
            });
            this._mobileViewButtons.labels = this._mobileViewLabels;
            this._mobileViewButtons.selectedIndex = 0;
            this._invalidateMobileView();
        }
        this.invalidate();
    }
    _onLanguageChanged() {
        let tm = TradingManager.instance;
        let lm = ALanguageManager.instance;
        this._accountMenuItem.label = `${lm.get('Menu', 'Account')}`;
        this._accountMenuAuthenticateItem.label = `${lm.get('Menu', 'Sign In')}`;
        this._accountMenuRegisterItem.label = `${lm.get('Menu', 'Register')}`;
        this._themeMenuItem.label = `${lm.get('Menu', 'Theme')}`;
        this._layoutMenuItem.label = `${lm.get('Menu', 'Layout')}`;
        this._helpMenuItem.label = `${lm.get('Menu', 'Help')}`;
        this._termsConditionsMenuItem.label = `${lm.get('Menu', 'Terms & Conditions')}`;
        this._privacyPolicyMenuItem.label = `${lm.get('Menu', 'Privacy Policy')}`;
        this._aboutMenuItem.label = `${lm.get('Menu', 'About')}`;
        let languageMenuData = new AMenuData(null, `${lm.get('Menu', 'Language')}`);
        let currentMenuDataItem = null;
        languageMenuData.label = lm.languageName;
        languageMenuData.items = lm.languageNames.map((name, index) => {
            let mdi = new AMenuDataItem(null, name, lm.languageIDs[index]);
            if (lm.languageID === mdi.data) {
                currentMenuDataItem = mdi;
            }
            return mdi;
        });
        this._languageMenuButton.data = languageMenuData;
        this._languageMenuButton.selectedItem = currentMenuDataItem;
        this._menuBar.invalidate(true);
        if (tm.isMobile) {
            this._mobileViewLabels = [];
            tm.UIConfig.MobileViews.forEach((view) => {
                this._mobileViewLabels.push(lm.get('MobileViews', view.LabelLanguageID));
            });
            this._mobileViewButtons.labels = this._mobileViewLabels;
        }
    }
    _onSettingsIconClicked() {
        TradingManager.instance.ShowSettingsDialog();
    }
    _onLanguageMenuButtonChanged() {
        ALanguageManager.instance.languageID = this._languageMenuButton.selectedItem.data;
    }
    _onTradingManagerReadyStateChanged() {
        let tm = TradingManager.instance;
        let strength = 1;
        let tooltip = '';
        if (tm.ReadyState.InstanceConfigReady) {
            if (!tm.ReadyState.PreviousInstanceConfigReady) {
                this._termsConditionsMenuItem.data = tm.UIConfig.TermsConditionsURI;
                this._privacyPolicyMenuItem.data = tm.UIConfig.PrivacyPolicyURI;
                this._aboutMenuItem.label = `About ${tm.UIConfig.OperatorName}`;
                this._aboutMenuItem.data = tm.UIConfig.AboutURI;
            }
            strength++;
            tooltip += 'API: Ready';
        }
        else {
            tooltip += 'API: Not Ready';
        }
        if (tm.ReadyState.MarketDataReady) {
            strength++;
            tooltip += '\nMarket Data: Ready';
        }
        else {
            tooltip += '\nMarket Data: Not Ready';
        }
        if (tm.ReadyState.AccountsReady) {
            this._accountMenuItem.label = tm.UserInfo.UserName || 'Account';
            this._accountMenuItem.items = [
                new AMenuDataItem(null, 'Settings', 'settings'),
                new AMenuDataDividerItem(),
                new AMenuDataItem(null, 'Reports', 'reports'),
                new AMenuDataDividerItem(),
                new AMenuDataItem(null, 'Sign Out', 'sign-out')
            ];
            this._settingsIcon.visible = true;
            strength++;
            tooltip += '\nAccounts: Ready';
        }
        else {
            this._settingsIcon.visible = false;
            tooltip += '\nAccounts: Not Ready';
        }
        if (strength > 1) {
            this._systemHealthIcon.visible = true;
            this._systemHealthIcon.value = ['fad', `fa-signal-alt${strength < 4 ? `-${strength}` : ''}`];
            this._systemHealthIcon.title = tooltip;
        }
        else {
            this._systemHealthIcon.visible = true;
        }
        this.invalidate();
    }
    _invalidateMobileView() {
        try {
            if (this._mobileViewClasses.length > 0) {
                this.removeClasses(...this._mobileViewClasses);
                if (TradingManager.instance.isMobile) {
                    this.addClass(this._mobileViewClasses[this._mobileViewButtons.selectedIndex]);
                }
            }
        }
        catch (error) {
        }
    }
    _onRenderManagerResize(event) {
        this._invalidateMobileView();
    }
    _onMobileViewButtonsChanged(event) {
        this._invalidateMobileView();
    }
    _toggleFullscreen() {
        let document = window.document;
        if (!document.fullscreenElement) {
            this.parentElement.requestFullscreen();
        }
        else {
            document.exitFullscreen();
        }
    }
    _onMenuItemMousedOver(event) {
        let tm = TradingManager.instance;
        let menuData = event.detail.menuData;
        let menuDataItem = event.detail.menuDataItem;
        if (menuData.label === 'Theme') {
            if (menuDataItem.data === 'theme') {
                tm.theme = menuDataItem.label;
            }
        }
        else if (menuData.label === 'Layout') {
            if (menuDataItem.data === 'layout') {
                tm.layout = menuDataItem.label;
            }
        }
    }
    _onMenuItemClicked(event) {
        let tm = TradingManager.instance;
        let menuData = event.detail.menuData;
        let menuDataItem = event.detail.menuDataItem;
        if (menuDataItem.data === 'authenticate') {
            TradingManager.instance.PromptAuthentication();
        }
        else if (menuDataItem.data === 'register') {
            TradingManager.instance.PromptRegistration();
        }
        else if (menuDataItem.data === 'settings') {
            TradingManager.instance.ShowSettingsDialog();
        }
        else if (menuDataItem.data === 'reports') {
            TradingManager.instance.ShowReportsDialog();
        }
        else if (menuDataItem.data === 'sign-out') {
            TradingManager.instance.Deauthenticate();
        }
        else if (menuData.label === 'View') {
            if (menuDataItem.data === 'fullscreen') {
                this._toggleFullscreen();
            }
        }
        else if (menuData.label === 'Theme') {
            if (menuDataItem.data === 'theme') {
                tm.theme = menuDataItem.label;
                this._themeMenuItem.items.forEach((dataItem) => {
                    dataItem.selected = dataItem.label === tm.theme;
                });
            }
        }
        else if (menuData.label === 'Layout') {
            if (menuDataItem.data === 'layout') {
                tm.layout = menuDataItem.label;
                this._layoutMenuItem.items.forEach((dataItem) => {
                    dataItem.selected = dataItem.label === tm.layout;
                });
            }
        }
        else if (menuData.label === 'Help') {
            window.open(menuDataItem.data);
        }
    }
    _onMenuClosed(event) {
        let tm = TradingManager.instance;
        this._themeMenuItem.items.forEach((dataItem) => {
            if (dataItem.selected) {
                tm.theme = dataItem.label;
            }
        });
        this._layoutMenuItem.items.forEach((dataItem) => {
            if (dataItem.selected) {
                tm.layout = dataItem.label;
            }
        });
    }
    _onContextMenuItemClicked(event) {
        if (event.detail.menuDataItem.data && event.detail.menuDataItem.data.call !== undefined) {
            event.detail.menuDataItem.data.call();
        }
        this.hideContextMenu();
    }
    _onDocumentMouseDown(event) {
        this.hideContextMenu();
    }
    _onThemeChanged(theme) {
    }
    _onLayoutChanged(layoutClass) {
        this._panelGrid.invalidateLayout();
    }
    showContextMenu(menuData, x, y) {
        this._contextMenu.data = menuData;
        this._contextMenu.visible = true;
        let menuX = Math.min(x, this.offsetWidth - this._contextMenu.offsetWidth);
        let menuY = Math.min(y, this.offsetWidth - this._contextMenu.offsetWidth);
        this._contextMenu.style.left = `${menuX}px`;
        this._contextMenu.style.top = `${menuY}px`;
    }
    hideContextMenu() {
        this._contextMenu.data = null;
        this._contextMenu.visible = false;
    }
}
window.customElements.define('a-trading', Trading);
