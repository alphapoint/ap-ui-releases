import { isInteger, isNumber } from '../helpers/strict-type-checks.js';
const formatterOptions = {
    decimalSign: '.',
    decimalSignFractional: '\'',
};
export function numberToStringWithLeadingZero(value, length) {
    if (!isNumber(value)) {
        return 'n/a';
    }
    if (!isInteger(length)) {
        throw new TypeError('invalid length');
    }
    if (length < 0 || length > 16) {
        throw new TypeError('invalid length');
    }
    if (length === 0) {
        return value.toString();
    }
    const dummyString = '0000000000000000';
    return (dummyString + value.toString()).slice(-length);
}
export class PriceFormatter {
    constructor(priceScale, minMove) {
        if (!minMove) {
            minMove = 1;
        }
        if (!isNumber(priceScale) || !isInteger(priceScale)) {
            priceScale = 100;
        }
        if (priceScale < 0) {
            throw new TypeError('invalid base');
        }
        this._priceScale = priceScale;
        this._minMove = minMove;
        this._calculateDecimal();
    }
    format(price) {
        const sign = price < 0 ? '\u2212' : '';
        price = Math.abs(price);
        return sign + this._formatAsDecimal(price);
    }
    _calculateDecimal() {
        this._fractionalLength = 0;
        if (this._priceScale > 0 && this._minMove > 0) {
            let base = this._priceScale;
            while (base > 1) {
                base /= 10;
                this._fractionalLength++;
            }
        }
    }
    _formatAsDecimal(price) {
        const base = this._priceScale / this._minMove;
        let intPart = Math.floor(price);
        let fracString = '';
        const fracLength = this._fractionalLength !== undefined ? this._fractionalLength : NaN;
        if (base > 1) {
            let fracPart = +(Math.round(price * base) - intPart * base).toFixed(this._fractionalLength);
            if (fracPart >= base) {
                fracPart -= base;
                intPart += 1;
            }
            fracString = formatterOptions.decimalSign + numberToStringWithLeadingZero(+fracPart.toFixed(this._fractionalLength) * this._minMove, fracLength);
        }
        else {
            intPart = Math.round(intPart * base) / base;
            if (fracLength > 0) {
                fracString = formatterOptions.decimalSign + numberToStringWithLeadingZero(0, fracLength);
            }
        }
        return intPart.toFixed(0) + fracString;
    }
}
