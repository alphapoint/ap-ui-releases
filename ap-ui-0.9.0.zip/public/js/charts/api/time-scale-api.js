import { assert } from '../helpers/assertions.js';
import { Delegate } from '../helpers/delegate.js';
import { clone } from '../helpers/strict-type-checks.js';
import { convertTime } from './data-layer.js';
export class TimeScaleApi {
    constructor(model) {
        this._timeRangeChanged = new Delegate();
        this._logicalRangeChanged = new Delegate();
        this._model = model;
        this._timeScale().visibleBarsChanged().subscribe(this._onVisibleBarsChanged.bind(this));
        this._timeScale().logicalRangeChanged().subscribe(this._onVisibleLogicalRangeChanged.bind(this));
    }
    destroy() {
        this._timeScale().visibleBarsChanged().unsubscribeAll(this);
        this._timeScale().logicalRangeChanged().unsubscribeAll(this);
        this._timeRangeChanged.destroy();
    }
    scrollPosition() {
        return this._timeScale().rightOffset();
    }
    scrollToPosition(position, animated) {
        if (!animated) {
            this._model.setRightOffset(position);
            return;
        }
        this._timeScale().scrollToOffsetAnimated(position, 1000);
    }
    scrollToRealTime() {
        this._timeScale().scrollToRealTime();
    }
    getVisibleRange() {
        const timeRange = this._timeScale().visibleTimeRange();
        if (timeRange === null) {
            return null;
        }
        return {
            from: timeRange.from.businessDay ?? timeRange.from.timestamp,
            to: timeRange.to.businessDay ?? timeRange.to.timestamp,
        };
    }
    setVisibleRange(range) {
        const convertedRange = {
            from: convertTime(range.from),
            to: convertTime(range.to),
        };
        const logicalRange = this._timeScale().logicalRangeForTimeRange(convertedRange);
        this._model.setTargetLogicalRange(logicalRange);
    }
    getVisibleLogicalRange() {
        const logicalRange = this._timeScale().visibleLogicalRange();
        if (logicalRange === null) {
            return null;
        }
        return {
            from: logicalRange.left(),
            to: logicalRange.right(),
        };
    }
    setVisibleLogicalRange(range) {
        assert(range.from <= range.to, 'The from index cannot be after the to index.');
        this._model.setTargetLogicalRange(range);
    }
    resetTimeScale() {
        this._model.resetTimeScale();
    }
    fitContent() {
        this._model.fitContent();
    }
    logicalToCoordinate(logical) {
        const timeScale = this._model.timeScale();
        if (timeScale.isEmpty()) {
            return null;
        }
        else {
            return timeScale.indexToCoordinate(logical);
        }
    }
    coordinateToLogical(x) {
        const timeScale = this._model.timeScale();
        if (timeScale.isEmpty()) {
            return null;
        }
        else {
            return timeScale.coordinateToIndex(x);
        }
    }
    timeToCoordinate(time) {
        const timePoint = convertTime(time);
        const timeScale = this._model.timeScale();
        const timePointIndex = timeScale.timeToIndex(timePoint, false);
        if (timePointIndex === null) {
            return null;
        }
        return timeScale.indexToCoordinate(timePointIndex);
    }
    coordinateToTime(x) {
        const timeScale = this._model.timeScale();
        const timePointIndex = timeScale.coordinateToIndex(x);
        const timePoint = timeScale.indexToTime(timePointIndex);
        if (timePoint === null) {
            return null;
        }
        return timePoint.businessDay ?? timePoint.timestamp;
    }
    subscribeVisibleTimeRangeChange(handler) {
        this._timeRangeChanged.subscribe(handler);
    }
    unsubscribeVisibleTimeRangeChange(handler) {
        this._timeRangeChanged.unsubscribe(handler);
    }
    subscribeVisibleLogicalRangeChange(handler) {
        this._logicalRangeChanged.subscribe(handler);
    }
    unsubscribeVisibleLogicalRangeChange(handler) {
        this._logicalRangeChanged.unsubscribe(handler);
    }
    applyOptions(options) {
        this._timeScale().applyOptions(options);
    }
    options() {
        return clone(this._timeScale().options());
    }
    _timeScale() {
        return this._model.timeScale();
    }
    _onVisibleBarsChanged() {
        if (this._timeRangeChanged.hasListeners()) {
            this._timeRangeChanged.fire(this.getVisibleRange());
        }
    }
    _onVisibleLogicalRangeChanged() {
        if (this._logicalRangeChanged.hasListeners()) {
            this._logicalRangeChanged.fire(this.getVisibleLogicalRange());
        }
    }
}
