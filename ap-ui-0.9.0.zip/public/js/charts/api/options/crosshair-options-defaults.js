export const crosshairOptionsDefaults = {
    vertLine: {
        color: '#758696',
        width: 1,
        style: 3,
        visible: true,
        labelVisible: true,
        labelBackgroundColor: '#4c525e',
    },
    horzLine: {
        color: '#758696',
        width: 1,
        style: 3,
        visible: true,
        labelVisible: true,
        labelBackgroundColor: '#4c525e',
    },
    mode: 1,
};
