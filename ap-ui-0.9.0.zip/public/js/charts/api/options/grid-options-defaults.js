export const gridOptionsDefaults = {
    vertLines: {
        color: '#D6DCDE',
        style: 0,
        visible: true,
    },
    horzLines: {
        color: '#D6DCDE',
        style: 0,
        visible: true,
    },
};
