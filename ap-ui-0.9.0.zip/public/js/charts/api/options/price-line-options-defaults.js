export const priceLineOptionsDefaults = {
    color: '#FF0000',
    price: 0,
    lineStyle: 2,
    lineWidth: 1,
    axisLabelVisible: true,
    title: '',
};
