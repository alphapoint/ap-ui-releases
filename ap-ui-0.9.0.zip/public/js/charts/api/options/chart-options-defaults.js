import { isRunningOnClientSide } from '../../helpers/is-running-on-client-side.js';
import { crosshairOptionsDefaults } from './crosshair-options-defaults.js';
import { gridOptionsDefaults } from './grid-options-defaults.js';
import { layoutOptionsDefaults } from './layout-options-defaults.js';
import { priceScaleOptionsDefaults } from './price-scale-options-defaults.js';
import { timeScaleOptionsDefaults } from './time-scale-options-defaults.js';
import { watermarkOptionsDefaults } from './watermark-options-defaults.js';
export const chartOptionsDefaults = {
    width: 0,
    height: 0,
    layout: layoutOptionsDefaults,
    crosshair: crosshairOptionsDefaults,
    grid: gridOptionsDefaults,
    overlayPriceScales: {
        ...priceScaleOptionsDefaults,
    },
    leftPriceScale: {
        ...priceScaleOptionsDefaults,
        visible: false,
    },
    rightPriceScale: {
        ...priceScaleOptionsDefaults,
        visible: true,
    },
    timeScale: timeScaleOptionsDefaults,
    watermark: watermarkOptionsDefaults,
    localization: {
        locale: isRunningOnClientSide ? navigator.language : '',
        dateFormat: 'dd MMM \'yy',
    },
    handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
    },
    handleScale: {
        axisPressedMouseMove: {
            time: true,
            price: true,
        },
        axisDoubleClickReset: true,
        mouseWheel: true,
        pinch: true,
    },
};
