import { ensureNotNull } from '../helpers/assertions.js';
import { clone, merge } from '../helpers/strict-type-checks.js';
import { RangeImpl } from '../model/range-impl.js';
import { TimeScaleVisibleRange } from '../model/time-scale-visible-range.js';
import { convertTime } from './data-layer.js';
import { checkItemsAreOrdered, checkPriceLineOptions, checkSeriesValuesType } from './data-validators.js';
import { priceLineOptionsDefaults } from './options/price-line-options-defaults.js';
import { PriceLine } from './price-line-api.js';
export function migrateOptions(options) {
    const { overlay, ...res } = options;
    if (overlay) {
        res.priceScaleId = '';
    }
    return res;
}
export class SeriesApi {
    constructor(series, dataUpdatesConsumer, priceScaleApiProvider) {
        this._series = series;
        this._dataUpdatesConsumer = dataUpdatesConsumer;
        this._priceScaleApiProvider = priceScaleApiProvider;
    }
    priceFormatter() {
        return this._series.formatter();
    }
    series() {
        return this._series;
    }
    priceToCoordinate(price) {
        const firstValue = this._series.firstValue();
        if (firstValue === null) {
            return null;
        }
        return this._series.priceScale().priceToCoordinate(price, firstValue.value);
    }
    coordinateToPrice(coordinate) {
        const firstValue = this._series.firstValue();
        if (firstValue === null) {
            return null;
        }
        return this._series.priceScale().coordinateToPrice(coordinate, firstValue.value);
    }
    barsInLogicalRange(range) {
        if (range === null) {
            return null;
        }
        const correctedRange = new TimeScaleVisibleRange(new RangeImpl(range.from, range.to)).strictRange();
        const bars = this._series.bars();
        if (bars.isEmpty()) {
            return null;
        }
        const dataFirstBarInRange = bars.search(correctedRange.left(), 1);
        const dataLastBarInRange = bars.search(correctedRange.right(), -1);
        const dataFirstIndex = ensureNotNull(bars.firstIndex());
        const dataLastIndex = ensureNotNull(bars.lastIndex());
        if (dataFirstBarInRange !== null && dataLastBarInRange !== null && dataFirstBarInRange.index > dataLastBarInRange.index) {
            return {
                barsBefore: range.from - dataFirstIndex,
                barsAfter: dataLastIndex - range.to,
            };
        }
        const barsBefore = (dataFirstBarInRange === null || dataFirstBarInRange.index === dataFirstIndex)
            ? range.from - dataFirstIndex
            : dataFirstBarInRange.index - dataFirstIndex;
        const barsAfter = (dataLastBarInRange === null || dataLastBarInRange.index === dataLastIndex)
            ? dataLastIndex - range.to
            : dataLastIndex - dataLastBarInRange.index;
        const result = { barsBefore, barsAfter };
        if (dataFirstBarInRange !== null && dataLastBarInRange !== null) {
            result.from = dataFirstBarInRange.time.businessDay || dataFirstBarInRange.time.timestamp;
            result.to = dataLastBarInRange.time.businessDay || dataLastBarInRange.time.timestamp;
        }
        return result;
    }
    setData(data) {
        checkItemsAreOrdered(data);
        checkSeriesValuesType(this._series.seriesType(), data);
        this._dataUpdatesConsumer.applyNewData(this._series, data);
    }
    update(bar) {
        checkSeriesValuesType(this._series.seriesType(), [bar]);
        this._dataUpdatesConsumer.updateData(this._series, bar);
    }
    setMarkers(data) {
        checkItemsAreOrdered(data, true);
        const convertedMarkers = data.map((marker) => ({
            ...marker,
            time: convertTime(marker.time),
        }));
        this._series.setMarkers(convertedMarkers);
    }
    applyOptions(options) {
        const migratedOptions = migrateOptions(options);
        this._series.applyOptions(migratedOptions);
    }
    options() {
        return clone(this._series.options());
    }
    priceScale() {
        return this._priceScaleApiProvider.priceScale(this._series.priceScale().id());
    }
    createPriceLine(options) {
        checkPriceLineOptions(options);
        const strictOptions = merge(clone(priceLineOptionsDefaults), options);
        const priceLine = this._series.createPriceLine(strictOptions);
        return new PriceLine(priceLine);
    }
    removePriceLine(line) {
        this._series.removePriceLine(line.priceLine());
    }
}
