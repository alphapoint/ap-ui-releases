import { assert } from '../helpers/assertions.js';
import { isString } from '../helpers/strict-type-checks.js';
import { ChartApi } from './chart-api.js';
export { isBusinessDay, isUTCTimestamp, } from './data-consumer.js';
export function createChart(container, options) {
    let htmlElement;
    if (isString(container)) {
        const element = document.getElementById(container);
        assert(element !== null, `Cannot find element in DOM with id=${container}`);
        htmlElement = element;
    }
    else {
        htmlElement = container;
    }
    return new ChartApi(htmlElement, options);
}
