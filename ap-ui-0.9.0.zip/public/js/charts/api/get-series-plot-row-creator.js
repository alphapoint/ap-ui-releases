import { isWhitespaceData } from './data-consumer.js';
function getLineBasedSeriesPlotRow(time, index, item) {
    const val = item.value;
    const res = { index, time, value: [val, val, val, val] };
    if ('color' in item && item.color !== undefined) {
        res.color = item.color;
    }
    return res;
}
function getOHLCBasedSeriesPlotRow(time, index, item) {
    return { index, time, value: [item.open, item.high, item.low, item.close] };
}
export function isSeriesPlotRow(row) {
    return row.value !== undefined;
}
function wrapWhitespaceData(createPlotRowFn) {
    return (time, index, bar) => {
        if (isWhitespaceData(bar)) {
            return { time, index };
        }
        return createPlotRowFn(time, index, bar);
    };
}
const seriesPlotRowFnMap = {
    Candlestick: wrapWhitespaceData(getOHLCBasedSeriesPlotRow),
    Bar: wrapWhitespaceData(getOHLCBasedSeriesPlotRow),
    Area: wrapWhitespaceData(getLineBasedSeriesPlotRow),
    Histogram: wrapWhitespaceData(getLineBasedSeriesPlotRow),
    Line: wrapWhitespaceData(getLineBasedSeriesPlotRow),
};
export function getSeriesPlotRowCreator(seriesType) {
    return seriesPlotRowFnMap[seriesType];
}
