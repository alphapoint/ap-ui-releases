import { ensureDefined, ensureNotNull } from '../helpers/assertions.js';
import { isString } from '../helpers/strict-type-checks.js';
import { isBusinessDay, isUTCTimestamp, } from './data-consumer.js';
import { getSeriesPlotRowCreator, isSeriesPlotRow } from './get-series-plot-row-creator.js';
import { fillWeightsForPoints } from './time-scale-point-weight-generator.js';
function businessDayConverter(time) {
    if (!isBusinessDay(time)) {
        throw new Error('time must be of type BusinessDay');
    }
    const date = new Date(Date.UTC(time.year, time.month - 1, time.day, 0, 0, 0, 0));
    return {
        timestamp: Math.round(date.getTime() / 1000),
        businessDay: time,
    };
}
function timestampConverter(time) {
    if (!isUTCTimestamp(time)) {
        throw new Error('time must be of type isUTCTimestamp');
    }
    return {
        timestamp: time,
    };
}
function selectTimeConverter(data) {
    if (data.length === 0) {
        return null;
    }
    if (isBusinessDay(data[0].time)) {
        return businessDayConverter;
    }
    return timestampConverter;
}
export function convertTime(time) {
    if (isUTCTimestamp(time)) {
        return timestampConverter(time);
    }
    if (!isBusinessDay(time)) {
        return businessDayConverter(stringToBusinessDay(time));
    }
    return businessDayConverter(time);
}
const validDateRegex = /^\d\d\d\d-\d\d-\d\d$/;
export function stringToBusinessDay(value) {
    const d = new Date(value);
    if (isNaN(d.getTime())) {
        throw new Error(`Invalid date string=${value}, expected format=yyyy-mm-dd`);
    }
    return {
        day: d.getUTCDate(),
        month: d.getUTCMonth() + 1,
        year: d.getUTCFullYear(),
    };
}
function convertStringToBusinessDay(value) {
    if (isString(value.time)) {
        value.time = stringToBusinessDay(value.time);
    }
}
function convertStringsToBusinessDays(data) {
    return data.forEach(convertStringToBusinessDay);
}
function createEmptyTimePointData(timePoint) {
    return { index: 0, mapping: new Map(), timePoint };
}
export class DataLayer {
    constructor() {
        this._pointDataByTimePoint = new Map();
        this._seriesRowsBySeries = new Map();
        this._seriesLastTimePoint = new Map();
        this._sortedTimePoints = [];
    }
    destroy() {
        this._pointDataByTimePoint.clear();
        this._seriesRowsBySeries.clear();
        this._seriesLastTimePoint.clear();
        this._sortedTimePoints = [];
    }
    setSeriesData(series, data) {
        if (this._seriesLastTimePoint.has(series)) {
            this._pointDataByTimePoint.forEach((pointData) => pointData.mapping.delete(series));
        }
        let seriesRows = [];
        if (data.length !== 0) {
            convertStringsToBusinessDays(data);
            const timeConverter = ensureNotNull(selectTimeConverter(data));
            const createPlotRow = getSeriesPlotRowCreator(series.seriesType());
            seriesRows = data.map((item) => {
                const time = timeConverter(item.time);
                let timePointData = this._pointDataByTimePoint.get(time.timestamp);
                if (timePointData === undefined) {
                    timePointData = createEmptyTimePointData(time);
                    this._pointDataByTimePoint.set(time.timestamp, timePointData);
                }
                const row = createPlotRow(time, timePointData.index, item);
                timePointData.mapping.set(series, row);
                return row;
            });
        }
        this._cleanupPointsData();
        this._setRowsToSeries(series, seriesRows);
        return this._syncIndexesAndApplyChanges(series);
    }
    removeSeries(series) {
        return this.setSeriesData(series, []);
    }
    updateSeriesData(series, data) {
        convertStringToBusinessDay(data);
        const time = ensureNotNull(selectTimeConverter([data]))(data.time);
        const lastSeriesTime = this._seriesLastTimePoint.get(series);
        if (lastSeriesTime !== undefined && time.timestamp < lastSeriesTime.timestamp) {
            throw new Error(`Cannot update oldest data, last time=${lastSeriesTime.timestamp}, new time=${time.timestamp}`);
        }
        let pointDataAtTime = this._pointDataByTimePoint.get(time.timestamp);
        const affectsTimeScale = pointDataAtTime === undefined;
        if (pointDataAtTime === undefined) {
            pointDataAtTime = createEmptyTimePointData(time);
            this._pointDataByTimePoint.set(time.timestamp, pointDataAtTime);
        }
        const createPlotRow = getSeriesPlotRowCreator(series.seriesType());
        const plotRow = createPlotRow(time, pointDataAtTime.index, data);
        pointDataAtTime.mapping.set(series, plotRow);
        const seriesChanges = this._updateLastSeriesRow(series, plotRow);
        if (!affectsTimeScale) {
            const seriesUpdate = new Map();
            if (seriesChanges !== null) {
                seriesUpdate.set(series, seriesChanges);
            }
            return {
                series: seriesUpdate,
                timeScale: {
                    baseIndex: this._getBaseIndex(),
                },
            };
        }
        return this._syncIndexesAndApplyChanges(series);
    }
    _updateLastSeriesRow(series, plotRow) {
        let seriesData = this._seriesRowsBySeries.get(series);
        if (seriesData === undefined) {
            seriesData = [];
            this._seriesRowsBySeries.set(series, seriesData);
        }
        const lastSeriesRow = seriesData.length !== 0 ? seriesData[seriesData.length - 1] : null;
        let result = null;
        if (lastSeriesRow === null || plotRow.time.timestamp > lastSeriesRow.time.timestamp) {
            if (isSeriesPlotRow(plotRow)) {
                seriesData.push(plotRow);
                result = {
                    fullUpdate: false,
                    data: [plotRow],
                };
            }
        }
        else {
            if (isSeriesPlotRow(plotRow)) {
                seriesData[seriesData.length - 1] = plotRow;
                result = {
                    fullUpdate: false,
                    data: [plotRow],
                };
            }
            else {
                seriesData.splice(-1, 1);
                result = {
                    fullUpdate: true,
                    data: seriesData,
                };
            }
        }
        this._seriesLastTimePoint.set(series, plotRow.time);
        return result;
    }
    _setRowsToSeries(series, seriesRows) {
        if (seriesRows.length !== 0) {
            this._seriesRowsBySeries.set(series, seriesRows.filter(isSeriesPlotRow));
            this._seriesLastTimePoint.set(series, seriesRows[seriesRows.length - 1].time);
        }
        else {
            this._seriesRowsBySeries.delete(series);
            this._seriesLastTimePoint.delete(series);
        }
    }
    _cleanupPointsData() {
        const newPointsData = new Map();
        this._pointDataByTimePoint.forEach((pointData, key) => {
            if (pointData.mapping.size > 0) {
                newPointsData.set(key, pointData);
            }
        });
        this._pointDataByTimePoint = newPointsData;
    }
    _updateTimeScalePoints(newTimePoints) {
        let firstChangedPointIndex = -1;
        for (let index = 0; index < this._sortedTimePoints.length && index < newTimePoints.length; ++index) {
            const oldPoint = this._sortedTimePoints[index];
            const newPoint = newTimePoints[index];
            if (oldPoint.time.timestamp !== newPoint.time.timestamp) {
                firstChangedPointIndex = index;
                break;
            }
            newPoint.timeWeight = oldPoint.timeWeight;
        }
        if (firstChangedPointIndex === -1 && this._sortedTimePoints.length !== newTimePoints.length) {
            firstChangedPointIndex = Math.min(this._sortedTimePoints.length, newTimePoints.length);
        }
        if (firstChangedPointIndex === -1) {
            return -1;
        }
        for (let index = firstChangedPointIndex; index < newTimePoints.length; ++index) {
            const pointData = ensureDefined(this._pointDataByTimePoint.get(newTimePoints[index].time.timestamp));
            pointData.index = index;
            pointData.mapping.forEach((seriesRow) => {
                seriesRow.index = index;
            });
        }
        fillWeightsForPoints(newTimePoints, firstChangedPointIndex);
        this._sortedTimePoints = newTimePoints;
        return firstChangedPointIndex;
    }
    _getBaseIndex() {
        let baseIndex = 0;
        this._seriesRowsBySeries.forEach((data) => {
            if (data.length !== 0) {
                baseIndex = Math.max(baseIndex, data[data.length - 1].index);
            }
        });
        return baseIndex;
    }
    _syncIndexesAndApplyChanges(series) {
        const newTimeScalePoints = Array.from(this._pointDataByTimePoint.values()).map((d) => ({ timeWeight: 0, time: d.timePoint }));
        newTimeScalePoints.sort((t1, t2) => t1.time.timestamp - t2.time.timestamp);
        const firstChangedPointIndex = this._updateTimeScalePoints(newTimeScalePoints);
        const dataUpdateResponse = {
            series: new Map(),
            timeScale: {
                baseIndex: this._getBaseIndex(),
            },
        };
        if (firstChangedPointIndex !== -1) {
            this._seriesRowsBySeries.forEach((data, s) => {
                dataUpdateResponse.series.set(s, { data, fullUpdate: true });
            });
            dataUpdateResponse.timeScale.points = this._sortedTimePoints;
        }
        else {
            const seriesData = this._seriesRowsBySeries.get(series);
            dataUpdateResponse.series.set(series, { data: seriesData || [], fullUpdate: true });
        }
        return dataUpdateResponse;
    }
}
