import { assert, ensureNever } from '../helpers/assertions.js';
import { isFulfilledData } from './data-consumer.js';
import { convertTime } from './data-layer.js';
export function checkPriceLineOptions(options) {
    assert(typeof options.price === 'number', `the type of 'price' price line's property must be a number, got '${typeof options.price}'`);
}
export function checkItemsAreOrdered(data, allowDuplicates = false) {
    if (data.length === 0) {
        return;
    }
    let prevTime = convertTime(data[0].time).timestamp;
    for (let i = 1; i < data.length; ++i) {
        const currentTime = convertTime(data[i].time).timestamp;
        const checkResult = allowDuplicates ? prevTime <= currentTime : prevTime < currentTime;
        assert(checkResult, `data must be asc ordered by time, index=${i}, time=${currentTime}, prev time=${prevTime}`);
        prevTime = currentTime;
    }
}
export function checkSeriesValuesType(type, data) {
    data.forEach(getChecker(type));
}
function getChecker(type) {
    switch (type) {
        case 'Bar':
        case 'Candlestick':
            return checkBarItem.bind(null, type);
        case 'Area':
        case 'Line':
        case 'Histogram':
            return checkLineItem.bind(null, type);
        default:
            ensureNever(type);
            throw new Error(`unsupported series type ${type}`);
    }
}
function checkBarItem(type, barItem) {
    if (!isFulfilledData(barItem)) {
        return;
    }
    assert(typeof barItem.open === 'number', `${type} series item data value of open must be a number, got=${typeof barItem.open}, value=${barItem.open}`);
    assert(typeof barItem.high === 'number', `${type} series item data value of high must be a number, got=${typeof barItem.high}, value=${barItem.high}`);
    assert(typeof barItem.low === 'number', `${type} series item data value of low must be a number, got=${typeof barItem.low}, value=${barItem.low}`);
    assert(typeof barItem.close === 'number', `${type} series item data value of close must be a number, got=${typeof barItem.close}, value=${barItem.close}`);
}
function checkLineItem(type, lineItem) {
    if (!isFulfilledData(lineItem)) {
        return;
    }
    assert(typeof lineItem.value === 'number', `${type} series item data value must be a number, got=${typeof lineItem.value}, value=${lineItem.value}`);
}
