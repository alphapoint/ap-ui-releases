import { log10 } from '../helpers/mathex.js';
import { PriceRangeImpl } from './price-range-impl.js';
export function fromPercent(value, baseValue) {
    if (baseValue < 0) {
        value = -value;
    }
    return (value / 100) * baseValue + baseValue;
}
export function toPercent(value, baseValue) {
    const result = 100 * (value - baseValue) / baseValue;
    return (baseValue < 0 ? -result : result);
}
export function toPercentRange(priceRange, baseValue) {
    const minPercent = toPercent(priceRange.minValue(), baseValue);
    const maxPercent = toPercent(priceRange.maxValue(), baseValue);
    return new PriceRangeImpl(minPercent, maxPercent);
}
export function fromIndexedTo100(value, baseValue) {
    value -= 100;
    if (baseValue < 0) {
        value = -value;
    }
    return (value / 100) * baseValue + baseValue;
}
export function toIndexedTo100(value, baseValue) {
    const result = 100 * (value - baseValue) / baseValue + 100;
    return (baseValue < 0 ? -result : result);
}
export function toIndexedTo100Range(priceRange, baseValue) {
    const minPercent = toIndexedTo100(priceRange.minValue(), baseValue);
    const maxPercent = toIndexedTo100(priceRange.maxValue(), baseValue);
    return new PriceRangeImpl(minPercent, maxPercent);
}
export function toLog(price) {
    const m = Math.abs(price);
    if (m < 1e-8) {
        return 0;
    }
    const res = log10(m + 0.0001) + 4;
    return ((price < 0) ? -res : res);
}
export function fromLog(logical) {
    const m = Math.abs(logical);
    if (m < 1e-8) {
        return 0;
    }
    const res = Math.pow(10, m - 4) - 0.0001;
    return (logical < 0) ? -res : res;
}
export function convertPriceRangeToLog(priceRange) {
    if (priceRange === null) {
        return null;
    }
    const min = toLog(priceRange.minValue());
    const max = toLog(priceRange.maxValue());
    return new PriceRangeImpl(min, max);
}
export function canConvertPriceRangeFromLog(priceRange) {
    if (priceRange === null) {
        return false;
    }
    const min = fromLog(priceRange.minValue());
    const max = fromLog(priceRange.maxValue());
    return isFinite(min) && isFinite(max);
}
export function convertPriceRangeFromLog(priceRange) {
    if (priceRange === null) {
        return null;
    }
    const min = fromLog(priceRange.minValue());
    const max = fromLog(priceRange.maxValue());
    return new PriceRangeImpl(min, max);
}
