const defaultReplacementRe = /[2-9]/g;
export class TextWidthCache {
    constructor(size = 50) {
        this._cache = new Map();
        this._keysIndex = 0;
        this._keys = Array.from(new Array(size));
    }
    reset() {
        this._cache.clear();
        this._keys.fill(undefined);
    }
    measureText(ctx, text, optimizationReplacementRe) {
        const re = optimizationReplacementRe || defaultReplacementRe;
        const cacheString = String(text).replace(re, '0');
        let width = this._cache.get(cacheString);
        if (width === undefined) {
            width = ctx.measureText(cacheString).width;
            if (width === 0 && text.length !== 0) {
                return 0;
            }
            const oldestKey = this._keys[this._keysIndex];
            if (oldestKey !== undefined) {
                this._cache.delete(oldestKey);
            }
            this._keys[this._keysIndex] = cacheString;
            this._keysIndex = (this._keysIndex + 1) % this._keys.length;
            this._cache.set(cacheString, width);
        }
        return width;
    }
}
