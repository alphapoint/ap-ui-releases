import { lowerbound, upperbound } from '../helpers/algorithms.js';
import { assert, ensureNotNull } from '../helpers/assertions.js';
const CHUNK_SIZE = 30;
export class PlotList {
    constructor() {
        this._items = [];
        this._minMaxCache = new Map();
        this._rowSearchCache = new Map();
    }
    clear() {
        this._items = [];
        this._minMaxCache.clear();
        this._rowSearchCache.clear();
    }
    last() {
        return this.size() > 0 ? this._items[this._items.length - 1] : null;
    }
    firstIndex() {
        return this.size() > 0 ? this._indexAt(0) : null;
    }
    lastIndex() {
        return this.size() > 0 ? this._indexAt((this._items.length - 1)) : null;
    }
    size() {
        return this._items.length;
    }
    isEmpty() {
        return this.size() === 0;
    }
    contains(index) {
        return this._search(index, 0) !== null;
    }
    valueAt(index) {
        return this.search(index);
    }
    search(index, searchMode = 0) {
        const pos = this._search(index, searchMode);
        if (pos === null) {
            return null;
        }
        return {
            ...this._valueAt(pos),
            index: this._indexAt(pos),
        };
    }
    rows() {
        return this._items;
    }
    minMaxOnRangeCached(start, end, plots) {
        if (this.isEmpty()) {
            return null;
        }
        let result = null;
        for (const plot of plots) {
            const plotMinMax = this._minMaxOnRangeCachedImpl(start, end, plot);
            result = mergeMinMax(result, plotMinMax);
        }
        return result;
    }
    merge(plotRows) {
        if (plotRows.length === 0) {
            return;
        }
        if (this.isEmpty() || plotRows[plotRows.length - 1].index < this._items[0].index) {
            this._prepend(plotRows);
            return;
        }
        if (plotRows[0].index > this._items[this._items.length - 1].index) {
            this._append(plotRows);
            return;
        }
        if (plotRows.length === 1 && plotRows[0].index === this._items[this._items.length - 1].index) {
            this._updateLast(plotRows[0]);
            return;
        }
        this._merge(plotRows);
    }
    _indexAt(offset) {
        return this._items[offset].index;
    }
    _valueAt(offset) {
        return this._items[offset];
    }
    _search(index, searchMode) {
        const exactPos = this._bsearch(index);
        if (exactPos === null && searchMode !== 0) {
            switch (searchMode) {
                case -1:
                    return this._searchNearestLeft(index);
                case 1:
                    return this._searchNearestRight(index);
                default:
                    throw new TypeError('Unknown search mode');
            }
        }
        return exactPos;
    }
    _searchNearestLeft(index) {
        let nearestLeftPos = this._lowerbound(index);
        if (nearestLeftPos > 0) {
            nearestLeftPos = nearestLeftPos - 1;
        }
        return (nearestLeftPos !== this._items.length && this._indexAt(nearestLeftPos) < index) ? nearestLeftPos : null;
    }
    _searchNearestRight(index) {
        const nearestRightPos = this._upperbound(index);
        return (nearestRightPos !== this._items.length && index < this._indexAt(nearestRightPos)) ? nearestRightPos : null;
    }
    _bsearch(index) {
        const start = this._lowerbound(index);
        if (start !== this._items.length && !(index < this._items[start].index)) {
            return start;
        }
        return null;
    }
    _lowerbound(index) {
        return lowerbound(this._items, index, (a, b) => a.index < b);
    }
    _upperbound(index) {
        return upperbound(this._items, index, (a, b) => b.index > a);
    }
    _plotMinMax(startIndex, endIndex, plotIndex) {
        let result = null;
        for (let i = startIndex; i < endIndex; i++) {
            const values = this._items[i].value;
            const v = values[plotIndex];
            if (Number.isNaN(v)) {
                continue;
            }
            if (result === null) {
                result = { min: v, max: v };
            }
            else {
                if (v < result.min) {
                    result.min = v;
                }
                if (v > result.max) {
                    result.max = v;
                }
            }
        }
        return result;
    }
    _invalidateCacheForRow(row) {
        const chunkIndex = Math.floor(row.index / CHUNK_SIZE);
        this._minMaxCache.forEach((cacheItem) => cacheItem.delete(chunkIndex));
    }
    _prepend(plotRows) {
        assert(plotRows.length !== 0, 'plotRows should not be empty');
        this._rowSearchCache.clear();
        this._minMaxCache.clear();
        this._items = plotRows.concat(this._items);
    }
    _append(plotRows) {
        assert(plotRows.length !== 0, 'plotRows should not be empty');
        this._rowSearchCache.clear();
        this._minMaxCache.clear();
        this._items = this._items.concat(plotRows);
    }
    _updateLast(plotRow) {
        assert(!this.isEmpty(), 'plot list should not be empty');
        const currentLastRow = this._items[this._items.length - 1];
        assert(currentLastRow.index === plotRow.index, 'last row index should match new row index');
        this._invalidateCacheForRow(plotRow);
        this._rowSearchCache.delete(plotRow.index);
        this._items[this._items.length - 1] = plotRow;
    }
    _merge(plotRows) {
        assert(plotRows.length !== 0, 'plot rows should not be empty');
        this._rowSearchCache.clear();
        this._minMaxCache.clear();
        this._items = mergePlotRows(this._items, plotRows);
    }
    _minMaxOnRangeCachedImpl(start, end, plotIndex) {
        if (this.isEmpty()) {
            return null;
        }
        let result = null;
        const firstIndex = ensureNotNull(this.firstIndex());
        const lastIndex = ensureNotNull(this.lastIndex());
        const s = Math.max(start, firstIndex);
        const e = Math.min(end, lastIndex);
        const cachedLow = Math.ceil(s / CHUNK_SIZE) * CHUNK_SIZE;
        const cachedHigh = Math.max(cachedLow, Math.floor(e / CHUNK_SIZE) * CHUNK_SIZE);
        {
            const startIndex = this._lowerbound(s);
            const endIndex = this._upperbound(Math.min(e, cachedLow, end));
            const plotMinMax = this._plotMinMax(startIndex, endIndex, plotIndex);
            result = mergeMinMax(result, plotMinMax);
        }
        let minMaxCache = this._minMaxCache.get(plotIndex);
        if (minMaxCache === undefined) {
            minMaxCache = new Map();
            this._minMaxCache.set(plotIndex, minMaxCache);
        }
        for (let c = Math.max(cachedLow + 1, s); c < cachedHigh; c += CHUNK_SIZE) {
            const chunkIndex = Math.floor(c / CHUNK_SIZE);
            let chunkMinMax = minMaxCache.get(chunkIndex);
            if (chunkMinMax === undefined) {
                const chunkStart = this._lowerbound(chunkIndex * CHUNK_SIZE);
                const chunkEnd = this._upperbound((chunkIndex + 1) * CHUNK_SIZE - 1);
                chunkMinMax = this._plotMinMax(chunkStart, chunkEnd, plotIndex);
                minMaxCache.set(chunkIndex, chunkMinMax);
            }
            result = mergeMinMax(result, chunkMinMax);
        }
        {
            const startIndex = this._lowerbound(cachedHigh);
            const endIndex = this._upperbound(e);
            const plotMinMax = this._plotMinMax(startIndex, endIndex, plotIndex);
            result = mergeMinMax(result, plotMinMax);
        }
        return result;
    }
}
function mergeMinMax(first, second) {
    if (first === null) {
        return second;
    }
    else {
        if (second === null) {
            return first;
        }
        else {
            const min = Math.min(first.min, second.min);
            const max = Math.max(first.max, second.max);
            return { min: min, max: max };
        }
    }
}
export function mergePlotRows(originalPlotRows, newPlotRows) {
    const newArraySize = calcMergedArraySize(originalPlotRows, newPlotRows);
    const result = new Array(newArraySize);
    let originalRowsIndex = 0;
    let newRowsIndex = 0;
    const originalRowsSize = originalPlotRows.length;
    const newRowsSize = newPlotRows.length;
    let resultRowsIndex = 0;
    while (originalRowsIndex < originalRowsSize && newRowsIndex < newRowsSize) {
        if (originalPlotRows[originalRowsIndex].index < newPlotRows[newRowsIndex].index) {
            result[resultRowsIndex] = originalPlotRows[originalRowsIndex];
            originalRowsIndex++;
        }
        else if (originalPlotRows[originalRowsIndex].index > newPlotRows[newRowsIndex].index) {
            result[resultRowsIndex] = newPlotRows[newRowsIndex];
            newRowsIndex++;
        }
        else {
            result[resultRowsIndex] = newPlotRows[newRowsIndex];
            originalRowsIndex++;
            newRowsIndex++;
        }
        resultRowsIndex++;
    }
    while (originalRowsIndex < originalRowsSize) {
        result[resultRowsIndex] = originalPlotRows[originalRowsIndex];
        originalRowsIndex++;
        resultRowsIndex++;
    }
    while (newRowsIndex < newRowsSize) {
        result[resultRowsIndex] = newPlotRows[newRowsIndex];
        newRowsIndex++;
        resultRowsIndex++;
    }
    return result;
}
function calcMergedArraySize(firstPlotRows, secondPlotRows) {
    const firstPlotsSize = firstPlotRows.length;
    const secondPlotsSize = secondPlotRows.length;
    let result = firstPlotsSize + secondPlotsSize;
    let firstIndex = 0;
    let secondIndex = 0;
    while (firstIndex < firstPlotsSize && secondIndex < secondPlotsSize) {
        if (firstPlotRows[firstIndex].index < secondPlotRows[secondIndex].index) {
            firstIndex++;
        }
        else if (firstPlotRows[firstIndex].index > secondPlotRows[secondIndex].index) {
            secondIndex++;
        }
        else {
            firstIndex++;
            secondIndex++;
            result--;
        }
    }
    return result;
}
