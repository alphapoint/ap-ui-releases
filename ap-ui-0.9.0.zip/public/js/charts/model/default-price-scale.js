export function isDefaultPriceScale(priceScaleId) {
    return priceScaleId === "left" || priceScaleId === "right";
}
