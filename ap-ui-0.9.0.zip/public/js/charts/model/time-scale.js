import { DateFormatter } from '../formatters/date-formatter.js';
import { DateTimeFormatter } from '../formatters/date-time-formatter.js';
import { ensureNotNull } from '../helpers/assertions.js';
import { Delegate } from '../helpers/delegate.js';
import { clamp } from '../helpers/mathex.js';
import { isInteger, merge } from '../helpers/strict-type-checks.js';
import { defaultTickMarkFormatter } from './default-tick-mark-formatter.js';
import { FormattedLabelsCache } from './formatted-labels-cache.js';
import { areRangesEqual, RangeImpl } from './range-impl.js';
import { TickMarks } from './tick-marks.js';
import { TimeScaleVisibleRange } from './time-scale-visible-range.js';
export class TimeScale {
    constructor(model, options, localizationOptions) {
        this._width = 0;
        this._baseIndexOrNull = null;
        this._points = [];
        this._scrollStartPoint = null;
        this._scaleStartPoint = null;
        this._tickMarks = new TickMarks();
        this._formattedByWeight = new Map();
        this._visibleRange = TimeScaleVisibleRange.invalid();
        this._visibleRangeInvalidated = true;
        this._visibleBarsChanged = new Delegate();
        this._logicalRangeChanged = new Delegate();
        this._optionsApplied = new Delegate();
        this._commonTransitionStartState = null;
        this._timeMarksCache = null;
        this._labels = [];
        this._options = options;
        this._localizationOptions = localizationOptions;
        this._rightOffset = options.rightOffset;
        this._barSpacing = options.barSpacing;
        this._model = model;
        this._updateDateTimeFormatter();
    }
    options() {
        return this._options;
    }
    applyLocalizationOptions(localizationOptions) {
        merge(this._localizationOptions, localizationOptions);
        this._invalidateTickMarks();
        this._updateDateTimeFormatter();
    }
    applyOptions(options, localizationOptions) {
        merge(this._options, options);
        if (this._options.fixLeftEdge) {
            this._doFixLeftEdge();
        }
        if (options.barSpacing !== undefined) {
            this._model.setBarSpacing(options.barSpacing);
        }
        if (options.rightOffset !== undefined) {
            this._model.setRightOffset(options.rightOffset);
        }
        this._invalidateTickMarks();
        this._updateDateTimeFormatter();
        this._optionsApplied.fire();
    }
    indexToTime(index) {
        return this._points[index]?.time || null;
    }
    timeToIndex(time, findNearest) {
        if (this._points.length < 1) {
            return null;
        }
        if (time.timestamp > this._points[this._points.length - 1].time.timestamp) {
            return findNearest ? this._points.length - 1 : null;
        }
        for (let i = 0; i < this._points.length; ++i) {
            if (time.timestamp === this._points[i].time.timestamp) {
                return i;
            }
            if (time.timestamp < this._points[i].time.timestamp) {
                return findNearest ? i : null;
            }
        }
        return null;
    }
    isEmpty() {
        return this._width === 0 || this._points.length === 0;
    }
    visibleStrictRange() {
        this._updateVisibleRange();
        return this._visibleRange.strictRange();
    }
    visibleLogicalRange() {
        this._updateVisibleRange();
        return this._visibleRange.logicalRange();
    }
    visibleTimeRange() {
        const visibleBars = this.visibleStrictRange();
        if (visibleBars === null) {
            return null;
        }
        const range = {
            from: visibleBars.left(),
            to: visibleBars.right(),
        };
        return this.timeRangeForLogicalRange(range);
    }
    timeRangeForLogicalRange(range) {
        const from = Math.round(range.from);
        const to = Math.round(range.to);
        const firstIndex = ensureNotNull(this._firstIndex());
        const lastIndex = ensureNotNull(this._lastIndex());
        return {
            from: ensureNotNull(this.indexToTime(Math.max(firstIndex, from))),
            to: ensureNotNull(this.indexToTime(Math.min(lastIndex, to))),
        };
    }
    logicalRangeForTimeRange(range) {
        const timeScale = this._model.timeScale();
        return {
            from: ensureNotNull(timeScale.timeToIndex(range.from, true)),
            to: ensureNotNull(timeScale.timeToIndex(range.to, true)),
        };
    }
    tickMarks() {
        return this._tickMarks;
    }
    width() {
        return this._width;
    }
    setWidth(width) {
        if (!isFinite(width) || width <= 0) {
            return;
        }
        if (this._width === width) {
            return;
        }
        if (this._options.lockVisibleTimeRangeOnResize && this._width) {
            const newBarSpacing = this._barSpacing * width / this._width;
            this._setBarSpacing(newBarSpacing);
        }
        if (this._options.fixLeftEdge) {
            const visibleRange = this.visibleStrictRange();
            if (visibleRange !== null) {
                const firstVisibleBar = visibleRange.left();
                if (firstVisibleBar <= 0) {
                    const delta = this._width - width;
                    this._rightOffset -= Math.round(delta / this._barSpacing) + 1;
                }
            }
        }
        this._width = width;
        this._visibleRangeInvalidated = true;
        this._correctBarSpacing();
        this._correctOffset();
    }
    indexToCoordinate(index) {
        if (this.isEmpty() || !isInteger(index)) {
            return 0;
        }
        const baseIndex = this.baseIndex();
        const deltaFromRight = baseIndex + this._rightOffset - index;
        const coordinate = this._width - (deltaFromRight + 0.5) * this._barSpacing;
        return coordinate;
    }
    indexesToCoordinates(points, visibleRange) {
        const baseIndex = this.baseIndex();
        const indexFrom = (visibleRange === undefined) ? 0 : visibleRange.from;
        const indexTo = (visibleRange === undefined) ? points.length : visibleRange.to;
        for (let i = indexFrom; i < indexTo; i++) {
            const index = points[i].time;
            const deltaFromRight = baseIndex + this._rightOffset - index;
            const coordinate = this._width - (deltaFromRight + 0.5) * this._barSpacing;
            points[i].x = coordinate;
        }
    }
    coordinateToIndex(x) {
        return Math.ceil(this._coordinateToFloatIndex(x));
    }
    setRightOffset(offset) {
        this._visibleRangeInvalidated = true;
        this._rightOffset = offset;
        this._correctOffset();
        this._model.recalculateAllPanes();
        this._model.lightUpdate();
    }
    barSpacing() {
        return this._barSpacing;
    }
    setBarSpacing(newBarSpacing) {
        this._setBarSpacing(newBarSpacing);
        this._correctOffset();
        this._model.recalculateAllPanes();
        this._model.lightUpdate();
    }
    rightOffset() {
        return this._rightOffset;
    }
    marks() {
        if (this.isEmpty()) {
            return null;
        }
        if (this._timeMarksCache !== null) {
            return this._timeMarksCache;
        }
        const spacing = this._barSpacing;
        const fontSize = this._model.options().layout.fontSize;
        const maxLabelWidth = (fontSize + 4) * 5;
        const indexPerLabel = Math.round(maxLabelWidth / spacing);
        const visibleBars = ensureNotNull(this.visibleStrictRange());
        const firstBar = Math.max(visibleBars.left(), visibleBars.left() - indexPerLabel);
        const lastBar = Math.max(visibleBars.right(), visibleBars.right() - indexPerLabel);
        const items = this._tickMarks.build(spacing, maxLabelWidth);
        let targetIndex = 0;
        for (const tm of items) {
            if (!(firstBar <= tm.index && tm.index <= lastBar)) {
                continue;
            }
            const time = this.indexToTime(tm.index);
            if (time === null) {
                continue;
            }
            if (targetIndex < this._labels.length) {
                const label = this._labels[targetIndex];
                label.coord = this.indexToCoordinate(tm.index);
                label.label = this._formatLabel(time, tm.weight);
                label.weight = tm.weight;
            }
            else {
                this._labels.push({
                    coord: this.indexToCoordinate(tm.index),
                    label: this._formatLabel(time, tm.weight),
                    weight: tm.weight,
                });
            }
            targetIndex++;
        }
        this._labels.length = targetIndex;
        this._timeMarksCache = this._labels;
        return this._labels;
    }
    restoreDefault() {
        this._visibleRangeInvalidated = true;
        this.setBarSpacing(this._options.barSpacing);
        this.setRightOffset(this._options.rightOffset);
    }
    setBaseIndex(baseIndex) {
        this._visibleRangeInvalidated = true;
        this._baseIndexOrNull = baseIndex;
        this._correctOffset();
        this._doFixLeftEdge();
    }
    zoom(zoomPoint, scale) {
        const floatIndexAtZoomPoint = this._coordinateToFloatIndex(zoomPoint);
        const barSpacing = this.barSpacing();
        const newBarSpacing = barSpacing + scale * (barSpacing / 10);
        this.setBarSpacing(newBarSpacing);
        if (!this._options.rightBarStaysOnScroll) {
            this.setRightOffset(this.rightOffset() + (floatIndexAtZoomPoint - this._coordinateToFloatIndex(zoomPoint)));
        }
    }
    startScale(x) {
        if (this._scrollStartPoint) {
            this.endScroll();
        }
        if (this._scaleStartPoint !== null || this._commonTransitionStartState !== null) {
            return;
        }
        if (this.isEmpty()) {
            return;
        }
        this._scaleStartPoint = x;
        this._saveCommonTransitionsStartState();
    }
    scaleTo(x) {
        if (this._commonTransitionStartState === null) {
            return;
        }
        const startLengthFromRight = clamp(this._width - x, 0, this._width);
        const currentLengthFromRight = clamp(this._width - ensureNotNull(this._scaleStartPoint), 0, this._width);
        if (startLengthFromRight === 0 || currentLengthFromRight === 0) {
            return;
        }
        this.setBarSpacing(this._commonTransitionStartState.barSpacing * startLengthFromRight / currentLengthFromRight);
    }
    endScale() {
        if (this._scaleStartPoint === null) {
            return;
        }
        this._scaleStartPoint = null;
        this._clearCommonTransitionsStartState();
    }
    startScroll(x) {
        if (this._scrollStartPoint !== null || this._commonTransitionStartState !== null) {
            return;
        }
        if (this.isEmpty()) {
            return;
        }
        this._scrollStartPoint = x;
        this._saveCommonTransitionsStartState();
    }
    scrollTo(x) {
        if (this._scrollStartPoint === null) {
            return;
        }
        const shiftInLogical = (this._scrollStartPoint - x) / this.barSpacing();
        this._rightOffset = ensureNotNull(this._commonTransitionStartState).rightOffset + shiftInLogical;
        this._visibleRangeInvalidated = true;
        this._correctOffset();
    }
    endScroll() {
        if (this._scrollStartPoint === null) {
            return;
        }
        this._scrollStartPoint = null;
        this._clearCommonTransitionsStartState();
    }
    scrollToRealTime() {
        this.scrollToOffsetAnimated(this._options.rightOffset);
    }
    scrollToOffsetAnimated(offset, animationDuration = 400) {
        if (!isFinite(offset)) {
            throw new RangeError('offset is required and must be finite number');
        }
        if (!isFinite(animationDuration) || animationDuration <= 0) {
            throw new RangeError('animationDuration (optional) must be finite positive number');
        }
        const source = this._rightOffset;
        const animationStart = new Date().getTime();
        const animationFn = () => {
            const animationProgress = (new Date().getTime() - animationStart) / animationDuration;
            const finishAnimation = animationProgress >= 1;
            const rightOffset = finishAnimation ? offset : source + (offset - source) * animationProgress;
            this.setRightOffset(rightOffset);
            if (!finishAnimation) {
                setTimeout(animationFn, 20);
            }
        };
        animationFn();
    }
    update(newPoints) {
        this._visibleRangeInvalidated = true;
        this._points = newPoints;
        this._tickMarks.setTimeScalePoints(newPoints);
        this._correctOffset();
    }
    visibleBarsChanged() {
        return this._visibleBarsChanged;
    }
    logicalRangeChanged() {
        return this._logicalRangeChanged;
    }
    optionsApplied() {
        return this._optionsApplied;
    }
    baseIndex() {
        return this._baseIndexOrNull || 0;
    }
    setVisibleRange(range) {
        const length = range.count();
        this._setBarSpacing(this._width / length);
        this._rightOffset = range.right() - this.baseIndex();
        this._correctOffset();
        this._visibleRangeInvalidated = true;
        this._model.recalculateAllPanes();
        this._model.lightUpdate();
    }
    fitContent() {
        const first = this._firstIndex();
        const last = this._lastIndex();
        if (first === null || last === null) {
            return;
        }
        this.setVisibleRange(new RangeImpl(first, last + this._options.rightOffset));
    }
    setLogicalRange(range) {
        const barRange = new RangeImpl(range.from, range.to);
        this.setVisibleRange(barRange);
    }
    formatDateTime(time) {
        if (this._localizationOptions.timeFormatter !== undefined) {
            return this._localizationOptions.timeFormatter(time.businessDay || time.timestamp);
        }
        return this._dateTimeFormatter.format(new Date(time.timestamp * 1000));
    }
    _firstIndex() {
        return this._points.length === 0 ? null : 0;
    }
    _lastIndex() {
        return this._points.length === 0 ? null : (this._points.length - 1);
    }
    _rightOffsetForCoordinate(x) {
        return (this._width + 1 - x) / this._barSpacing;
    }
    _coordinateToFloatIndex(x) {
        const deltaFromRight = this._rightOffsetForCoordinate(x);
        const baseIndex = this.baseIndex();
        const index = baseIndex + this._rightOffset - deltaFromRight;
        return Math.round(index * 1000000) / 1000000;
    }
    _setBarSpacing(newBarSpacing) {
        const oldBarSpacing = this._barSpacing;
        this._barSpacing = newBarSpacing;
        this._correctBarSpacing();
        if (oldBarSpacing !== this._barSpacing) {
            this._visibleRangeInvalidated = true;
            this._resetTimeMarksCache();
        }
    }
    _updateVisibleRange() {
        if (!this._visibleRangeInvalidated) {
            return;
        }
        this._visibleRangeInvalidated = false;
        if (this.isEmpty()) {
            this._setVisibleRange(TimeScaleVisibleRange.invalid());
            return;
        }
        const baseIndex = this.baseIndex();
        const newBarsLength = this._width / this._barSpacing;
        const rightBorder = this._rightOffset + baseIndex;
        const leftBorder = rightBorder - newBarsLength + 1;
        const logicalRange = new RangeImpl(leftBorder, rightBorder);
        this._setVisibleRange(new TimeScaleVisibleRange(logicalRange));
    }
    _correctBarSpacing() {
        if (this._barSpacing < 0.5) {
            this._barSpacing = 0.5;
            this._visibleRangeInvalidated = true;
        }
        if (this._width !== 0) {
            const maxBarSpacing = this._width * 0.5;
            if (this._barSpacing > maxBarSpacing) {
                this._barSpacing = maxBarSpacing;
                this._visibleRangeInvalidated = true;
            }
        }
    }
    _correctOffset() {
        const maxRightOffset = this._maxRightOffset();
        if (this._rightOffset > maxRightOffset) {
            this._rightOffset = maxRightOffset;
            this._visibleRangeInvalidated = true;
        }
        const minRightOffset = this._minRightOffset();
        if (minRightOffset !== null && this._rightOffset < minRightOffset) {
            this._rightOffset = minRightOffset;
            this._visibleRangeInvalidated = true;
        }
    }
    _minRightOffset() {
        const firstIndex = this._firstIndex();
        const baseIndex = this._baseIndexOrNull;
        if (firstIndex === null || baseIndex === null) {
            return null;
        }
        const barsEstimation = this._options.fixLeftEdge
            ? this._width / this._barSpacing
            : Math.min(2, this._points.length);
        return firstIndex - baseIndex - 1 + barsEstimation;
    }
    _maxRightOffset() {
        return (this._width / this._barSpacing) - Math.min(2, this._points.length);
    }
    _saveCommonTransitionsStartState() {
        this._commonTransitionStartState = {
            barSpacing: this.barSpacing(),
            rightOffset: this.rightOffset(),
        };
    }
    _clearCommonTransitionsStartState() {
        this._commonTransitionStartState = null;
    }
    _formatLabel(time, weight) {
        let formatter = this._formattedByWeight.get(weight);
        if (formatter === undefined) {
            formatter = new FormattedLabelsCache((timePoint) => {
                return this._formatLabelImpl(timePoint, weight);
            });
            this._formattedByWeight.set(weight, formatter);
        }
        return formatter.format(time);
    }
    _formatLabelImpl(timePoint, weight) {
        let tickMarkType;
        const timeVisible = this._options.timeVisible;
        if (weight < 20 && timeVisible) {
            tickMarkType = this._options.secondsVisible ? 4 : 3;
        }
        else if (weight < 40 && timeVisible) {
            tickMarkType = 3;
        }
        else if (weight < 50) {
            tickMarkType = 2;
        }
        else if (weight < 60) {
            tickMarkType = 2;
        }
        else if (weight < 70) {
            tickMarkType = 1;
        }
        else {
            tickMarkType = 0;
        }
        if (this._options.tickMarkFormatter !== undefined) {
            return this._options.tickMarkFormatter(timePoint.businessDay ?? timePoint.timestamp, tickMarkType, this._localizationOptions.locale);
        }
        return defaultTickMarkFormatter(timePoint, tickMarkType, this._localizationOptions.locale);
    }
    _setVisibleRange(newVisibleRange) {
        const oldVisibleRange = this._visibleRange;
        this._visibleRange = newVisibleRange;
        if (!areRangesEqual(oldVisibleRange.strictRange(), this._visibleRange.strictRange())) {
            this._visibleBarsChanged.fire();
        }
        if (!areRangesEqual(oldVisibleRange.logicalRange(), this._visibleRange.logicalRange())) {
            this._logicalRangeChanged.fire();
        }
        this._resetTimeMarksCache();
    }
    _resetTimeMarksCache() {
        this._timeMarksCache = null;
    }
    _invalidateTickMarks() {
        this._resetTimeMarksCache();
        this._formattedByWeight.clear();
    }
    _updateDateTimeFormatter() {
        const dateFormat = this._localizationOptions.dateFormat;
        if (this._options.timeVisible) {
            this._dateTimeFormatter = new DateTimeFormatter({
                dateFormat: dateFormat,
                timeFormat: this._options.secondsVisible ? '%h:%m:%s' : '%h:%m',
                dateTimeSeparator: '   ',
                locale: this._localizationOptions.locale,
            });
        }
        else {
            this._dateTimeFormatter = new DateFormatter(dateFormat, this._localizationOptions.locale);
        }
    }
    _doFixLeftEdge() {
        if (!this._options.fixLeftEdge) {
            return;
        }
        const firstIndex = this._firstIndex();
        if (firstIndex === null) {
            return;
        }
        const delta = ensureNotNull(this.visibleStrictRange()).left() - firstIndex;
        if (delta < 0) {
            const leftEdgeOffset = this._rightOffset - delta - 1;
            this.setRightOffset(leftEdgeOffset);
        }
    }
}
