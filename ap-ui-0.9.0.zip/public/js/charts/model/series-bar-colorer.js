import { ensure, ensureNotNull } from '../helpers/assertions.js';
const emptyResult = {
    barColor: '',
    barBorderColor: '',
    barWickColor: '',
};
export class SeriesBarColorer {
    constructor(series) {
        this._series = series;
    }
    barStyle(barIndex, precomputedBars) {
        const targetType = this._series.seriesType();
        const seriesOptions = this._series.options();
        switch (targetType) {
            case 'Line':
                return this._lineStyle(seriesOptions);
            case 'Area':
                return this._areaStyle(seriesOptions);
            case 'Bar':
                return this._barStyle(seriesOptions, barIndex, precomputedBars);
            case 'Candlestick':
                return this._candleStyle(seriesOptions, barIndex, precomputedBars);
            case 'Histogram':
                return this._histogramStyle(seriesOptions, barIndex, precomputedBars);
        }
        throw new Error('Unknown chart style');
    }
    _barStyle(barStyle, barIndex, precomputedBars) {
        const result = { ...emptyResult };
        const upColor = barStyle.upColor;
        const downColor = barStyle.downColor;
        const borderUpColor = upColor;
        const borderDownColor = downColor;
        const currentBar = ensureNotNull(this._findBar(barIndex, precomputedBars));
        const isUp = ensure(currentBar.value[0]) <= ensure(currentBar.value[3]);
        result.barColor = isUp ? upColor : downColor;
        result.barBorderColor = isUp ? borderUpColor : borderDownColor;
        return result;
    }
    _candleStyle(candlestickStyle, barIndex, precomputedBars) {
        const result = { ...emptyResult };
        const upColor = candlestickStyle.upColor;
        const downColor = candlestickStyle.downColor;
        const borderUpColor = candlestickStyle.borderUpColor;
        const borderDownColor = candlestickStyle.borderDownColor;
        const wickUpColor = candlestickStyle.wickUpColor;
        const wickDownColor = candlestickStyle.wickDownColor;
        const currentBar = ensureNotNull(this._findBar(barIndex, precomputedBars));
        const isUp = ensure(currentBar.value[0]) <= ensure(currentBar.value[3]);
        result.barColor = isUp ? upColor : downColor;
        result.barBorderColor = isUp ? borderUpColor : borderDownColor;
        result.barWickColor = isUp ? wickUpColor : wickDownColor;
        return result;
    }
    _areaStyle(areaStyle) {
        return {
            ...emptyResult,
            barColor: areaStyle.lineColor,
        };
    }
    _lineStyle(lineStyle) {
        return {
            ...emptyResult,
            barColor: lineStyle.color,
        };
    }
    _histogramStyle(histogramStyle, barIndex, precomputedBars) {
        const result = { ...emptyResult };
        const currentBar = ensureNotNull(this._findBar(barIndex, precomputedBars));
        result.barColor = currentBar.color !== undefined ? currentBar.color : histogramStyle.color;
        return result;
    }
    _findBar(barIndex, precomputedBars) {
        if (precomputedBars !== undefined) {
            return precomputedBars.value;
        }
        return this._series.bars().valueAt(barIndex);
    }
}
