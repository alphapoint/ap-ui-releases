import { PercentageFormatter } from '../formatters/percentage-formatter.js';
import { PriceFormatter } from '../formatters/price-formatter.js';
import { VolumeFormatter } from '../formatters/volume-formatter.js';
import { ensureNotNull } from '../helpers/assertions.js';
import { isInteger, merge } from '../helpers/strict-type-checks.js';
import { SeriesAreaPaneView } from '../views/pane/area-pane-view.js';
import { SeriesBarsPaneView } from '../views/pane/bars-pane-view.js';
import { SeriesCandlesticksPaneView } from '../views/pane/candlesticks-pane-view.js';
import { SeriesHistogramPaneView } from '../views/pane/histogram-pane-view.js';
import { SeriesLinePaneView } from '../views/pane/line-pane-view.js';
import { PanePriceAxisView } from '../views/pane/pane-price-axis-view.js';
import { SeriesHorizontalBaseLinePaneView } from '../views/pane/series-horizontal-base-line-pane-view.js';
import { SeriesMarkersPaneView } from '../views/pane/series-markers-pane-view.js';
import { SeriesPriceLinePaneView } from '../views/pane/series-price-line-pane-view.js';
import { SeriesPriceAxisView } from '../views/price-axis/series-price-axis-view.js';
import { AutoscaleInfoImpl } from './autoscale-info-impl.js';
import { CustomPriceLine } from './custom-price-line.js';
import { isDefaultPriceScale } from './default-price-scale.js';
import { PriceDataSource } from './price-data-source.js';
import { PriceRangeImpl } from './price-range-impl.js';
import { SeriesBarColorer } from './series-bar-colorer.js';
import { createSeriesPlotList } from './series-data.js';
export class Series extends PriceDataSource {
    constructor(model, options, seriesType) {
        super(model);
        this._data = createSeriesPlotList();
        this._priceLineView = new SeriesPriceLinePaneView(this);
        this._customPriceLines = [];
        this._baseHorizontalLineView = new SeriesHorizontalBaseLinePaneView(this);
        this._barColorerCache = null;
        this._markers = [];
        this._indexedMarkers = [];
        this._options = options;
        this._seriesType = seriesType;
        const priceAxisView = new SeriesPriceAxisView(this);
        this._priceAxisViews = [priceAxisView];
        this._panePriceAxisView = new PanePriceAxisView(priceAxisView, this, model);
        this._recreateFormatter();
        this._recreatePaneViews();
    }
    destroy() {
    }
    priceLineColor(lastBarColor) {
        return this._options.priceLineColor || lastBarColor;
    }
    lastValueData(globalLast, withRawPrice) {
        const noDataRes = { noData: true };
        const priceScale = this.priceScale();
        if (this.model().timeScale().isEmpty() || priceScale.isEmpty() || this._data.isEmpty()) {
            return noDataRes;
        }
        const visibleBars = this.model().timeScale().visibleStrictRange();
        const firstValue = this.firstValue();
        if (visibleBars === null || firstValue === null) {
            return noDataRes;
        }
        let bar;
        let lastIndex;
        if (globalLast) {
            const lastBar = this._data.last();
            if (lastBar === null) {
                return noDataRes;
            }
            bar = lastBar;
            lastIndex = lastBar.index;
        }
        else {
            const endBar = this._data.search(visibleBars.right(), -1);
            if (endBar === null) {
                return noDataRes;
            }
            bar = this._data.valueAt(endBar.index);
            if (bar === null) {
                return noDataRes;
            }
            lastIndex = endBar.index;
        }
        const price = bar.value[3];
        const barColorer = this.barColorer();
        const style = barColorer.barStyle(lastIndex, { value: bar });
        const coordinate = priceScale.priceToCoordinate(price, firstValue.value);
        return {
            noData: false,
            price: withRawPrice ? price : undefined,
            text: priceScale.formatPrice(price, firstValue.value),
            formattedPriceAbsolute: priceScale.formatPriceAbsolute(price),
            formattedPricePercentage: priceScale.formatPricePercentage(price, firstValue.value),
            color: style.barColor,
            coordinate: coordinate,
            index: lastIndex,
        };
    }
    barColorer() {
        if (this._barColorerCache !== null) {
            return this._barColorerCache;
        }
        this._barColorerCache = new SeriesBarColorer(this);
        return this._barColorerCache;
    }
    options() {
        return this._options;
    }
    applyOptions(options) {
        const targetPriceScaleId = options.priceScaleId;
        if (targetPriceScaleId !== undefined && targetPriceScaleId !== this._options.priceScaleId) {
            this.model().moveSeriesToScale(this, targetPriceScaleId);
        }
        merge(this._options, options);
        if (this._priceScale !== null && options.scaleMargins !== undefined) {
            this._priceScale.applyOptions({
                scaleMargins: options.scaleMargins,
            });
        }
        if (options.priceFormat !== undefined) {
            this._recreateFormatter();
        }
        this.model().updateSource(this);
        this.model().updateCrosshair();
    }
    clearData() {
        this._data.clear();
        this._recreatePaneViews();
    }
    updateData(data, clearData) {
        if (clearData) {
            this._data.clear();
        }
        this._data.merge(data);
        this._recalculateMarkers();
        this._paneView.update('data');
        this._markersPaneView.update('data');
        const sourcePane = this.model().paneForSource(this);
        this.model().recalculatePane(sourcePane);
        this.model().updateSource(this);
        this.model().updateCrosshair();
        this.model().lightUpdate();
    }
    setMarkers(data) {
        this._markers = data.map((item) => ({ ...item }));
        this._recalculateMarkers();
        const sourcePane = this.model().paneForSource(this);
        this._markersPaneView.update('data');
        this.model().recalculatePane(sourcePane);
        this.model().updateSource(this);
        this.model().updateCrosshair();
        this.model().lightUpdate();
    }
    indexedMarkers() {
        return this._indexedMarkers;
    }
    createPriceLine(options) {
        const result = new CustomPriceLine(this, options);
        this._customPriceLines.push(result);
        this.model().updateSource(this);
        return result;
    }
    removePriceLine(line) {
        const index = this._customPriceLines.indexOf(line);
        if (index !== -1) {
            this._customPriceLines.splice(index, 1);
        }
        this.model().updateSource(this);
    }
    seriesType() {
        return this._seriesType;
    }
    firstValue() {
        const bar = this.firstBar();
        if (bar === null) {
            return null;
        }
        return {
            value: bar.value[3],
            timePoint: bar.time,
        };
    }
    firstBar() {
        const visibleBars = this.model().timeScale().visibleStrictRange();
        if (visibleBars === null) {
            return null;
        }
        const startTimePoint = visibleBars.left();
        return this._data.search(startTimePoint, 1);
    }
    bars() {
        return this._data;
    }
    dataAt(time) {
        const prices = this._data.valueAt(time);
        if (prices === null) {
            return null;
        }
        if (this._seriesType === 'Bar' || this._seriesType === 'Candlestick') {
            return {
                open: prices.value[0],
                high: prices.value[1],
                low: prices.value[2],
                close: prices.value[3],
            };
        }
        else {
            return prices.value[3];
        }
    }
    paneViews() {
        const res = [];
        if (!this._isOverlay()) {
            res.push(this._baseHorizontalLineView);
        }
        for (const customPriceLine of this._customPriceLines) {
            res.push(...customPriceLine.paneViews());
        }
        res.push(this._paneView);
        res.push(this._priceLineView);
        res.push(this._panePriceAxisView);
        res.push(this._markersPaneView);
        return res;
    }
    priceAxisViews(pane, priceScale) {
        const result = (priceScale === this._priceScale || this._isOverlay()) ? [...this._priceAxisViews] : [];
        for (const customPriceLine of this._customPriceLines) {
            result.push(customPriceLine.priceAxisView());
        }
        return result;
    }
    autoscaleInfo(startTimePoint, endTimePoint) {
        if (this._options.autoscaleInfoProvider !== undefined) {
            const autoscaleInfo = this._options.autoscaleInfoProvider(() => {
                const res = this._autoscaleInfoImpl(startTimePoint, endTimePoint);
                return (res === null) ? null : res.toRaw();
            });
            return AutoscaleInfoImpl.fromRaw(autoscaleInfo);
        }
        return this._autoscaleInfoImpl(startTimePoint, endTimePoint);
    }
    minMove() {
        return this._options.priceFormat.minMove;
    }
    formatter() {
        return this._formatter;
    }
    updateAllViews() {
        this._paneView.update();
        this._markersPaneView.update();
        for (const priceAxisView of this._priceAxisViews) {
            priceAxisView.update();
        }
        for (const customPriceLine of this._customPriceLines) {
            customPriceLine.update();
        }
        this._priceLineView.update();
        this._baseHorizontalLineView.update();
    }
    priceScale() {
        return ensureNotNull(this._priceScale);
    }
    markerDataAtIndex(index) {
        const getValue = (this._seriesType === 'Line' || this._seriesType === 'Area') &&
            this._options.crosshairMarkerVisible;
        if (!getValue) {
            return null;
        }
        const bar = this._data.valueAt(index);
        if (bar === null) {
            return null;
        }
        const price = bar.value[3];
        const radius = this._markerRadius();
        const borderColor = this._markerBorderColor();
        const backgroundColor = this._markerBackgroundColor(index);
        return { price, radius, borderColor, backgroundColor };
    }
    title() {
        return this._options.title;
    }
    _isOverlay() {
        const priceScale = this.priceScale();
        return !isDefaultPriceScale(priceScale.id());
    }
    _autoscaleInfoImpl(startTimePoint, endTimePoint) {
        if (!isInteger(startTimePoint) || !isInteger(endTimePoint) || this._data.isEmpty()) {
            return null;
        }
        const plots = this._seriesType === 'Line' || this._seriesType === 'Area' || this._seriesType === 'Histogram'
            ? [3]
            : [2, 1];
        const barsMinMax = this._data.minMaxOnRangeCached(startTimePoint, endTimePoint, plots);
        let range = barsMinMax !== null ? new PriceRangeImpl(barsMinMax.min, barsMinMax.max) : null;
        if (this.seriesType() === 'Histogram') {
            const base = this._options.base;
            const rangeWithBase = new PriceRangeImpl(base, base);
            range = range !== null ? range.merge(rangeWithBase) : rangeWithBase;
        }
        return new AutoscaleInfoImpl(range, this._markersPaneView.autoScaleMargins());
    }
    _markerRadius() {
        switch (this._seriesType) {
            case 'Line':
            case 'Area':
                return this._options.crosshairMarkerRadius;
        }
        return 0;
    }
    _markerBorderColor() {
        switch (this._seriesType) {
            case 'Line':
            case 'Area': {
                const crosshairMarkerBorderColor = this._options.crosshairMarkerBorderColor;
                if (crosshairMarkerBorderColor.length !== 0) {
                    return crosshairMarkerBorderColor;
                }
            }
        }
        return this.model().options().layout.backgroundColor;
    }
    _markerBackgroundColor(index) {
        switch (this._seriesType) {
            case 'Line':
            case 'Area': {
                const crosshairMarkerBackgroundColor = this._options.crosshairMarkerBackgroundColor;
                if (crosshairMarkerBackgroundColor.length !== 0) {
                    return crosshairMarkerBackgroundColor;
                }
            }
        }
        return this.barColorer().barStyle(index).barColor;
    }
    _recreateFormatter() {
        switch (this._options.priceFormat.type) {
            case 'custom': {
                this._formatter = { format: this._options.priceFormat.formatter };
                break;
            }
            case 'volume': {
                this._formatter = new VolumeFormatter(this._options.priceFormat.precision);
                break;
            }
            case 'percent': {
                this._formatter = new PercentageFormatter(this._options.priceFormat.precision);
                break;
            }
            default: {
                const priceScale = Math.pow(10, this._options.priceFormat.precision);
                this._formatter = new PriceFormatter(priceScale, this._options.priceFormat.minMove * priceScale);
            }
        }
        if (this._priceScale !== null) {
            this._priceScale.updateFormatter();
        }
    }
    _recalculateMarkers() {
        const timeScale = this.model().timeScale();
        if (timeScale.isEmpty() || this._data.size() === 0) {
            this._indexedMarkers = [];
            return;
        }
        const firstDataIndex = ensureNotNull(this._data.firstIndex());
        this._indexedMarkers = this._markers.map((marker, index) => {
            const timePointIndex = ensureNotNull(timeScale.timeToIndex(marker.time, true));
            const searchMode = timePointIndex < firstDataIndex ? 1 : -1;
            const seriesDataIndex = ensureNotNull(this._data.search(timePointIndex, searchMode)).index;
            return {
                time: seriesDataIndex,
                position: marker.position,
                shape: marker.shape,
                color: marker.color,
                id: marker.id,
                internalId: index,
                text: marker.text,
                size: marker.size,
            };
        });
    }
    _recreatePaneViews() {
        this._markersPaneView = new SeriesMarkersPaneView(this, this.model());
        switch (this._seriesType) {
            case 'Bar': {
                this._paneView = new SeriesBarsPaneView(this, this.model());
                break;
            }
            case 'Candlestick': {
                this._paneView = new SeriesCandlesticksPaneView(this, this.model());
                break;
            }
            case 'Line': {
                this._paneView = new SeriesLinePaneView(this, this.model());
                break;
            }
            case 'Area': {
                this._paneView = new SeriesAreaPaneView(this, this.model());
                break;
            }
            case 'Histogram': {
                this._paneView = new SeriesHistogramPaneView(this, this.model());
                break;
            }
            default: throw Error('Unknown chart style assigned: ' + this._seriesType);
        }
    }
}
