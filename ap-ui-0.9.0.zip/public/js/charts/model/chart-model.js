import { assert, ensureNotNull } from '../helpers/assertions.js';
import { Delegate } from '../helpers/delegate.js';
import { merge } from '../helpers/strict-type-checks.js';
import { PriceAxisRendererOptionsProvider } from '../renderers/price-axis-renderer-options-provider.js';
import { Crosshair } from './crosshair.js';
import { isDefaultPriceScale } from './default-price-scale.js';
import { InvalidateMask } from './invalidate-mask.js';
import { Magnet } from './magnet.js';
import { DEFAULT_STRETCH_FACTOR, Pane } from './pane.js';
import { Series } from './series.js';
import { TimeScale } from './time-scale.js';
import { Watermark } from './watermark.js';
export class ChartModel {
    constructor(invalidateHandler, options) {
        this._panes = [];
        this._serieses = [];
        this._width = 0;
        this._initialTimeScrollPos = null;
        this._hoveredSource = null;
        this._priceScalesOptionsChanged = new Delegate();
        this._crosshairMoved = new Delegate();
        this._invalidateHandler = invalidateHandler;
        this._options = options;
        this._rendererOptionsProvider = new PriceAxisRendererOptionsProvider(this);
        this._timeScale = new TimeScale(this, options.timeScale, this._options.localization);
        this._crosshair = new Crosshair(this, options.crosshair);
        this._magnet = new Magnet(options.crosshair);
        this._watermark = new Watermark(this, options.watermark);
        this.createPane();
        this._panes[0].setStretchFactor(DEFAULT_STRETCH_FACTOR * 2);
    }
    fullUpdate() {
        this._invalidate(new InvalidateMask(3));
    }
    lightUpdate() {
        this._invalidate(new InvalidateMask(2));
    }
    updateSource(source) {
        const inv = this._invalidationMaskForSource(source);
        this._invalidate(inv);
    }
    hoveredSource() {
        return this._hoveredSource;
    }
    setHoveredSource(source) {
        const prevSource = this._hoveredSource;
        this._hoveredSource = source;
        if (prevSource !== null) {
            this.updateSource(prevSource.source);
        }
        if (source !== null) {
            this.updateSource(source.source);
        }
    }
    options() {
        return this._options;
    }
    applyOptions(options) {
        merge(this._options, options);
        this._panes.forEach((p) => p.applyScaleOptions(options));
        if (options.timeScale !== undefined) {
            this._timeScale.applyOptions(options.timeScale);
        }
        if (options.localization !== undefined) {
            this._timeScale.applyLocalizationOptions(options.localization);
        }
        if (options.leftPriceScale || options.rightPriceScale) {
            this._priceScalesOptionsChanged.fire();
        }
        this.fullUpdate();
    }
    applyPriceScaleOptions(priceScaleId, options) {
        const res = this.findPriceScale(priceScaleId);
        if (res === null) {
            return;
        }
        res.priceScale.applyOptions(options);
        this._priceScalesOptionsChanged.fire();
    }
    findPriceScale(priceScaleId) {
        for (const pane of this._panes) {
            const priceScale = pane.priceScaleById(priceScaleId);
            if (priceScale !== null) {
                return {
                    pane,
                    priceScale,
                };
            }
        }
        return null;
    }
    timeScale() {
        return this._timeScale;
    }
    panes() {
        return this._panes;
    }
    watermarkSource() {
        return this._watermark;
    }
    crosshairSource() {
        return this._crosshair;
    }
    crosshairMoved() {
        return this._crosshairMoved;
    }
    setPaneHeight(pane, height) {
        pane.setHeight(height);
        this.recalculateAllPanes();
    }
    setWidth(width) {
        this._width = width;
        this._timeScale.setWidth(this._width);
        this._panes.forEach((pane) => pane.setWidth(width));
        this.recalculateAllPanes();
    }
    createPane(index) {
        const pane = new Pane(this._timeScale, this);
        if (index !== undefined) {
            this._panes.splice(index, 0, pane);
        }
        else {
            this._panes.push(pane);
        }
        const actualIndex = (index === undefined) ? this._panes.length - 1 : index;
        const mask = new InvalidateMask(3);
        mask.invalidatePane(actualIndex, {
            level: 0,
            autoScale: true,
        });
        this._invalidate(mask);
        return pane;
    }
    startScalePrice(pane, priceScale, x) {
        pane.startScalePrice(priceScale, x);
    }
    scalePriceTo(pane, priceScale, x) {
        pane.scalePriceTo(priceScale, x);
        this.updateCrosshair();
        this._invalidate(this._paneInvalidationMask(pane, 2));
    }
    endScalePrice(pane, priceScale) {
        pane.endScalePrice(priceScale);
        this._invalidate(this._paneInvalidationMask(pane, 2));
    }
    startScrollPrice(pane, priceScale, x) {
        if (priceScale.isAutoScale()) {
            return;
        }
        pane.startScrollPrice(priceScale, x);
    }
    scrollPriceTo(pane, priceScale, x) {
        if (priceScale.isAutoScale()) {
            return;
        }
        pane.scrollPriceTo(priceScale, x);
        this.updateCrosshair();
        this._invalidate(this._paneInvalidationMask(pane, 2));
    }
    endScrollPrice(pane, priceScale) {
        if (priceScale.isAutoScale()) {
            return;
        }
        pane.endScrollPrice(priceScale);
        this._invalidate(this._paneInvalidationMask(pane, 2));
    }
    resetPriceScale(pane, priceScale) {
        pane.resetPriceScale(priceScale);
        this._invalidate(this._paneInvalidationMask(pane, 2));
    }
    startScaleTime(position) {
        this._timeScale.startScale(position);
    }
    zoomTime(pointX, scale) {
        const timeScale = this.timeScale();
        if (timeScale.isEmpty() || scale === 0) {
            return;
        }
        const timeScaleWidth = timeScale.width();
        pointX = Math.max(1, Math.min(pointX, timeScaleWidth));
        timeScale.zoom(pointX, scale);
        this.recalculateAllPanes();
    }
    scrollChart(x) {
        this.startScrollTime(0);
        this.scrollTimeTo(x);
        this.endScrollTime();
    }
    scaleTimeTo(x) {
        this._timeScale.scaleTo(x);
        this.recalculateAllPanes();
    }
    endScaleTime() {
        this._timeScale.endScale();
        this.lightUpdate();
    }
    startScrollTime(x) {
        this._initialTimeScrollPos = x;
        this._timeScale.startScroll(x);
    }
    scrollTimeTo(x) {
        let res = false;
        if (this._initialTimeScrollPos !== null && Math.abs(x - this._initialTimeScrollPos) > 20) {
            this._initialTimeScrollPos = null;
            res = true;
        }
        this._timeScale.scrollTo(x);
        this.recalculateAllPanes();
        return res;
    }
    endScrollTime() {
        this._timeScale.endScroll();
        this.lightUpdate();
        this._initialTimeScrollPos = null;
    }
    serieses() {
        return this._serieses;
    }
    setAndSaveCurrentPosition(x, y, pane) {
        this._crosshair.saveOriginCoord(x, y);
        let price = NaN;
        let index = this._timeScale.coordinateToIndex(x);
        const visibleBars = this._timeScale.visibleStrictRange();
        if (visibleBars !== null) {
            index = Math.min(Math.max(visibleBars.left(), index), visibleBars.right());
        }
        const priceScale = pane.defaultPriceScale();
        const firstValue = priceScale.firstValue();
        if (firstValue !== null) {
            price = priceScale.coordinateToPrice(y, firstValue);
        }
        price = this._magnet.align(price, index, pane);
        this._crosshair.setPosition(index, price, pane);
        this._cursorUpdate();
        this._crosshairMoved.fire(this._crosshair.appliedIndex(), { x, y });
    }
    clearCurrentPosition() {
        const crosshair = this.crosshairSource();
        crosshair.clearPosition();
        this._cursorUpdate();
        this._crosshairMoved.fire(null, null);
    }
    updateCrosshair() {
        const pane = this._crosshair.pane();
        if (pane !== null) {
            const x = this._crosshair.originCoordX();
            const y = this._crosshair.originCoordY();
            this.setAndSaveCurrentPosition(x, y, pane);
        }
        this._crosshair.updateAllViews();
    }
    updateTimeScale(newBaseIndex, newPoints) {
        const oldFirstTime = this._timeScale.indexToTime(0);
        if (newPoints !== undefined) {
            this._timeScale.update(newPoints);
        }
        const newFirstTime = this._timeScale.indexToTime(0);
        const currentBaseIndex = this._timeScale.baseIndex();
        const visibleBars = this._timeScale.visibleStrictRange();
        if (visibleBars !== null && oldFirstTime !== null && newFirstTime !== null) {
            const isLastSeriesBarVisible = visibleBars.contains(currentBaseIndex);
            const isLeftBarShiftToLeft = oldFirstTime.timestamp > newFirstTime.timestamp;
            const isSeriesPointsAdded = newBaseIndex > currentBaseIndex;
            const isSeriesPointsAddedToRight = isSeriesPointsAdded && !isLeftBarShiftToLeft;
            if (isSeriesPointsAddedToRight && !isLastSeriesBarVisible) {
                const compensationShift = newBaseIndex - currentBaseIndex;
                this._timeScale.setRightOffset(this._timeScale.rightOffset() - compensationShift);
            }
        }
        this._timeScale.setBaseIndex(newBaseIndex);
    }
    recalculatePane(pane) {
        if (pane !== null) {
            pane.recalculate();
        }
    }
    paneForSource(source) {
        const pane = this._panes.find((p) => p.orderedSources().includes(source));
        return pane === undefined ? null : pane;
    }
    recalculateAllPanes() {
        this._watermark.updateAllViews();
        this._panes.forEach((p) => p.recalculate());
        this.updateCrosshair();
    }
    destroy() {
        this._panes.forEach((p) => p.destroy());
        this._panes.length = 0;
        this._options.localization.priceFormatter = undefined;
        this._options.localization.timeFormatter = undefined;
    }
    rendererOptionsProvider() {
        return this._rendererOptionsProvider;
    }
    priceAxisRendererOptions() {
        return this._rendererOptionsProvider.options();
    }
    priceScalesOptionsChanged() {
        return this._priceScalesOptionsChanged;
    }
    createSeries(seriesType, options) {
        const pane = this._panes[0];
        const series = this._createSeries(options, seriesType, pane);
        this._serieses.push(series);
        if (this._serieses.length === 1) {
            this.fullUpdate();
        }
        else {
            this.lightUpdate();
        }
        return series;
    }
    removeSeries(series) {
        const pane = this.paneForSource(series);
        const seriesIndex = this._serieses.indexOf(series);
        assert(seriesIndex !== -1, 'Series not found');
        this._serieses.splice(seriesIndex, 1);
        ensureNotNull(pane).removeDataSource(series);
        if (series.destroy) {
            series.destroy();
        }
    }
    moveSeriesToScale(series, targetScaleId) {
        const pane = ensureNotNull(this.paneForSource(series));
        pane.removeDataSource(series);
        const target = this.findPriceScale(targetScaleId);
        if (target === null) {
            const zOrder = series.zorder();
            pane.addDataSource(series, targetScaleId, zOrder);
        }
        else {
            const zOrder = (target.pane === pane) ? series.zorder() : undefined;
            target.pane.addDataSource(series, targetScaleId, zOrder);
        }
    }
    fitContent() {
        const mask = new InvalidateMask(2);
        mask.setFitContent();
        this._invalidate(mask);
    }
    setTargetLogicalRange(range) {
        const mask = new InvalidateMask(2);
        mask.applyRange(range);
        this._invalidate(mask);
    }
    resetTimeScale() {
        const mask = new InvalidateMask(2);
        mask.resetTimeScale();
        this._invalidate(mask);
    }
    setBarSpacing(spacing) {
        const mask = new InvalidateMask(2);
        mask.setBarSpacing(spacing);
        this._invalidate(mask);
    }
    setRightOffset(offset) {
        const mask = new InvalidateMask(2);
        mask.setRightOffset(offset);
        this._invalidate(mask);
    }
    defaultVisiblePriceScaleId() {
        return this._options.rightPriceScale.visible ? "right" : "left";
    }
    _paneInvalidationMask(pane, level) {
        const inv = new InvalidateMask(level);
        if (pane !== null) {
            const index = this._panes.indexOf(pane);
            inv.invalidatePane(index, {
                level,
            });
        }
        return inv;
    }
    _invalidationMaskForSource(source, invalidateType) {
        if (invalidateType === undefined) {
            invalidateType = 2;
        }
        return this._paneInvalidationMask(this.paneForSource(source), invalidateType);
    }
    _invalidate(mask) {
        if (this._invalidateHandler) {
            this._invalidateHandler(mask);
        }
        this._panes.forEach((pane) => pane.grid().paneView().update());
    }
    _cursorUpdate() {
        this._invalidate(new InvalidateMask(1));
    }
    _createSeries(options, seriesType, pane) {
        const series = new Series(this, options, seriesType);
        const targetScaleId = options.priceScaleId !== undefined ? options.priceScaleId : this.defaultVisiblePriceScaleId();
        pane.addDataSource(series, targetScaleId);
        if (!isDefaultPriceScale(targetScaleId)) {
            series.applyOptions(options);
        }
        return series;
    }
}
