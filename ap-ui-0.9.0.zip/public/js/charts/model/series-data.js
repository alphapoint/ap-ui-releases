import { PlotList } from './plot-list.js';
export function createSeriesPlotList() {
    return new PlotList();
}
