import { WatermarkPaneView } from '../views/pane/watermark-pane-view.js';
import { DataSource } from './data-source.js';
export class Watermark extends DataSource {
    constructor(model, options) {
        super();
        this._options = options;
        this._paneView = new WatermarkPaneView(this);
    }
    paneViews() {
        return [this._paneView];
    }
    options() {
        return this._options;
    }
    updateAllViews() {
        this._paneView.update();
    }
}
