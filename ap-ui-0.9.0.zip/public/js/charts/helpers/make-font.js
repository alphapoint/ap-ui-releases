export const defaultFontFamily = `'Trebuchet MS', Roboto, Ubuntu, sans-serif`;
export function makeFont(size, family, style) {
    if (style !== undefined) {
        style = `${style} `;
    }
    else {
        style = '';
    }
    if (family === undefined) {
        family = defaultFontFamily;
    }
    return `${style}${size}px ${family}`;
}
