export const isRunningOnClientSide = typeof window !== 'undefined';
