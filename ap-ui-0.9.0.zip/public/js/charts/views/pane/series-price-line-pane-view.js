import { SeriesHorizontalLinePaneView } from './series-horizontal-line-pane-view.js';
export class SeriesPriceLinePaneView extends SeriesHorizontalLinePaneView {
    constructor(series) {
        super(series);
    }
    _updateImpl(height, width) {
        const data = this._lineRendererData;
        data.visible = false;
        const seriesOptions = this._series.options();
        if (!seriesOptions.priceLineVisible || !seriesOptions.visible) {
            return;
        }
        const lastValueData = this._series.lastValueData(seriesOptions.priceLineSource === 0);
        if (lastValueData.noData) {
            return;
        }
        data.visible = true;
        data.y = lastValueData['coordinate'];
        data.color = this._series.priceLineColor(lastValueData['color']);
        data.width = width;
        data.height = height;
        data.lineWidth = seriesOptions.priceLineWidth;
        data.lineStyle = seriesOptions.priceLineStyle;
    }
}
