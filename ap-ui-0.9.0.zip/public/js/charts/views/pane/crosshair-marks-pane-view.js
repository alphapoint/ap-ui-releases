import { ensureNotNull } from '../../helpers/assertions.js';
import { CompositeRenderer } from '../../renderers/composite-renderer.js';
import { PaneRendererMarks } from '../../renderers/marks-renderer.js';
function createEmptyMarkerData(chartOptions) {
    return {
        items: [{
                x: 0,
                y: 0,
                time: 0,
                price: 0,
            }],
        lineColor: '',
        backColor: chartOptions.layout.backgroundColor,
        radius: 0,
        visibleRange: null,
    };
}
const rangeForSinglePoint = { from: 0, to: 1 };
export class CrosshairMarksPaneView {
    constructor(chartModel, crosshair) {
        this._compositeRenderer = new CompositeRenderer();
        this._markersRenderers = [];
        this._markersData = [];
        this._invalidated = true;
        this._chartModel = chartModel;
        this._crosshair = crosshair;
        this._compositeRenderer.setRenderers(this._markersRenderers);
    }
    update(updateType) {
        const serieses = this._chartModel.serieses();
        if (serieses.length !== this._markersRenderers.length) {
            this._markersData = serieses.map(() => createEmptyMarkerData(this._chartModel.options()));
            this._markersRenderers = this._markersData.map((data) => {
                const res = new PaneRendererMarks();
                res.setData(data);
                return res;
            });
            this._compositeRenderer.setRenderers(this._markersRenderers);
        }
        this._invalidated = true;
    }
    renderer(height, width, addAnchors) {
        if (this._invalidated) {
            this._updateImpl();
            this._invalidated = false;
        }
        return this._compositeRenderer;
    }
    _updateImpl() {
        const serieses = this._chartModel.serieses();
        const timePointIndex = this._crosshair.appliedIndex();
        const timeScale = this._chartModel.timeScale();
        serieses.forEach((s, index) => {
            const data = this._markersData[index];
            const seriesData = s.markerDataAtIndex(timePointIndex);
            if (seriesData === null || !s.options().visible) {
                data.visibleRange = null;
                return;
            }
            const firstValue = ensureNotNull(s.firstValue());
            data.lineColor = seriesData.backgroundColor;
            data.backColor = seriesData.borderColor;
            data.radius = seriesData.radius;
            data.items[0].price = seriesData.price;
            data.items[0].y = s.priceScale().priceToCoordinate(seriesData.price, firstValue.value);
            data.items[0].time = timePointIndex;
            data.items[0].x = timeScale.indexToCoordinate(timePointIndex);
            data.visibleRange = rangeForSinglePoint;
        });
    }
}
