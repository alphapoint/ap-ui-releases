import { PaneRendererLine } from '../../renderers/line-renderer.js';
import { LinePaneViewBase } from './line-pane-view-base.js';
export class SeriesLinePaneView extends LinePaneViewBase {
    constructor(series, model) {
        super(series, model);
        this._lineRenderer = new PaneRendererLine();
    }
    renderer(height, width) {
        const lineStyleProps = this._series.options();
        if (!lineStyleProps.visible) {
            return null;
        }
        this._makeValid();
        const data = {
            items: this._items,
            lineColor: lineStyleProps.color,
            lineStyle: lineStyleProps.lineStyle,
            lineType: lineStyleProps.lineType,
            lineWidth: lineStyleProps.lineWidth,
            visibleRange: this._itemsVisibleRange,
            barWidth: this._model.timeScale().barSpacing(),
        };
        this._lineRenderer.setData(data);
        return this._lineRenderer;
    }
    _createRawItem(time, price) {
        return this._createRawItemBase(time, price);
    }
}
