import { SeriesHorizontalLinePaneView } from './series-horizontal-line-pane-view.js';
export class CustomPriceLinePaneView extends SeriesHorizontalLinePaneView {
    constructor(series, priceLine) {
        super(series);
        this._priceLine = priceLine;
    }
    _updateImpl(height, width) {
        const data = this._lineRendererData;
        data.visible = false;
        if (!this._series.options().visible) {
            return;
        }
        const y = this._priceLine.yCoord();
        if (y === null) {
            return;
        }
        const lineOptions = this._priceLine.options();
        data.visible = true;
        data.y = y;
        data.color = lineOptions.color;
        data.width = width;
        data.height = height;
        data.lineWidth = lineOptions.lineWidth;
        data.lineStyle = lineOptions.lineStyle;
    }
}
