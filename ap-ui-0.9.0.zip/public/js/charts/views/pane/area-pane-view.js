import { PaneRendererArea } from '../../renderers/area-renderer.js';
import { CompositeRenderer } from '../../renderers/composite-renderer.js';
import { PaneRendererLine } from '../../renderers/line-renderer.js';
import { LinePaneViewBase } from './line-pane-view-base.js';
export class SeriesAreaPaneView extends LinePaneViewBase {
    constructor(series, model) {
        super(series, model);
        this._renderer = new CompositeRenderer();
        this._areaRenderer = new PaneRendererArea();
        this._lineRenderer = new PaneRendererLine();
        this._renderer.setRenderers([this._areaRenderer, this._lineRenderer]);
    }
    renderer(height, width) {
        const areaStyleProperties = this._series.options();
        if (!areaStyleProperties.visible) {
            return null;
        }
        this._makeValid();
        const data = {
            lineType: areaStyleProperties.lineType,
            items: this._items,
            lineColor: areaStyleProperties.lineColor,
            lineStyle: areaStyleProperties.lineStyle,
            lineWidth: areaStyleProperties.lineWidth,
            topColor: areaStyleProperties.topColor,
            bottomColor: areaStyleProperties.bottomColor,
            bottom: height,
            visibleRange: this._itemsVisibleRange,
            barWidth: this._model.timeScale().barSpacing(),
        };
        this._areaRenderer.setData(data);
        this._lineRenderer.setData(data);
        return this._renderer;
    }
    _createRawItem(time, price) {
        return this._createRawItemBase(time, price);
    }
}
