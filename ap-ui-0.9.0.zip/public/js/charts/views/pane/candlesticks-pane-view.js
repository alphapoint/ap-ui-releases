import { PaneRendererCandlesticks, } from '../../renderers/candlesticks-renderer.js';
import { BarsPaneViewBase } from './bars-pane-view-base.js';
export class SeriesCandlesticksPaneView extends BarsPaneViewBase {
    constructor() {
        super(...arguments);
        this._renderer = new PaneRendererCandlesticks();
    }
    renderer(height, width) {
        const candlestickStyleProps = this._series.options();
        if (!candlestickStyleProps.visible) {
            return null;
        }
        this._makeValid();
        const data = {
            bars: this._items,
            barSpacing: this._model.timeScale().barSpacing(),
            wickVisible: candlestickStyleProps.wickVisible,
            borderVisible: candlestickStyleProps.borderVisible,
            visibleRange: this._itemsVisibleRange,
        };
        this._renderer.setData(data);
        return this._renderer;
    }
    _createRawItem(time, bar, colorer) {
        const style = colorer.barStyle(time);
        return {
            ...this._createDefaultItem(time, bar, colorer),
            color: style.barColor,
            wickColor: style.barWickColor,
            borderColor: style.barBorderColor,
        };
    }
}
