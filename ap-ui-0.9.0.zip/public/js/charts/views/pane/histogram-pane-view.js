import { ensureNotNull } from '../../helpers/assertions.js';
import { visibleTimedValues } from '../../model/time-data.js';
import { CompositeRenderer } from '../../renderers/composite-renderer.js';
import { PaneRendererHistogram } from '../../renderers/histogram-renderer.js';
import { SeriesPaneViewBase } from './series-pane-view-base.js';
function createEmptyHistogramData(barSpacing) {
    return {
        items: [],
        barSpacing,
        histogramBase: NaN,
        visibleRange: null,
    };
}
function createRawItem(time, price, color) {
    return {
        time: time,
        price: price,
        x: NaN,
        y: NaN,
        color,
    };
}
export class SeriesHistogramPaneView extends SeriesPaneViewBase {
    constructor(series, model) {
        super(series, model, false);
        this._compositeRenderer = new CompositeRenderer();
        this._histogramData = createEmptyHistogramData(0);
        this._renderer = new PaneRendererHistogram();
    }
    renderer(height, width) {
        if (!this._series.options().visible) {
            return null;
        }
        this._makeValid();
        return this._compositeRenderer;
    }
    _fillRawPoints() {
        const barSpacing = this._model.timeScale().barSpacing();
        this._histogramData = createEmptyHistogramData(barSpacing);
        let targetIndex = 0;
        let itemIndex = 0;
        const defaultColor = this._series.options().color;
        for (const row of this._series.bars().rows()) {
            const value = row.value[3];
            const color = row.color !== undefined ? row.color : defaultColor;
            const item = createRawItem(row.index, value, color);
            targetIndex++;
            if (targetIndex < this._histogramData.items.length) {
                this._histogramData.items[targetIndex] = item;
            }
            else {
                this._histogramData.items.push(item);
            }
            this._items[itemIndex++] = { time: row.index, x: 0 };
        }
        this._renderer.setData(this._histogramData);
        this._compositeRenderer.setRenderers([this._renderer]);
    }
    _clearVisibleRange() {
        super._clearVisibleRange();
        this._histogramData.visibleRange = null;
    }
    _convertToCoordinates(priceScale, timeScale, firstValue) {
        if (this._itemsVisibleRange === null) {
            return;
        }
        const barSpacing = timeScale.barSpacing();
        const visibleBars = ensureNotNull(timeScale.visibleStrictRange());
        const histogramBase = priceScale.priceToCoordinate(this._series.options().base, firstValue);
        timeScale.indexesToCoordinates(this._histogramData.items);
        priceScale.pointsArrayToCoordinates(this._histogramData.items, firstValue);
        this._histogramData.histogramBase = histogramBase;
        this._histogramData.visibleRange = visibleTimedValues(this._histogramData.items, visibleBars, false);
        this._histogramData.barSpacing = barSpacing;
        this._renderer.setData(this._histogramData);
    }
}
