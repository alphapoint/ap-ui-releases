import { PaneRendererBars, } from '../../renderers/bars-renderer.js';
import { BarsPaneViewBase } from './bars-pane-view-base.js';
export class SeriesBarsPaneView extends BarsPaneViewBase {
    constructor() {
        super(...arguments);
        this._renderer = new PaneRendererBars();
    }
    renderer(height, width) {
        const barStyleProps = this._series.options();
        if (!barStyleProps.visible) {
            return null;
        }
        this._makeValid();
        const data = {
            bars: this._items,
            barSpacing: this._model.timeScale().barSpacing(),
            openVisible: barStyleProps.openVisible,
            thinBars: barStyleProps.thinBars,
            visibleRange: this._itemsVisibleRange,
        };
        this._renderer.setData(data);
        return this._renderer;
    }
    _createRawItem(time, bar, colorer) {
        return {
            ...this._createDefaultItem(time, bar, colorer),
            color: colorer.barStyle(time).barColor,
        };
    }
}
