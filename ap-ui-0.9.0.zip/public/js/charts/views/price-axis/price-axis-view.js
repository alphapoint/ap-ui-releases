import { PriceAxisViewRenderer } from '../../renderers/price-axis-view-renderer.js';
export class PriceAxisView {
    constructor(ctor) {
        this._commonRendererData = {
            coordinate: 0,
            color: '#FFF',
            background: '#000',
        };
        this._axisRendererData = {
            text: '',
            visible: false,
            tickVisible: true,
            moveTextToInvisibleTick: false,
            borderColor: '',
        };
        this._paneRendererData = {
            text: '',
            visible: false,
            tickVisible: false,
            moveTextToInvisibleTick: true,
            borderColor: '',
        };
        this._invalidated = true;
        this._axisRenderer = new (ctor || PriceAxisViewRenderer)(this._axisRendererData, this._commonRendererData);
        this._paneRenderer = new (ctor || PriceAxisViewRenderer)(this._paneRendererData, this._commonRendererData);
    }
    text() {
        return this._axisRendererData.text;
    }
    coordinate() {
        this._updateRendererDataIfNeeded();
        return this._commonRendererData.coordinate;
    }
    update() {
        this._invalidated = true;
    }
    height(rendererOptions, useSecondLine = false) {
        return Math.max(this._axisRenderer.height(rendererOptions, useSecondLine), this._paneRenderer.height(rendererOptions, useSecondLine));
    }
    getFixedCoordinate() {
        return this._commonRendererData.fixedCoordinate || 0;
    }
    setFixedCoordinate(value) {
        this._commonRendererData.fixedCoordinate = value;
    }
    isVisible() {
        this._updateRendererDataIfNeeded();
        return this._axisRendererData.visible || this._paneRendererData.visible;
    }
    isAxisLabelVisible() {
        this._updateRendererDataIfNeeded();
        return this._axisRendererData.visible;
    }
    renderer(priceScale) {
        this._updateRendererDataIfNeeded();
        this._axisRendererData.tickVisible = this._axisRendererData.tickVisible && priceScale.options().drawTicks;
        this._paneRendererData.tickVisible = this._paneRendererData.tickVisible && priceScale.options().drawTicks;
        this._axisRenderer.setData(this._axisRendererData, this._commonRendererData);
        this._paneRenderer.setData(this._paneRendererData, this._commonRendererData);
        return this._axisRenderer;
    }
    paneRenderer() {
        this._updateRendererDataIfNeeded();
        this._axisRenderer.setData(this._axisRendererData, this._commonRendererData);
        this._paneRenderer.setData(this._paneRendererData, this._commonRendererData);
        return this._paneRenderer;
    }
    _updateRendererDataIfNeeded() {
        if (this._invalidated) {
            this._axisRendererData.tickVisible = true;
            this._paneRendererData.tickVisible = false;
            this._updateRendererData(this._axisRendererData, this._paneRendererData, this._commonRendererData);
        }
    }
}
