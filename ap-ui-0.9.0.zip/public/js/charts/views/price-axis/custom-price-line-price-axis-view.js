import { generateContrastColors } from '../../helpers/color.js';
import { PriceAxisView } from './price-axis-view.js';
export class CustomPriceLinePriceAxisView extends PriceAxisView {
    constructor(series, priceLine) {
        super();
        this._series = series;
        this._priceLine = priceLine;
    }
    _updateRendererData(axisRendererData, paneRendererData, commonData) {
        axisRendererData.visible = false;
        paneRendererData.visible = false;
        const options = this._priceLine.options();
        const labelVisible = options.axisLabelVisible;
        const showPaneLabel = options.title !== '';
        if (!labelVisible || !this._series.options().visible) {
            return;
        }
        const y = this._priceLine.yCoord();
        if (y === null) {
            return;
        }
        if (showPaneLabel) {
            paneRendererData.text = options.title;
            paneRendererData.visible = true;
        }
        paneRendererData.borderColor = this._series.model().options().layout.backgroundColor;
        axisRendererData.text = this._series.priceScale().formatPriceAbsolute(options.price);
        axisRendererData.visible = true;
        const colors = generateContrastColors(options.color);
        commonData.background = colors.background;
        commonData.color = colors.foreground;
        commonData.coordinate = y;
    }
}
