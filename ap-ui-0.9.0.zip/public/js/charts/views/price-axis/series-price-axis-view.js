import { generateContrastColors } from '../../helpers/color.js';
import { PriceAxisView } from './price-axis-view.js';
export class SeriesPriceAxisView extends PriceAxisView {
    constructor(source) {
        super();
        this._source = source;
    }
    _updateRendererData(axisRendererData, paneRendererData, commonRendererData) {
        axisRendererData.visible = false;
        paneRendererData.visible = false;
        const seriesOptions = this._source.options();
        if (!seriesOptions.visible) {
            return;
        }
        const showSeriesLastValue = seriesOptions.lastValueVisible;
        const showSymbolLabel = this._source.title() !== '';
        const showPriceAndPercentage = seriesOptions.seriesLastValueMode === 0;
        const lastValueData = this._source.lastValueData(false);
        if (lastValueData.noData) {
            return;
        }
        if (showSeriesLastValue) {
            axisRendererData.text = this._axisText(lastValueData, showSeriesLastValue, showPriceAndPercentage);
            axisRendererData.visible = axisRendererData.text.length !== 0;
        }
        if (showSymbolLabel || showPriceAndPercentage) {
            paneRendererData.text = this._paneText(lastValueData, showSeriesLastValue, showSymbolLabel, showPriceAndPercentage);
            paneRendererData.visible = paneRendererData.text.length > 0;
        }
        const lastValueColor = this._source.priceLineColor(lastValueData['color']);
        const colors = generateContrastColors(lastValueColor);
        commonRendererData.background = colors.background;
        commonRendererData.color = colors.foreground;
        commonRendererData.coordinate = lastValueData['coordinate'];
        paneRendererData.borderColor = this._source.model().options().layout.backgroundColor;
        axisRendererData.borderColor = lastValueColor;
    }
    _paneText(lastValue, showSeriesLastValue, showSymbolLabel, showPriceAndPercentage) {
        let result = '';
        const title = this._source.title();
        if (showSymbolLabel && title.length !== 0) {
            result += `${title} `;
        }
        if (showSeriesLastValue && showPriceAndPercentage) {
            result += this._source.priceScale().isPercentage() ?
                lastValue.formattedPriceAbsolute : lastValue.formattedPricePercentage;
        }
        return result.trim();
    }
    _axisText(lastValueData, showSeriesLastValue, showPriceAndPercentage) {
        if (!showSeriesLastValue) {
            return '';
        }
        if (!showPriceAndPercentage) {
            return lastValueData.text;
        }
        return this._source.priceScale().isPercentage() ?
            lastValueData.formattedPricePercentage : lastValueData.formattedPriceAbsolute;
    }
}
