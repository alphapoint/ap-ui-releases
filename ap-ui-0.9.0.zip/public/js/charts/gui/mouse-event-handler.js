import { ensure } from '../helpers/assertions.js';
import { mobileTouch } from './support-touch.js';
export class MouseEventHandler {
    constructor(target, handler, options) {
        this._clickCount = 0;
        this._clickTimeoutId = null;
        this._longTapTimeoutId = null;
        this._longTapActive = false;
        this._mouseMoveStartPosition = null;
        this._moveExceededManhattanDistance = false;
        this._cancelClick = false;
        this._unsubscribeOutsideEvents = null;
        this._unsubscribeMousemove = null;
        this._unsubscribeRoot = null;
        this._startPinchMiddlePoint = null;
        this._startPinchDistance = 0;
        this._pinchPrevented = false;
        this._preventDragProcess = false;
        this._mousePressed = false;
        this._target = target;
        this._handler = handler;
        this._options = options;
        this._init();
    }
    destroy() {
        if (this._unsubscribeOutsideEvents !== null) {
            this._unsubscribeOutsideEvents();
            this._unsubscribeOutsideEvents = null;
        }
        if (this._unsubscribeMousemove !== null) {
            this._unsubscribeMousemove();
            this._unsubscribeMousemove = null;
        }
        if (this._unsubscribeRoot !== null) {
            this._unsubscribeRoot();
            this._unsubscribeRoot = null;
        }
        this._clearLongTapTimeout();
        this._resetClickTimeout();
    }
    _mouseEnterHandler(enterEvent) {
        if (this._unsubscribeMousemove) {
            this._unsubscribeMousemove();
        }
        {
            const boundMouseMoveHandler = this._mouseMoveHandler.bind(this);
            this._unsubscribeMousemove = () => {
                this._target.removeEventListener('mousemove', boundMouseMoveHandler);
            };
            this._target.addEventListener('mousemove', boundMouseMoveHandler);
        }
        if (isTouchEvent(enterEvent)) {
            this._mouseMoveHandler(enterEvent);
        }
        const compatEvent = this._makeCompatEvent(enterEvent);
        this._processEvent(compatEvent, this._handler.mouseEnterEvent);
    }
    _resetClickTimeout() {
        if (this._clickTimeoutId !== null) {
            clearTimeout(this._clickTimeoutId);
        }
        this._clickCount = 0;
        this._clickTimeoutId = null;
    }
    _mouseMoveHandler(moveEvent) {
        if (this._mousePressed && !isTouchEvent(moveEvent)) {
            return;
        }
        const compatEvent = this._makeCompatEvent(moveEvent);
        this._processEvent(compatEvent, this._handler.mouseMoveEvent);
    }
    _mouseMoveWithDownHandler(moveEvent) {
        if ('button' in moveEvent && moveEvent.button !== 0) {
            return;
        }
        if (this._startPinchMiddlePoint !== null) {
            return;
        }
        const isTouch = isTouchEvent(moveEvent);
        if (this._preventDragProcess && isTouch) {
            return;
        }
        this._pinchPrevented = true;
        const compatEvent = this._makeCompatEvent(moveEvent);
        const startMouseMovePos = ensure(this._mouseMoveStartPosition);
        const xOffset = Math.abs(startMouseMovePos.x - compatEvent.pageX);
        const yOffset = Math.abs(startMouseMovePos.y - compatEvent.pageY);
        const moveExceededManhattanDistance = xOffset + yOffset > 5;
        if (!moveExceededManhattanDistance && isTouch) {
            return;
        }
        if (moveExceededManhattanDistance && !this._moveExceededManhattanDistance && isTouch) {
            const correctedXOffset = xOffset * 0.5;
            const isVertDrag = yOffset >= correctedXOffset && !this._options.treatVertTouchDragAsPageScroll;
            const isHorzDrag = correctedXOffset > yOffset && !this._options.treatHorzTouchDragAsPageScroll;
            if (!isVertDrag && !isHorzDrag) {
                this._preventDragProcess = true;
            }
        }
        if (moveExceededManhattanDistance) {
            this._moveExceededManhattanDistance = true;
            this._cancelClick = true;
            if (isTouch) {
                this._clearLongTapTimeout();
            }
        }
        if (!this._preventDragProcess) {
            this._processEvent(compatEvent, this._handler.pressedMouseMoveEvent);
            if (isTouch) {
                preventDefault(moveEvent);
            }
        }
    }
    _mouseUpHandler(mouseUpEvent) {
        if ('button' in mouseUpEvent && mouseUpEvent.button !== 0) {
            return;
        }
        const compatEvent = this._makeCompatEvent(mouseUpEvent);
        this._clearLongTapTimeout();
        this._mouseMoveStartPosition = null;
        this._mousePressed = false;
        if (this._unsubscribeRoot) {
            this._unsubscribeRoot();
            this._unsubscribeRoot = null;
        }
        if (isTouchEvent(mouseUpEvent)) {
            this._mouseLeaveHandler(mouseUpEvent);
        }
        this._processEvent(compatEvent, this._handler.mouseUpEvent);
        ++this._clickCount;
        if (this._clickTimeoutId && this._clickCount > 1) {
            this._processEvent(compatEvent, this._handler.mouseDoubleClickEvent);
            this._resetClickTimeout();
        }
        else {
            if (!this._cancelClick) {
                this._processEvent(compatEvent, this._handler.mouseClickEvent);
            }
        }
        if (isTouchEvent(mouseUpEvent)) {
            preventDefault(mouseUpEvent);
            this._mouseLeaveHandler(mouseUpEvent);
            if (mouseUpEvent.touches.length === 0) {
                this._longTapActive = false;
            }
        }
    }
    _clearLongTapTimeout() {
        if (this._longTapTimeoutId === null) {
            return;
        }
        clearTimeout(this._longTapTimeoutId);
        this._longTapTimeoutId = null;
    }
    _mouseDownHandler(downEvent) {
        if ('button' in downEvent && downEvent.button !== 0) {
            return;
        }
        const compatEvent = this._makeCompatEvent(downEvent);
        this._cancelClick = false;
        this._moveExceededManhattanDistance = false;
        this._preventDragProcess = false;
        if (isTouchEvent(downEvent)) {
            this._mouseEnterHandler(downEvent);
        }
        this._mouseMoveStartPosition = {
            x: compatEvent.pageX,
            y: compatEvent.pageY,
        };
        if (this._unsubscribeRoot) {
            this._unsubscribeRoot();
            this._unsubscribeRoot = null;
        }
        {
            const boundMouseMoveWithDownHandler = this._mouseMoveWithDownHandler.bind(this);
            const boundMouseUpHandler = this._mouseUpHandler.bind(this);
            const rootElement = this._target.ownerDocument.documentElement;
            this._unsubscribeRoot = () => {
                rootElement.removeEventListener('touchmove', boundMouseMoveWithDownHandler);
                rootElement.removeEventListener('touchend', boundMouseUpHandler);
                rootElement.removeEventListener('mousemove', boundMouseMoveWithDownHandler);
                rootElement.removeEventListener('mouseup', boundMouseUpHandler);
            };
            rootElement.addEventListener('touchmove', boundMouseMoveWithDownHandler, { passive: false });
            rootElement.addEventListener('touchend', boundMouseUpHandler, { passive: false });
            this._clearLongTapTimeout();
            if (isTouchEvent(downEvent) && downEvent.touches.length === 1) {
                this._longTapTimeoutId = setTimeout(this._longTapHandler.bind(this, downEvent), 240);
            }
            else {
                rootElement.addEventListener('mousemove', boundMouseMoveWithDownHandler);
                rootElement.addEventListener('mouseup', boundMouseUpHandler);
            }
        }
        this._mousePressed = true;
        this._processEvent(compatEvent, this._handler.mouseDownEvent);
        if (!this._clickTimeoutId) {
            this._clickCount = 0;
            this._clickTimeoutId = setTimeout(this._resetClickTimeout.bind(this), 500);
        }
    }
    _init() {
        this._target.addEventListener('mouseenter', this._mouseEnterHandler.bind(this));
        this._target.addEventListener('touchcancel', this._clearLongTapTimeout.bind(this));
        {
            const doc = this._target.ownerDocument;
            const outsideHandler = (event) => {
                if (!this._handler.mouseDownOutsideEvent) {
                    return;
                }
                if (event.composed && this._target.contains(event.composedPath()[0])) {
                    return;
                }
                if (event.target && this._target.contains(event.target)) {
                    return;
                }
                this._handler.mouseDownOutsideEvent();
            };
            this._unsubscribeOutsideEvents = () => {
                doc.removeEventListener('mousedown', outsideHandler);
                doc.removeEventListener('touchstart', outsideHandler);
            };
            doc.addEventListener('mousedown', outsideHandler);
            doc.addEventListener('touchstart', outsideHandler, { passive: true });
        }
        this._target.addEventListener('mouseleave', this._mouseLeaveHandler.bind(this));
        this._target.addEventListener('touchstart', this._mouseDownHandler.bind(this), { passive: true });
        if (!mobileTouch) {
            this._target.addEventListener('mousedown', this._mouseDownHandler.bind(this));
        }
        this._initPinch();
        this._target.addEventListener('touchmove', () => { }, { passive: false });
    }
    _initPinch() {
        if (this._handler.pinchStartEvent === undefined &&
            this._handler.pinchEvent === undefined &&
            this._handler.pinchEndEvent === undefined) {
            return;
        }
        this._target.addEventListener('touchstart', (event) => this._checkPinchState(event.touches), { passive: true });
        this._target.addEventListener('touchmove', (event) => {
            if (event.touches.length !== 2 || this._startPinchMiddlePoint === null) {
                return;
            }
            if (this._handler.pinchEvent !== undefined) {
                const currentDistance = getDistance(event.touches[0], event.touches[1]);
                const scale = currentDistance / this._startPinchDistance;
                this._handler.pinchEvent(this._startPinchMiddlePoint, scale);
                preventDefault(event);
            }
        }, { passive: false });
        this._target.addEventListener('touchend', (event) => {
            this._checkPinchState(event.touches);
        });
    }
    _checkPinchState(touches) {
        if (touches.length === 1) {
            this._pinchPrevented = false;
        }
        if (touches.length !== 2 || this._pinchPrevented || this._longTapActive) {
            this._stopPinch();
        }
        else {
            this._startPinch(touches);
        }
    }
    _startPinch(touches) {
        const box = getBoundingClientRect(this._target);
        this._startPinchMiddlePoint = {
            x: ((touches[0].clientX - box.left) + (touches[1].clientX - box.left)) / 2,
            y: ((touches[0].clientY - box.top) + (touches[1].clientY - box.top)) / 2,
        };
        this._startPinchDistance = getDistance(touches[0], touches[1]);
        if (this._handler.pinchStartEvent !== undefined) {
            this._handler.pinchStartEvent();
        }
        this._clearLongTapTimeout();
    }
    _stopPinch() {
        if (this._startPinchMiddlePoint === null) {
            return;
        }
        this._startPinchMiddlePoint = null;
        if (this._handler.pinchEndEvent !== undefined) {
            this._handler.pinchEndEvent();
        }
    }
    _mouseLeaveHandler(event) {
        if (this._unsubscribeMousemove) {
            this._unsubscribeMousemove();
        }
        const compatEvent = this._makeCompatEvent(event);
        this._processEvent(compatEvent, this._handler.mouseLeaveEvent);
    }
    _longTapHandler(event) {
        const compatEvent = this._makeCompatEvent(event);
        this._processEvent(compatEvent, this._handler.longTapEvent);
        this._cancelClick = true;
        this._longTapActive = true;
    }
    _processEvent(event, callback) {
        if (!callback) {
            return;
        }
        callback.call(this._handler, event);
    }
    _makeCompatEvent(event) {
        let eventLike;
        if ('touches' in event && event.touches.length) {
            eventLike = event.touches[0];
        }
        else if ('changedTouches' in event && event.changedTouches.length) {
            eventLike = event.changedTouches[0];
        }
        else {
            eventLike = event;
        }
        const box = getBoundingClientRect(this._target);
        return {
            clientX: eventLike.clientX,
            clientY: eventLike.clientY,
            pageX: eventLike.pageX,
            pageY: eventLike.pageY,
            screenX: eventLike.screenX,
            screenY: eventLike.screenY,
            localX: eventLike.clientX - box.left,
            localY: eventLike.clientY - box.top,
            ctrlKey: event.ctrlKey,
            altKey: event.altKey,
            shiftKey: event.shiftKey,
            metaKey: event.metaKey,
            type: event.type.startsWith('mouse') ? 'mouse' : 'touch',
            view: event.view,
        };
    }
}
function getBoundingClientRect(element) {
    return element.getBoundingClientRect() || new DOMRect();
}
function getDistance(p1, p2) {
    const xDiff = p1.clientX - p2.clientX;
    const yDiff = p1.clientY - p2.clientY;
    return Math.sqrt(xDiff * xDiff + yDiff * yDiff);
}
function isTouchEvent(event) {
    return Boolean(event.touches);
}
function preventDefault(event) {
    if (event.cancelable) {
        event.preventDefault();
    }
}
