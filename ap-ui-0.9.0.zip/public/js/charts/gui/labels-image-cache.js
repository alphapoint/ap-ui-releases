import { createPreconfiguredCanvas, getCanvasDevicePixelRatio, getContext2D, Size } from './canvas-utils.js';
import { ensureDefined } from '../helpers/assertions.js';
import { drawScaled } from '../helpers/canvas-helpers.js';
import { makeFont } from '../helpers/make-font.js';
import { ceiledEven } from '../helpers/mathex.js';
import { TextWidthCache } from '../model/text-width-cache.js';
const MAX_COUNT = 200;
export class LabelsImageCache {
    constructor(fontSize, color, fontFamily, fontStyle) {
        this._textWidthCache = new TextWidthCache(MAX_COUNT);
        this._fontSize = 0;
        this._color = '';
        this._font = '';
        this._keys = [];
        this._hash = new Map();
        this._fontSize = fontSize;
        this._color = color;
        this._font = makeFont(fontSize, fontFamily, fontStyle);
    }
    destroy() {
        this._textWidthCache.reset();
        this._keys = [];
        this._hash.clear();
    }
    paintTo(ctx, text, x, y, align) {
        const label = this._getLabelImage(ctx, text);
        if (align !== 'left') {
            const pixelRatio = getCanvasDevicePixelRatio(ctx.canvas);
            x -= Math.floor(label.textWidth * pixelRatio);
        }
        y -= Math.floor(label.height / 2);
        ctx.drawImage(label.canvas, x, y, label.width, label.height);
    }
    _getLabelImage(ctx, text) {
        let item;
        if (this._hash.has(text)) {
            item = ensureDefined(this._hash.get(text));
        }
        else {
            if (this._keys.length >= MAX_COUNT) {
                const key = ensureDefined(this._keys.shift());
                this._hash.delete(key);
            }
            const pixelRatio = getCanvasDevicePixelRatio(ctx.canvas);
            const margin = Math.ceil(this._fontSize / 4.5);
            const baselineOffset = Math.round(this._fontSize / 10);
            const textWidth = Math.ceil(this._textWidthCache.measureText(ctx, text));
            const width = ceiledEven(Math.round(textWidth + margin * 2));
            const height = ceiledEven(this._fontSize + margin * 2);
            const canvas = createPreconfiguredCanvas(document, new Size(width, height));
            item = {
                text: text,
                textWidth: Math.round(Math.max(1, textWidth)),
                width: Math.ceil(width * pixelRatio),
                height: Math.ceil(height * pixelRatio),
                canvas: canvas,
            };
            if (textWidth !== 0) {
                this._keys.push(item.text);
                this._hash.set(item.text, item);
            }
            ctx = getContext2D(item.canvas);
            drawScaled(ctx, pixelRatio, () => {
                ctx.font = this._font;
                ctx.fillStyle = this._color;
                ctx.fillText(text, 0, height - margin - baselineOffset);
            });
        }
        return item;
    }
}
