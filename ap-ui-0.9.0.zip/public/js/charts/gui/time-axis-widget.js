import { clearRect, drawScaled } from '../helpers/canvas-helpers.js';
import { makeFont } from '../helpers/make-font.js';
import { TextWidthCache } from '../model/text-width-cache.js';
import { createBoundCanvas, getContext2D, Size } from './canvas-utils.js';
import { MouseEventHandler } from './mouse-event-handler.js';
import { PriceAxisStub } from './price-axis-stub.js';
function markWithGreaterWeight(a, b) {
    return a.weight > b.weight ? a : b;
}
export class TimeAxisWidget {
    constructor(chartWidget) {
        this._leftStub = null;
        this._rightStub = null;
        this._rendererOptions = null;
        this._mouseDown = false;
        this._size = new Size(0, 0);
        this._canvasConfiguredHandler = () => this._chart.model().lightUpdate();
        this._topCanvasConfiguredHandler = () => this._chart.model().lightUpdate();
        this._chart = chartWidget;
        this._options = chartWidget.options().layout;
        this._element = document.createElement('tr');
        this._leftStubCell = document.createElement('td');
        this._leftStubCell.style.padding = '0';
        this._rightStubCell = document.createElement('td');
        this._rightStubCell.style.padding = '0';
        this._cell = document.createElement('td');
        this._cell.style.height = '25px';
        this._cell.style.padding = '0';
        this._dv = document.createElement('div');
        this._dv.style.width = '100%';
        this._dv.style.height = '100%';
        this._dv.style.position = 'relative';
        this._dv.style.overflow = 'hidden';
        this._cell.appendChild(this._dv);
        this._canvasBinding = createBoundCanvas(this._dv, new Size(16, 16));
        this._canvasBinding.subscribeCanvasConfigured(this._canvasConfiguredHandler);
        const canvas = this._canvasBinding.canvas;
        canvas.style.position = 'absolute';
        canvas.style.zIndex = '1';
        canvas.style.left = '0';
        canvas.style.top = '0';
        this._topCanvasBinding = createBoundCanvas(this._dv, new Size(16, 16));
        this._topCanvasBinding.subscribeCanvasConfigured(this._topCanvasConfiguredHandler);
        const topCanvas = this._topCanvasBinding.canvas;
        topCanvas.style.position = 'absolute';
        topCanvas.style.zIndex = '2';
        topCanvas.style.left = '0';
        topCanvas.style.top = '0';
        this._element.appendChild(this._leftStubCell);
        this._element.appendChild(this._cell);
        this._element.appendChild(this._rightStubCell);
        this._recreateStubs();
        this._chart.model().priceScalesOptionsChanged().subscribe(this._recreateStubs.bind(this), this);
        this._mouseEventHandler = new MouseEventHandler(this._topCanvasBinding.canvas, this, {
            treatVertTouchDragAsPageScroll: true,
            treatHorzTouchDragAsPageScroll: false,
        });
    }
    destroy() {
        this._mouseEventHandler.destroy();
        if (this._leftStub !== null) {
            this._leftStub.destroy();
        }
        if (this._rightStub !== null) {
            this._rightStub.destroy();
        }
        this._topCanvasBinding.unsubscribeCanvasConfigured(this._topCanvasConfiguredHandler);
        this._topCanvasBinding.destroy();
        this._canvasBinding.unsubscribeCanvasConfigured(this._canvasConfiguredHandler);
        this._canvasBinding.destroy();
    }
    getElement() {
        return this._element;
    }
    leftStub() {
        return this._leftStub;
    }
    rightStub() {
        return this._rightStub;
    }
    mouseDownEvent(event) {
        if (this._mouseDown) {
            return;
        }
        this._mouseDown = true;
        const model = this._chart.model();
        if (model.timeScale().isEmpty() || !this._chart.options().handleScale.axisPressedMouseMove.time) {
            return;
        }
        model.startScaleTime(event.localX);
    }
    mouseDownOutsideEvent() {
        const model = this._chart.model();
        if (!model.timeScale().isEmpty() && this._mouseDown) {
            this._mouseDown = false;
            if (this._chart.options().handleScale.axisPressedMouseMove.time) {
                model.endScaleTime();
            }
        }
    }
    pressedMouseMoveEvent(event) {
        const model = this._chart.model();
        if (model.timeScale().isEmpty() || !this._chart.options().handleScale.axisPressedMouseMove.time) {
            return;
        }
        model.scaleTimeTo(event.localX);
    }
    mouseUpEvent(event) {
        this._mouseDown = false;
        const model = this._chart.model();
        if (model.timeScale().isEmpty() && !this._chart.options().handleScale.axisPressedMouseMove.time) {
            return;
        }
        model.endScaleTime();
    }
    mouseDoubleClickEvent() {
        if (this._chart.options().handleScale.axisDoubleClickReset) {
            this._chart.model().resetTimeScale();
        }
    }
    mouseEnterEvent(e) {
        if (this._chart.model().options().handleScale.axisPressedMouseMove.time) {
            this._setCursor(1);
        }
    }
    mouseLeaveEvent(e) {
        this._setCursor(0);
    }
    getSize() {
        return this._size;
    }
    setSizes(timeAxisSize, leftStubWidth, rightStubWidth) {
        if (!this._size || !this._size.equals(timeAxisSize)) {
            this._size = timeAxisSize;
            this._canvasBinding.resizeCanvas({ width: timeAxisSize.w, height: timeAxisSize.h });
            this._topCanvasBinding.resizeCanvas({ width: timeAxisSize.w, height: timeAxisSize.h });
            this._cell.style.width = timeAxisSize.w + 'px';
            this._cell.style.height = timeAxisSize.h + 'px';
        }
        if (this._leftStub !== null) {
            this._leftStub.setSize(new Size(leftStubWidth, timeAxisSize.h));
        }
        if (this._rightStub !== null) {
            this._rightStub.setSize(new Size(rightStubWidth, timeAxisSize.h));
        }
    }
    optimalHeight() {
        const rendererOptions = this._getRendererOptions();
        return Math.ceil(rendererOptions.borderSize +
            rendererOptions.tickLength +
            rendererOptions.fontSize +
            rendererOptions.paddingTop +
            rendererOptions.paddingBottom);
    }
    update() {
        this._chart.model().timeScale().marks();
    }
    getImage() {
        return this._canvasBinding.canvas;
    }
    paint(type) {
        if (type === 0) {
            return;
        }
        if (type !== 1) {
            const ctx = getContext2D(this._canvasBinding.canvas);
            this._drawBackground(ctx, this._canvasBinding.pixelRatio);
            this._drawBorder(ctx, this._canvasBinding.pixelRatio);
            this._drawTickMarks(ctx, this._canvasBinding.pixelRatio);
            if (this._leftStub !== null) {
                this._leftStub.paint(type);
            }
            if (this._rightStub !== null) {
                this._rightStub.paint(type);
            }
        }
        const topCtx = getContext2D(this._topCanvasBinding.canvas);
        const pixelRatio = this._topCanvasBinding.pixelRatio;
        topCtx.clearRect(0, 0, Math.ceil(this._size.w * pixelRatio), Math.ceil(this._size.h * pixelRatio));
        this._drawLabels([this._chart.model().crosshairSource()], topCtx, pixelRatio);
    }
    _drawBackground(ctx, pixelRatio) {
        drawScaled(ctx, pixelRatio, () => {
            clearRect(ctx, 0, 0, this._size.w, this._size.h, this._backgroundColor());
        });
    }
    _drawBorder(ctx, pixelRatio) {
        if (this._chart.options().timeScale.borderVisible) {
            ctx.save();
            ctx.fillStyle = this._lineColor();
            const borderSize = Math.max(1, Math.floor(this._getRendererOptions().borderSize * pixelRatio));
            ctx.fillRect(0, 0, Math.ceil(this._size.w * pixelRatio), borderSize);
            ctx.restore();
        }
    }
    _drawTickMarks(ctx, pixelRatio) {
        const tickMarks = this._chart.model().timeScale().marks();
        if (!tickMarks || tickMarks.length === 0) {
            return;
        }
        let maxWeight = tickMarks.reduce(markWithGreaterWeight, tickMarks[0]).weight;
        if (maxWeight > 30 && maxWeight < 40) {
            maxWeight = 30;
        }
        ctx.save();
        ctx.strokeStyle = this._lineColor();
        const rendererOptions = this._getRendererOptions();
        const yText = (rendererOptions.borderSize +
            rendererOptions.tickLength +
            rendererOptions.paddingTop +
            rendererOptions.fontSize -
            rendererOptions.baselineOffset);
        ctx.textAlign = 'center';
        ctx.fillStyle = this._lineColor();
        const borderSize = Math.floor(this._getRendererOptions().borderSize * pixelRatio);
        const tickWidth = Math.max(1, Math.floor(pixelRatio));
        const tickOffset = Math.floor(pixelRatio * 0.5);
        if (this._chart.model().timeScale().options().borderVisible) {
            ctx.beginPath();
            const tickLen = Math.round(rendererOptions.tickLength * pixelRatio);
            for (let index = tickMarks.length; index--;) {
                const x = Math.round(tickMarks[index].coord * pixelRatio);
                ctx.rect(x - tickOffset, borderSize, tickWidth, tickLen);
            }
            ctx.fill();
        }
        ctx.fillStyle = this._textColor();
        drawScaled(ctx, pixelRatio, () => {
            ctx.font = this._baseFont();
            for (const tickMark of tickMarks) {
                if (tickMark.weight < maxWeight) {
                    ctx.fillText(tickMark.label, tickMark.coord, yText);
                }
            }
            ctx.font = this._baseBoldFont();
            for (const tickMark of tickMarks) {
                if (tickMark.weight >= maxWeight) {
                    ctx.fillText(tickMark.label, tickMark.coord, yText);
                }
            }
        });
    }
    _drawLabels(sources, ctx, pixelRatio) {
        const rendererOptions = this._getRendererOptions();
        for (const source of sources) {
            for (const view of source.timeAxisViews()) {
                ctx.save();
                view.renderer().draw(ctx, rendererOptions, pixelRatio);
                ctx.restore();
            }
        }
    }
    _backgroundColor() {
        return this._options.backgroundColor;
    }
    _lineColor() {
        return this._chart.options().timeScale.borderColor;
    }
    _textColor() {
        return this._options.textColor;
    }
    _fontSize() {
        return this._options.fontSize;
    }
    _baseFont() {
        return makeFont(this._fontSize(), this._options.fontFamily);
    }
    _baseBoldFont() {
        return makeFont(this._fontSize(), this._options.fontFamily, 'bold');
    }
    _getRendererOptions() {
        if (this._rendererOptions === null) {
            this._rendererOptions = {
                borderSize: 1,
                baselineOffset: NaN,
                paddingTop: NaN,
                paddingBottom: NaN,
                paddingHorizontal: NaN,
                tickLength: 3,
                fontSize: NaN,
                font: '',
                widthCache: new TextWidthCache(),
            };
        }
        const rendererOptions = this._rendererOptions;
        const newFont = this._baseFont();
        if (rendererOptions.font !== newFont) {
            const fontSize = this._fontSize();
            rendererOptions.fontSize = fontSize;
            rendererOptions.font = newFont;
            rendererOptions.paddingTop = Math.ceil(fontSize / 2.5);
            rendererOptions.paddingBottom = rendererOptions.paddingTop;
            rendererOptions.paddingHorizontal = Math.ceil(fontSize / 2);
            rendererOptions.baselineOffset = Math.round(this._fontSize() / 5);
            rendererOptions.widthCache.reset();
        }
        return this._rendererOptions;
    }
    _setCursor(type) {
        this._cell.style.cursor = type === 1 ? 'ew-resize' : 'default';
    }
    _recreateStubs() {
        const model = this._chart.model();
        const options = model.options();
        if (!options.leftPriceScale.visible && this._leftStub !== null) {
            this._leftStubCell.removeChild(this._leftStub.getElement());
            this._leftStub.destroy();
            this._leftStub = null;
        }
        if (!options.rightPriceScale.visible && this._rightStub !== null) {
            this._rightStubCell.removeChild(this._rightStub.getElement());
            this._rightStub.destroy();
            this._rightStub = null;
        }
        const rendererOptionsProvider = this._chart.model().rendererOptionsProvider();
        const params = {
            rendererOptionsProvider: rendererOptionsProvider,
        };
        if (options.leftPriceScale.visible && this._leftStub === null) {
            const borderVisibleGetter = () => {
                return options.leftPriceScale.borderVisible && model.timeScale().options().borderVisible;
            };
            this._leftStub = new PriceAxisStub('left', this._chart.options(), params, borderVisibleGetter);
            this._leftStubCell.appendChild(this._leftStub.getElement());
        }
        if (options.rightPriceScale.visible && this._rightStub === null) {
            const borderVisibleGetter = () => {
                return options.rightPriceScale.borderVisible && model.timeScale().options().borderVisible;
            };
            this._rightStub = new PriceAxisStub('right', this._chart.options(), params, borderVisibleGetter);
            this._rightStubCell.appendChild(this._rightStub.getElement());
        }
    }
}
