const defaultBindingOptions = {
    allowDownsampling: true,
};
export function bindToDevicePixelRatio(canvas, options = defaultBindingOptions) {
    return new DevicePixelRatioBinding(canvas, options);
}
class DevicePixelRatioBinding {
    constructor(canvas, options) {
        this._resolutionMediaQueryList = null;
        this._resolutionListener = (ev) => this._onResolutionChanged();
        this._canvasConfiguredListeners = [];
        this.canvas = canvas;
        this._canvasSize = {
            width: this.canvas.clientWidth,
            height: this.canvas.clientHeight,
        };
        this._options = options;
        this._configureCanvas();
        this._installResolutionListener();
    }
    destroy() {
        this._canvasConfiguredListeners.length = 0;
        this._uninstallResolutionListener();
        this.canvas = null;
    }
    get canvasSize() {
        return {
            width: this._canvasSize.width,
            height: this._canvasSize.height,
        };
    }
    resizeCanvas(size) {
        this._canvasSize = {
            width: size.width,
            height: size.height,
        };
        this._configureCanvas();
    }
    get pixelRatio() {
        const win = this.canvas.ownerDocument.defaultView;
        if (win == null) {
            throw new Error('No window is associated with the canvas');
        }
        return win.devicePixelRatio > 1 || this._options.allowDownsampling ? win.devicePixelRatio : 1;
    }
    subscribeCanvasConfigured(listener) {
        this._canvasConfiguredListeners.push(listener);
    }
    unsubscribeCanvasConfigured(listener) {
        this._canvasConfiguredListeners = this._canvasConfiguredListeners.filter(l => l != listener);
    }
    _configureCanvas() {
        const ratio = this.pixelRatio;
        this.canvas.style.width = `${this._canvasSize.width}px`;
        this.canvas.style.height = `${this._canvasSize.height}px`;
        this.canvas.width = this._canvasSize.width * ratio;
        this.canvas.height = this._canvasSize.height * ratio;
        this._emitCanvasConfigured();
    }
    _emitCanvasConfigured() {
        this._canvasConfiguredListeners.forEach(listener => listener.call(this));
    }
    _installResolutionListener() {
        if (this._resolutionMediaQueryList !== null) {
            throw new Error('Resolution listener is already installed');
        }
        const win = this.canvas.ownerDocument.defaultView;
        if (win == null) {
            throw new Error('No window is associated with the canvas');
        }
        const dppx = win.devicePixelRatio;
        this._resolutionMediaQueryList = win.matchMedia(`all and (resolution: ${dppx}dppx)`);
        this._resolutionMediaQueryList.addListener(this._resolutionListener);
    }
    _uninstallResolutionListener() {
        if (this._resolutionMediaQueryList !== null) {
            this._resolutionMediaQueryList.removeListener(this._resolutionListener);
            this._resolutionMediaQueryList = null;
        }
    }
    _reinstallResolutionListener() {
        this._uninstallResolutionListener();
        this._installResolutionListener();
    }
    _onResolutionChanged() {
        this._configureCanvas();
        this._reinstallResolutionListener();
    }
}
