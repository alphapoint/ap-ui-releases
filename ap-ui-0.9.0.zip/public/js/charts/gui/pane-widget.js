import { ensureNotNull } from '../helpers/assertions.js';
import { clearRect, drawScaled } from '../helpers/canvas-helpers.js';
import { Delegate } from '../helpers/delegate.js';
import { createBoundCanvas, getContext2D, Size } from './canvas-utils.js';
import { MouseEventHandler } from './mouse-event-handler.js';
import { PriceAxisWidget } from './price-axis-widget.js';
import { isMobile, mobileTouch } from './support-touch.js';
const trackCrosshairOnlyAfterLongTap = isMobile;
export class PaneWidget {
    constructor(chart, state) {
        this._size = new Size(0, 0);
        this._leftPriceAxisWidget = null;
        this._rightPriceAxisWidget = null;
        this._startScrollingPos = null;
        this._isScrolling = false;
        this._clicked = new Delegate();
        this._prevPinchScale = 0;
        this._longTap = false;
        this._startTrackPoint = null;
        this._exitTrackingModeOnNextTry = false;
        this._initCrosshairPosition = null;
        this._canvasConfiguredHandler = () => this._state && this._model().lightUpdate();
        this._topCanvasConfiguredHandler = () => this._state && this._model().lightUpdate();
        this._chart = chart;
        this._state = state;
        this._state.onDestroyed().subscribe(this._onStateDestroyed.bind(this), this, true);
        this._paneCell = document.createElement('td');
        this._paneCell.style.padding = '0';
        this._paneCell.style.position = 'relative';
        const paneWrapper = document.createElement('div');
        paneWrapper.style.width = '100%';
        paneWrapper.style.height = '100%';
        paneWrapper.style.position = 'relative';
        paneWrapper.style.overflow = 'hidden';
        this._leftAxisCell = document.createElement('td');
        this._leftAxisCell.style.padding = '0';
        this._rightAxisCell = document.createElement('td');
        this._rightAxisCell.style.padding = '0';
        this._paneCell.appendChild(paneWrapper);
        this._canvasBinding = createBoundCanvas(paneWrapper, new Size(16, 16));
        this._canvasBinding.subscribeCanvasConfigured(this._canvasConfiguredHandler);
        const canvas = this._canvasBinding.canvas;
        canvas.style.position = 'absolute';
        canvas.style.zIndex = '1';
        canvas.style.left = '0';
        canvas.style.top = '0';
        this._topCanvasBinding = createBoundCanvas(paneWrapper, new Size(16, 16));
        this._topCanvasBinding.subscribeCanvasConfigured(this._topCanvasConfiguredHandler);
        const topCanvas = this._topCanvasBinding.canvas;
        topCanvas.style.position = 'absolute';
        topCanvas.style.zIndex = '2';
        topCanvas.style.left = '0';
        topCanvas.style.top = '0';
        this._rowElement = document.createElement('tr');
        this._rowElement.appendChild(this._leftAxisCell);
        this._rowElement.appendChild(this._paneCell);
        this._rowElement.appendChild(this._rightAxisCell);
        this.updatePriceAxisWidgets();
        const scrollOptions = this.chart().options().handleScroll;
        this._mouseEventHandler = new MouseEventHandler(this._topCanvasBinding.canvas, this, {
            treatVertTouchDragAsPageScroll: !scrollOptions.vertTouchDrag,
            treatHorzTouchDragAsPageScroll: !scrollOptions.horzTouchDrag,
        });
    }
    destroy() {
        if (this._leftPriceAxisWidget !== null) {
            this._leftPriceAxisWidget.destroy();
        }
        if (this._rightPriceAxisWidget !== null) {
            this._rightPriceAxisWidget.destroy();
        }
        this._topCanvasBinding.unsubscribeCanvasConfigured(this._topCanvasConfiguredHandler);
        this._topCanvasBinding.destroy();
        this._canvasBinding.unsubscribeCanvasConfigured(this._canvasConfiguredHandler);
        this._canvasBinding.destroy();
        if (this._state !== null) {
            this._state.onDestroyed().unsubscribeAll(this);
        }
        this._mouseEventHandler.destroy();
    }
    state() {
        return ensureNotNull(this._state);
    }
    setState(pane) {
        if (this._state !== null) {
            this._state.onDestroyed().unsubscribeAll(this);
        }
        this._state = pane;
        if (this._state !== null) {
            this._state.onDestroyed().subscribe(PaneWidget.prototype._onStateDestroyed.bind(this), this, true);
        }
        this.updatePriceAxisWidgets();
    }
    chart() {
        return this._chart;
    }
    getElement() {
        return this._rowElement;
    }
    updatePriceAxisWidgets() {
        if (this._state === null) {
            return;
        }
        this._recreatePriceAxisWidgets();
        if (this._model().serieses().length === 0) {
            return;
        }
        if (this._leftPriceAxisWidget !== null) {
            const leftPriceScale = this._state.leftPriceScale();
            this._leftPriceAxisWidget.setPriceScale(ensureNotNull(leftPriceScale));
        }
        if (this._rightPriceAxisWidget !== null) {
            const rightPriceScale = this._state.rightPriceScale();
            this._rightPriceAxisWidget.setPriceScale(ensureNotNull(rightPriceScale));
        }
    }
    stretchFactor() {
        return this._state !== null ? this._state.stretchFactor() : 0;
    }
    setStretchFactor(stretchFactor) {
        if (this._state) {
            this._state.setStretchFactor(stretchFactor);
        }
    }
    mouseEnterEvent(event) {
        if (!this._state) {
            return;
        }
        const x = event.localX;
        const y = event.localY;
        if (!mobileTouch) {
            this._setCrosshairPosition(x, y);
        }
    }
    mouseDownEvent(event) {
        this._longTap = false;
        this._exitTrackingModeOnNextTry = this._startTrackPoint !== null;
        if (!this._state) {
            return;
        }
        if (document.activeElement !== document.body && document.activeElement !== document.documentElement) {
            ensureNotNull(document.activeElement).blur();
        }
        else {
            const selection = document.getSelection();
            if (selection !== null) {
                selection.removeAllRanges();
            }
        }
        const model = this._model();
        const priceScale = this._state.defaultPriceScale();
        if (priceScale.isEmpty() || model.timeScale().isEmpty()) {
            return;
        }
        if (this._startTrackPoint !== null) {
            const crosshair = model.crosshairSource();
            this._initCrosshairPosition = { x: crosshair.appliedX(), y: crosshair.appliedY() };
            this._startTrackPoint = { x: event.localX, y: event.localY };
        }
        if (!mobileTouch) {
            this._setCrosshairPosition(event.localX, event.localY);
        }
    }
    mouseMoveEvent(event) {
        if (!this._state) {
            return;
        }
        const x = event.localX;
        const y = event.localY;
        if (this._preventCrosshairMove()) {
            this._clearCrosshairPosition();
        }
        if (!mobileTouch) {
            this._setCrosshairPosition(x, y);
            const hitTest = this.hitTest(x, y);
            this._model().setHoveredSource(hitTest && { source: hitTest.source, object: hitTest.object });
            if (hitTest !== null && hitTest.view.moveHandler !== undefined) {
                hitTest.view.moveHandler(x, y);
            }
        }
    }
    mouseClickEvent(event) {
        if (this._state === null) {
            return;
        }
        const x = event.localX;
        const y = event.localY;
        const hitTest = this.hitTest(x, y);
        if (hitTest !== null && hitTest.view.clickHandler !== undefined) {
            hitTest.view.clickHandler(x, y);
        }
        if (this._clicked.hasListeners()) {
            const currentTime = this._model().crosshairSource().appliedIndex();
            this._clicked.fire(currentTime, { x, y });
        }
        this._tryExitTrackingMode();
    }
    pressedMouseMoveEvent(event) {
        if (this._state === null) {
            return;
        }
        const model = this._model();
        const x = event.localX;
        const y = event.localY;
        if (this._startTrackPoint !== null) {
            this._exitTrackingModeOnNextTry = false;
            const origPoint = ensureNotNull(this._initCrosshairPosition);
            const newX = origPoint.x + (x - this._startTrackPoint.x);
            const newY = origPoint.y + (y - this._startTrackPoint.y);
            this._setCrosshairPosition(newX, newY);
        }
        else if (!this._preventCrosshairMove()) {
            this._setCrosshairPosition(x, y);
        }
        if (model.timeScale().isEmpty()) {
            return;
        }
        const scrollOptions = this._chart.options().handleScroll;
        if ((!scrollOptions.pressedMouseMove || event.type === 'touch') &&
            (!scrollOptions.horzTouchDrag && !scrollOptions.vertTouchDrag || event.type === 'mouse')) {
            return;
        }
        const priceScale = this._state.defaultPriceScale();
        if (this._startScrollingPos === null && !this._preventScroll()) {
            this._startScrollingPos = {
                x: event.clientX,
                y: event.clientY,
            };
        }
        if (this._startScrollingPos !== null &&
            (this._startScrollingPos.x !== event.clientX || this._startScrollingPos.y !== event.clientY)) {
            if (!this._isScrolling) {
                if (!priceScale.isEmpty()) {
                    model.startScrollPrice(this._state, priceScale, event.localY);
                }
                model.startScrollTime(event.localX);
                this._isScrolling = true;
            }
        }
        if (this._isScrolling) {
            if (!priceScale.isEmpty()) {
                model.scrollPriceTo(this._state, priceScale, event.localY);
            }
            model.scrollTimeTo(event.localX);
        }
    }
    mouseUpEvent(event) {
        if (this._state === null) {
            return;
        }
        this._longTap = false;
        const model = this._model();
        if (this._isScrolling) {
            const priceScale = this._state.defaultPriceScale();
            model.endScrollPrice(this._state, priceScale);
            model.endScrollTime();
            this._startScrollingPos = null;
            this._isScrolling = false;
        }
    }
    longTapEvent(event) {
        this._longTap = true;
        if (this._startTrackPoint === null && trackCrosshairOnlyAfterLongTap) {
            const point = { x: event.localX, y: event.localY };
            this._startTrackingMode(point, point);
        }
    }
    mouseLeaveEvent(event) {
        if (this._state === null) {
            return;
        }
        this._state.model().setHoveredSource(null);
        if (!isMobile) {
            this._clearCrosshairPosition();
        }
    }
    clicked() {
        return this._clicked;
    }
    pinchStartEvent() {
        this._prevPinchScale = 1;
    }
    pinchEvent(middlePoint, scale) {
        if (!this._chart.options().handleScale.pinch) {
            return;
        }
        const zoomScale = (scale - this._prevPinchScale) * 5;
        this._prevPinchScale = scale;
        this._model().zoomTime(middlePoint.x, zoomScale);
    }
    hitTest(x, y) {
        const state = this._state;
        if (state === null) {
            return null;
        }
        const sources = state.orderedSources();
        for (const source of sources) {
            const sourceResult = this._hitTestPaneView(source.paneViews(state), x, y);
            if (sourceResult !== null) {
                return {
                    source: source,
                    view: sourceResult.view,
                    object: sourceResult.object,
                };
            }
        }
        return null;
    }
    setPriceAxisSize(width, position) {
        const priceAxisWidget = position === 'left' ? this._leftPriceAxisWidget : this._rightPriceAxisWidget;
        ensureNotNull(priceAxisWidget).setSize(new Size(width, this._size.h));
    }
    getSize() {
        return this._size;
    }
    setSize(size) {
        if (size.w < 0 || size.h < 0) {
            throw new Error('Try to set invalid size to PaneWidget ' + JSON.stringify(size));
        }
        if (this._size.equals(size)) {
            return;
        }
        this._size = size;
        this._canvasBinding.resizeCanvas({ width: size.w, height: size.h });
        this._topCanvasBinding.resizeCanvas({ width: size.w, height: size.h });
        this._paneCell.style.width = size.w + 'px';
        this._paneCell.style.height = size.h + 'px';
    }
    recalculatePriceScales() {
        const pane = ensureNotNull(this._state);
        pane.recalculatePriceScale(pane.leftPriceScale());
        pane.recalculatePriceScale(pane.rightPriceScale());
        for (const source of pane.dataSources()) {
            if (pane.isOverlay(source)) {
                const priceScale = source.priceScale();
                if (priceScale !== null) {
                    pane.recalculatePriceScale(priceScale);
                }
                source.updateAllViews();
            }
        }
    }
    getImage() {
        return this._canvasBinding.canvas;
    }
    paint(type) {
        if (type === 0) {
            return;
        }
        if (this._state === null) {
            return;
        }
        if (type > 1) {
            this.recalculatePriceScales();
        }
        if (this._leftPriceAxisWidget !== null) {
            this._leftPriceAxisWidget.paint(type);
        }
        if (this._rightPriceAxisWidget !== null) {
            this._rightPriceAxisWidget.paint(type);
        }
        if (type !== 1) {
            const ctx = getContext2D(this._canvasBinding.canvas);
            ctx.save();
            this._drawBackground(ctx, this._backgroundColor(), this._canvasBinding.pixelRatio);
            if (this._state) {
                this._drawGrid(ctx, this._canvasBinding.pixelRatio);
                this._drawWatermark(ctx, this._canvasBinding.pixelRatio);
                this._drawSources(ctx, this._canvasBinding.pixelRatio);
            }
            ctx.restore();
        }
        const topCtx = getContext2D(this._topCanvasBinding.canvas);
        topCtx.clearRect(0, 0, Math.ceil(this._size.w * this._topCanvasBinding.pixelRatio), Math.ceil(this._size.h * this._topCanvasBinding.pixelRatio));
        this._drawCrosshair(topCtx, this._topCanvasBinding.pixelRatio);
    }
    leftPriceAxisWidget() {
        return this._leftPriceAxisWidget;
    }
    rightPriceAxisWidget() {
        return this._rightPriceAxisWidget;
    }
    _backgroundColor() {
        return this._chart.options().layout.backgroundColor;
    }
    _onStateDestroyed() {
        if (this._state !== null) {
            this._state.onDestroyed().unsubscribeAll(this);
        }
        this._state = null;
    }
    _drawBackground(ctx, color, pixelRatio) {
        drawScaled(ctx, pixelRatio, () => {
            clearRect(ctx, 0, 0, this._size.w, this._size.h, color);
        });
    }
    _drawGrid(ctx, pixelRatio) {
        const state = ensureNotNull(this._state);
        const paneView = state.grid().paneView();
        const renderer = paneView.renderer(state.height(), state.width());
        if (renderer !== null) {
            ctx.save();
            renderer.draw(ctx, pixelRatio, false);
            ctx.restore();
        }
    }
    _drawWatermark(ctx, pixelRatio) {
        const source = this._model().watermarkSource();
        this._drawSourceBackground(source, ctx, pixelRatio);
        this._drawSource(source, ctx, pixelRatio);
    }
    _drawCrosshair(ctx, pixelRatio) {
        this._drawSource(this._model().crosshairSource(), ctx, pixelRatio);
    }
    _drawSources(ctx, pixelRatio) {
        const state = ensureNotNull(this._state);
        const sources = state.orderedSources();
        for (const source of sources) {
            this._drawSourceBackground(source, ctx, pixelRatio);
        }
        for (const source of sources) {
            this._drawSource(source, ctx, pixelRatio);
        }
    }
    _drawSource(source, ctx, pixelRatio) {
        const state = ensureNotNull(this._state);
        const paneViews = source.paneViews(state);
        const height = state.height();
        const width = state.width();
        const hoveredSource = state.model().hoveredSource();
        const isHovered = hoveredSource !== null && hoveredSource.source === source;
        const objecId = hoveredSource !== null && isHovered && hoveredSource.object !== undefined
            ? hoveredSource.object.hitTestData
            : undefined;
        for (const paneView of paneViews) {
            const renderer = paneView.renderer(height, width);
            if (renderer !== null) {
                ctx.save();
                renderer.draw(ctx, pixelRatio, isHovered, objecId);
                ctx.restore();
            }
        }
    }
    _drawSourceBackground(source, ctx, pixelRatio) {
        const state = ensureNotNull(this._state);
        const paneViews = source.paneViews(state);
        const height = state.height();
        const width = state.width();
        const hoveredSource = state.model().hoveredSource();
        const isHovered = hoveredSource !== null && hoveredSource.source === source;
        const objecId = hoveredSource !== null && isHovered && hoveredSource.object !== undefined
            ? hoveredSource.object.hitTestData
            : undefined;
        for (const paneView of paneViews) {
            const renderer = paneView.renderer(height, width);
            if (renderer !== null && renderer.drawBackground !== undefined) {
                ctx.save();
                renderer.drawBackground(ctx, pixelRatio, isHovered, objecId);
                ctx.restore();
            }
        }
    }
    _hitTestPaneView(paneViews, x, y) {
        for (const paneView of paneViews) {
            const renderer = paneView.renderer(this._size.h, this._size.w);
            if (renderer !== null && renderer.hitTest) {
                const result = renderer.hitTest(x, y);
                if (result !== null) {
                    return {
                        view: paneView,
                        object: result,
                    };
                }
            }
        }
        return null;
    }
    _recreatePriceAxisWidgets() {
        if (this._state === null) {
            return;
        }
        const chart = this._chart;
        if (!chart.options().leftPriceScale.visible && this._leftPriceAxisWidget !== null) {
            this._leftAxisCell.removeChild(this._leftPriceAxisWidget.getElement());
            this._leftPriceAxisWidget.destroy();
            this._leftPriceAxisWidget = null;
        }
        if (!chart.options().rightPriceScale.visible && this._rightPriceAxisWidget !== null) {
            this._rightAxisCell.removeChild(this._rightPriceAxisWidget.getElement());
            this._rightPriceAxisWidget.destroy();
            this._rightPriceAxisWidget = null;
        }
        const rendererOptionsProvider = chart.model().rendererOptionsProvider();
        if (chart.options().leftPriceScale.visible && this._leftPriceAxisWidget === null) {
            this._leftPriceAxisWidget = new PriceAxisWidget(this, chart.options().layout, rendererOptionsProvider, 'left');
            this._leftAxisCell.appendChild(this._leftPriceAxisWidget.getElement());
        }
        if (chart.options().rightPriceScale.visible && this._rightPriceAxisWidget === null) {
            this._rightPriceAxisWidget = new PriceAxisWidget(this, chart.options().layout, rendererOptionsProvider, 'right');
            this._rightAxisCell.appendChild(this._rightPriceAxisWidget.getElement());
        }
    }
    _preventCrosshairMove() {
        return trackCrosshairOnlyAfterLongTap && this._startTrackPoint === null;
    }
    _preventScroll() {
        return trackCrosshairOnlyAfterLongTap && this._longTap || this._startTrackPoint !== null;
    }
    _correctXCoord(x) {
        return Math.max(0, Math.min(x, this._size.w - 1));
    }
    _correctYCoord(y) {
        return Math.max(0, Math.min(y, this._size.h - 1));
    }
    _setCrosshairPosition(x, y) {
        this._model().setAndSaveCurrentPosition(this._correctXCoord(x), this._correctYCoord(y), ensureNotNull(this._state));
    }
    _clearCrosshairPosition() {
        this._model().clearCurrentPosition();
    }
    _tryExitTrackingMode() {
        if (this._exitTrackingModeOnNextTry) {
            this._startTrackPoint = null;
            this._clearCrosshairPosition();
        }
    }
    _startTrackingMode(startTrackPoint, crossHairPosition) {
        this._startTrackPoint = startTrackPoint;
        this._exitTrackingModeOnNextTry = false;
        this._setCrosshairPosition(crossHairPosition.x, crossHairPosition.y);
        const crosshair = this._model().crosshairSource();
        this._initCrosshairPosition = { x: crosshair.appliedX(), y: crosshair.appliedY() };
    }
    _model() {
        return this._chart.model();
    }
}
