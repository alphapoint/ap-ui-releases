import { bindToDevicePixelRatio } from './coordinate-space.js';
import { ensureNotNull } from '../helpers/assertions.js';
export class Size {
    constructor(w, h) {
        this.w = w;
        this.h = h;
    }
    equals(size) {
        return (this.w === size.w) && (this.h === size.h);
    }
}
export function getCanvasDevicePixelRatio(canvas) {
    return canvas.ownerDocument &&
        canvas.ownerDocument.defaultView &&
        canvas.ownerDocument.defaultView.devicePixelRatio
        || 1;
}
export function getContext2D(canvas) {
    const ctx = ensureNotNull(canvas.getContext('2d'));
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    return ctx;
}
export function createPreconfiguredCanvas(doc, size) {
    const canvas = doc.createElement('canvas');
    const pixelRatio = getCanvasDevicePixelRatio(canvas);
    canvas.style.width = `${size.w}px`;
    canvas.style.height = `${size.h}px`;
    canvas.width = size.w * pixelRatio;
    canvas.height = size.h * pixelRatio;
    return canvas;
}
export function createBoundCanvas(parentElement, size) {
    const doc = ensureNotNull(parentElement.ownerDocument);
    const canvas = doc.createElement('canvas');
    parentElement.appendChild(canvas);
    const binding = bindToDevicePixelRatio(canvas);
    binding.resizeCanvas({
        width: size.w,
        height: size.h,
    });
    return binding;
}
export function drawScaled(ctx, ratio, func) {
    ctx.save();
    ctx.scale(ratio, ratio);
    func();
    ctx.restore();
}
