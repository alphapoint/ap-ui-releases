import { isRunningOnClientSide } from '../helpers/is-running-on-client-side.js';
function checkTouchEvents() {
    if (!isRunningOnClientSide) {
        return false;
    }
    if ('ontouchstart' in window) {
        return true;
    }
    return Boolean(window.DocumentTouch && document instanceof window.DocumentTouch);
}
function getMobileTouch() {
    if (!isRunningOnClientSide) {
        return false;
    }
    const touch = !!navigator.maxTouchPoints || !!navigator.msMaxTouchPoints || checkTouchEvents();
    return 'onorientationchange' in window && touch;
}
export const mobileTouch = getMobileTouch();
function getIsMobile() {
    if (!isRunningOnClientSide) {
        return false;
    }
    const android = /Android/i.test(navigator.userAgent);
    const iOS = /iPhone|iPad|iPod|AppleWebKit.+Mobile/i.test(navigator.userAgent);
    return android || iOS;
}
export const isMobile = getIsMobile();
