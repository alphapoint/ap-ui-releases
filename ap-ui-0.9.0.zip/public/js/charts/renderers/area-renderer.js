import { setLineStyle } from './draw-line.js';
import { ScaledRenderer } from './scaled-renderer.js';
import { walkLine } from './walk-line.js';
export class PaneRendererArea extends ScaledRenderer {
    constructor() {
        super(...arguments);
        this._data = null;
    }
    setData(data) {
        this._data = data;
    }
    _drawImpl(ctx) {
        if (this._data === null || this._data.items.length === 0 || this._data.visibleRange === null) {
            return;
        }
        ctx.lineCap = 'butt';
        ctx.strokeStyle = this._data.lineColor;
        ctx.lineWidth = this._data.lineWidth;
        setLineStyle(ctx, this._data.lineStyle);
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (this._data.items.length === 1) {
            const point = this._data.items[0];
            const halfBarWidth = this._data.barWidth / 2;
            ctx.moveTo(point.x - halfBarWidth, this._data.bottom);
            ctx.lineTo(point.x - halfBarWidth, point.y);
            ctx.lineTo(point.x + halfBarWidth, point.y);
            ctx.lineTo(point.x + halfBarWidth, this._data.bottom);
        }
        else {
            ctx.moveTo(this._data.items[this._data.visibleRange.from].x, this._data.bottom);
            ctx.lineTo(this._data.items[this._data.visibleRange.from].x, this._data.items[this._data.visibleRange.from].y);
            walkLine(ctx, this._data.items, this._data.lineType, this._data.visibleRange);
            if (this._data.visibleRange.to > this._data.visibleRange.from) {
                ctx.lineTo(this._data.items[this._data.visibleRange.to - 1].x, this._data.bottom);
                ctx.lineTo(this._data.items[this._data.visibleRange.from].x, this._data.bottom);
            }
        }
        ctx.closePath();
        const gradient = ctx.createLinearGradient(0, 0, 0, this._data.bottom);
        gradient.addColorStop(0, this._data.topColor);
        gradient.addColorStop(1, this._data.bottomColor);
        ctx.fillStyle = gradient;
        ctx.fill();
    }
}
