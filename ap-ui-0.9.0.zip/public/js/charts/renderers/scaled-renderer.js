export class ScaledRenderer {
    draw(ctx, pixelRatio, isHovered, hitTestData) {
        ctx.save();
        ctx.scale(pixelRatio, pixelRatio);
        this._drawImpl(ctx, isHovered, hitTestData);
        ctx.restore();
    }
    drawBackground(ctx, pixelRatio, isHovered, hitTestData) {
        ctx.save();
        ctx.scale(pixelRatio, pixelRatio);
        this._drawBackgroundImpl(ctx, isHovered, hitTestData);
        ctx.restore();
    }
    _drawBackgroundImpl(ctx, isHovered, hitTestData) {
    }
}
