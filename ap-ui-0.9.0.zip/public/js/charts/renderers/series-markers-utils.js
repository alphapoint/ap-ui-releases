import { ensureNever } from '../helpers/assertions.js';
import { ceiledEven, ceiledOdd } from '../helpers/mathex.js';
function size(barSpacing, coeff) {
    const result = Math.min(Math.max(barSpacing, 12), 30) * coeff;
    return ceiledOdd(result);
}
export function shapeSize(shape, originalSize) {
    switch (shape) {
        case 'arrowDown':
        case 'arrowUp':
            return size(originalSize, 1);
        case 'circle':
            return size(originalSize, 0.8);
        case 'square':
            return size(originalSize, 0.7);
    }
    ensureNever(shape);
}
export function calculateShapeHeight(barSpacing) {
    return ceiledEven(size(barSpacing, 1));
}
export function shapeMargin(barSpacing) {
    return Math.max(size(barSpacing, 0.1), 3);
}
