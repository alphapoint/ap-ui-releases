import { setLineStyle } from './draw-line.js';
import { ScaledRenderer } from './scaled-renderer.js';
import { walkLine } from './walk-line.js';
export class PaneRendererLine extends ScaledRenderer {
    constructor() {
        super(...arguments);
        this._data = null;
    }
    setData(data) {
        this._data = data;
    }
    _drawImpl(ctx) {
        if (this._data === null || this._data.items.length === 0 || this._data.visibleRange === null) {
            return;
        }
        ctx.lineCap = 'butt';
        ctx.lineWidth = this._data.lineWidth;
        setLineStyle(ctx, this._data.lineStyle);
        ctx.strokeStyle = this._data.lineColor;
        ctx.lineJoin = 'miter';
        ctx.beginPath();
        if (this._data.items.length === 1) {
            const point = this._data.items[0];
            ctx.moveTo(point.x - this._data.barWidth / 2, point.y);
            ctx.lineTo(point.x + this._data.barWidth / 2, point.y);
        }
        else {
            walkLine(ctx, this._data.items, this._data.lineType, this._data.visibleRange);
        }
        ctx.stroke();
    }
}
