import { ensureNotNull } from '../helpers/assertions.js';
import { setLineStyle, strokeInPixel } from './draw-line.js';
export class GridRenderer {
    constructor() {
        this._data = null;
    }
    setData(data) {
        this._data = data;
    }
    draw(ctx, pixelRatio, isHovered, hitTestData) {
        if (this._data === null) {
            return;
        }
        const lineWidth = Math.max(1, Math.floor(pixelRatio));
        ctx.lineWidth = lineWidth;
        const height = Math.ceil(this._data.h * pixelRatio);
        const width = Math.ceil(this._data.w * pixelRatio);
        strokeInPixel(ctx, () => {
            const data = ensureNotNull(this._data);
            if (data.vertLinesVisible) {
                ctx.strokeStyle = data.vertLinesColor;
                setLineStyle(ctx, data.vertLineStyle);
                ctx.beginPath();
                for (const timeMark of data.timeMarks) {
                    const x = Math.round(timeMark.coord * pixelRatio);
                    ctx.moveTo(x, -lineWidth);
                    ctx.lineTo(x, height + lineWidth);
                }
                ctx.stroke();
            }
            if (data.horzLinesVisible) {
                ctx.strokeStyle = data.horzLinesColor;
                setLineStyle(ctx, data.horzLineStyle);
                ctx.beginPath();
                for (const priceMark of data.priceMarks) {
                    const y = Math.round(priceMark.coord * pixelRatio);
                    ctx.moveTo(-lineWidth, y);
                    ctx.lineTo(width + lineWidth, y);
                }
                ctx.stroke();
            }
        });
    }
}
