export class CompositeRenderer {
    constructor() {
        this._renderers = [];
    }
    setRenderers(renderers) {
        this._renderers = renderers;
    }
    draw(ctx, pixelRatio, isHovered, hitTestData) {
        this._renderers.forEach((r) => {
            ctx.save();
            r.draw(ctx, pixelRatio, isHovered, hitTestData);
            ctx.restore();
        });
    }
}
