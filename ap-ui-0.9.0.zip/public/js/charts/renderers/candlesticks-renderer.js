import { fillRectInnerBorder } from '../helpers/canvas-helpers.js';
import { optimalCandlestickWidth } from './optimal-bar-width.js';
export class PaneRendererCandlesticks {
    constructor() {
        this._data = null;
        this._barWidth = 0;
    }
    setData(data) {
        this._data = data;
    }
    draw(ctx, pixelRatio, isHovered, hitTestData) {
        if (this._data === null || this._data.bars.length === 0 || this._data.visibleRange === null) {
            return;
        }
        this._barWidth = optimalCandlestickWidth(this._data.barSpacing, pixelRatio);
        if (this._barWidth >= 2) {
            const wickWidth = Math.floor(pixelRatio);
            if ((wickWidth % 2) !== (this._barWidth % 2)) {
                this._barWidth--;
            }
        }
        const bars = this._data.bars;
        if (this._data.wickVisible) {
            this._drawWicks(ctx, bars, this._data.visibleRange, pixelRatio);
        }
        if (this._data.borderVisible) {
            this._drawBorder(ctx, bars, this._data.visibleRange, this._data.barSpacing, pixelRatio);
        }
        const borderWidth = this._calculateBorderWidth(pixelRatio);
        if (!this._data.borderVisible || this._barWidth > borderWidth * 2) {
            this._drawCandles(ctx, bars, this._data.visibleRange, pixelRatio);
        }
    }
    _drawWicks(ctx, bars, visibleRange, pixelRatio) {
        if (this._data === null) {
            return;
        }
        let prevWickColor = '';
        let wickWidth = Math.min(Math.floor(pixelRatio), Math.floor(this._data.barSpacing * pixelRatio));
        wickWidth = Math.max(Math.floor(pixelRatio), Math.min(wickWidth, this._barWidth));
        const wickOffset = Math.floor(wickWidth * 0.5);
        let prevEdge = null;
        for (let i = visibleRange.from; i < visibleRange.to; i++) {
            const bar = bars[i];
            if (bar.wickColor !== prevWickColor) {
                ctx.fillStyle = bar.wickColor;
                prevWickColor = bar.wickColor;
            }
            const top = Math.round(Math.min(bar.openY, bar.closeY) * pixelRatio);
            const bottom = Math.round(Math.max(bar.openY, bar.closeY) * pixelRatio);
            const high = Math.round(bar.highY * pixelRatio);
            const low = Math.round(bar.lowY * pixelRatio);
            const scaledX = Math.round(pixelRatio * bar.x);
            let left = scaledX - wickOffset;
            const right = left + wickWidth - 1;
            if (prevEdge !== null) {
                left = Math.max(prevEdge + 1, left);
                left = Math.min(left, right);
            }
            const width = right - left + 1;
            ctx.fillRect(left, high, width, top - high);
            ctx.fillRect(left, bottom + 1, width, low - bottom);
            prevEdge = right;
        }
    }
    _calculateBorderWidth(pixelRatio) {
        let borderWidth = Math.floor(1 * pixelRatio);
        if (this._barWidth <= 2 * borderWidth) {
            borderWidth = Math.floor((this._barWidth - 1) * 0.5);
        }
        const res = Math.max(Math.floor(pixelRatio), borderWidth);
        if (this._barWidth <= res * 2) {
            return Math.max(Math.floor(pixelRatio), Math.floor(1 * pixelRatio));
        }
        return res;
    }
    _drawBorder(ctx, bars, visibleRange, barSpacing, pixelRatio) {
        if (this._data === null) {
            return;
        }
        let prevBorderColor = '';
        const borderWidth = this._calculateBorderWidth(pixelRatio);
        let prevEdge = null;
        for (let i = visibleRange.from; i < visibleRange.to; i++) {
            const bar = bars[i];
            if (bar.borderColor !== prevBorderColor) {
                ctx.fillStyle = bar.borderColor;
                prevBorderColor = bar.borderColor;
            }
            let left = Math.round(bar.x * pixelRatio) - Math.floor(this._barWidth * 0.5);
            const right = left + this._barWidth - 1;
            const top = Math.round(Math.min(bar.openY, bar.closeY) * pixelRatio);
            const bottom = Math.round(Math.max(bar.openY, bar.closeY) * pixelRatio);
            if (prevEdge !== null) {
                left = Math.max(prevEdge + 1, left);
                left = Math.min(left, right);
            }
            if (this._data.barSpacing * pixelRatio > 2 * borderWidth) {
                fillRectInnerBorder(ctx, left, top, right - left + 1, bottom - top + 1, borderWidth);
            }
            else {
                const width = right - left + 1;
                ctx.fillRect(left, top, width, bottom - top + 1);
            }
            prevEdge = right;
        }
    }
    _drawCandles(ctx, bars, visibleRange, pixelRatio) {
        if (this._data === null) {
            return;
        }
        let prevBarColor = '';
        const borderWidth = this._calculateBorderWidth(pixelRatio);
        for (let i = visibleRange.from; i < visibleRange.to; i++) {
            const bar = bars[i];
            let top = Math.round(Math.min(bar.openY, bar.closeY) * pixelRatio);
            let bottom = Math.round(Math.max(bar.openY, bar.closeY) * pixelRatio);
            let left = Math.round(bar.x * pixelRatio) - Math.floor(this._barWidth * 0.5);
            let right = left + this._barWidth - 1;
            if (bar.color !== prevBarColor) {
                const barColor = bar.color;
                ctx.fillStyle = barColor;
                prevBarColor = barColor;
            }
            if (this._data.borderVisible) {
                left += borderWidth;
                top += borderWidth;
                right -= borderWidth;
                bottom -= borderWidth;
            }
            if (top > bottom) {
                continue;
            }
            ctx.fillRect(left, top, right - left + 1, bottom - top + 1);
        }
    }
}
