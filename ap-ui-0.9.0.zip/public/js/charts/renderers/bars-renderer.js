import { ensureNotNull } from '../helpers/assertions.js';
import { optimalBarWidth } from './optimal-bar-width.js';
export class PaneRendererBars {
    constructor() {
        this._data = null;
        this._barWidth = 0;
        this._barLineWidth = 0;
    }
    setData(data) {
        this._data = data;
    }
    draw(ctx, pixelRatio, isHovered, hitTestData) {
        if (this._data === null || this._data.bars.length === 0 || this._data.visibleRange === null) {
            return;
        }
        this._barWidth = this._calcBarWidth(pixelRatio);
        if (this._barWidth >= 2) {
            const lineWidth = Math.max(1, Math.floor(pixelRatio));
            if ((lineWidth % 2) !== (this._barWidth % 2)) {
                this._barWidth--;
            }
        }
        this._barLineWidth = this._data.thinBars ? Math.min(this._barWidth, Math.floor(pixelRatio)) : this._barWidth;
        let prevColor = null;
        const drawOpenClose = this._barLineWidth <= this._barWidth && this._data.barSpacing >= Math.floor(1.5 * pixelRatio);
        for (let i = this._data.visibleRange.from; i < this._data.visibleRange.to; ++i) {
            const bar = this._data.bars[i];
            if (prevColor !== bar.color) {
                ctx.fillStyle = bar.color;
                prevColor = bar.color;
            }
            const bodyWidthHalf = Math.floor(this._barLineWidth * 0.5);
            const bodyCenter = Math.round(bar.x * pixelRatio);
            const bodyLeft = bodyCenter - bodyWidthHalf;
            const bodyWidth = this._barLineWidth;
            const bodyRight = bodyLeft + bodyWidth - 1;
            const high = Math.min(bar.highY, bar.lowY);
            const low = Math.max(bar.high, bar.lowY);
            const bodyTop = Math.round(high * pixelRatio) - bodyWidthHalf;
            const bodyBottom = Math.round(low * pixelRatio) + bodyWidthHalf;
            const bodyHeight = Math.max((bodyBottom - bodyTop), this._barLineWidth);
            ctx.fillRect(bodyLeft, bodyTop, bodyWidth, bodyHeight);
            const sideWidth = Math.ceil(this._barWidth * 1.5);
            if (drawOpenClose) {
                if (this._data.openVisible) {
                    const openLeft = bodyCenter - sideWidth;
                    let openTop = Math.max(bodyTop, Math.round(bar.openY * pixelRatio) - bodyWidthHalf);
                    let openBottom = openTop + bodyWidth - 1;
                    if (openBottom > bodyTop + bodyHeight - 1) {
                        openBottom = bodyTop + bodyHeight - 1;
                        openTop = openBottom - bodyWidth + 1;
                    }
                    ctx.fillRect(openLeft, openTop, bodyLeft - openLeft, openBottom - openTop + 1);
                }
                const closeRight = bodyCenter + sideWidth;
                let closeTop = Math.max(bodyTop, Math.round(bar.closeY * pixelRatio) - bodyWidthHalf);
                let closeBottom = closeTop + bodyWidth - 1;
                if (closeBottom > bodyTop + bodyHeight - 1) {
                    closeBottom = bodyTop + bodyHeight - 1;
                    closeTop = closeBottom - bodyWidth + 1;
                }
                ctx.fillRect(bodyRight + 1, closeTop, closeRight - bodyRight, closeBottom - closeTop + 1);
            }
        }
    }
    _calcBarWidth(pixelRatio) {
        const limit = Math.floor(pixelRatio);
        return Math.max(limit, Math.floor(optimalBarWidth(ensureNotNull(this._data).barSpacing, pixelRatio)));
    }
}
