import { makeFont } from '../helpers/make-font.js';
export class PriceAxisRendererOptionsProvider {
    constructor(chartModel) {
        this._rendererOptions = {
            borderSize: 1,
            tickLength: 4,
            fontSize: NaN,
            font: '',
            fontFamily: '',
            color: '',
            paddingBottom: 0,
            paddingInner: 0,
            paddingOuter: 0,
            paddingTop: 0,
            baselineOffset: 0,
        };
        this._chartModel = chartModel;
    }
    options() {
        const rendererOptions = this._rendererOptions;
        const currentFontSize = this._fontSize();
        const currentFontFamily = this._fontFamily();
        if (rendererOptions.fontSize !== currentFontSize || rendererOptions.fontFamily !== currentFontFamily) {
            rendererOptions.fontSize = currentFontSize;
            rendererOptions.fontFamily = currentFontFamily;
            rendererOptions.font = makeFont(currentFontSize, currentFontFamily);
            rendererOptions.paddingTop = Math.floor(currentFontSize / 3.5);
            rendererOptions.paddingBottom = rendererOptions.paddingTop;
            rendererOptions.paddingInner = Math.max(Math.ceil(currentFontSize / 2 - rendererOptions.tickLength / 2), 0);
            rendererOptions.paddingOuter = Math.ceil(currentFontSize / 2 + rendererOptions.tickLength / 2);
            rendererOptions.baselineOffset = Math.round(currentFontSize / 10);
        }
        rendererOptions.color = this._textColor();
        return this._rendererOptions;
    }
    _textColor() {
        return this._chartModel.options().layout.textColor;
    }
    _fontSize() {
        return this._chartModel.options().layout.fontSize;
    }
    _fontFamily() {
        return this._chartModel.options().layout.fontFamily;
    }
}
