export function walkLine(ctx, points, lineType, visibleRange) {
    if (points.length === 0) {
        return;
    }
    const x = points[visibleRange.from].x;
    const y = points[visibleRange.from].y;
    ctx.moveTo(x, y);
    for (let i = visibleRange.from + 1; i < visibleRange.to; ++i) {
        const currItem = points[i];
        if (lineType === 1) {
            const prevY = points[i - 1].y;
            const currX = currItem.x;
            ctx.lineTo(currX, prevY);
        }
        ctx.lineTo(currItem.x, currItem.y);
    }
}
