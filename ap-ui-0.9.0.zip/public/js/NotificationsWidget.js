import { AContainer, AFontAwesomeIcon, ADataGrid, ALanguageManager } from './a/index.js';
import { NotificationItem, NotificationType, TradingManager } from './managers/TradingManager.js';
import { NotificationsDataGridRow } from './renderers/NotificationsDataGridRow.js';
export class NotificationsWidget extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._activeNotificationRenderer = new NotificationsDataGridRow();
        this._activeNotificationRenderer.addClass('timed-out');
        this.appendChild(this._activeNotificationRenderer);
        this._showHideIcon = new AFontAwesomeIcon();
        this._showHideIcon.value = ['fal', 'fa-angle-down'];
        this.appendChild(this._showHideIcon);
        this._notificationsGrid = new ADataGrid();
        this._notificationsGrid.rowRenderer = NotificationsDataGridRow;
        this._notificationsGrid.visible = false;
        this._notificationsGrid.selectable = false;
        this._notificationsGrid.columnLabels = ['Notifications'];
        this.appendChild(this._notificationsGrid);
        this._activeNotificationID = null;
        this._notificationTimeout = null;
        this._lastAnimationTime = 0;
        this._animationDelay = 100;
    }
    _registerListeners() {
        super._registerListeners();
        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('click', this._onClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);
        let tm = TradingManager.instance;
        this._onTradingManagerReadyStateChanged = this._onTradingManagerReadyStateChanged.bind(this);
        tm.ReadyState.StateChanged.SubscribeEvent(this._onTradingManagerReadyStateChanged);
        this._onNotificationTriggered = this._onNotificationTriggered.bind(this);
        tm.NotificationTriggered.SubscribeEvent(this._onNotificationTriggered);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('click', this._onClicked);
        document.removeEventListener('mousedown', this._onDocumentMouseDown);
        document.removeEventListener('keydown', this._onKeyDown);
        let tm = TradingManager.instance;
        tm.ReadyState.StateChanged.UnsubscribeEvent(this._onTradingManagerReadyStateChanged);
        tm.NotificationTriggered.UnsubscribeEvent(this._onNotificationTriggered);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let notEmpty = tm.notifications.size > 0;
            if (this._activeNotificationID !== null) {
                this._activeNotificationRenderer.data = [tm.notifications.get(this._activeNotificationID)];
                if (notEmpty && this._notificationsGrid.visible) {
                    let items = [];
                    tm.notifications.forEach((item) => {
                        items.push([item]);
                    });
                    items.reverse();
                    this._notificationsGrid.setItems(items);
                }
            }
            if (notEmpty) {
                this.addClass('not-empty');
            }
            else {
                this.removeClass('not-empty');
                this._activeNotificationRenderer.data = [new NotificationItem(Math.random(), NotificationType.NOOP, [], [ALanguageManager.instance.get('NotificationsWidget', 'Notifications')])];
            }
            return true;
        }
        else {
            return false;
        }
    }
    _openNotificationsGrid() {
        this.addClass('is-open');
        this._notificationsGrid.visible = true;
        this.invalidate();
    }
    _closeNotificationsGrid() {
        this.removeClass('is-open');
        this._notificationsGrid.visible = false;
    }
    _onClicked(event) {
        if (!this._notificationsGrid.visible && TradingManager.instance.notifications.size > 0) {
            this._openNotificationsGrid();
        }
        else {
            this._closeNotificationsGrid();
        }
    }
    _onDocumentMouseDown(event) {
        let widget = event.target.closest('a-notifications-widget');
        if (!widget) {
            this._closeNotificationsGrid();
        }
    }
    _onKeyDown(event) {
        if (event.key === 'Escape' && this._notificationsGrid.visible) {
            this._closeNotificationsGrid();
        }
    }
    _onTradingManagerReadyStateChanged() {
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstanceConfigReady) {
        }
        if (tm.ReadyState.AccountsReady) {
        }
    }
    _onNotificationTriggered(notificationID) {
        this._activeNotificationID = notificationID;
        let now = Date.now();
        if ((now - this._lastAnimationTime) > this._animationDelay) {
            this._lastAnimationTime = now;
            this._activeNotificationRenderer.removeClass('timed-out');
            if (this._notificationTimeout !== null) {
                clearTimeout(this._notificationTimeout);
            }
            this._notificationTimeout = setTimeout(() => {
                this._activeNotificationRenderer.addClass('timed-out');
                this._notificationTimeout = null;
            }, 250);
            this.invalidate();
        }
    }
}
window.customElements.define('a-notifications-widget', NotificationsWidget);
