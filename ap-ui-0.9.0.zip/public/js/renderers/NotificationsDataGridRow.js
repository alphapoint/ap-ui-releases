import { AComponent, AContainer, ALabel, AText } from '../a/index.js';
import { NotificationItem, NotificationType } from '../managers/TradingManager.js';
export class NotificationsDataGridRowItem extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._label = null;
        this._text = null;
        this._labelLabel = new ALabel();
        this.appendChild(this._labelLabel);
        this._textText = new AText();
        this.appendChild(this._textText);
    }
    _render() {
        if (super._render()) {
            if (this._label || this._text) {
                if (this._label) {
                    this._labelLabel.text = this._label;
                    this._labelLabel.visible = true;
                }
                else {
                    this._labelLabel.visible = false;
                }
                if (this._text) {
                    this._textText.text = this._text;
                    this._textText.visible = true;
                }
                else {
                    this._textText.visible = false;
                }
            }
            else {
                this._labelLabel.visible = false;
                this._textText.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    get label() {
        return this._label;
    }
    set label(l) {
        if (this._label !== l) {
            this._label = l;
            this.invalidate();
        }
    }
    get text() {
        return this._text;
    }
    set text(t) {
        if (this._text !== t) {
            this._text = t;
            this.invalidate();
        }
    }
}
window.customElements.define('a-notifications-data-grid-row-item', NotificationsDataGridRowItem);
export class NotificationsDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
    }
    _render() {
        if (super._render()) {
            if (this._data !== null && this._data.length === 1 && this._data[0] && this._data[0].constructor === NotificationItem) {
                let notification = this._data[0];
                if (notification.type !== NotificationType.NOOP) {
                    let maxLen = Math.max(notification.labelArray.length, notification.textArray.length);
                    while (this.childElementCount !== maxLen) {
                        if (this.childElementCount < maxLen) {
                            let item = new NotificationsDataGridRowItem();
                            this.appendChild(item);
                        }
                        else if (this.childElementCount > maxLen) {
                            this.removeChild(this.getChildAt(this.childElementCount - 1));
                        }
                    }
                    for (let i = 0; i < maxLen; i++) {
                        let item = this.getChildAt(i);
                        item.label = notification.labelArray[i] || null;
                        item.text = notification.textArray[i] || null;
                    }
                }
                else {
                }
            }
            else {
                this.destroyAllChildren();
            }
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-notifications-data-grid-row', NotificationsDataGridRow);
