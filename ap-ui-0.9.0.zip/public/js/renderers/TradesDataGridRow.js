import { AComponent, AFormatManager, AText } from '../a/index.js';
import { NumberFormatType } from '../a/managers/AFormatManager.js';
import { OrderSideEnum, User_MD_TradeUpdate_Output, User_OrderTrade_Output } from '../BrowserSDK/UserAPI/GeneratedPublicBrowserMessages/Generated_Public_Web_Messages.js';
export default class TradesDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._priceText = new AText();
        this.appendChild(this._priceText);
        this._quantityText = new AText();
        this.appendChild(this._quantityText);
        this._timeText = new AText();
        this.appendChild(this._timeText);
    }
    _render() {
        if (super._render()) {
            this.removeClasses('buy', 'sell');
            if (this._data !== null && this._data.length === 1 && (this._data[0].constructor === User_MD_TradeUpdate_Output || this._data[0].constructor === User_OrderTrade_Output)) {
                let fm = AFormatManager.instance;
                let trade = this._data[0];
                if (trade.constructor === User_MD_TradeUpdate_Output) {
                    this._priceText.text = fm.format(trade.InstrumentId, NumberFormatType.PRICE, trade.Price);
                    this._quantityText.text = fm.format(trade.InstrumentId, NumberFormatType.QUANTITY, trade.Quantity);
                    this._timeText.text = `${new Date(trade.TradeTime).toString().substr(16, 8)}`;
                    if (trade.MakerSide === OrderSideEnum.Buy) {
                        this.addClass('buy');
                    }
                    else if (trade.MakerSide === OrderSideEnum.Sell) {
                        this.addClass('sell');
                    }
                }
                else if (trade.constructor === User_OrderTrade_Output) {
                    this._priceText.text = fm.format(trade.InstrumentId, NumberFormatType.PRICE, trade.Price);
                    this._quantityText.text = fm.format(trade.InstrumentId, NumberFormatType.QUANTITY, trade.Quantity);
                    this._timeText.text = `${new Date(trade.TradeTime).toString().substr(16, 8)}`;
                }
            }
            else {
                this._priceText.text = '';
                this._quantityText.text = '';
                this._timeText.text = '';
            }
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-trades-data-grid-row', TradesDataGridRow);
