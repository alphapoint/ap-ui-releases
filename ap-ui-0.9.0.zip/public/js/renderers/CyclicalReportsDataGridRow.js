import { AComponent, AContainer, AFontAwesomeIcon, AText } from '../a/index.js';
import { UserReportFrequency } from '../BrowserSDK/UserAPI/index.js';
export default class CyclicalReportsDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._typeText = new AText();
        this.appendChild(this._typeText);
        this._frequencyText = new AText();
        this.appendChild(this._frequencyText);
        this._createdDateText = new AText();
        this.appendChild(this._createdDateText);
        this._actionsContainer = new AContainer();
        this.appendChild(this._actionsContainer);
        this._cancelIcon = new AFontAwesomeIcon();
        this._cancelIcon.title = 'Cancel Report';
        this._cancelIcon.addClass('cancel');
        this._cancelIcon.value = ['far', 'fa-ban'];
        this._actionsContainer.appendChild(this._cancelIcon);
    }
    _render() {
        if (super._render()) {
            if (this._data !== null && this._data.length === 1) {
                let reportTicket = this._data[0];
                this._typeText.text = reportTicket.reportFlavor;
                this._frequencyText.text = reportTicket.ReportFrequency === UserReportFrequency.OnDemand ? 'Single' : reportTicket.ReportFrequency;
                let createdDate = new Date(reportTicket.createTime);
                this._createdDateText.text = `${createdDate.toLocaleDateString()}`;
                this._cancelIcon.visible = true;
                this.removeClass('empty');
            }
            else {
                this._typeText.text = '';
                this._frequencyText.text = '';
                this._createdDateText.text = '';
                this._cancelIcon.visible = false;
                this.addClass('empty');
            }
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-cyclical-reports-data-grid-row', CyclicalReportsDataGridRow);
