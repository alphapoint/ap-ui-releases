import { AComponent, AContainer, AFontAwesomeIcon, AFormatManager, ALanguageManager, AText } from '../a/index.js';
import { NumberFormatType } from '../a/managers/AFormatManager.js';
import { OrderCurrentState, OrderSideEnum, OrderTIFEnum, OrderTypeEnum } from '../BrowserSDK/UserAPI/GeneratedPublicBrowserMessages/Generated_Public_Web_Messages.js';
import { TradingManager } from '../managers/TradingManager.js';
export default class AccountOrdersDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._dateText = new AText();
        this.appendChild(this._dateText);
        this._instrumentNameText = new AText();
        this.appendChild(this._instrumentNameText);
        this._typeSideText = new AText();
        this.appendChild(this._typeSideText);
        this._statusText = new AText();
        this.appendChild(this._statusText);
        this._originalQuantityText = new AText();
        this.appendChild(this._originalQuantityText);
        this._executedQuantityText = new AText();
        this.appendChild(this._executedQuantityText);
        this._remainingQuantityText = new AText();
        this.appendChild(this._remainingQuantityText);
        this._limitPriceText = new AText();
        this.appendChild(this._limitPriceText);
        this._stopPriceText = new AText();
        this.appendChild(this._stopPriceText);
        this._averageExecutedValueText = new AText();
        this.appendChild(this._averageExecutedValueText);
        this._tifText = new AText();
        this.appendChild(this._tifText);
        this._actionsContainer = new AContainer();
        this.appendChild(this._actionsContainer);
        this._cancelIcon = new AFontAwesomeIcon();
        this._cancelIcon.addClass('cancel');
        this._cancelIcon.value = ['fas', 'fa-ban'];
        this._actionsContainer.appendChild(this._cancelIcon);
        this._executeAtMarketIcon = new AFontAwesomeIcon();
        this._executeAtMarketIcon.addClass('execute-at-market');
        this._executeAtMarketIcon.value = ['fas', 'fa-step-forward'];
        this._executeAtMarketIcon.visible = false;
        this._actionsContainer.appendChild(this._executeAtMarketIcon);
        this._editIcon = new AFontAwesomeIcon();
        this._editIcon.addClass('edit');
        this._editIcon.value = ['fas', 'fa-edit'];
        this._editIcon.visible = false;
        this._actionsContainer.appendChild(this._editIcon);
    }
    _render() {
        if (super._render()) {
            if (this._data !== null && this._data.length === 1) {
                let lm = ALanguageManager.instance;
                let tm = TradingManager.instance;
                let fm = AFormatManager.instance;
                this._cancelIcon.title = lm.get('AccountOrdersWidget', 'Cancel');
                this._executeAtMarketIcon.title = lm.get('AccountOrdersWidget', 'Execute at market');
                this._editIcon.title = lm.get('AccountOrdersWidget', 'Edit');
                let orderState = this._data[0];
                let timestamp = new Date(orderState.EntryTime);
                this._dateText.text = `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`;
                this._instrumentNameText.text = tm.APIState.InstrumentInfos.get(orderState.InstrumentId).Symbol || '';
                this._typeSideText.text = `${OrderTypeEnum[orderState.OrderType]} ${OrderSideEnum[orderState.Side]}`;
                this._statusText.text = OrderCurrentState[orderState.CurrentOrderState];
                this._originalQuantityText.text = fm.format(orderState.InstrumentId, NumberFormatType.QUANTITY, orderState.OrigQuantity);
                this._executedQuantityText.text = fm.format(orderState.InstrumentId, NumberFormatType.QUANTITY, orderState.ExecutedQuantity);
                this._remainingQuantityText.text = fm.format(orderState.InstrumentId, NumberFormatType.QUANTITY, orderState.RemainingQuantity);
                this._limitPriceText.text = fm.format(orderState.InstrumentId, NumberFormatType.PRICE, orderState.LimitPrice);
                this._stopPriceText.text = orderState.StopPrice > 0 ? fm.format(orderState.InstrumentId, NumberFormatType.PRICE, orderState.StopPrice) : '';
                this._averageExecutedValueText.text = orderState.ValueExecuted > 0 && orderState.ExecutedQuantity > 0 ? fm.format(orderState.InstrumentId, NumberFormatType.PRICE, orderState.ValueExecuted / orderState.ExecutedQuantity) : '';
                this._tifText.text = OrderTIFEnum[orderState.TIF];
                this._cancelIcon.visible = orderState.CurrentOrderState === OrderCurrentState.Working && orderState.RemainingQuantity !== null;
                this.removeClass('empty');
            }
            else {
                this._dateText.text = '';
                this._instrumentNameText.text = '';
                this._typeSideText.text = '';
                this._statusText.text = '';
                this._originalQuantityText.text = '';
                this._executedQuantityText.text = '';
                this._remainingQuantityText.text = '';
                this._limitPriceText.text = '';
                this._stopPriceText.text = '';
                this._averageExecutedValueText.text = '';
                this._tifText.text = '';
                this._cancelIcon.visible = false;
                this.addClass('empty');
            }
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-account-orders-data-grid-row', AccountOrdersDataGridRow);
