import { AComponent, AContainer, AFontAwesomeIcon, AText } from '../a/index.js';
import { UserReportFrequency, UserReportStatus } from '../BrowserSDK/UserAPI/index.js';
export default class AvailableReportsDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._typeText = new AText();
        this.appendChild(this._typeText);
        this._dateRangeText = new AText();
        this.appendChild(this._dateRangeText);
        this._frequencyText = new AText();
        this.appendChild(this._frequencyText);
        this._createdDateText = new AText();
        this.appendChild(this._createdDateText);
        this._statusText = new AText();
        this.appendChild(this._statusText);
        this._actionsContainer = new AContainer();
        this.appendChild(this._actionsContainer);
        this._downloadIcon = new AFontAwesomeIcon();
        this._downloadIcon.title = 'Download Report';
        this._downloadIcon.addClass('download');
        this._downloadIcon.value = ['far', 'fa-arrow-circle-down'];
        this._actionsContainer.appendChild(this._downloadIcon);
    }
    _render() {
        if (super._render()) {
            if (this._data !== null && this._data.length === 1) {
                let reportTicket = this._data[0];
                this._typeText.text = reportTicket.reportFlavor;
                let startDate = new Date(reportTicket.intervalStartTime);
                let endDate = new Date(reportTicket.intervalEndTime);
                this._dateRangeText.text = `${startDate.toLocaleDateString()}${startDate !== endDate ? ' - ' + endDate.toLocaleDateString() : ''}`;
                this._frequencyText.text = reportTicket.ReportFrequency === UserReportFrequency.OnDemand ? 'Single' : reportTicket.ReportFrequency;
                let createdDate = new Date(reportTicket.createTime);
                this._createdDateText.text = `${createdDate.toLocaleDateString()}`;
                this._statusText.text = reportTicket.RequestStatus;
                this._downloadIcon.visible = reportTicket.RequestStatus === UserReportStatus.Completed;
                this.removeClass('empty');
            }
            else {
                this._typeText.text = '';
                this._dateRangeText.text = '';
                this._frequencyText.text = '';
                this._createdDateText.text = '';
                this._statusText.text = '';
                this._downloadIcon.visible = false;
                this.addClass('empty');
            }
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-available-reports-data-grid-row', AvailableReportsDataGridRow);
