import { AButton, AComponent, AFormatManager, ALabel, ALanguageManager, AText } from '../a/index.js';
import { NumberFormatType } from '../a/managers/AFormatManager.js';
import { OrderCurrentState, OrderSideEnum } from '../BrowserSDK/UserAPI/GeneratedPublicBrowserMessages/Generated_Public_Web_Messages.js';
import { TradingManager } from '../managers/TradingManager.js';
export default class MobileTradeAccountOrdersDataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._buySellText = new AText();
        this._buySellText.addClass('buy-sell');
        this.appendChild(this._buySellText);
        this._instrumentNameText = new AText();
        this._instrumentNameText.addClass('instrument-name');
        this.appendChild(this._instrumentNameText);
        this._dateTimeLabel = new ALabel();
        this._dateTimeLabel.addClass('date-time');
        this.appendChild(this._dateTimeLabel);
        this._priceLabel = new ALabel();
        this._priceLabel.addClass('price');
        this.appendChild(this._priceLabel);
        this._priceText = new AText();
        this._priceText.addClass('price');
        this.appendChild(this._priceText);
        this._quantityLabel = new ALabel();
        this._quantityLabel.addClass('quantity');
        this.appendChild(this._quantityLabel);
        this._quantityText = new AText();
        this._quantityText.addClass('quantity');
        this.appendChild(this._quantityText);
        this._cancelButton = new AButton();
        this._cancelButton.addClass('cancel');
        this.appendChild(this._cancelButton);
        this._statusText = new AText();
        this._statusText.addClass('status');
        this.appendChild(this._statusText);
    }
    _render() {
        if (super._render()) {
            if (this._data !== null && this._data.length === 1) {
                let lm = ALanguageManager.instance;
                let tm = TradingManager.instance;
                let fm = AFormatManager.instance;
                let orderState = this._data[0];
                let instrumentInfo = tm.APIState.InstrumentInfos.get(orderState.InstrumentId);
                if (orderState && instrumentInfo) {
                    if (orderState.Side === OrderSideEnum.Buy) {
                        this._buySellText.text = lm.get('MobileTradeWidget', 'Buy');
                        this._buySellText.addClass('buy');
                        this._buySellText.removeClass('sell');
                    }
                    else if (orderState.Side === OrderSideEnum.Sell) {
                        this._buySellText.text = lm.get('MobileTradeWidget', 'Sell');
                        this._buySellText.addClass('sell');
                        this._buySellText.removeClass('buy');
                    }
                    let instrumentInfo = tm.APIState.InstrumentInfos.get(orderState.InstrumentId);
                    this._instrumentNameText.text = instrumentInfo.Symbol;
                    let timestamp = new Date(orderState.EntryTime);
                    this._dateTimeLabel.text = `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`;
                    this._priceLabel.text = `${lm.get('MobileTradeWidget', 'Price')}(${instrumentInfo.Product2Symbol})`;
                    if (orderState.CurrentOrderState === OrderCurrentState.FullyExecuted) {
                        this._priceText.text = orderState.ValueExecuted > 0 && orderState.ExecutedQuantity > 0 ? fm.format(orderState.InstrumentId, NumberFormatType.PRICE, orderState.ValueExecuted / orderState.ExecutedQuantity) : '-';
                    }
                    else {
                        this._priceText.text = fm.format(orderState.InstrumentId, NumberFormatType.PRICE, orderState.LimitPrice) || '-';
                    }
                    this._quantityLabel.text = `${lm.get('MobileTradeWidget', 'Qty')}(${instrumentInfo.Product1Symbol})`;
                    this._quantityText.text = `${fm.format(orderState.InstrumentId, NumberFormatType.QUANTITY, orderState.ExecutedQuantity)}/${fm.format(orderState.InstrumentId, NumberFormatType.QUANTITY, orderState.OrigQuantity)}`;
                    this._cancelButton.label = lm.get('MobileTradeWidget', 'Cancel');
                    if (orderState.CurrentOrderState === OrderCurrentState.Working && orderState.RemainingQuantity !== null) {
                        this._cancelButton.visible = true;
                        this._statusText.visible = false;
                    }
                    else {
                        this._statusText.visible = true;
                        this._statusText.text = OrderCurrentState[orderState.CurrentOrderState];
                        this._cancelButton.visible = false;
                    }
                    this.removeClass('empty');
                    return true;
                }
            }
            this._buySellText.text = '';
            this._instrumentNameText.text = '';
            this._dateTimeLabel.text = '';
            this._priceLabel.text = '';
            this._priceText.text = '';
            this._quantityLabel.text = '';
            this._quantityText.text = '';
            this._cancelButton.visible = false;
            this._statusText.text = '';
            this.addClass('empty');
            return true;
        }
        else {
            return false;
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-mobile-trade-account-orders-data-grid-row', MobileTradeAccountOrdersDataGridRow);
