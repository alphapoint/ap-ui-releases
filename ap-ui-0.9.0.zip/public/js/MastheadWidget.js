import { AContainer, ALabel, AImage, AText, AFormatManager, ALanguageManagerEvent, ALanguageManager, NumberFormatType } from './a/index.js';
import { InstrumentSelect } from './components/InstrumentSelect.js';
import { TradingManager } from './managers/TradingManager.js';
export class MastheadWidget extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._logo = new AImage();
        this.appendChild(this._logo);
        this._instrumentSelect = new InstrumentSelect();
        this.appendChild(this._instrumentSelect);
        let lastPriceContainer = new AContainer();
        lastPriceContainer.addClass('last-price');
        this.appendChild(lastPriceContainer);
        this._lastPriceLabel = new ALabel();
        lastPriceContainer.appendChild(this._lastPriceLabel);
        this._lastPriceText = new AText();
        lastPriceContainer.appendChild(this._lastPriceText);
        let dayChangeContainer = new AContainer();
        dayChangeContainer.addClasses('up');
        this.appendChild(dayChangeContainer);
        this._dayChangeLabel = new ALabel();
        dayChangeContainer.appendChild(this._dayChangeLabel);
        this._dayChangeText = new AText();
        dayChangeContainer.appendChild(this._dayChangeText);
        let dayHighContainer = new AContainer();
        dayHighContainer.addClasses('day-high', 'up');
        this.appendChild(dayHighContainer);
        this._dayHighLabel = new ALabel();
        dayHighContainer.appendChild(this._dayHighLabel);
        this._dayHighText = new AText();
        dayHighContainer.appendChild(this._dayHighText);
        let dayLowContainer = new AContainer();
        dayLowContainer.addClasses('day-low', 'down');
        this.appendChild(dayLowContainer);
        this._dayLowLabel = new ALabel();
        dayLowContainer.appendChild(this._dayLowLabel);
        this._dayLowText = new AText();
        dayLowContainer.appendChild(this._dayLowText);
        let dayVolumeContainer = new AContainer();
        dayVolumeContainer.addClass('day-volume');
        this.appendChild(dayVolumeContainer);
        this._dayVolumeLabel = new ALabel();
        dayVolumeContainer.appendChild(this._dayVolumeLabel);
        this._dayVolumeText = new AText();
        dayVolumeContainer.appendChild(this._dayVolumeText);
    }
    _registerListeners() {
        super._registerListeners();
        this._onLanguageChanged = this._onLanguageChanged.bind(this);
        ALanguageManager.instance.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        this._onUIConfigReady = this._onUIConfigReady.bind(this);
        tm.UIConfigReady.SubscribeEvent(this._onUIConfigReady);
        this._onTradingManagerReadyStateChanged = this._onTradingManagerReadyStateChanged.bind(this);
        tm.ReadyState.StateChanged.SubscribeEvent(this._onTradingManagerReadyStateChanged);
        this._onAccountIdChanged = this._onAccountIdChanged.bind(this);
        tm.AccountIdChanged.SubscribeEvent(this._onAccountIdChanged);
        this._onInstrumentIdChanged = this._onInstrumentIdChanged.bind(this);
        tm.InstrumentIdChanged.SubscribeEvent(this._onInstrumentIdChanged);
        this._onProductsMarketDataChanged = this._onProductsMarketDataChanged.bind(this);
        tm.ProductsMarketDataChanged.SubscribeEvent(this._onProductsMarketDataChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        ALanguageManager.instance.removeEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        tm.UIConfigReady.UnsubscribeEvent(this._onUIConfigReady);
        tm.ReadyState.StateChanged.UnsubscribeEvent(this._onTradingManagerReadyStateChanged);
        tm.AccountIdChanged.UnsubscribeEvent(this._onAccountIdChanged);
        tm.InstrumentIdChanged.UnsubscribeEvent(this._onInstrumentIdChanged);
        tm.ProductsMarketDataChanged.UnsubscribeEvent(this._onProductsMarketDataChanged);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let instrumentInfo = TradingManager.instance.APIState.InstrumentInfos.get(tm.instrumentId);
            if (instrumentInfo) {
                tm.GlobalInstrumentData.Get_Rolling24HR_OHLCV(instrumentInfo.Product1Symbol, instrumentInfo.Product2Symbol, (ohlcv) => {
                    if (ohlcv) {
                        let fm = AFormatManager.instance;
                        this._lastPriceText.text = fm.format(tm.instrumentId, NumberFormatType.PRICE, ohlcv.Close);
                        this._dayChangeText.text = `${fm.format(tm.instrumentId, NumberFormatType.PERCENT, ((ohlcv.Close - ohlcv.Open) / ohlcv.Close) / 100)}`;
                        this._dayHighText.text = fm.format(tm.instrumentId, NumberFormatType.PRICE, ohlcv.High);
                        this._dayLowText.text = fm.format(tm.instrumentId, NumberFormatType.PRICE, ohlcv.Low);
                        this._dayVolumeText.text = `${fm.format(tm.instrumentId, NumberFormatType.QUANTITY, ohlcv.TradeVolumeValue)}`;
                    }
                    else {
                        this._lastPriceText.text = '—';
                        this._dayChangeText.text = '—';
                        this._dayHighText.text = '—';
                        this._dayLowText.text = '—';
                        this._dayVolumeText.text = '—';
                    }
                });
            }
            else {
                this._lastPriceText.text = '—';
                this._dayChangeText.text = '—';
                this._dayHighText.text = '—';
                this._dayLowText.text = '—';
                this._dayVolumeText.text = '—';
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onLanguageChanged();
    }
    _onLanguageChanged() {
        let lm = ALanguageManager.instance;
        this._instrumentSelect.defaultText = lm.get('MastheadWidget', 'Select...');
        this._instrumentSelect.invalidate(true);
        this._lastPriceLabel.text = lm.get('MastheadWidget', 'Last price');
        this._dayChangeLabel.text = lm.get('MastheadWidget', '24h change');
        this._dayHighLabel.text = lm.get('MastheadWidget', '24h high');
        this._dayLowLabel.text = lm.get('MastheadWidget', '24h low');
        this._dayVolumeLabel.text = lm.get('MastheadWidget', '24h volume');
        this.invalidate();
    }
    _onUIConfigReady() {
        this._logo.src = TradingManager.instance.UIConfig.OperatorLogo;
    }
    _onTradingManagerReadyStateChanged() {
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstanceConfigReady) {
            this._instrumentSelect.instrumentId = TradingManager.instance.instrumentId;
        }
    }
    _onAccountIdChanged() {
    }
    _onInstrumentIdChanged() {
        this._instrumentSelect.instrumentId = TradingManager.instance.instrumentId;
        this.invalidate();
    }
    _onProductsMarketDataChanged() {
        this.invalidate();
    }
}
window.customElements.define('a-masthead-widget', MastheadWidget);
