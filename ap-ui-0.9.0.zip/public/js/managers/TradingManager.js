import { ALanguageManagerEvent, NumberFormatType, AFormatManager, ASystemManager, ALanguageManager, AImageManager, AIFrame } from "../a/index.js";
import { DepositWithdraw } from "../components/DepositWithdraw.js";
import { Portfolio } from "../components/Portfolio.js";
import { SendReceive } from "../components/SendReceive.js";
import { OrderCurrentState, OrderSideEnum, OrderTypeEnum, RejectReason, AccountCredentialsObject, UserAPI, UserAPI_MarketDataHistoryService_Connection, QuickEvent, AccountCredentialObject_AuthMethodEnum, UserReportType } from "../BrowserSDK/UserAPI/index.js";
import { Settings } from "../components/Settings.js";
import { Reports } from "../components/Reports.js";
export var TransactionType;
(function (TransactionType) {
    TransactionType["DEPOSIT"] = "DEPOSIT";
    TransactionType["WITHDRAW"] = "WITHDRAW";
    TransactionType["SEND"] = "SEND";
    TransactionType["RECEIVE"] = "RECEIVE";
})(TransactionType || (TransactionType = {}));
export var NotificationType;
(function (NotificationType) {
    NotificationType["AUTHENTICATION"] = "AUTHENTICATION";
    NotificationType["ORDER"] = "ORDER";
    NotificationType["TRADE"] = "TRADE";
    NotificationType["DEPOSIT"] = "DEPOSIT";
    NotificationType["WITHDRAW"] = "WITHDRAW";
    NotificationType["NOOP"] = "NOOP";
})(NotificationType || (NotificationType = {}));
export class NotificationItem {
    constructor(id, type, labelArray = [], textArray = []) {
        this.id = id;
        this.type = type;
        this.labelArray = labelArray;
        this.textArray = textArray;
    }
}
export var VerificationLevelIncreaseStatus;
(function (VerificationLevelIncreaseStatus) {
    VerificationLevelIncreaseStatus["PASS"] = "pass";
    VerificationLevelIncreaseStatus["UNDER_REVIEW"] = "underReview";
    VerificationLevelIncreaseStatus["FAIL"] = "fail";
})(VerificationLevelIncreaseStatus || (VerificationLevelIncreaseStatus = {}));
export class TradingManager extends UserAPI {
    constructor() {
        super();
        this._coinMetadataRefreshInterval = 10000;
        this._defaultDepositTemplate = {
            FullName: '',
            Amount: 0,
            Comments: ''
        };
        this.UIConfig = null;
        this.isMobile = String(getComputedStyle(document.documentElement).getPropertyValue('--is-mobile')).trim() === 'true';
        this._applyPolyfills();
        this._themes = new Map();
        this._theme = null;
        this._layouts = new Map();
        this._layout = null;
        this._gettingUserInfo = false;
        this.UserInfo = null;
        this.UserConfig = new Map();
        this._gettingAccountInfo = false;
        this.AccountInfo = null;
        this._apexAPISessionKeyAuthenticationAttempts = 0;
        this._accountId = null;
        this._instrumentId = null;
        this.uiConfigReady = new QuickEvent();
        this.userInfoUpdated = new QuickEvent();
        this.userConfigUpdated = new QuickEvent();
        this.accountInfoUpdated = new QuickEvent();
        this.accountIdChanged = new QuickEvent();
        this.instrumentIdChanged = new QuickEvent();
        this.LiveMDH = new UserAPI_MarketDataHistoryService_Connection();
        this.productsMarketDataChanged = new QuickEvent();
        this.orderBookSideSelected = new QuickEvent();
        this.orderBookPriceSelected = new QuickEvent();
        this.themeChanged = new QuickEvent();
        this.layoutChanged = new QuickEvent();
        this.notificationTriggered = new QuickEvent();
        this._notifications = new Map();
        this._onBeforeLanguageChanged = this._onBeforeLanguageChanged.bind(this);
        ALanguageManager.instance.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onBeforeLanguageChanged);
        this._onReadyStateChanged = this._onReadyStateChanged.bind(this);
        this.ReadyState.StateChanged.SubscribeEvent(this._onReadyStateChanged);
        this._onApexGatewayMessage = this._onApexGatewayMessage.bind(this);
        this._onOrderStateChanged = this._onOrderStateChanged.bind(this);
        this.APIState.Account_OrderStateChangedEvent.SubscribeEvent(this._onOrderStateChanged);
        this._onNewTrade = this._onNewTrade.bind(this);
        this.APIState.Account_NewTradeEvent.SubscribeEvent(this._onNewTrade);
        ASystemManager.instance.ForgotPasswordOverride = () => {
            this.ShowForgotPasswordDialog();
        };
        ASystemManager.instance.RegisterOverride = () => {
            this.PromptRegistration();
        };
        window['TradingManager'] = this;
        this._initializeUIConfig();
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new TradingManager();
        }
        return this._instance;
    }
    get UIConfigReady() { return this.uiConfigReady.Expose(); }
    get UserInfoUpdated() { return this.userInfoUpdated.Expose(); }
    get UserConfigUpdated() { return this.userConfigUpdated.Expose(); }
    get AccountInfoUpdated() { return this.accountInfoUpdated.Expose(); }
    get AccountIdChanged() { return this.accountIdChanged.Expose(); }
    get InstrumentIdChanged() { return this.instrumentIdChanged.Expose(); }
    get ProductsMarketDataChanged() { return this.productsMarketDataChanged.Expose(); }
    get OrderBookSideSelected() { return this.orderBookSideSelected.Expose(); }
    get OrderBookPriceSelected() { return this.orderBookPriceSelected.Expose(); }
    get ThemeChanged() { return this.themeChanged.Expose(); }
    get LayoutChanged() { return this.layoutChanged.Expose(); }
    get NotificationTriggered() { return this.notificationTriggered.Expose(); }
    _applyPolyfills() {
        if (!DataView.prototype.setBigInt64) {
            DataView.prototype.setBigInt64 = function (byteOffset, value, littleEndian) {
                const wh = Number((value >> 32n) & 0xffffffffn);
                const wl = Number((value) & 0xffffffffn);
                const [h, l] = littleEndian ? [4, 0] : [0, 4];
                this.setInt32(byteOffset + h, wh, littleEndian);
                this.setInt32(byteOffset + l, wl, littleEndian);
            };
        }
        if (!DataView.prototype.getBigInt64) {
            DataView.prototype.getBigInt64 = function (byteOffset, littleEndian) {
                const [h, l] = littleEndian ? [4, 0] : [0, 4];
                const wh = BigInt(this.getInt32(byteOffset + h, littleEndian));
                const wl = BigInt(this.getInt32(byteOffset + l, littleEndian));
                return (wh << 32n) + wl;
            };
        }
        if (!DataView.prototype.setBigUint64) {
            DataView.prototype.setBigUint64 = function (byteOffset, value, littleEndian) {
                const wh = Number((value >> 32n) & 0xffffffffn);
                const wl = Number((value) & 0xffffffffn);
                const [h, l] = littleEndian ? [4, 0] : [0, 4];
                this.setUint32(byteOffset + h, wh, littleEndian);
                this.setUint32(byteOffset + l, wl, littleEndian);
            };
        }
        if (!DataView.prototype.getBigUint64) {
            DataView.prototype.getBigUint64 = function (byteOffset, littleEndian) {
                const [h, l] = littleEndian ? [4, 0] : [0, 4];
                const wh = BigInt(this.getUint32(byteOffset + h, littleEndian));
                const wl = BigInt(this.getUint32(byteOffset + l, littleEndian));
                return (wh << 32n) + wl;
            };
        }
    }
    _initializeUIConfig() {
        fetch('config.json')
            .then((response) => {
            return response.json();
        })
            .then((config) => {
            if (config !== null) {
                this.UIConfig = config;
                ASystemManager.instance.AllowRegistration = config.AllowUserRegistration;
                AImageManager.instance.baseURI = this.UIConfig.AssetsBaseURI;
                ALanguageManager.instance.setConfig(config.Language);
                this._theme = config.Theme;
                config.Themes.forEach((theme) => {
                    theme.CSSString = null;
                    this._themes.set(theme.Name, theme);
                });
                this._layout = config.Layout;
                config.Layouts.forEach((layout) => {
                    layout.CSSString = null;
                    this._layouts.set(layout.Name, layout);
                });
                this._processURLParameters();
                setTimeout(() => {
                    this.uiConfigReady.DispatchEvent();
                    this.SetAPIConfig(config.APIConfig, (instanceConfig) => {
                        this.instrumentId = Array.from(this.APIState.InstrumentInfos.values())[0].InstrumentId;
                    });
                });
            }
        }).catch((error) => {
            console.log('error getting config.json', error);
        });
    }
    _onBeforeLanguageChanged() {
        this._processNumberFormatters();
    }
    _onAccountIdChanged() {
        this.DispatchAccountIdChanged();
    }
    DispatchAccountIdChanged() {
        this.accountIdChanged.DispatchEvent();
    }
    _onInstrumentIdChanged() {
        this.DispatchInstrumentIdChanged();
    }
    _onReadyStateChanged() {
        if (this.ReadyState.InstanceConfigReady && !this.ReadyState.PreviousInstanceConfigReady) {
            this._processNumberFormatters();
            this._loadRollingOHLCV();
            this._preloadCurrencyImages();
        }
        if (this.ReadyState.InstanceConfigReady && this.ReadyState.ApexGatewayReady) {
            this.apexGatewayAPI.MessageReceived.SubscribeEvent(this._onApexGatewayMessage);
            let storedSessionKey = localStorage.getItem('apex-session-key') || (new URL(document.location.href)).searchParams.get('apex-session-key');
            if (storedSessionKey && this._apexAPISessionKeyAuthenticationAttempts < 1) {
                this.apexGatewayAPI.Authenticate(null, null, storedSessionKey);
                this._apexAPISessionKeyAuthenticationAttempts++;
            }
            else {
                if (this.ReadyState.ApexGatewayAuthenticated && !this.apexGatewayAPI.requiresTwoFAAuthentication) {
                    if (!this.AccountCredentials || (this.apexGatewayAPI.SessionToken !== this.AccountCredentials.SessionToken)) {
                        localStorage.setItem('apex-session-key', this.apexGatewayAPI.SessionToken);
                        this.AuthenticateWithApexSessionToken(this.apexGatewayAPI.SessionToken);
                    }
                }
                else if (!this.ReadyState.ApexGatewayAuthenticated) {
                    localStorage.removeItem('apex-session-key');
                }
            }
            if (this.ReadyState.ApexGatewayAuthenticated && !this.ReadyState.PreviousApexGatewayAuthenticated) {
                this._getApexUserInfo();
            }
        }
    }
    _processURLParameters() {
        let params = (new URL(document.location.href)).searchParams;
        let verifyEmailParam = params.get('verifyEmail') === 'true';
        let verifyDeviceParam = params.get('verifyDevice') === 'true';
        let resetPassParam = params.get('resetPass') === 'true';
        let verifyWithdrawAddressParam = params.get('verifyWithdrawAddress') === 'true';
        let confirmWithdrawParam = params.get('confirmWithdraw') === 'true';
        if (verifyEmailParam) {
            let uri;
            try {
                uri = atob(params.get('d1'));
            }
            catch (error) {
            }
            this.ShowVerifyEmailDialog(params.get('UserId'), params.get('verifycode'), uri);
        }
        else if (resetPassParam) {
            let uri;
            try {
                uri = atob(params.get('d1'));
            }
            catch (error) {
            }
            this.ShowResetPasswordDialog(params.get('UserId'), params.get('verifycode'), uri);
        }
        else if (verifyDeviceParam) {
            let uri;
            try {
                uri = atob(params.get('d1'));
            }
            catch (error) {
            }
            this.ShowVerifyDeviceDialog(params.get('UserId'), params.get('hashCode'), params.get('verifycode'), uri);
        }
        else if (verifyWithdrawAddressParam) {
            let uri;
            try {
                uri = atob(params.get('d1'));
            }
            catch (error) {
            }
            this.ShowVerifyWithdrawalAddressDialog(params.get('UserId'), params.get('hashCode'), params.get('verifycode'), uri);
        }
        else if (confirmWithdrawParam) {
            let uri;
            try {
                uri = atob(params.get('d1'));
            }
            catch (error) {
            }
            this.ShowConfirmWithdrawalDialog(params.get('UserId'), params.get('verifycode'), uri);
        }
    }
    _updateUserInfo(info) {
        this.UserInfo = info;
        this.userInfoUpdated.DispatchEvent();
    }
    _updateUserConfig(config) {
        this.UserConfig = config;
        this.userConfigUpdated.DispatchEvent();
    }
    _updateAccountInfo(info) {
        this.AccountInfo = info;
        this.accountInfoUpdated.DispatchEvent();
    }
    _onApexGatewayMessage(msg) {
        if (msg.hasOwnProperty('n')) {
            if (msg.n === 'AccountUpdateEvent') {
                this._updateAccountInfo(msg.o);
                this._getApexUserConfig();
            }
        }
    }
    _getApexUserInfo() {
        if (!this._gettingUserInfo && this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this._gettingUserInfo = true;
            this.apexGatewayAPI.Request('GetUserInfo', {}, (data) => {
                if (data.hasOwnProperty('UserId')) {
                    this._updateUserInfo(data);
                    this._accountId = data.AccountId;
                    this._getApexUserConfig();
                    this._getApexAccountInfo();
                }
                setTimeout(() => {
                    this._gettingUserInfo = false;
                }, 1000);
            });
        }
    }
    _getApexUserConfig() {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetUserConfig', {
                UserId: this.UserInfo.UserId,
                UserName: this.UserInfo.UserName
            }, (data) => {
                let m = new Map();
                if (data.constructor === Array) {
                    data.forEach((item) => {
                        if (item.hasOwnProperty('Key') && item.hasOwnProperty('Value')) {
                            m.set(item.Key, item.Value);
                        }
                    });
                }
                this._updateUserConfig(m);
            });
        }
    }
    _getApexAccountInfo() {
        if (!this._gettingAccountInfo && this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this._gettingAccountInfo = true;
            this.apexGatewayAPI.Request('GetAccountInfo', {
                AccountId: this.UserInfo.AccountId
            }, (data) => {
                if (data.hasOwnProperty('AccountId')) {
                    this._updateAccountInfo(data);
                }
                setTimeout(() => {
                    this._gettingAccountInfo = false;
                }, 1000);
            });
        }
    }
    _preloadCurrencyImages() {
        this.APIState.InstrumentInfos.forEach((instrumentInfo) => {
            AImageManager.instance.get(`/images/currency/${instrumentInfo.Product1Symbol.toLowerCase()}.png`, '/images/currency/generic.png');
        });
    }
    _processNumberFormatters() {
        if (this.ReadyState.InstanceConfigReady) {
            let fm = AFormatManager.instance;
            this.APIState.InstrumentInfos.forEach((instrumentInfo) => {
                let productOne = this.APIState.ProductInfos.get(instrumentInfo.Product1);
                let productTwo = this.APIState.ProductInfos.get(instrumentInfo.Product2);
                if (productOne && productTwo) {
                    fm.registerNumberFormatter(productOne.ProductId, NumberFormatType.QUANTITY, productOne.DecimalPlaces, productOne.DecimalPlaces);
                    fm.registerNumberFormatter(productOne.ProductId, NumberFormatType.PERCENT, 2, 2);
                    fm.registerNumberFormatter(productTwo.ProductId, NumberFormatType.QUANTITY, productTwo.DecimalPlaces, productTwo.DecimalPlaces);
                    fm.registerNumberFormatter(productTwo.ProductId, NumberFormatType.PERCENT, 2, 2);
                    if (productTwo.ProductType === 'NationalCurrency' && (productTwo.Product === 'USD' || productTwo.Product === 'USDT' || productTwo.Product === 'USDC')) {
                        fm.registerNumberFormatter(instrumentInfo.InstrumentId, NumberFormatType.PRICE, 2, 2);
                    }
                    else {
                        let priceDecimals = fm.getDecimalPlaceCount(instrumentInfo.PriceIncrement);
                        fm.registerNumberFormatter(instrumentInfo.InstrumentId, NumberFormatType.PRICE, priceDecimals, priceDecimals);
                    }
                    let quantityDecimals = fm.getDecimalPlaceCount(instrumentInfo.QuantityIncrement);
                    fm.registerNumberFormatter(instrumentInfo.InstrumentId, NumberFormatType.QUANTITY, quantityDecimals, quantityDecimals);
                    fm.registerNumberFormatter(instrumentInfo.InstrumentId, NumberFormatType.PERCENT, 2, 2);
                }
            });
        }
    }
    _loadRollingOHLCV() {
        if (this.ReadyState.InstanceConfigReady) {
            let time = 0;
            this.APIState.InstrumentInfos.forEach((instrumentInfo) => {
                setTimeout(() => {
                    if (instrumentInfo.Product1Symbol !== 'CAD' && instrumentInfo.Product1Symbol !== instrumentInfo.Product2Symbol) {
                        this.GlobalInstrumentData.Get_Rolling24HR_OHLCV(instrumentInfo.Product1Symbol, instrumentInfo.Product2Symbol, (ohlcv) => {
                        });
                    }
                }, time += 50);
            });
            setTimeout(() => {
                this.productsMarketDataChanged.DispatchEvent();
            }, time += 50);
        }
        setTimeout(() => {
            this._loadRollingOHLCV();
        }, 10000);
    }
    GetSparkSVG(prices = [], positive = true) {
        let w = 400;
        let h = 100;
        let points = `0,${h} `;
        let high = Number.NEGATIVE_INFINITY;
        let low = Number.POSITIVE_INFINITY;
        let style = getComputedStyle(document.body);
        let fill;
        if (positive) {
            fill = style.getPropertyValue('--spark-chart-positive-color');
        }
        else {
            fill = style.getPropertyValue('--spark-chart-negative-color');
        }
        prices.forEach((p) => {
            if (p > high) {
                high = p;
            }
            if (p < low) {
                low = p;
            }
        });
        let diff = high - low;
        let len = prices.length;
        for (let i = 0; i < len; i++) {
            let price = prices[i];
            points += `${((i / len) * w) | 0},${(h - (((price - low) / diff) * h)) | 0} `;
        }
        points += `${w},${h}`;
        return `<svg xmlns='http://www.w3.org/2000/svg' width='100%' height='100%' viewBox='0 0 ${w} ${h}'><polyline fill='${fill}' stroke='none' points='${points}'/></svg>`;
    }
    _onOrderStateChanged(sender, order) {
        let instrument = this.APIState.InstrumentInfos.get(order.InstrumentId);
        let fm = AFormatManager.instance;
        let timestamp = new Date(order.EntryTime);
        let avgPrice = (order.ValueExecuted / order.ExecutedQuantity);
        let notification = new NotificationItem(order.OrderId, NotificationType.ORDER, [
            `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`,
            'Order Id',
            'Instrument',
            'Type',
            'Avg Price',
            'Qty',
            'Status'
        ], [
            'Order Update',
            `${order.OrderId}`,
            `${instrument.Symbol}`,
            `${OrderTypeEnum[order.OrderType]} ${OrderSideEnum[order.Side]}`,
            `${Object.is(avgPrice, NaN) ? '-' : fm.format(order.InstrumentId, NumberFormatType.PRICE, avgPrice)}`,
            `${fm.format(order.InstrumentId, NumberFormatType.QUANTITY, order.ExecutedQuantity)}/${fm.format(order.InstrumentId, NumberFormatType.QUANTITY, order.ExecutedQuantity + order.RemainingQuantity)}`,
            `${OrderCurrentState[order.CurrentOrderState]}${RejectReason[Number(order.RejectReason)] ? ' - ' + RejectReason[Number(order.RejectReason)] : ''}`
        ]);
        this.triggerNotification(notification.id, notification);
    }
    _onNewTrade(accountState, trade) {
        let instrument = this.APIState.InstrumentInfos.get(trade.InstrumentId);
        let fm = AFormatManager.instance;
        let timestamp = new Date(trade.TradeTime);
        let notification = new NotificationItem(Math.random(), NotificationType.TRADE, [
            `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`,
            'Instrument',
            'Price',
            'Qty'
        ], [
            'Trade Execution',
            `${instrument.Symbol}`,
            fm.format(trade.InstrumentId, NumberFormatType.PRICE, trade.Price),
            fm.format(trade.InstrumentId, NumberFormatType.QUANTITY, trade.Quantity)
        ]);
        this.triggerNotification(notification.id, notification);
    }
    DispatchInstrumentIdChanged() {
        this.instrumentIdChanged.DispatchEvent();
    }
    _onThemeChanged() {
        this.themeChanged.DispatchEvent(this._theme);
    }
    _onLayoutChanged() {
        this.layoutChanged.DispatchEvent(this._layout);
    }
    Deauthenticate() {
        localStorage.removeItem('apex-session-key');
        window.location.reload();
    }
    PromptAuthentication() {
        if (this.ReadyState.ApexGatewayReady) {
            let sm = ASystemManager.instance;
            sm.showAuthenticateUsernamePasswordDialog((username, password) => {
                this.apexGatewayAPI.Authenticate(username, password, null, () => {
                    if (!this.apexGatewayAPI.IsAuthenticated) {
                        if (this.apexGatewayAPI.requiresTwoFAAuthentication) {
                            sm.showAuthenticateTwoFADialog((twoFACode) => {
                                this.apexGatewayAPI.AuthenticateTwoFA(twoFACode, (success) => {
                                    if (!success) {
                                        sm.showAlertDialog('Two-Factor Authentication unsuccessful. Please try again.');
                                    }
                                });
                            });
                        }
                        else {
                            let timestamp = new Date();
                            let notification = new NotificationItem(Math.random(), NotificationType.AUTHENTICATION, [
                                `${timestamp.toLocaleDateString()}, ${timestamp.toLocaleTimeString()}`
                            ], [
                                'Authentication failure',
                            ]);
                            this.triggerNotification(notification.id, notification);
                            sm.showAlertDialog('Authentication failed, please try again', () => {
                                setTimeout(() => {
                                    this.PromptAuthentication();
                                });
                            });
                        }
                    }
                });
            });
        }
    }
    PromptSetupTwoFA(successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            let sm = ASystemManager.instance;
            this.apexGatewayAPI.Request('EnableGoogle2FA', {}, (data) => {
                if (data.hasOwnProperty('ManualCode')) {
                    let qrData = `otpauth://totp/${this.UIConfig.OperatorName}:${this.UserInfo.Email}?secret=${data.ManualCode}`;
                    sm.showSetupTwoFADialog(qrData, (twoFACode) => {
                        this.apexGatewayAPI.AuthenticateTwoFA(twoFACode, (success) => {
                            if (success) {
                                successCallback();
                                sm.showNoticeDialog('2FA Setup successfully.');
                            }
                            else {
                                failureCallback();
                                sm.showAlertDialog('There was an error setting up Two-Factor\nAuthentication. Please try again.');
                            }
                        });
                    }, () => {
                        failureCallback();
                    });
                }
                else {
                    failureCallback();
                    sm.showAlertDialog('There was an error setting up Two-Factor\nAuthentication. Please try again.');
                }
            }, () => {
                failureCallback();
                console.log('TwoFA setup fail');
            });
        }
    }
    PromptRegistration() {
        if (this.ReadyState.ApexGatewayReady) {
            let sm = ASystemManager.instance;
            sm.showRegisterDialog((username, email, password) => {
                this.Register(username, email, password, (data) => {
                    setTimeout(() => {
                        this.PromptAuthentication();
                    }, 20);
                    setTimeout(() => {
                        sm.showNoticeDialog('Thanks for signing up, please check your inbox for a confirmation email');
                    }, 40);
                }, () => {
                    setTimeout(() => {
                        sm.showAlertDialog('There was an error registering. Please try again.');
                    }, 20);
                });
            }, () => {
            });
        }
    }
    ShowVerifyEmailDialog(userID, verifyCode, uri) {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        this.VerifyEmail(userID, verifyCode, uri, (data) => {
            setTimeout(() => {
                sm.showNoticeDialog(lm.get('VerifyEmailDialog', 'Your email has been verified successfully. You can now login to the exchange.'));
            }, 40);
        }, () => {
            sm.showAlertDialog(lm.get('VerifyEmailDialog', 'There was an error verifying your email. Please try again.'));
        });
    }
    ShowResetPasswordDialog(userID, verifyCode, uri) {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        sm.showPromptDialog(lm.get('ResetPasswordDialog', 'Please enter a new password.'), lm.get('ResetPasswordDialog', 'New Password'), (password) => {
            this.ResetPassword(userID, password, verifyCode, uri, (data) => {
                setTimeout(() => {
                    sm.showNoticeDialog(lm.get('ResetPasswordDialog', 'You successfully reset your password. You can now login with your new password.'));
                }, 40);
            }, () => {
                sm.showAlertDialog(lm.get('ResetPasswordDialog', 'Your attempt to reset your password has failed. Contact the exchange admin if the problem persists.'));
            });
        }, () => {
        });
    }
    ShowVerifyDeviceDialog(userID, hashCode, verifyCode, uri) {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        this.ConfirmDevice(userID, hashCode, verifyCode, uri, (data) => {
            setTimeout(() => {
                sm.showNoticeDialog(lm.get('VerifyDeviceDialog', 'Your device has been successfully registered.'));
            }, 40);
        }, () => {
            sm.showAlertDialog(lm.get('VerifyDeviceDialog', 'Your device registration failed. Try clicking the link in the email you received again. Contact the exchange admin if the problem persists.'));
        });
    }
    ShowVerifyWithdrawalAddressDialog(userID, hashCode, verifyCode, uri) {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        this.ConfirmDevice(userID, hashCode, verifyCode, uri, (data) => {
            setTimeout(() => {
                sm.showNoticeDialog(lm.get('VerifyDeviceDialog', 'Your device has been successfully registered.'));
            }, 40);
        }, () => {
            sm.showAlertDialog(lm.get('VerifyDeviceDialog', 'Your device registration failed. Try clicking the link in the email you received again. Contact the exchange admin if the problem persists.'));
        });
    }
    ShowConfirmWithdrawalDialog(userID, verifyCode, uri) {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        this.ConfirmWithdrawal(userID, verifyCode, uri, (data) => {
            setTimeout(() => {
                sm.showNoticeDialog(lm.get('WithdrawalConfirmationDialog', 'Your withdrawal has been confirmed successfully and has started processing.'));
            }, 40);
        }, () => {
            sm.showAlertDialog(lm.get('WithdrawalConfirmationDialog', 'Your withdrawal confirmation failed. Try clicking the link in the email you received again. Contact the exchange admin if the problem persists.'));
        });
    }
    AuthenticateWithApexSessionToken(sessionToken) {
        let accountCreds = new AccountCredentialsObject();
        accountCreds.AuthMethod = AccountCredentialObject_AuthMethodEnum.SessionToken;
        accountCreds.UserName = null;
        accountCreds.Password = null;
        accountCreds.SessionToken = sessionToken;
        this.SetAccountCredentials(accountCreds);
    }
    SelectOrderBookSide(side) {
        this.orderBookSideSelected.DispatchEvent(side);
    }
    SelectOrderBookPrice(price) {
        this.orderBookPriceSelected.DispatchEvent(price);
    }
    ShowTransactionDialog(type, accountID, productID) {
        let dialogContent = null;
        let dialogTitle = '';
        let productInfo = TradingManager.instance.APIState.ProductInfos.get(productID);
        if (type === TransactionType.SEND || type === TransactionType.RECEIVE) {
            dialogTitle = `Send / Receive${productInfo ? ' ' + productInfo.Product : ''}`;
            dialogContent = new SendReceive();
        }
        else if (type === TransactionType.DEPOSIT || type === TransactionType.WITHDRAW) {
            dialogTitle = `Deposit / Withdraw${productInfo ? ' ' + productInfo.Product : ''}`;
            dialogContent = new DepositWithdraw();
        }
        if (dialogContent !== null) {
            dialogContent.accountID = accountID;
            dialogContent.productID = productID;
            dialogContent.type = type;
            let dialog = ASystemManager.instance.showCustomDialog(dialogContent);
            dialog.title = dialogTitle;
            dialog.showX = true;
            dialog.showOK = false;
            dialog.showCancel = false;
        }
    }
    ShowSettingsDialog() {
        let dialog = ASystemManager.instance.showCustomDialog(new Settings());
        dialog.title = ALanguageManager.instance.get('SettingsDialog', 'Settings');
        dialog.showX = true;
        dialog.showOK = false;
        dialog.showCancel = false;
    }
    GetVerificationLevels() {
        let lm = ALanguageManager.instance;
        if (this.UIConfig && this.UIConfig.Verification.hasOwnProperty(lm.languageID)) {
            return this.UIConfig.Verification[lm.languageID];
        }
        else {
            return [];
        }
    }
    GetVerificationLevelIncreaseStatus(callback) {
        this.apexGatewayAPI.Request('GetGeneralKVP', {
            Key: 'levelIncreaseStatus'
        }, (data) => {
            if (data.hasOwnProperty('errormsg') && data.errormsg !== undefined) {
                callback(null);
            }
            else {
                callback(data.levelIncreaseStatus);
            }
        }, () => {
            callback(null);
        });
    }
    ShowKYCDialog(title, uri) {
        let iframe = new AIFrame();
        iframe.addClass('kyc');
        let dialog = ASystemManager.instance.showCustomDialog(iframe);
        dialog.title = title;
        dialog.showX = true;
        dialog.showOK = false;
        dialog.showCancel = false;
        setTimeout(() => {
            iframe.uri = uri;
        });
    }
    ShowPortfolioDialog(productID) {
        let dialog = ASystemManager.instance.showCustomDialog(new Portfolio());
        dialog.title = ALanguageManager.instance.get('PortfolioDialog', 'Portfolio');
        dialog.showX = true;
        dialog.showOK = false;
        dialog.showCancel = false;
    }
    GetDepositHistory(successCallback, failureCallback) {
        this.apexGatewayAPI.Request('GetDepositTickets', {
            AccountId: this.accountId,
            OperatorId: this.UserInfo.OperatorId
        }, (data) => {
            if (!data.hasOwnProperty('errormsg') && data.constructor === Array) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }, failureCallback);
    }
    GetWithdrawalHistory(successCallback, failureCallback) {
        this.apexGatewayAPI.Request('GetWithdrawTickets', {
            AccountId: this.accountId,
            OperatorId: this.UserInfo.OperatorId
        }, (data) => {
            if (!data.hasOwnProperty('errormsg') && data.constructor === Array) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }, failureCallback);
    }
    ShowReportsDialog() {
        let dialog = ASystemManager.instance.showCustomDialog(new Reports());
        dialog.title = 'Reports';
        dialog.showX = true;
        dialog.showOK = false;
        dialog.showCancel = false;
    }
    ShowForgotPasswordDialog() {
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        let dialog = sm.showPromptDialog(lm.get('ForgotPasswordDialog', 'Please enter your username to receive an\nemail with password reset instructions'), lm.get('ForgotPasswordDialog', 'Username'), (output) => {
            this.RequestResetPassword(output);
            setTimeout(() => {
                sm.showNoticeDialog(lm.get('ForgotPasswordDialog', 'Please check your email for a reset password link'));
            }, 20);
        }, () => {
        });
        dialog.title = lm.get('ForgotPasswordDialog', 'Recover Password');
        dialog.okLabel = lm.get('ForgotPasswordDialog', 'OK');
        dialog.cancelLabel = lm.get('ForgotPasswordDialog', 'Cancel');
    }
    GetUserInfo(successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetUserInfo', {}, successCallback, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    GetUserReportTickets(successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetUserReportTickets', {
                UserId: this.apexGatewayAPI.UserId
            }, successCallback, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    GetUserReportWriterResultRecords(successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetUserReportWriterResultRecords', {}, successCallback, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    GetOpenTradeReports(successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetOpenTradeReports', {
                AccountId: this.accountId,
                Limit: 100
            }, successCallback, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    ScheduleUserReport(type, frequency, startDate, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            let command = null;
            if (type === UserReportType.TradeActivity) {
                command = 'ScheduleTradeActivityReport';
            }
            else if (type === UserReportType.Transaction) {
                command = 'ScheduleTransactionActivityReport';
            }
            else if (type === UserReportType.Treasury) {
                command = 'ScheduleTreasuryActivityReport';
            }
            this.apexGatewayAPI.Request(command, {
                frequency: frequency,
                beginTime: startDate.toISOString(),
                accountIdList: [this.accountId]
            }, (data) => {
                if (!data.errormsg) {
                    successCallback();
                }
                else {
                    failureCallback();
                }
            }, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    GenerateUserReport(type, startDate, endDate, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            let command = null;
            if (type === UserReportType.TradeActivity) {
                command = 'GenerateTradeActivityReport';
            }
            else if (type === UserReportType.Transaction) {
                command = 'GenerateTransactionActivityReport';
            }
            else if (type === UserReportType.Treasury) {
                command = 'GenerateTreasuryActivityReport';
            }
            this.apexGatewayAPI.Request(command, {
                startTime: startDate.toISOString(),
                endTime: endDate.toISOString(),
                accountIdList: [this.accountId]
            }, (data) => {
                if (!data.errormsg) {
                    successCallback();
                }
                else {
                    failureCallback();
                }
            }, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    CancelUserReport(reportID, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('CancelUserReport', {
                UserReportId: reportID
            }, (data) => {
                if (data.result && !data.errormsg) {
                    successCallback();
                }
                else {
                    failureCallback();
                }
            }, failureCallback);
        }
        else {
            failureCallback();
        }
    }
    DownloadDocument(id) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('DownloadDocument', {
                descriptorId: id
            }, (data1) => {
                if (data1.hasOwnProperty('statusCode') && data1.statusCode === 'Success') {
                    this.apexGatewayAPI.Request('DownloadDocumentSlice', {
                        descriptorId: id,
                        sliceNum: 0
                    }, (data2) => {
                        if (data2.hasOwnProperty('statusCode') && data2.statusCode === 'Success') {
                            console.log('REPORT', data2.base64Bytes);
                        }
                        else {
                            this._showDocumentDownloadError();
                        }
                    }, () => {
                        this._showDocumentDownloadError();
                    });
                }
                else {
                    this._showDocumentDownloadError();
                }
            }, () => {
                this._showDocumentDownloadError();
            });
        }
        else {
            this._showDocumentDownloadError();
        }
    }
    _showDocumentDownloadError() {
        ASystemManager.instance.showAlertDialog('There was an error downloading your document. Please try again.');
    }
    GetDepositCryptoInfo(accountID, productID, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetDepositRequestInfoTemplate', {
                AccountId: accountID,
                ProductId: productID
            }, (data1) => {
                if (data1.result && !data1.errormsg) {
                    this.apexGatewayAPI.Request('GetDepositInfo', {
                        AccountId: accountID,
                        ProductId: productID,
                        GenerateNewKey: true
                    }, (data2) => {
                        if (data2.result && !data2.errormsg) {
                            successCallback(data2);
                        }
                        else {
                            failureCallback();
                        }
                    }, () => {
                        failureCallback();
                    });
                }
                else {
                    failureCallback();
                }
            }, (error) => {
                failureCallback();
            });
        }
    }
    GetWithdrawCryptoInfo(accountID, productID, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetWithdrawFormTemplateTypes', {
                AccountId: accountID,
                ProductId: productID
            }, (data1) => {
                if (data1.result && !data1.errormsg && data1.hasOwnProperty('TemplateTypes') && data1.TemplateTypes.constructor === Array && data1.TemplateTypes.length > 0) {
                    this.apexGatewayAPI.Request('GetWithdrawTemplate', {
                        AccountId: accountID,
                        ProductId: productID,
                        TemplateType: data1.TemplateTypes[0].TemplateName,
                        AccountProviderId: data1.TemplateTypes[0].AccountProviderId
                    }, (data2) => {
                        if (data2.result && !data2.errormsg) {
                            data2.TemplateName = data1.TemplateTypes[0].TemplateName;
                            data2.AccountProviderId = data1.TemplateTypes[0].AccountProviderId;
                            successCallback(data2);
                        }
                        else {
                            failureCallback();
                        }
                    }, () => {
                        failureCallback();
                    });
                }
                else {
                    failureCallback();
                }
            }, (error) => {
                failureCallback();
            });
        }
    }
    GetDepositFiatInfo(accountID, productID, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetDepositTemplateTypes', {
                AccountId: accountID,
                ProductId: productID
            }, (data1) => {
                if (data1.result && !data1.errormsg && data1.hasOwnProperty('TemplateTypes') && data1.TemplateTypes.constructor === Array && data1.TemplateTypes.length > 0) {
                    if (data1.TemplateTypes[0].TemplateName === 'Standard') {
                        successCallback({
                            TemplateType: 'Standard',
                            TemplateName: data1.TemplateTypes[0].TemplateName,
                            AccountProviderId: data1.TemplateTypes[0].AccountProviderId,
                            Template: JSON.stringify(this._defaultDepositTemplate)
                        });
                    }
                    else {
                        this.apexGatewayAPI.Request('GetDepositRequestInfoTemplate', {
                            AccountId: accountID,
                            ProductId: productID,
                            AccountProviderId: data1.TemplateTypes[0].AccountProviderId
                        }, (data2) => {
                            if (data2.result && !data2.errormsg) {
                                data2.TemplateName = data1.TemplateTypes[0].TemplateName;
                                data2.AccountProviderId = data1.TemplateTypes[0].AccountProviderId;
                                successCallback(data2);
                            }
                            else {
                                failureCallback();
                            }
                        }, () => {
                            failureCallback();
                        });
                    }
                }
                else {
                    failureCallback();
                }
            }, (error) => {
                failureCallback();
            });
        }
    }
    GetWithdrawFiatInfo(accountID, productID, successCallback, failureCallback) {
        if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
            this.apexGatewayAPI.Request('GetWithdrawFormTemplateTypes', {
                AccountId: accountID,
                ProductId: productID
            }, (data1) => {
                if (data1.result && !data1.errormsg && data1.hasOwnProperty('TemplateTypes') && data1.TemplateTypes.constructor === Array && data1.TemplateTypes.length > 0) {
                    this.apexGatewayAPI.Request('GetWithdrawTemplate', {
                        AccountId: accountID,
                        ProductId: productID,
                        TemplateType: data1.TemplateTypes[0].TemplateName,
                        AccountProviderId: data1.TemplateTypes[0].AccountProviderId
                    }, (data2) => {
                        if (data2.result && !data2.errormsg) {
                            data2.TemplateName = data1.TemplateTypes[0].TemplateName;
                            data2.AccountProviderId = data1.TemplateTypes[0].AccountProviderId;
                            successCallback(data2);
                        }
                        else {
                            failureCallback();
                        }
                    }, () => {
                        failureCallback();
                    });
                }
                else {
                    failureCallback();
                }
            }, (error) => {
                failureCallback();
            });
        }
    }
    CreateWithdrawTicket(accountID, productID, amount, templateType, templateForm, successCallback, failureCallback) {
        try {
            if (this.ReadyState.ApexGatewayReady && this.ReadyState.ApexGatewayAuthenticated) {
                this.apexGatewayAPI.Request('CreateWithdrawTicket', {
                    AccountId: accountID,
                    ProductId: productID,
                    Amount: amount,
                    TemplateType: templateType,
                    TemplateForm: JSON.stringify(templateForm)
                }, (data) => {
                    if (data.result && !data.errormsg) {
                        successCallback(data.detail);
                    }
                    else {
                        failureCallback(data.detail);
                    }
                }, (error) => {
                    failureCallback('');
                });
            }
        }
        catch (error) {
            failureCallback('');
        }
    }
    triggerNotification(id, notification) {
        if (this._notifications.has(id)) {
            this._notifications.delete(id);
        }
        this._notifications.set(id, notification);
        if (this._notifications.size > 100) {
            let removeCount = this._notifications.size - 100;
            this._notifications.forEach((notificationItem, notificationID) => {
                if (removeCount > 0) {
                    this._notifications.delete(notificationID);
                    removeCount--;
                }
            });
        }
        this.notificationTriggered.DispatchEvent(id);
    }
    get notifications() {
        return this._notifications;
    }
    get accountId() {
        if (this._accountId !== null) {
            return this._accountId;
        }
        else if (this.ReadyState.AccountsReady) {
            return this.APIState.DefaultAccount.AccountId;
        }
        else {
            return null;
        }
    }
    set accountId(id) {
        if (this._accountId !== id) {
            this._accountId = id;
            this._onAccountIdChanged();
        }
    }
    get instrumentId() {
        return this._instrumentId;
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            if (this._instrumentId !== null) {
                this.SendSubscribeUnsubscribeL2(this._instrumentId, false);
                this.SendSubscribeUnsubscribeMDTrades(this._instrumentId, false);
            }
            this._instrumentId = id;
            this.SendSubscribeUnsubscribeL2(this._instrumentId, true);
            this.SendSubscribeUnsubscribeMDTrades(this._instrumentId, true);
            this._onInstrumentIdChanged();
        }
    }
    get theme() {
        return this._theme;
    }
    set theme(t) {
        if (this._theme !== t) {
            this._theme = t;
            let theme = this._themes.get(t);
            if (theme) {
                let themeElement = document.createElement('style');
                if (theme.CSSString) {
                    document.getElementById('theme').remove();
                    themeElement.id = 'theme';
                    themeElement.textContent = theme.CSSString;
                    document.head.appendChild(themeElement);
                    this._onThemeChanged();
                }
                else {
                    fetch(theme.URI)
                        .then(response => response.text())
                        .then((css) => {
                        document.getElementById('theme').remove();
                        themeElement.id = 'theme';
                        theme.CSSString = css;
                        themeElement.textContent = css;
                        document.head.appendChild(themeElement);
                        this._onThemeChanged();
                    });
                }
            }
        }
    }
    get themes() {
        return this._themes;
    }
    get layout() {
        return this._layout;
    }
    set layout(l) {
        if (this._layout !== l) {
            this._layout = l;
            let layout = this._layouts.get(l);
            if (layout) {
                let layoutElement = document.createElement('style');
                if (layout.CSSString) {
                    document.getElementById('layout').remove();
                    layoutElement.id = 'layout';
                    layoutElement.textContent = layout.CSSString;
                    document.head.appendChild(layoutElement);
                    this._onLayoutChanged();
                }
                else {
                    fetch(layout.URI)
                        .then(response => response.text())
                        .then((css) => {
                        document.getElementById('layout').remove();
                        layoutElement.id = 'layout';
                        layout.CSSString = css;
                        layoutElement.textContent = css;
                        document.head.appendChild(layoutElement);
                        this._onLayoutChanged();
                    });
                }
            }
        }
    }
    get layouts() {
        return this._layouts;
    }
}
