import { AEvent } from '../a/index.js';
export class OrderBookEvent extends AEvent {
}
OrderBookEvent.ITEM_CLICKED = 'orderBookItemClicked';
