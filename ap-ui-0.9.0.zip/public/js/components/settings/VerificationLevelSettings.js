import { AContainer, ALanguageManager } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
import { DialogContentBlock } from '../DialogContentBlock.js';
import { VerificationLevelCard } from './VerificationLevelCard.js';
export class VerificationLevelSettings extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        let lm = ALanguageManager.instance;
        this._verificationsLevelBlock = new DialogContentBlock();
        this._verificationsLevelBlock.title = lm.get('SettingsDialog', 'Current Verification Level');
        this._verificationsLevelBlock.instruction = lm.get('SettingsDialog', 'For your security, some of our services require you to provide basic or additional levels of verification. To verify your account or to check what your current verification level is, see below.');
        this.appendChild(this._verificationsLevelBlock);
    }
    _registerListeners() {
        super._registerListeners();
        this._onAccountInfoUpdated = this._onAccountInfoUpdated.bind(this);
        TradingManager.instance.AccountInfoUpdated.SubscribeEvent(this._onAccountInfoUpdated);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        TradingManager.instance.AccountInfoUpdated.UnsubscribeEvent(this._onAccountInfoUpdated);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let currentLevel = tm.AccountInfo.VerificationLevel;
            let isVerifiedIndex = 99999;
            let verificationLevels = tm.GetVerificationLevels();
            let container = this._verificationsLevelBlock.content;
            while (container.childElementCount !== verificationLevels.length) {
                if (container.childElementCount < verificationLevels.length) {
                    let card = new VerificationLevelCard();
                    container.appendChild(card);
                }
                else if (container.childElementCount > verificationLevels.length) {
                    container.removeChildAt(container.childElementCount - 1);
                }
            }
            verificationLevels.forEach((verificationLevel, index) => {
                console.log('Levels', verificationLevel.Level, currentLevel);
                if (verificationLevel.Level === currentLevel) {
                    isVerifiedIndex = index;
                }
                let card = this._verificationsLevelBlock.content.getChildAt(index);
                card.verificationLevel = verificationLevel;
                card.isVerified = index === isVerifiedIndex;
                card.canApply = index === (isVerifiedIndex + 1);
            });
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        TradingManager.instance.GetVerificationLevelIncreaseStatus((status) => {
        });
    }
    _onAccountInfoUpdated() {
        console.log('AccountInfo Updated', TradingManager.instance.AccountInfo);
    }
}
window.customElements.define('a-verification-level-settings', VerificationLevelSettings);
