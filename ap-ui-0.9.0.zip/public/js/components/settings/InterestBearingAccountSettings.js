import { AButton, AContainer, ALanguageManager, AText } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
import { DialogContentBlock } from '../DialogContentBlock.js';
export class InterestBearingAccountSettings extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        let lm = ALanguageManager.instance;
        let ibaBlock = new DialogContentBlock();
        ibaBlock.title = lm.get('SettingsDialog', 'Interest Bearing Accounts');
        ibaBlock.instruction = lm.get('SettingsDialog', 'Apply to earn passive income on your deposits of selected products. Restrictions apply.');
        this.appendChild(ibaBlock);
        this._lendingStatusText = new AText();
        this._lendingStatusText.text = lm.get('SettingsDialog', 'Lending is enabled');
        ibaBlock.content.appendChild(this._lendingStatusText);
        this._enableDisableIBAButton = new AButton();
        this._enableDisableIBAButton.label = lm.get('SettingsDialog', 'Disable');
        ibaBlock.content.appendChild(this._enableDisableIBAButton);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
}
window.customElements.define('a-interest-bearing-account-settings', InterestBearingAccountSettings);
