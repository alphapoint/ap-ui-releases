import { AButton, AContainer, AText } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
import { DialogContentBlock } from '../DialogContentBlock.js';
export class TradeSettings extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        let ibaBlock = new DialogContentBlock();
        ibaBlock.title = 'Margin Trading';
        ibaBlock.instruction = 'Margin trading is the process by which a trader borrows money from the AlphaPoint Exchange in order to either buy or sell more stock than that trader would otherwise be able to afford.';
        this.appendChild(ibaBlock);
        this._marginStatusText = new AText();
        this._marginStatusText.text = 'Margin Trading is disabled';
        ibaBlock.content.appendChild(this._marginStatusText);
        this._enableDisableMarginButton = new AButton();
        this._enableDisableMarginButton.label = 'Enable';
        ibaBlock.content.appendChild(this._enableDisableMarginButton);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
}
window.customElements.define('a-trade-settings', TradeSettings);
