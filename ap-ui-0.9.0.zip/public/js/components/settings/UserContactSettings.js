import { AContainer, AText } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
export class UserContactSettings extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        let t = new AText();
        t.text = 'User Contact Settings';
        this.appendChild(t);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
}
window.customElements.define('a-user-contact-settings', UserContactSettings);
