import { AButton, AContainer, ALanguageManager, ASelect, ASystemManager } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
import { DialogContentBlock } from '../DialogContentBlock.js';
export class ProfileAndSecuritySettings extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        let lm = ALanguageManager.instance;
        let resetPassBlock = new DialogContentBlock();
        resetPassBlock.title = lm.get('SettingsDialog', 'Password');
        resetPassBlock.instruction = lm.get('SettingsDialog', 'To change your password, we will send you an email that will allow you to access the Reset Password feature. Click the button below to receive the email.');
        this.appendChild(resetPassBlock);
        this._resetPassButton = new AButton();
        this._resetPassButton.label = 'Reset Password';
        resetPassBlock.content.appendChild(this._resetPassButton);
        let twoFABlock = new DialogContentBlock();
        twoFABlock.title = lm.get('SettingsDialog', 'Two-Factor Authentication');
        twoFABlock.instruction = lm.get('SettingsDialog', 'Two-Factor Authentication (2FA) adds another layer of protection to your account by requiring an additional passcode during the logging in process.\n\nYou will need to download Google Authenticator on your smartphone as part of the process to enable 2FA.');
        this.appendChild(twoFABlock);
        this._twoFASelect = new ASelect();
        this._twoFASelect.options = `<option value="1">${lm.get('SettingsDialog', 'Enabled')}</option><option value="0">${lm.get('SettingsDialog', 'Disabled')}</option>`;
        twoFABlock.content.appendChild(this._twoFASelect);
        let languageBlock = new DialogContentBlock();
        languageBlock.title = lm.get('SettingsDialog', 'Region');
        languageBlock.instruction = lm.get('SettingsDialog', 'Allows you to set your preferred language across device logins.');
        this.appendChild(languageBlock);
        this._languageSelect = new ASelect();
        this._languageSelect.options = `<option value="en-US">English</option><option value="pt-BR">Português</option>`;
        languageBlock.content.appendChild(this._languageSelect);
    }
    _registerListeners() {
        super._registerListeners();
        this._resetPassClicked = this._resetPassClicked.bind(this);
        this._resetPassButton.addEventListener('click', this._resetPassClicked);
        this._onTwoFAChange = this._onTwoFAChange.bind(this);
        this._twoFASelect.addEventListener('change', this._onTwoFAChange);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._resetPassButton.removeEventListener('click', this._resetPassClicked);
        this._twoFASelect.removeEventListener('change', this._onTwoFAChange);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._updateUserInfo();
    }
    _updateUserInfo() {
        TradingManager.instance.GetUserInfo((data) => {
            if (data.hasOwnProperty('Use2FA') && data.Use2FA) {
                this._twoFASelect.value = '1';
            }
            else {
                this._twoFASelect.value = '0';
            }
        }, () => {
            this._twoFASelect.value = '0';
        });
    }
    _resetPassClicked(event) {
        let tm = TradingManager.instance;
        let sm = ASystemManager.instance;
        let lm = ALanguageManager.instance;
        sm.showNoticeDialog(lm.get('SettingsDialog', 'Check your email with instructions on changing your password.'));
        tm.RequestResetPassword(tm.UserInfo.UserName);
    }
    _onTwoFAChange(event) {
        if (this._twoFASelect.value === '1') {
            TradingManager.instance.PromptSetupTwoFA(() => {
                this._updateUserInfo();
            }, () => {
                this._updateUserInfo();
            });
        }
    }
}
window.customElements.define('a-profile-and-security-settings', ProfileAndSecuritySettings);
