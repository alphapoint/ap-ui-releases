import { AButton, AContainer, ALabel, ALanguageManager, AText } from '../../a/index.js';
import { TradingManager } from '../../managers/TradingManager.js';
export class VerificationLevelCard extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._canApply = false;
        this._isVerified = false;
        this._verificationLevel = null;
        this._status = null;
        this._headerText = new AText();
        this._headerText.addClass('header');
        this.appendChild(this._headerText);
        this._limitsLabel = new ALabel();
        this.appendChild(this._limitsLabel);
        this._limitsText = new AText();
        this.appendChild(this._limitsText);
        this._benefitsLabel = new ALabel();
        this.appendChild(this._benefitsLabel);
        this._benefitsText = new AText();
        this.appendChild(this._benefitsText);
        this._requirementsLabel = new ALabel();
        this.appendChild(this._requirementsLabel);
        this._requirementsText = new AText();
        this.appendChild(this._requirementsText);
        this._applyButton = new AButton();
        this._applyButton.label = ALanguageManager.instance.get('SettingsDialog', 'Apply');
        this.appendChild(this._applyButton);
    }
    _registerListeners() {
        super._registerListeners();
        this._onApplyClicked = this._onApplyClicked.bind(this);
        this._applyButton.addEventListener('click', this._onApplyClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._applyButton.removeEventListener('click', this._onApplyClicked);
    }
    _render() {
        if (super._render()) {
            if (this._verificationLevel !== null) {
                this._headerText.text = `${this._verificationLevel.Header}${this._isVerified ? ' ' + this.verificationLevel.VerifiedSymbol : ''}`;
                this._headerText.visible = true;
                if (this._verificationLevel.Limits && this._verificationLevel.Limits.constructor === Array && this._verificationLevel.Limits.length > 0) {
                    let l = '';
                    this._verificationLevel.Limits.forEach((limitString, index) => {
                        if (index === 0) {
                            this._limitsLabel.text = limitString;
                        }
                        else {
                            l += limitString;
                            if (index < this._verificationLevel.Limits.length - 1) {
                                l += '\n';
                            }
                        }
                    });
                    this._limitsLabel.visible = true;
                    this._limitsText.text = l;
                    this._limitsText.visible = true;
                }
                else {
                    this._limitsLabel.visible = false;
                    this._limitsText.visible = false;
                }
                if (this._verificationLevel.Benefits && this._verificationLevel.Benefits.constructor === Array && this._verificationLevel.Benefits.length > 0) {
                    let b = '';
                    this._verificationLevel.Benefits.forEach((benefitString, index) => {
                        if (index === 0) {
                            this._benefitsLabel.text = benefitString;
                        }
                        else {
                            b += benefitString;
                            if (index < this._verificationLevel.Benefits.length - 1) {
                                b += '\n';
                            }
                        }
                    });
                    this._benefitsLabel.visible = true;
                    this._benefitsText.text = b;
                    this._benefitsText.visible = true;
                }
                else {
                    this._benefitsLabel.visible = false;
                    this._benefitsText.visible = false;
                }
                if (this._verificationLevel.Requirements && this._verificationLevel.Requirements.constructor === Array && this._verificationLevel.Requirements.length > 0) {
                    let r = '';
                    this._verificationLevel.Requirements.forEach((requirementString, index) => {
                        if (index === 0) {
                            this._requirementsLabel.text = requirementString;
                        }
                        else {
                            r += requirementString;
                            if (index < this._verificationLevel.Requirements.length - 1) {
                                r += '\n';
                            }
                        }
                    });
                    this._requirementsLabel.visible = true;
                    this._requirementsText.text = r;
                    this._requirementsText.visible = true;
                }
                else {
                    this._requirementsLabel.visible = false;
                    this._requirementsText.visible = false;
                }
                this._applyButton.visible = this._canApply;
            }
            else {
                this._headerText.visible = false;
                this._limitsLabel.visible = false;
                this._limitsText.visible = false;
                this._benefitsLabel.visible = false;
                this._benefitsText.visible = false;
                this._requirementsLabel.visible = false;
                this._requirementsText.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _onApplyClicked(event) {
        TradingManager.instance.ShowKYCDialog(this.verificationLevel.IframeTitle, this.verificationLevel.IframeURI);
    }
    get verificationLevel() {
        return this._verificationLevel;
    }
    set verificationLevel(v) {
        if (this._verificationLevel !== v) {
            this._verificationLevel = v;
            this.invalidate();
        }
    }
    get status() {
        return this._status;
    }
    set status(s) {
        if (this._status !== s) {
            this._status = s;
            this.invalidate();
        }
    }
    get canApply() {
        return this._canApply;
    }
    set canApply(c) {
        if (this._canApply !== c) {
            this._canApply = c;
            this.invalidate();
        }
    }
    get isVerified() {
        return this._isVerified;
    }
    set isVerified(i) {
        if (this._isVerified !== i) {
            this._isVerified = i;
            this.invalidate();
        }
    }
}
window.customElements.define('a-verification-level-card', VerificationLevelCard);
