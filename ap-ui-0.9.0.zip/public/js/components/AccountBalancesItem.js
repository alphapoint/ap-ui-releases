import { AComponent, AContainer, AFontAwesomeIcon, AFormatManager, AHeader, AButton, AImage, AText, AImageManager } from '../a/index.js';
import { NumberFormatType } from '../a/managers/AFormatManager.js';
import { ProductType } from '../BrowserSDK/UserAPI/index.js';
import { TradingManager, TransactionType } from '../managers/TradingManager.js';
export class AccountBalancesItem extends AComponent {
    constructor() {
        super();
        this._productId = null;
        this._isCollapsed = true;
        this._currencyImageFailed = false;
    }
    _build() {
        super._build();
        this._header = new AHeader();
        this.appendChild(this._header);
        this._currencyImage = new AImage();
        this._currencyImage.addClass('currency');
        this._header.appendChild(this._currencyImage);
        this._productNameText = new AText();
        this._productNameText.addClass('product-name');
        this._header.appendChild(this._productNameText);
        this._totalAmountText = new AText();
        this._totalAmountText.addClass('total');
        this._totalAmountText.text = '-';
        this._header.appendChild(this._totalAmountText);
        this._availableAmountText = new AText();
        this._availableAmountText.addClass('available');
        this._availableAmountText.text = '-';
        this._header.appendChild(this._availableAmountText);
        this._collapseIcon = new AFontAwesomeIcon();
        this._collapseIcon.addClass('collapse');
        this._header.appendChild(this._collapseIcon);
        this._content = new AContainer();
        this.appendChild(this._content);
        let text = new AText();
        text.text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce porttitor erat at ante gravida, sit amet cursus ligula tristique. Aliquam tellus velit, aliquet ut tempus eget, molestie id velit.';
        this._content.appendChild(text);
        this._sendActionButton = new AButton();
        this._sendActionButton.label = 'Withdraw...';
        this._content.appendChild(this._sendActionButton);
        this._receiveActionButton = new AButton();
        this._receiveActionButton.label = 'Deposit...';
        this._content.appendChild(this._receiveActionButton);
    }
    _registerListeners() {
        super._registerListeners();
        this._onHeaderClicked = this._onHeaderClicked.bind(this);
        this._header.addEventListener('click', this._onHeaderClicked);
        this._onCurrencyImageError = this._onCurrencyImageError.bind(this);
        this._currencyImage.addEventListener('error', this._onCurrencyImageError);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._header.removeEventListener('click', this._onHeaderClicked);
        this._currencyImage.removeEventListener('error', this._onCurrencyImageError);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let productInfo = tm.APIState.ProductInfos.get(this._productId);
            if (productInfo) {
                let fm = AFormatManager.instance;
                this._collapseIcon.visible = true;
                this._currencyImage.visible = true;
                let currencyImageFile = `${productInfo.Product.toLowerCase()}.png`;
                let currencyImageURI = `/images/currency/${currencyImageFile}`;
                this._currencyImage.src = AImageManager.instance.get(currencyImageURI, '/images/currency/generic.png');
                this._productNameText.visible = true;
                this._productNameText.text = productInfo.Product;
                this._totalAmountText.text = this._totalAmount !== null ? fm.format(productInfo.ProductId, NumberFormatType.QUANTITY, this._totalAmount) : '-';
                this._availableAmountText.text = this._availableAmount !== null ? fm.format(productInfo.ProductId, NumberFormatType.QUANTITY, this._availableAmount) : '-';
                if (!this._isCollapsed) {
                    this._collapseIcon.value = ['fal', 'fa-angle-up'];
                    this._content.visible = true;
                    if (productInfo.ProductType === ProductType.CRYPTO_CURRENCY) {
                        this._sendActionButton.label = 'Send...';
                        this._sendActionButton.dataset.action = TransactionType.SEND;
                        this._receiveActionButton.label = 'Receive...';
                        this._receiveActionButton.dataset.action = TransactionType.RECEIVE;
                    }
                    else if (productInfo.ProductType === ProductType.NATIONAL_CURRENCY) {
                        this._sendActionButton.label = 'Withdraw...';
                        this._sendActionButton.dataset.action = TransactionType.WITHDRAW;
                        this._receiveActionButton.label = 'Deposit...';
                        this._receiveActionButton.dataset.action = TransactionType.DEPOSIT;
                    }
                }
                else {
                    this._collapseIcon.value = ['fal', 'fa-angle-down'];
                    this._content.visible = false;
                }
            }
            else {
                this._collapseIcon.visible = false;
                this._currencyImage.visible = false;
                this._productNameText.visible = false;
                this._totalAmountText.visible = false;
                this._availableAmountText.visible = false;
                this._content.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _onHeaderClicked(event) {
    }
    _onCurrencyImageError() {
        this._currencyImageFailed = true;
        this._currencyImage.src = AImageManager.instance.get('/images/currency/generic.png');
    }
    get productID() {
        return this._productId;
    }
    set productID(id) {
        if (this._productId !== id) {
            this._productId = id;
            this._currencyImageFailed = false;
            this.invalidate();
        }
    }
    get totalAmount() {
        return this._productId;
    }
    set totalAmount(a) {
        if (this._totalAmount !== a) {
            this._totalAmount = a;
            this.invalidate();
        }
    }
    get availableAmount() {
        return this._availableAmount;
    }
    set availableAmount(a) {
        if (this._availableAmount !== a) {
            this._availableAmount = a;
            this.invalidate();
        }
    }
    get isCollapsed() {
        return this._isCollapsed;
    }
    set isCollapsed(c) {
        if (this._isCollapsed !== c) {
            this._isCollapsed = c;
            this.invalidate();
        }
    }
}
window.customElements.define('a-account-balances-item', AccountBalancesItem);
