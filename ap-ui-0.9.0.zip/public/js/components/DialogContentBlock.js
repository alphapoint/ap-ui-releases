import { AContainer, ALabel, AText } from '../a/index.js';
export class DialogContentBlock extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._title = null;
        this._instruction = null;
        this._titleText = new AText();
        this._titleText.addClass('title');
        this.appendChild(this._titleText);
        this._instructionLabel = new ALabel();
        this._instructionLabel.addClass('instruction');
        this.appendChild(this._instructionLabel);
        this._content = new AContainer();
        this.appendChild(this._content);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            this._titleText.visible = this._title !== null;
            this._instructionLabel.visible = this._instruction !== null;
            this._titleText.text = this._title;
            this._instructionLabel.text = this._instruction;
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    get title() {
        return this._title;
    }
    set title(t) {
        if (this._title !== t) {
            this._title = t;
            this.invalidate();
        }
    }
    get instruction() {
        return this._instruction;
    }
    set instruction(i) {
        if (this._instruction !== i) {
            this._instruction = i;
            this.invalidate();
        }
    }
    get content() {
        return this._content;
    }
}
window.customElements.define('a-dialog-content-block', DialogContentBlock);
