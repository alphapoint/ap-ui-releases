import { AComponent, AContainer, NumberFormatType, AFormatManager, ALanguageManager, AButton, AImage, AText, AImageManager } from '../a/index.js';
import { TradingManager, TransactionType } from '../managers/TradingManager.js';
export class PortfolioProductsItem extends AComponent {
    constructor(accountId = TradingManager.instance.accountId, productID = null) {
        super();
        this._accountId = accountId;
        this._productId = productID;
        this._currencyImageFailed = false;
    }
    _build() {
        super._build();
        let productContainer = new AContainer();
        productContainer.addClass('product');
        this.appendChild(productContainer);
        this._currencyImage = new AImage();
        this._currencyImage.addClass('currency');
        productContainer.appendChild(this._currencyImage);
        this._productNameText = new AText();
        this._productNameText.addClass('product-name');
        productContainer.appendChild(this._productNameText);
        let holdingsContainer = new AContainer();
        holdingsContainer.addClass('holdings');
        this.appendChild(holdingsContainer);
        this._holdingsText = new AText();
        holdingsContainer.appendChild(this._holdingsText);
        let availableBalanceContainer = new AContainer();
        availableBalanceContainer.addClass('available-balance');
        this.appendChild(availableBalanceContainer);
        this._availableBalanceText = new AText();
        availableBalanceContainer.appendChild(this._availableBalanceText);
        let pendingBalanceContainer = new AContainer();
        pendingBalanceContainer.addClass('pending-balance');
        this.appendChild(pendingBalanceContainer);
        this._pendingBalanceText = new AText();
        pendingBalanceContainer.appendChild(this._pendingBalanceText);
        let availableQuantityContainer = new AContainer();
        availableQuantityContainer.addClass('available-quantity');
        this.appendChild(availableQuantityContainer);
        this._availableQuantityText = new AText();
        availableQuantityContainer.appendChild(this._availableQuantityText);
        let priceContainer = new AContainer();
        priceContainer.addClass('price');
        this.appendChild(priceContainer);
        this._priceText = new AText();
        priceContainer.appendChild(this._priceText);
        let actionsContainer = new AContainer();
        actionsContainer.addClass('actions');
        this.appendChild(actionsContainer);
        this._depositButton = new AButton();
        this._depositButton.addClass('deposit-button');
        actionsContainer.appendChild(this._depositButton);
        this._withdrawButton = new AButton();
        this._withdrawButton.addClass('withdraw-button');
        actionsContainer.appendChild(this._withdrawButton);
    }
    _registerListeners() {
        super._registerListeners();
        this._onCurrencyImageError = this._onCurrencyImageError.bind(this);
        this._currencyImage.addEventListener('error', this._onCurrencyImageError);
        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('click', this._onClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._currencyImage.removeEventListener('error', this._onCurrencyImageError);
        this.removeEventListener('click', this._onClicked);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let productInfo = tm.APIState.ProductInfos.get(this._productId);
            let accountState = tm.APIState.AccountStates.get(this._accountId);
            let accountProductState = accountState ? accountState.AccountProductStates.get(this._productId) : null;
            if (productInfo && accountState) {
                this.visible = true;
                let fm = AFormatManager.instance;
                let lm = ALanguageManager.instance;
                let currencyImageFile = `${productInfo.Product.toLowerCase()}.png`;
                let currencyImageURI = `/images/currency/${currencyImageFile}`;
                this._currencyImage.src = AImageManager.instance.get(currencyImageURI, '/images/currency/generic.png');
                this._productNameText.text = productInfo.Product;
                this._depositButton.label = lm.get('PortfolioDialog', 'Deposit');
                this._withdrawButton.label = lm.get('PortfolioDialog', 'Withdraw');
                if (accountProductState) {
                    this._holdingsText.text = fm.format(accountProductState.ProductId, NumberFormatType.PERCENT, .25);
                    this._availableBalanceText.text = fm.format(accountProductState.ProductId, NumberFormatType.PRICE, accountProductState.ProductAmount);
                    this._pendingBalanceText.text = fm.format(accountProductState.ProductId, NumberFormatType.PRICE, accountProductState.ProductHold);
                    this._availableQuantityText.text = fm.format(accountProductState.ProductId, NumberFormatType.QUANTITY, accountProductState.ProductAmount);
                    this._priceText.text = fm.format(accountProductState.ProductId, NumberFormatType.PRICE, accountProductState.ProductAmount);
                    this._withdrawButton.enabled = (accountProductState.ProductAmount - accountProductState.ProductHold) > 0;
                }
                else {
                    this._holdingsText.text = '-';
                    this._availableBalanceText.text = '-';
                    this._pendingBalanceText.text = '-';
                    this._availableQuantityText.text = '-';
                    this._priceText.text = '-';
                    this._withdrawButton.enabled = false;
                }
            }
            else {
                this.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _onCurrencyImageError() {
        this._currencyImageFailed = true;
        this._currencyImage.src = AImageManager.instance.get('/images/currency/generic.png');
    }
    _onClicked(event) {
        if (event.target === this._depositButton) {
            TradingManager.instance.ShowTransactionDialog(TransactionType.DEPOSIT, this._accountId, this._productId);
        }
        else if (event.target === this._withdrawButton) {
            TradingManager.instance.ShowTransactionDialog(TransactionType.WITHDRAW, this._accountId, this._productId);
        }
    }
}
window.customElements.define('a-portfolio-products-item', PortfolioProductsItem);
