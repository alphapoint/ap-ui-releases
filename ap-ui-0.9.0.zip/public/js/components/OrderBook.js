import { AContainer, AFormatManager, AHeader, ASystemManager, AText, ALanguageManager, NumberFormatType, ALanguageManagerEvent } from '../a/index.js';
import { OrderBookEvent } from '../events/OrderBookEvent.js';
import { TradingManager } from '../managers/TradingManager.js';
import { OrderBookItem, OrderBookItemType } from './OrderBookItem.js';
export class OrderBook extends AContainer {
    constructor() {
        super();
        this._productOneSymbol = '';
        this._productTwoSymbol = '';
        this._openOrders = new Map();
        this._askReuseArray = [];
        this._bidReuseArray = [];
        this._bestBid = 0;
        this._bestAsk = 0;
        this.precision = null;
        this._activeOrderBookItem = null;
    }
    _build() {
        super._build();
        this._header = new AHeader();
        this.appendChild(this._header);
        this._priceHeaderText = new AText();
        this._header.appendChild(this._priceHeaderText);
        this._quantityHeaderText = new AText();
        this._header.appendChild(this._quantityHeaderText);
        this._totalHeaderText = new AText();
        this._header.appendChild(this._totalHeaderText);
        this._userSizeHeaderText = new AText();
        this._header.appendChild(this._userSizeHeaderText);
        this._asksContainer = new AContainer();
        this._asksContainer.addClass('asks');
        this.appendChild(this._asksContainer);
        this._infoContainer = new AContainer();
        this._infoContainer.addClass('info');
        this._infoContainer.visible = TradingManager.instance.UIConfig?.ShowOrderBookSpread || false;
        this.appendChild(this._infoContainer);
        this._spreadText = new AText();
        this._infoContainer.appendChild(this._spreadText);
        this._bidsContainer = new AContainer();
        this._bidsContainer.addClass('bids');
        this.appendChild(this._bidsContainer);
    }
    _registerListeners() {
        super._registerListeners();
        this._onLanguageChanged = this._onLanguageChanged.bind(this);
        ALanguageManager.instance.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        this._onResizeObserved = this._onResizeObserved.bind(this);
        this._resizeObserver = new ResizeObserver(this._onResizeObserved);
        this._resizeObserver.observe(this, {
            box: 'border-box'
        });
        this._onMouseUp = this._onMouseUp.bind(this);
        this.addEventListener('mouseup', this._onMouseUp);
        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('click', this._onClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        ALanguageManager.instance.removeEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        this.removeEventListener('mouseup', this._onMouseUp);
        this.removeEventListener('click', this._onClicked);
        ASystemManager.instance.unregisterContextItem(this._asksContainer);
        ASystemManager.instance.unregisterContextItem(this._bidsContainer);
    }
    _render() {
        if (super._render()) {
            let askItemCount = this._asksContainer.childElementCount;
            let hasAsks = this._instrumentMarketData && this._instrumentMarketData.OrderBookAsks && this._instrumentMarketData.OrderBookAsks.size > 0;
            let a = 0;
            let firstAsk = null;
            let askPrice = 0;
            let askQuantity = 0;
            let askTotal = 0;
            let askOrderQuantity = 0;
            let maxAskQuantity = 0;
            let maxAskChildDataIndex = 0;
            if (hasAsks) {
                let askIterator = this._instrumentMarketData.OrderBookAsks.entries(undefined, this._askReuseArray);
                for (let val of askIterator) {
                    if (a >= askItemCount) {
                        break;
                    }
                    let item = val[1];
                    if (firstAsk === null) {
                        firstAsk = item.Price;
                        askPrice = this._precision !== null ? Math.ceil(item.Price / this._precision) * this._precision : item.Price;
                    }
                    if (this._precision !== null) {
                        if (item.Price > askPrice) {
                            askPrice += this._precision;
                            askQuantity = item.Quantity;
                            askOrderQuantity = this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                            askTotal = item.Price * item.Quantity;
                            a++;
                        }
                        else {
                            askQuantity += item.Quantity;
                            askOrderQuantity += this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                            askTotal += item.Price * item.Quantity;
                        }
                    }
                    else {
                        askPrice = item.Price;
                        askQuantity = item.Quantity;
                        askOrderQuantity = this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                        askTotal = item.Price * item.Quantity;
                    }
                    if (askQuantity > maxAskQuantity) {
                        maxAskQuantity = askQuantity;
                    }
                    let askItem = this._asksContainer.getChildAt(a);
                    if (askItem) {
                        askItem.instrumentId = this.instrumentId;
                        askItem.price = askPrice;
                        askItem.quantity = askQuantity;
                        askItem.total = askTotal;
                        askItem.userOrderQuantity = askOrderQuantity || null;
                        maxAskChildDataIndex = a;
                        if (this._precision === null) {
                            a++;
                        }
                    }
                }
            }
            this._asksContainer.style.setProperty('--max-quantity', String(maxAskQuantity));
            for (let i = a; i < this._asksContainer.childElementCount; i++) {
                let askItem = this._asksContainer.getChildAt(i);
                askItem.price = null;
                askItem.quantity = null;
                askItem.userOrderQuantity = null;
            }
            this._bestAsk = firstAsk || 0;
            let bidItemCount = this._bidsContainer.childElementCount;
            let hasBids = this._instrumentMarketData && this._instrumentMarketData.OrderBookBids && this._instrumentMarketData.OrderBookBids.size > 0;
            let b = 0;
            let firstBid = null;
            let bidPrice = 0;
            let bidQuantity = 0;
            let bidTotal = 0;
            let bidOrderQuantity = 0;
            let maxBidQuantity = 0;
            let maxBidChildDataIndex = 0;
            if (hasBids) {
                let bidIterator = this._instrumentMarketData.OrderBookBids.entries(undefined, this._bidReuseArray);
                for (let val of bidIterator) {
                    if (b >= bidItemCount) {
                        break;
                    }
                    let item = val[1];
                    if (firstBid === null) {
                        firstBid = item.Price;
                        bidPrice = this._precision !== null ? Math.floor(item.Price / this._precision) * this._precision : item.Price;
                    }
                    if (this._precision !== null) {
                        if (item.Price < bidPrice) {
                            bidPrice -= this._precision;
                            bidQuantity = item.Quantity;
                            bidOrderQuantity = this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                            bidTotal = item.Price * item.Quantity;
                            b++;
                        }
                        else {
                            bidQuantity += item.Quantity;
                            bidOrderQuantity += this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                            bidTotal += item.Price * item.Quantity;
                        }
                    }
                    else {
                        bidPrice = item.Price;
                        bidQuantity = item.Quantity;
                        bidOrderQuantity = this._getOpenOrderQuantityAtPrice(item.Price) || 0;
                        bidTotal = item.Price * item.Quantity;
                    }
                    if (bidQuantity > maxBidQuantity) {
                        maxBidQuantity = bidQuantity;
                    }
                    let bidItem = this._bidsContainer.getChildAt(b);
                    if (bidItem) {
                        bidItem.instrumentId = this.instrumentId;
                        bidItem.price = bidPrice;
                        bidItem.quantity = bidQuantity;
                        bidItem.total = bidTotal;
                        bidItem.userOrderQuantity = bidOrderQuantity || null;
                        maxBidChildDataIndex = b;
                        if (this._precision === null) {
                            b++;
                        }
                    }
                }
            }
            this._bidsContainer.style.setProperty('--max-quantity', String(maxBidQuantity));
            for (let i = b; i < this._bidsContainer.childElementCount; i++) {
                let bidItem = this._bidsContainer.getChildAt(i);
                bidItem.price = null;
                bidItem.quantity = null;
                bidItem.userOrderQuantity = null;
            }
            this._bestBid = firstBid || 0;
            let spread = this._bestAsk - this._bestBid;
            if (hasBids && this._instrumentMarketData.OrderBookBids.size > 0 && hasAsks && this._instrumentMarketData.OrderBookAsks.size > 0 && spread >= 0) {
                this._spreadText.text = `${AFormatManager.instance.format(this.instrumentId, NumberFormatType.PRICE, spread)}`;
            }
            else {
                this._spreadText.text = '';
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onLanguageChanged();
    }
    _computeAndDrawRows() {
        if (this._asksContainer.childElementCount === 0) {
            let askItem = new OrderBookItem();
            askItem.type = OrderBookItemType.ASK;
            this._asksContainer.appendChild(askItem);
        }
        let asksHeight = this._asksContainer.offsetHeight;
        let askRowHeight = this._asksContainer.getChildAt(0).offsetHeight;
        let asksRowCount = Math.max(Math.ceil(asksHeight / askRowHeight), 1);
        while (this._asksContainer.childElementCount !== asksRowCount) {
            if (this._asksContainer.childElementCount < asksRowCount) {
                let askItem = new OrderBookItem();
                askItem.type = OrderBookItemType.ASK;
                this._asksContainer.appendChild(askItem);
            }
            else if (this._asksContainer.childElementCount > asksRowCount) {
                this._asksContainer.removeChild(this._asksContainer.getChildAt(this._asksContainer.childElementCount - 1));
            }
        }
        if (this._bidsContainer.childElementCount === 0) {
            let bidItem = new OrderBookItem();
            bidItem.type = OrderBookItemType.BID;
            this._bidsContainer.appendChild(bidItem);
        }
        let bidsHeight = this._bidsContainer.offsetHeight;
        let bidRowHeight = this._bidsContainer.getChildAt(0).offsetHeight;
        let bidsRowCount = Math.max(Math.ceil(bidsHeight / bidRowHeight), 1);
        while (this._bidsContainer.childElementCount !== bidsRowCount) {
            if (this._bidsContainer.childElementCount < bidsRowCount) {
                let bidItem = new OrderBookItem();
                bidItem.type = OrderBookItemType.BID;
                this._bidsContainer.appendChild(bidItem);
            }
            else if (this._bidsContainer.childElementCount > bidsRowCount) {
                this._bidsContainer.removeChild(this._bidsContainer.getChildAt(this._bidsContainer.childElementCount - 1));
            }
        }
    }
    _onLanguageChanged() {
        let lm = ALanguageManager.instance;
        this._priceHeaderText.text = `${lm.get('OrderBook', 'Price')} (${this._productTwoSymbol})`;
        this._quantityHeaderText.text = `${lm.get('OrderBook', 'Qty')} (${this._productOneSymbol})`;
        this._totalHeaderText.text = `${lm.get('OrderBook', 'Total')} (${this._productTwoSymbol})`;
        this._userSizeHeaderText.text = `${lm.get('OrderBook', 'My Order')}`;
    }
    _onResizeObserved(entries, observer) {
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].target === this) {
                this._computeAndDrawRows();
                this.invalidate();
                return;
            }
        }
    }
    _onMouseUp(event) {
        if (event.target.constructor === OrderBookItem) {
            this._activeOrderBookItem = event.target;
        }
        else {
            this._activeOrderBookItem = null;
        }
        if (this._activeOrderBookItem && this._activeOrderBookItem.price !== null) {
        }
    }
    _onClicked(event) {
        if (event.target.constructor === OrderBookItem) {
            let item = event.target;
            if (item.price !== null) {
                this.dispatchEvent(new OrderBookEvent(OrderBookEvent.ITEM_CLICKED));
            }
        }
    }
    _getOpenOrderQuantityAtPrice(price) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this._accountId);
        if (accountState && accountState.OpenOrdersByPrice.has(price)) {
            let ordersByPrice = accountState.OpenOrdersByPrice.get(price);
            if (ordersByPrice && ordersByPrice.size > 0) {
                let quantity = 0;
                ordersByPrice.forEach((order) => {
                    if (order.InstrumentId === this._instrumentId && order.LimitPrice === price && order.RemainingQuantity > 0) {
                        quantity += order.RemainingQuantity;
                    }
                });
                return quantity;
            }
        }
        return null;
    }
    get accountId() {
        return this._accountId;
    }
    set accountId(id) {
        if (this._accountId !== id) {
            this._accountId = id;
            this.invalidate();
        }
    }
    get instrumentId() {
        return this._instrumentId;
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            let tm = TradingManager.instance;
            this._instrumentInfo = tm.APIState.InstrumentInfos.get(this._instrumentId) || null;
            this._instrumentMarketData = tm.APIState.GetInstrumentState(this._instrumentId) || null;
            this._productOneSymbol = this._instrumentInfo ? this._instrumentInfo.Product1Symbol.toUpperCase() : '';
            this._productTwoSymbol = this._instrumentInfo ? this._instrumentInfo.Product2Symbol.toUpperCase() : '';
            this._askReuseArray = [];
            this._bidReuseArray = [];
            this._onLanguageChanged();
            this.invalidate();
        }
    }
    get openOrders() {
        return this._openOrders;
    }
    set openOrders(orders) {
        if (this._openOrders !== orders) {
            this._openOrders = orders;
        }
        this.invalidate();
    }
    get bestAsk() {
        return this._bestAsk;
    }
    get bestBid() {
        return this._bestBid;
    }
    get spread() {
        return this._bestAsk - this._bestBid;
    }
    get activeOrderBookItem() {
        return this._activeOrderBookItem;
    }
    get precision() {
        return this._precision;
    }
    set precision(p) {
        if (this._precision !== p) {
            this._precision = p;
        }
        this.invalidate();
    }
}
window.customElements.define('a-order-book', OrderBook);
