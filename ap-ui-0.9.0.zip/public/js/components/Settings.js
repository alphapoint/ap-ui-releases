import { AButtonBar, AButtonBarEvent, AContainer } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
import { InterestBearingAccountSettings } from './settings/InterestBearingAccountSettings.js';
import { ProfileAndSecuritySettings } from './settings/ProfileAndSecuritySettings.js';
import { VerificationLevelSettings } from './settings/VerificationLevelSettings.js';
export class Settings extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        this._constructorArray = [
            ProfileAndSecuritySettings,
            InterestBearingAccountSettings,
            VerificationLevelSettings,
        ];
        this._instanceMap = new Map();
        this._buttonBar = new AButtonBar();
        this._buttonBar.labels = [
            'Profile & Security',
            'IBA Settings',
            'Verification Level',
        ];
        this._buttonBar.selectedIndex = 0;
        this.appendChild(this._buttonBar);
        this._settingsContainer = new AContainer();
        this.appendChild(this._settingsContainer);
    }
    _registerListeners() {
        super._registerListeners();
        this._onButtonBarChanged = this._onButtonBarChanged.bind(this);
        this._buttonBar.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onButtonBarChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._buttonBar.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onButtonBarChanged);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._showSettings();
    }
    _showSettings() {
        let selectedIndex = this._buttonBar.selectedIndex;
        if (!this._instanceMap.has(selectedIndex)) {
            let component = new this._constructorArray[selectedIndex]();
            this._settingsContainer.appendChild(component);
            this._instanceMap.set(selectedIndex, component);
        }
        this._instanceMap.forEach((component, index) => {
            component.visible = index === selectedIndex;
        });
    }
    _onButtonBarChanged(event) {
        this._showSettings();
    }
}
window.customElements.define('a-settings', Settings);
