import { AContainer, AQRCode, ATextInput } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
export class TwoFASetup extends AContainer {
    constructor(accountID = TradingManager.instance.accountId) {
        super();
        this._accountID = accountID;
    }
    _build() {
        super._build();
        this._qrData = null;
        this._qrCode = new AQRCode();
        this.appendChild(this._qrCode);
        this._twoFAInput = new ATextInput();
        this._twoFAInput.label = '2FA Code';
        this.appendChild(this._twoFAInput);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            if (this._qrData !== null) {
                this._qrCode.data = this._qrData;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    get qrData() {
        return this._qrData;
    }
    set qrData(c) {
        if (this._qrData !== c) {
            this._qrData = c;
            this.invalidate();
        }
    }
    get twoFACode() {
        return this._twoFAInput.value;
    }
}
window.customElements.define('a-two-fa-setup', TwoFASetup);
