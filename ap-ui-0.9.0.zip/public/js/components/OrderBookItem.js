import { AContainer, AFormatManager, NumberFormatType, AText } from '../a/index.js';
export var OrderBookItemType;
(function (OrderBookItemType) {
    OrderBookItemType["BID"] = "BID";
    OrderBookItemType["ASK"] = "ASK";
})(OrderBookItemType || (OrderBookItemType = {}));
export class OrderBookItem extends AContainer {
    constructor() {
        super();
        this._instrumentId = null;
        this._price = null;
        this._quantity = null;
        this._total = null;
        this._userOrderQuantity = null;
        this._userStopOrderQuantity = null;
    }
    _build() {
        super._build();
        this._priceText = new AText();
        this._priceText.addClass('price');
        this.appendChild(this._priceText);
        this._quantityText = new AText();
        this._quantityText.addClass('quantity');
        this.appendChild(this._quantityText);
        this._totalText = new AText();
        this._totalText.addClass('total');
        this.appendChild(this._totalText);
        this._userOrderQuantityText = new AText();
        this._userOrderQuantityText.addClass('user-order-quantity');
        this.appendChild(this._userOrderQuantityText);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            if (this._instrumentId !== null && this._price !== null && this._quantity !== null) {
                let fm = AFormatManager.instance;
                this._priceText.text = fm.format(this._instrumentId, NumberFormatType.PRICE, this._price);
                this._quantityText.text = fm.format(this._instrumentId, NumberFormatType.QUANTITY, this._quantity);
                this._totalText.text = fm.format(this._instrumentId, NumberFormatType.PRICE, this._total);
                if (this._userOrderQuantity !== null && this._userOrderQuantity > 0) {
                    let uoq = fm.format(this._instrumentId, NumberFormatType.QUANTITY, this._userOrderQuantity);
                    if (this._userStopOrderQuantity !== null && this._userStopOrderQuantity > 0) {
                        uoq += ` (${fm.format(this._instrumentId, NumberFormatType.QUANTITY, this._userStopOrderQuantity)})`;
                    }
                    this._userOrderQuantityText.text = uoq;
                }
                else {
                    this._userOrderQuantityText.text = '-';
                }
            }
            else {
                this._priceText.text = '';
                this._quantityText.text = '';
                this._totalText.text = '';
                this._userOrderQuantityText.text = '';
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    get type() {
        return this._type;
    }
    set type(t) {
        if (this._type !== t) {
            this._type = t;
            this.invalidate();
        }
    }
    get instrumentId() {
        return this._instrumentId;
    }
    set instrumentId(i) {
        if (this._instrumentId !== i) {
            this._instrumentId = i;
            this.invalidate();
        }
    }
    get price() {
        return this._price;
    }
    set price(p) {
        if (this._price !== p) {
            this._price = p;
            this.invalidate();
        }
    }
    get quantity() {
        return this._quantity;
    }
    set quantity(q) {
        if (this._quantity !== q) {
            this._quantity = Math.max(q, 0);
            this.style.setProperty('--quantity', String(this._quantity));
            this.invalidate();
        }
    }
    get total() {
        return this._total;
    }
    set total(t) {
        if (this._total !== t) {
            this._total = t;
            this.invalidate();
        }
    }
    get userOrderQuantity() {
        return this._userOrderQuantity;
    }
    set userOrderQuantity(q) {
        if (this._userOrderQuantity !== q) {
            this._userOrderQuantity = q;
            this.invalidate();
        }
    }
    get userStopOrderQuantity() {
        return this._userStopOrderQuantity;
    }
    set userStopOrderQuantity(q) {
        if (this._userOrderQuantity !== q) {
            this._userOrderQuantity = q;
            this.invalidate();
        }
    }
    get percentOfTotal() {
        return this._percentOfTotal;
    }
    set percentOfTotal(p) {
        if (this._percentOfTotal !== p) {
            this._percentOfTotal = p;
            this.invalidate();
        }
    }
}
window.customElements.define('a-order-book-item', OrderBookItem);
