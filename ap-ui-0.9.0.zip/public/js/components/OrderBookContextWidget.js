import { AContextWidget, AButton, ALabel, AText, ATextInput } from '../a/index.js';
import { OrderBookItemType } from './OrderBookItem.js';
export class OrderBookContextWidget extends AContextWidget {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._titleText = new AText();
        this.appendChild(this._titleText);
        let priceLabel = new ALabel();
        priceLabel.text = 'Limit Price';
        this.appendChild(priceLabel);
        this._priceInput = new ATextInput();
        this.appendChild(this._priceInput);
        let quantityLabel = new ALabel();
        quantityLabel.text = 'Quantity';
        this.appendChild(quantityLabel);
        this._quantityInput = new ATextInput();
        this.appendChild(this._quantityInput);
        this._executeButton = new AButton();
        this.appendChild(this._executeButton);
    }
    _render() {
        if (super._render()) {
            this.removeClasses('sell', 'buy');
            if (this._type === OrderBookItemType.ASK) {
                this.addClass('sell');
                this._titleText.text = 'Limit Order Sell';
                this._executeButton.label = 'Sell';
            }
            else if (this._type === OrderBookItemType.BID) {
                this.addClass('buy');
                this._titleText.text = 'Limit Order Buy';
                this._executeButton.label = 'Buy';
            }
            return true;
        }
        else {
            return false;
        }
    }
    _registerListeners() {
        super._registerListeners();
        this._executeButtonClicked = this._executeButtonClicked.bind(this);
        this._executeButton.addEventListener('clicked', this._executeButtonClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._executeButton.removeEventListener('clicked', this._executeButtonClicked);
    }
    setOrderBookItem(item = null) {
        if (item !== null) {
            this._type = item.type;
            this._priceInput.value = String(item.price || '');
            this._quantityInput.value = '0';
        }
        else {
            this._type = null;
        }
        this.invalidate();
    }
    _executeButtonClicked(event) {
        console.log('Execute Clicked', this._type === OrderBookItemType.ASK ? 'Sell' : 'Buy', this._priceInput.value, this._quantityInput.value);
    }
    get isViewable() {
        return this._type !== null && this._priceInput.value !== '';
    }
}
window.customElements.define('a-order-book-context-widget', OrderBookContextWidget);
