import { AButton, AButtonBar, AButtonBarEvent, AContainer, ADataGrid, ADataGridEvent, AFontAwesomeIcon, ASelect, ASystemManager, ATextInput } from '../a/index.js';
import { UserReportFrequency, UserReportStatus } from '../BrowserSDK/UserAPI/index.js';
import { TradingManager } from '../managers/TradingManager.js';
import AvailableReportsDataGridRow from '../renderers/AvailableReportsDataGridRow.js';
import CyclicalReportsDataGridRow from '../renderers/CyclicalReportsDataGridRow.js';
import { DialogContentBlock } from './DialogContentBlock.js';
export class Reports extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._newReportBlock = new DialogContentBlock();
        this._newReportBlock.addClass('new-report');
        this._newReportBlock.title = 'New Report';
        this._newReportBlock.instruction = 'All of your activity on the exchange is available for you to download as a spreadsheet. Simply choose the type of activity and the timeframe to generate your report.';
        this.appendChild(this._newReportBlock);
        this._newReportFrequencyButtons = new AButtonBar();
        this._newReportFrequencyButtons.labels = ['Single', 'Cyclical'];
        this._newReportFrequencyButtons.selectedIndex = 0;
        this._newReportBlock.content.appendChild(this._newReportFrequencyButtons);
        this._newReportTypeSelect = new ASelect();
        this._newReportTypeSelect.label = 'Type';
        this._newReportTypeSelect.options = `<option value="TradeActivity">Trade Activity</option><option value="Transaction">Transaction</option><option value="Treasury">Treasury</option>`;
        this._newReportBlock.content.appendChild(this._newReportTypeSelect);
        this._newReportStartDate = new ATextInput();
        this._newReportStartDate.type = ATextInput.DATE;
        this._newReportStartDate.label = 'Start Date';
        this._newReportBlock.content.appendChild(this._newReportStartDate);
        this._newSingleReportEndDate = new ATextInput();
        this._newSingleReportEndDate.type = ATextInput.DATE;
        this._newSingleReportEndDate.label = 'End Date';
        this._newReportBlock.content.appendChild(this._newSingleReportEndDate);
        this._newCyclicalReportFrequencySelect = new ASelect();
        this._newCyclicalReportFrequencySelect.label = 'Frequency';
        this._newCyclicalReportFrequencySelect.options = `<option value="Hourly">Hourly</option><option value="Daily">Daily</option><option value="Weekly">Weekly</option><option value="Monthly">Monthly</option><option value="Annual">Annually</option>`;
        this._newReportBlock.content.appendChild(this._newCyclicalReportFrequencySelect);
        this._newReportCreateButton = new AButton();
        this._newReportCreateButton.label = 'Create New Report';
        this._newReportBlock.content.appendChild(this._newReportCreateButton);
        let cyclicalReportsBlock = new DialogContentBlock();
        cyclicalReportsBlock.addClass('cyclical-reports');
        cyclicalReportsBlock.title = 'Cyclical Reports';
        this.appendChild(cyclicalReportsBlock);
        this._cyclicalReportsGrid = new ADataGrid();
        this._cyclicalReportsGrid.columnLabels = ['Type', 'Frequency', 'Created', 'Actions'];
        this._cyclicalReportsGrid.rowRenderer = CyclicalReportsDataGridRow;
        this._cyclicalReportsGrid.selectable = false;
        cyclicalReportsBlock.content.appendChild(this._cyclicalReportsGrid);
        let availableReportsBlock = new DialogContentBlock();
        availableReportsBlock.addClass('available-reports');
        availableReportsBlock.title = 'Available Reports';
        this.appendChild(availableReportsBlock);
        this._availableReportsGrid = new ADataGrid();
        this._availableReportsGrid.columnLabels = ['Type', 'Date Range', 'Frequency', 'Created', 'Status', 'Actions'];
        this._availableReportsGrid.rowRenderer = AvailableReportsDataGridRow;
        this._availableReportsGrid.selectable = false;
        availableReportsBlock.content.appendChild(this._availableReportsGrid);
        this._onNewReportChange(null);
    }
    _registerListeners() {
        super._registerListeners();
        this._onNewReportChange = this._onNewReportChange.bind(this);
        this._newReportBlock.addEventListener('change', this._onNewReportChange);
        this._newReportFrequencyButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onNewReportChange);
        this._onNewReportCreateButtonClicked = this._onNewReportCreateButtonClicked.bind(this);
        this._newReportCreateButton.addEventListener('click', this._onNewReportCreateButtonClicked);
        this._onCyclicalReportsDataGridRowClicked = this._onCyclicalReportsDataGridRowClicked.bind(this);
        this._cyclicalReportsGrid.addEventListener(ADataGridEvent.ROW_CLICK, this._onCyclicalReportsDataGridRowClicked);
        this._onAvailableReportsDataGridRowClicked = this._onAvailableReportsDataGridRowClicked.bind(this);
        this._availableReportsGrid.addEventListener(ADataGridEvent.ROW_CLICK, this._onAvailableReportsDataGridRowClicked);
        this._refreshInterval = setInterval(() => {
            this._getReports();
        }, 10000);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._newReportBlock.removeEventListener('change', this._onNewReportChange);
        this._newReportFrequencyButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onNewReportChange);
        this._newReportCreateButton.removeEventListener('click', this._onNewReportCreateButtonClicked);
        this._cyclicalReportsGrid.removeEventListener(ADataGridEvent.ROW_CLICK, this._onCyclicalReportsDataGridRowClicked);
        this._availableReportsGrid.removeEventListener(ADataGridEvent.ROW_CLICK, this._onAvailableReportsDataGridRowClicked);
        clearInterval(this._refreshInterval);
        this._refreshInterval = null;
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._getReports();
    }
    _onNewReportChange(event) {
        let isValid = false;
        if (this._newReportFrequencyButtons.selectedIndex === 0) {
            this._newSingleReportEndDate.visible = true;
            this._newCyclicalReportFrequencySelect.visible = false;
            let offset = new Date().getTimezoneOffset() * 60 * 1000;
            if (this._newReportStartDate.value !== '' && this._newSingleReportEndDate.value !== '') {
                this._newReportStartDate.max = this._newSingleReportEndDate.value;
                this._newSingleReportEndDate.min = this._newReportStartDate.value;
                let s = Date.parse(this._newReportStartDate.value);
                let e = Date.parse(this._newSingleReportEndDate.value);
                isValid = s <= e;
            }
            else if (this._newReportStartDate.value !== '') {
                this._newSingleReportEndDate.min = this._newReportStartDate.value;
            }
            else if (this._newSingleReportEndDate.value !== '') {
                this._newReportStartDate.max = this._newSingleReportEndDate.value;
            }
        }
        else if (this._newReportFrequencyButtons.selectedIndex === 1) {
            this._newSingleReportEndDate.visible = false;
            this._newCyclicalReportFrequencySelect.visible = true;
            this._newReportStartDate.max = '';
            this._newSingleReportEndDate.value = '';
            if (this._newReportStartDate.value !== '') {
                isValid = true;
            }
        }
        this._newReportCreateButton.enabled = isValid;
    }
    _getReports() {
        let tm = TradingManager.instance;
        if (tm.ReadyState.ApexGatewayAuthenticated) {
            tm.GetUserReportTickets((tickets) => {
                this._cyclicalReportsGrid.removeAllItems();
                this._availableReportsGrid.removeAllItems();
                tickets.forEach((ticket) => {
                    if (ticket.RequestStatus === UserReportStatus.InProgress || ticket.RequestStatus === UserReportStatus.Completed) {
                        this._availableReportsGrid.addItem([ticket]);
                    }
                    else if ((ticket.RequestStatus === UserReportStatus.Scheduled || ticket.RequestStatus === UserReportStatus.Submitted) && ticket.ReportFrequency !== UserReportFrequency.OnDemand) {
                        this._cyclicalReportsGrid.addItem([ticket]);
                    }
                });
            }, () => {
                this._cyclicalReportsGrid.removeAllItems();
                this._availableReportsGrid.removeAllItems();
            });
        }
    }
    _cancelCyclicalReport(reportID) {
        let dialog = ASystemManager.instance.showConfirmDialog(`Are you sure you want to cancel this report?`, () => {
            let tm = TradingManager.instance;
            tm.CancelUserReport(reportID, () => {
                this._getReports();
            }, () => {
                this._getReports();
            });
        }, null);
        dialog.title = 'Cancel Report';
        dialog.okLabel = 'Yes';
        dialog.cancelLabel = 'No';
    }
    _onNewReportCreateButtonClicked(event) {
        let tm = TradingManager.instance;
        if (this._newReportFrequencyButtons.selectedIndex === 0) {
            tm.GenerateUserReport(this._newReportTypeSelect.value, new Date(this._newReportStartDate.value), new Date(this._newSingleReportEndDate.value), () => {
                this._newReportStartDate.value = '';
                this._newSingleReportEndDate.value = '';
                this._onNewReportChange(null);
                this._getReports();
            }, () => {
                ASystemManager.instance.showAlertDialog('There was an error creating your report. Please try again.');
                this._getReports();
            });
        }
        else if (this._newReportFrequencyButtons.selectedIndex === 1) {
            tm.ScheduleUserReport(this._newReportTypeSelect.value, this._newCyclicalReportFrequencySelect.value, new Date(this._newReportStartDate.value), () => {
                this._newReportStartDate.value = '';
                this._newSingleReportEndDate.value = '';
                this._onNewReportChange(null);
                this._getReports();
            }, () => {
                ASystemManager.instance.showAlertDialog('There was an error scheduling your report. Please try again.');
                this._getReports();
            });
        }
    }
    _onCyclicalReportsDataGridRowClicked(event) {
        if (event.target.constructor === AFontAwesomeIcon) {
            let icon = event.target;
            let reportID = this._cyclicalReportsGrid.getItemAt(event.detail.index)[0].RequestId;
            if (icon.hasClass('cancel')) {
                this._cancelCyclicalReport(reportID);
            }
        }
    }
    _onAvailableReportsDataGridRowClicked(event) {
        if (event.target.constructor === AFontAwesomeIcon) {
            let icon = event.target;
            let reportID = this._cyclicalReportsGrid.getItemAt(event.detail.index)[0].RequestId;
            if (icon.hasClass('download')) {
                this._cancelCyclicalReport(reportID);
            }
        }
    }
}
window.customElements.define('a-reports', Reports);
