import { AComponent, AFormatManager, AImage, AImageManager, AText } from '../a/index.js';
import { NumberFormatType } from '../a/managers/AFormatManager.js';
import { TradingManager } from '../managers/TradingManager.js';
export class InstrumentSelectorItem extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._instrumentId = null;
        this._product1Symbol = null;
        this._product2Symbol = null;
        this._isSelected = false;
        this._currencyImageFailed = false;
        this._currencyImage = new AImage();
        this._currencyImage.addClass('currency');
        this._currencyImage.visible = false;
        this.appendChild(this._currencyImage);
        this._instrumentNameText = new AText();
        this._instrumentNameText.addClass('instrument-name');
        this.appendChild(this._instrumentNameText);
        this._lastPriceText = new AText();
        this.appendChild(this._lastPriceText);
        this._24hrChangeText = new AText();
        this._24hrChangeText.addClass('day-change');
        this.appendChild(this._24hrChangeText);
        this._24hrVolumeText = new AText();
        this._24hrVolumeText.addClasses('day-volume', 'up');
        this.appendChild(this._24hrVolumeText);
    }
    _registerListeners() {
        super._registerListeners();
        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('mousedown', this._onClicked);
        this._onCurrencyImageError = this._onCurrencyImageError.bind(this);
        this._currencyImage.addEventListener('error', this._onCurrencyImageError);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._header.removeEventListener('click', this._onClicked);
        this._currencyImage.removeEventListener('error', this._onCurrencyImageError);
    }
    _render() {
        if (super._render()) {
            let tm = TradingManager.instance;
            let instrumentInfo = tm.APIState.InstrumentInfos.get(this._instrumentId);
            if (instrumentInfo && instrumentInfo.Product1Symbol !== 'CAD') {
                let fm = AFormatManager.instance;
                if (this._isSelected) {
                    if (!this.hasClass('selected')) {
                        this.addClass('selected');
                    }
                }
                else {
                    if (this.hasClass('selected')) {
                        this.removeClass('selected');
                    }
                }
                let currencyImageFile = `${instrumentInfo.Product1Symbol.toLowerCase()}.png`;
                let currencyImageURI = `/images/currency/${currencyImageFile}`;
                this._currencyImage.src = AImageManager.instance.get(currencyImageURI, '/images/currency/generic.png');
                this._currencyImage.visible = true;
                this._instrumentNameText.text = instrumentInfo.Symbol;
                if (tm.ReadyState.GlobalInstrumentDataFXReady) {
                    tm.GlobalInstrumentData.Get_Rolling24HR_OHLCV(instrumentInfo.Product1Symbol, instrumentInfo.Product2Symbol, (ohlcv) => {
                        if (ohlcv) {
                            this._lastPriceText.text = `$${fm.format(instrumentInfo.InstrumentId, NumberFormatType.PRICE, ohlcv.Close)}`;
                            let changePercent = ((ohlcv.Close - ohlcv.Open) / ohlcv.Close) / 100;
                            this._24hrChangeText.removeClasses('up', 'down');
                            this._24hrChangeText.addClass(changePercent >= 0 ? 'up' : 'down');
                            this._24hrChangeText.text = `${fm.format(instrumentInfo.InstrumentId, NumberFormatType.PERCENT, changePercent)}`;
                            this._24hrVolumeText.text = `${fm.format(instrumentInfo.InstrumentId, NumberFormatType.QUANTITY, ohlcv.TradeVolumeValue)}`;
                        }
                        else {
                            this._lastPriceText.text = '—';
                            this._24hrChangeText.text = '—';
                            this._24hrVolumeText.text = '—';
                        }
                    });
                }
                else {
                    this._lastPriceText.text = '—';
                    this._24hrChangeText.text = '—';
                    this._24hrVolumeText.text = '—';
                }
            }
            else {
                this._currencyImage.visible = false;
                this.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _onClicked(event) {
        TradingManager.instance.instrumentId = event.target.closest('a-instrument-selector-item').instrumentID;
    }
    _onCurrencyImageError() {
        this._currencyImageFailed = true;
        this._currencyImage.src = AImageManager.instance.get('/images/currency/generic.png');
    }
    get instrumentID() {
        return this._instrumentId;
    }
    set instrumentID(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            this._currencyImageFailed = false;
            let tm = TradingManager.instance;
            if (tm.APIState.InstrumentInfos.has(this._instrumentId)) {
                let instrumentInfo = tm.APIState.InstrumentInfos.get(this._instrumentId);
                this._instrumentSymbol = instrumentInfo.Symbol.toLowerCase();
                this._product1Symbol = instrumentInfo.Product1Symbol.toLowerCase();
                this._product2Symbol = instrumentInfo.Product2Symbol.toLowerCase();
            }
            else {
                this._product1Symbol = null;
                this._product2Symbol = null;
            }
            this.invalidate();
        }
    }
    get instrumentSymbol() {
        return this._instrumentSymbol;
    }
    get product1Symbol() {
        return this._product1Symbol;
    }
    get product2Symbol() {
        return this._product2Symbol;
    }
    get isSelected() {
        return this._isSelected;
    }
    set isSelected(s) {
        if (this._isSelected !== s) {
            this._isSelected = s;
            this.invalidate();
        }
    }
}
window.customElements.define('a-instrument-selector-item', InstrumentSelectorItem);
