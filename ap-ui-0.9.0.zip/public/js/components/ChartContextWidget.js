import { AContextWidget, AButton, ATextInput, AButtonBar } from '../a/index.js';
export class ChartContextWidget extends AContextWidget {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._price = null;
        this._orderSideButtons = new AButtonBar();
        this._orderSideButtons.addClass('order-side-buttons');
        this._orderSideButtons.labels = ['Buy', 'Sell'];
        this._orderSideButtons.selectedIndex = 0;
        this.appendChild(this._orderSideButtons);
        this._priceInput = new ATextInput();
        this._priceInput.label = 'Limit Price';
        this.appendChild(this._priceInput);
        this._quantityInput = new ATextInput();
        this._quantityInput.label = 'Quantity';
        this.appendChild(this._quantityInput);
        this._executeButton = new AButton();
        this._executeButton.label = 'Send Order';
        this.appendChild(this._executeButton);
    }
    _render() {
        if (super._render()) {
            this._priceInput.value = String(this._price);
            return true;
        }
        else {
            return false;
        }
    }
    _registerListeners() {
        super._registerListeners();
        this._executeButtonClicked = this._executeButtonClicked.bind(this);
        this._executeButton.addEventListener('clicked', this._executeButtonClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._executeButton.removeEventListener('clicked', this._executeButtonClicked);
    }
    _executeButtonClicked(event) {
        console.log('Execute Clicked', this._priceInput.value, this._quantityInput.value);
    }
    get isViewable() {
        return this._price !== null;
    }
    get price() {
        return this._price;
    }
    set price(p) {
        if (this._price !== p) {
            this._price = p;
            this.invalidate();
        }
    }
}
window.customElements.define('a-chart-context-widget', ChartContextWidget);
