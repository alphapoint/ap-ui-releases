import { AContainer, AButton, AText, APanel, ALanguageManager, ALanguageManagerEvent } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
export class TradingPanel extends APanel {
    constructor() {
        super();
        this._requireAuthentication = false;
        this._accountId = null;
        this._instrumentId = null;
    }
    _build() {
        super._build();
        this._authenticationOverlay = new AContainer();
        this._authenticationOverlay.addClass('authentication-overlay');
        this._authenticationOverlay.visible = false;
        this._panelContents.appendChild(this._authenticationOverlay);
        this._authenticateText = new AText();
        this._authenticateText.text = 'To use this feature, you must be authenticated.';
        this._authenticationOverlay.appendChild(this._authenticateText);
        this._authenticateButton = new AButton();
        this._authenticateButton.icon = ['fal', 'fa-user-unlock'];
        this._authenticateButton.label = 'Authenticate';
        this._authenticationOverlay.appendChild(this._authenticateButton);
    }
    _registerListeners() {
        super._registerListeners();
        let lm = ALanguageManager.instance;
        this._onLanguageChanged = this._onLanguageChanged.bind(this);
        lm.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        this._onTradingManagerReadyStateChanged = this._onTradingManagerReadyStateChanged.bind(this);
        tm.ReadyState.StateChanged.SubscribeEvent(this._onTradingManagerReadyStateChanged);
        this._onAccountIdChanged = this._onAccountIdChanged.bind(this);
        tm.InstrumentIdChanged.SubscribeEvent(this._onAccountIdChanged);
        this._onInstrumentIdChanged = this._onInstrumentIdChanged.bind(this);
        tm.InstrumentIdChanged.SubscribeEvent(this._onInstrumentIdChanged);
        this._onAuthenticateClicked = this._onAuthenticateClicked.bind(this);
        this._authenticateButton.addEventListener('click', this._onAuthenticateClicked);
        this._onTradingManagerReadyStateChanged();
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let lm = ALanguageManager.instance;
        lm.removeEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        tm.ReadyState.StateChanged.UnsubscribeEvent(this._onTradingManagerReadyStateChanged);
        tm.InstrumentIdChanged.UnsubscribeEvent(this._onAccountIdChanged);
        tm.InstrumentIdChanged.UnsubscribeEvent(this._onInstrumentIdChanged);
        this._authenticateButton.removeEventListener('click', this._onAuthenticateClicked);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onLanguageChanged();
        this._onTradingManagerReadyStateChanged();
    }
    _onLanguageChanged() {
        this.invalidate();
    }
    _onTradingManagerReadyStateChanged() {
        this.invalidate();
        let tm = TradingManager.instance;
        if (this._requireAuthentication && !tm.ReadyState.AccountsReady) {
            this._authenticationOverlay.visible = true;
            this.addClass('require-authentication');
            this._authenticateText.visible = tm.UIConfig.AllowUserAuthentication;
            this._authenticateButton.visible = tm.UIConfig.AllowUserAuthentication;
        }
        else {
            this._authenticationOverlay.visible = false;
            this.removeClass('require-authentication');
        }
        if (tm.ReadyState.InstanceConfigReady && !tm.ReadyState.PreviousInstanceConfigReady) {
        }
    }
    _onAccountIdChanged() {
    }
    _onInstrumentIdChanged() {
    }
    _onAuthenticateClicked(event) {
        event.stopPropagation();
        let tm = TradingManager.instance;
        tm.PromptAuthentication();
    }
    get requireAuthentication() {
        return this._requireAuthentication;
    }
    set requireAuthentication(r) {
        if (this._requireAuthentication !== r) {
            this._requireAuthentication = r;
            this.invalidate();
        }
    }
    get accountId() {
        return this._accountId !== null ? this._accountId : (this.panelGrid.accountId || null);
    }
    set accountId(id) {
        if (this._accountId !== id) {
            this._accountId = id;
            TradingManager.instance.DispatchAccountIdChanged();
        }
    }
    get instrumentId() {
        return this._instrumentId !== null ? this._instrumentId : (this.panelGrid.instrumentId || null);
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            TradingManager.instance.DispatchInstrumentIdChanged();
        }
    }
}
window.customElements.define('a-trading-panel-contents', TradingPanel);
