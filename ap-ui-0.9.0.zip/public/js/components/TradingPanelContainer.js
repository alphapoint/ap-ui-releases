import { APanelGrid } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
export class TradingPanelContainer extends APanelGrid {
    constructor() {
        super();
        this._accountId = null;
        this._instrumentId = null;
    }
    _build() {
        super._build();
    }
    _registerListeners() {
        super._registerListeners();
        let tm = TradingManager.instance;
        this._onTradingManagerReadyStateChanged = this._onTradingManagerReadyStateChanged.bind(this);
        tm.ReadyState.StateChanged.SubscribeEvent(this._onTradingManagerReadyStateChanged);
        this._onAccountIdChanged = this._onAccountIdChanged.bind(this);
        tm.AccountIdChanged.SubscribeEvent(this._onAccountIdChanged);
        this._onInstrumentIdChanged = this._onInstrumentIdChanged.bind(this);
        tm.InstrumentIdChanged.SubscribeEvent(this._onInstrumentIdChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let tm = TradingManager.instance;
        tm.ReadyState.StateChanged.UnsubscribeEvent(this._onTradingManagerReadyStateChanged);
        tm.AccountIdChanged.UnsubscribeEvent(this._onAccountIdChanged);
        tm.InstrumentIdChanged.UnsubscribeEvent(this._onInstrumentIdChanged);
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onAccountIdChanged();
        this._onInstrumentIdChanged();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _onTradingManagerReadyStateChanged() {
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstanceConfigReady) {
            this._onAccountIdChanged();
            this._onInstrumentIdChanged();
        }
    }
    _onAccountIdChanged() {
    }
    _onInstrumentIdChanged() {
    }
    get accountId() {
        return this._accountId !== null ? this._accountId : (TradingManager.instance.accountId || null);
    }
    set accountId(id) {
        if (this._accountId !== id) {
            this._accountId = id;
            TradingManager.instance.DispatchAccountIdChanged();
        }
    }
    get instrumentId() {
        return this._instrumentId !== null ? this._instrumentId : (TradingManager.instance.instrumentId || null);
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            TradingManager.instance.DispatchInstrumentIdChanged();
        }
    }
}
window.customElements.define('a-trading-panel-container', TradingPanelContainer);
