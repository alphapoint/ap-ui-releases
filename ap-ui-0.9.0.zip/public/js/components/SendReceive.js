import { AButtonBar, AContainer, AForm, AButton, ALabel, ATabView, ATextInput } from '../a/index.js';
import { TransactionType } from '../managers/TradingManager.js';
export class SendReceive extends AContainer {
    constructor() {
        super();
        this._type = TransactionType.RECEIVE;
        this._productID = 0;
    }
    _build() {
        super._build();
        this._tabView = new ATabView();
        this._tabView.labels = ['Send', 'Receive'];
        this.appendChild(this._tabView);
        this._sendForm = new AForm();
        this._tabView.content.appendChild(this._sendForm);
        this._sendTargetButtons = new AButtonBar();
        this._sendTargetButtons.labels = ['To External Wallet', 'To Email Address'];
        this._sendTargetButtons.selectedIndex = 0;
        this._sendForm.appendChild(this._sendTargetButtons);
        let sendCommentLabel = new ALabel();
        sendCommentLabel.text = 'Comment';
        this._sendForm.appendChild(sendCommentLabel);
        this._sendCommentInput = new ATextInput();
        this._sendForm.appendChild(this._sendCommentInput);
        let sendExternalAddressLabel = new ALabel();
        sendExternalAddressLabel.text = 'External Address';
        this._sendForm.appendChild(sendExternalAddressLabel);
        this._sendExternalAddressInput = new ATextInput();
        this._sendForm.appendChild(this._sendExternalAddressInput);
        let sendQuantityLabel = new ALabel();
        sendQuantityLabel.text = 'Quantity';
        this._sendForm.appendChild(sendQuantityLabel);
        this._sendQuantityInput = new ATextInput();
        this._sendForm.appendChild(this._sendQuantityInput);
        this._sendButton = new AButton();
        this._sendButton.label = 'Send';
        this._sendForm.appendChild(this._sendButton);
        this._receiveForm = new AForm();
        this._tabView.content.appendChild(this._receiveForm);
        this._receiveSourceButtons = new AButtonBar();
        this._receiveSourceButtons.labels = ['From Friend', 'From External Wallet'];
        this._receiveSourceButtons.selectedIndex = 0;
        this._receiveForm.appendChild(this._receiveSourceButtons);
    }
    _registerListeners() {
        super._registerListeners();
        this._onSendSubmit = this._onSendSubmit.bind(this);
        this._sendForm.addEventListener('submit', this._onSendSubmit);
        this._onReceiveSubmit = this._onReceiveSubmit.bind(this);
        this._receiveForm.addEventListener('submit', this._onReceiveSubmit);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._sendForm.removeEventListener('submit', this._onSendSubmit);
        this._receiveForm.removeEventListener('submit', this._onReceiveSubmit);
    }
    _render() {
        if (super._render()) {
            if (this._type === TransactionType.SEND) {
                this._tabView.selectedIndex = 0;
            }
            else if (this._type === TransactionType.RECEIVE) {
                this._tabView.selectedIndex = 1;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _onSendSubmit(event) {
        event.preventDefault();
    }
    _onReceiveSubmit(event) {
        event.preventDefault();
    }
    get type() {
        return this._type;
    }
    set type(t) {
        if (this._type !== t) {
            this._type = t;
            this.invalidate();
        }
    }
    get accountID() {
        return this._accountID;
    }
    set accountID(id) {
        if (this._accountID !== id) {
            this._accountID = id;
            this.invalidate();
        }
    }
    get productID() {
        return this._productID;
    }
    set productID(id) {
        if (this._productID !== id) {
            this._productID = id;
            this.invalidate();
        }
    }
}
window.customElements.define('a-send-receive', SendReceive);
