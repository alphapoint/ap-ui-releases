import { AContainer, ATabView, ALanguageManager, ADataGrid, ATabViewEvent } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
import { PortfolioProducts } from './PortfolioProducts.js';
export class Portfolio extends AContainer {
    constructor() {
        super();
        this._accountID = TradingManager.instance.accountId;
    }
    _build() {
        super._build();
        this._tabView = new ATabView();
        this.appendChild(this._tabView);
        this._products = new PortfolioProducts(this._accountID);
        this._tabView.content.appendChild(this._products);
        this._deposits = new ADataGrid();
        this._tabView.content.appendChild(this._deposits);
        this._withdrawals = new ADataGrid();
        this._tabView.content.appendChild(this._withdrawals);
    }
    _registerListeners() {
        super._registerListeners();
        this._onTabChanged = this._onTabChanged.bind(this);
        this._tabView.addEventListener(ATabViewEvent.SELECTED_INDEX_CHANGE, this._onTabChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._tabView.removeEventListener(ATabViewEvent.SELECTED_INDEX_CHANGE, this._onTabChanged);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        let lm = ALanguageManager.instance;
        this._tabView.labels = [
            lm.get('PortfolioDialog', 'Products'),
            lm.get('PortfolioDialog', 'Deposit History'),
            lm.get('PortfolioDialog', 'Withdrawal History')
        ];
        this._deposits.columnLabels = [
            lm.get('PortfolioDialog', 'Product'),
            lm.get('PortfolioDialog', 'Amount'),
            lm.get('PortfolioDialog', 'Fee'),
            lm.get('PortfolioDialog', 'Notional Value'),
            lm.get('PortfolioDialog', 'Status'),
            lm.get('PortfolioDialog', 'Status Message'),
            lm.get('PortfolioDialog', 'Created'),
            lm.get('PortfolioDialog', 'Updated')
        ];
        this._withdrawals.columnLabels = [
            lm.get('PortfolioDialog', 'Product'),
            lm.get('PortfolioDialog', 'Amount'),
            lm.get('PortfolioDialog', 'Fee'),
            lm.get('PortfolioDialog', 'Notional Value'),
            lm.get('PortfolioDialog', 'Status'),
            lm.get('PortfolioDialog', 'Status Message'),
            lm.get('PortfolioDialog', 'Created'),
            lm.get('PortfolioDialog', 'Updated')
        ];
    }
    _onTabChanged() {
        this._getDepositWithdrawalHistory();
    }
    _getDepositWithdrawalHistory() {
        let tm = TradingManager.instance;
        tm.GetDepositHistory((depositTickets) => {
            let data = depositTickets.map((ticket) => {
                let createdDate = new Date(ticket.CreatedTimestamp);
                let updatedDate = new Date(ticket.LastUpdateTimeStamp);
                return [
                    ticket.AssetName,
                    ticket.Amount,
                    ticket.FeeAmt,
                    ticket.NotionalValue,
                    ticket.Status,
                    ticket.RejectReason || '',
                    `${createdDate.toLocaleDateString()} ${createdDate.toLocaleTimeString()}`,
                    `${updatedDate.toLocaleDateString()} ${updatedDate.toLocaleTimeString()}`
                ];
            });
            this._deposits.setItems(data);
        }, () => {
            this._deposits.setItems([]);
        });
        tm.GetWithdrawalHistory((withdrawalTickets) => {
            let data = withdrawalTickets.map((ticket) => {
                let createdDate = new Date(ticket.CreatedTimestamp);
                let updatedDate = new Date(ticket.LastUpdateTimestamp);
                return [
                    ticket.AssetName,
                    ticket.Amount,
                    ticket.FeeAmt,
                    ticket.NotionalValue,
                    ticket.Status,
                    ticket.RejectReason || '',
                    `${createdDate.toLocaleDateString()} ${createdDate.toLocaleTimeString()}`,
                    `${updatedDate.toLocaleDateString()} ${updatedDate.toLocaleTimeString()}`
                ];
            });
            this._withdrawals.setItems(data);
        }, () => {
            this._withdrawals.setItems([]);
        });
    }
}
window.customElements.define('a-portfolio', Portfolio);
