import { AContainer, AButton, ATabView, ATextInput, AQRCode, ASystemManager } from '../a/index.js';
import { ProductType } from '../BrowserSDK/UserAPI/index.js';
import { TradingManager, TransactionType } from '../managers/TradingManager.js';
export class DepositWithdraw extends AContainer {
    constructor() {
        super();
        this._type = TransactionType.DEPOSIT;
        this._productID = 0;
    }
    _build() {
        super._build();
        this._tabView = new ATabView();
        this._tabView.labels = ['Deposit', 'Withdraw'];
        this.appendChild(this._tabView);
        this._depositContainer = new AContainer();
        this._depositContainer.addClass('deposit');
        this._tabView.content.appendChild(this._depositContainer);
        this._withdrawContainer = new AContainer();
        this._withdrawContainer.addClass('withdraw');
        this._tabView.content.appendChild(this._withdrawContainer);
    }
    _registerListeners() {
        super._registerListeners();
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('click', this._onClick);
    }
    _render() {
        if (super._render()) {
            if (this._type === TransactionType.DEPOSIT) {
                this._tabView.selectedIndex = 0;
            }
            else if (this._type === TransactionType.WITHDRAW) {
                this._tabView.selectedIndex = 1;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        let tm = TradingManager.instance;
        let product = tm.APIState.ProductInfos.get(this._productID);
        if (product) {
            this._productType = product.ProductType;
            this._productSymbol = product.Product;
            if (this._productType === ProductType.CRYPTO_CURRENCY) {
                tm.GetDepositCryptoInfo(this._accountID, this._productID, (data) => {
                    this._parseDepositCryptoInfo(data);
                }, () => {
                    console.log('GetDepositCryptoInfo Error');
                });
                tm.GetWithdrawCryptoInfo(this._accountID, this._productID, (data) => {
                    this._parseWithdrawCryptoInfo(data);
                }, () => {
                    console.log('GetWithdrawCryptoInfo Error');
                });
            }
            else if (this._productType === ProductType.NATIONAL_CURRENCY) {
                tm.GetDepositFiatInfo(this._accountID, this._productID, (data) => {
                    this._parseDepositFiatInfo(data);
                }, () => {
                    console.log('GetDepositFiatInfo Error');
                });
                tm.GetWithdrawFiatInfo(this._accountID, this._productID, (data) => {
                    this._parseWithdrawFiatInfo(data);
                }, () => {
                    console.log('GetWithdrawFiatInfo Error');
                });
            }
        }
    }
    _parseDepositCryptoInfo(data) {
        this._depositContainer.destroyAllChildren();
        let depositInfos = JSON.parse(data.DepositInfo);
        let depositAddressInput = new ATextInput();
        depositAddressInput.label = 'deposit address';
        depositAddressInput.value = depositInfos[depositInfos.length - 1];
        this._depositContainer.appendChild(depositAddressInput);
        let depositAddressQRCode = new AQRCode();
        depositAddressQRCode.data = depositInfos[depositInfos.length - 1];
        this._depositContainer.appendChild(depositAddressQRCode);
    }
    _parseWithdrawCryptoInfo(data) {
        this._withdrawContainer.destroyAllChildren();
        try {
            let jsonTemplate = JSON.parse(data.Template);
            jsonTemplate.Amount = 0;
            this._withdrawCryptoAccountProviderId = data.AccountProviderId;
            this._withdrawCryptoTemplateName = data.TemplateName;
            this._withdrawCryptoTemplateType = jsonTemplate.TemplateType;
            for (var key in jsonTemplate) {
                if (key !== 'TemplateType') {
                    let val = jsonTemplate[key];
                    let input = new ATextInput();
                    input.dataset.keyName = key;
                    input.label = key.replace(/([A-Z])/g, ' $1').trim();
                    input.type = typeof (val) === 'number' ? ATextInput.NUMBER : ATextInput.TEXT;
                    this._withdrawContainer.appendChild(input);
                }
            }
            let withdrawButton = new AButton();
            withdrawButton.addClass('withdraw');
            withdrawButton.label = `Withdraw ${this._productSymbol}`;
            this._withdrawContainer.appendChild(withdrawButton);
        }
        catch (error) {
            console.log('GetWithdrawCryptoInfo Error');
        }
    }
    _parseDepositFiatInfo(data) {
        this._depositContainer.destroyAllChildren();
        try {
            let jsonTemplate = JSON.parse(data.Template);
            jsonTemplate.Amount = 0;
            this._depositFiatAccountProviderId = data.AccountProviderId;
            this._depositFiatTemplateName = data.TemplateName;
            this._depositFiatTemplateType = jsonTemplate.TemplateType;
            for (var key in jsonTemplate) {
                if (key !== 'TemplateType') {
                    let val = jsonTemplate[key];
                    let input = new ATextInput();
                    input.dataset.keyName = key;
                    input.label = key.replace(/([A-Z])/g, ' $1').trim();
                    input.type = typeof (val) === 'number' ? ATextInput.NUMBER : ATextInput.TEXT;
                    this._depositContainer.appendChild(input);
                }
            }
            let depositButton = new AButton();
            depositButton.addClass('deposit');
            depositButton.label = 'Place Deposit Ticket';
            this._depositContainer.appendChild(depositButton);
        }
        catch (error) {
            console.log('GetDepositFiatInfo Error');
        }
    }
    _parseWithdrawFiatInfo(data) {
        this._withdrawContainer.destroyAllChildren();
        try {
            let jsonTemplate = JSON.parse(data.Template);
            jsonTemplate.Amount = 0;
            this._withdrawCryptoAccountProviderId = data.AccountProviderId;
            this._withdrawCryptoTemplateName = data.TemplateName;
            this._withdrawCryptoTemplateType = jsonTemplate.TemplateType;
            for (var key in jsonTemplate) {
                if (key !== 'TemplateType') {
                    let val = jsonTemplate[key];
                    let input = new ATextInput();
                    input.dataset.keyName = key;
                    input.label = key.replace(/([A-Z])/g, ' $1').trim();
                    input.type = typeof (val) === 'number' ? ATextInput.NUMBER : ATextInput.TEXT;
                    this._withdrawContainer.appendChild(input);
                }
            }
            let withdrawButton = new AButton();
            withdrawButton.addClass('withdraw');
            withdrawButton.label = `Withdraw ${this._productSymbol}`;
            this._withdrawContainer.appendChild(withdrawButton);
        }
        catch (error) {
            console.log('GetWithdrawFiatInfo Error');
        }
    }
    _onClick(event) {
        let target = event.target;
        if (target.constructor === AButton) {
            if (target.hasClass('deposit')) {
            }
            else if (target.hasClass('withdraw')) {
                if (this._productType === ProductType.CRYPTO_CURRENCY) {
                    this._processCryptoWithdrawal();
                }
                else if (this._productType === ProductType.NATIONAL_CURRENCY) {
                }
            }
        }
    }
    _getJSONObject(container) {
        let out = {};
        for (let i = 0; i < container.childElementCount; i++) {
            let element = container.getChildAt(i);
            if (element.constructor === ATextInput) {
                let textInput = element;
                let inputType = textInput.type;
                out[textInput.dataset.keyName] = inputType === ATextInput.NUMBER ? Number(textInput.value.trim()) : textInput.value.trim();
            }
        }
        return out;
    }
    _processCryptoWithdrawal() {
        let data = this._getJSONObject(this._withdrawContainer);
        TradingManager.instance.CreateWithdrawTicket(this.accountID, this.productID, data.Amount, this._withdrawCryptoTemplateType, data, (ticket) => {
            ASystemManager.instance.dismissDialog();
        }, (errorMessage = null) => {
            ASystemManager.instance.showAlertDialog(`Withdraw failed${errorMessage ? ' ' + errorMessage : ''}`);
        });
    }
    get type() {
        return this._type;
    }
    set type(t) {
        if (this._type !== t) {
            this._type = t;
            this.invalidate();
        }
    }
    get accountID() {
        return this._accountID;
    }
    set accountID(id) {
        if (this._accountID !== id) {
            this._accountID = id;
            this.invalidate();
        }
    }
    get productID() {
        return this._productID;
    }
    set productID(id) {
        if (this._productID !== id) {
            this._productID = id;
            this.invalidate();
        }
    }
}
window.customElements.define('a-deposit-withdraw', DepositWithdraw);
