import { AContainer, AHeader, AText, ALanguageManager } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
import { PortfolioProductsItem } from './PortfolioProductsItem.js';
export class PortfolioProducts extends AContainer {
    constructor(accountId = TradingManager.instance.accountId) {
        super();
        this._accountId = accountId;
    }
    _build() {
        super._build();
        this._header = new AHeader();
        this.appendChild(this._header);
        this._productText = new AText();
        this._header.appendChild(this._productText);
        this._holdingsText = new AText();
        this._header.appendChild(this._holdingsText);
        this._availableBalanceText = new AText();
        this._header.appendChild(this._availableBalanceText);
        this._pendingBalanceText = new AText();
        this._header.appendChild(this._pendingBalanceText);
        this._availableQuantityText = new AText();
        this._header.appendChild(this._availableQuantityText);
        this._priceText = new AText();
        this._header.appendChild(this._priceText);
        this._actionsText = new AText();
        this._header.appendChild(this._actionsText);
        this._productItems = new AContainer();
        this.appendChild(this._productItems);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this._productText.text = lm.get('PortfolioDialog', 'Product');
            this._holdingsText.text = lm.get('PortfolioDialog', 'Holdings');
            this._availableBalanceText.text = lm.get('PortfolioDialog', 'Available Balance');
            this._pendingBalanceText.text = lm.get('PortfolioDialog', 'Pending Balance');
            this._availableQuantityText.text = lm.get('PortfolioDialog', 'Available Qty');
            this._priceText.text = lm.get('PortfolioDialog', 'Price');
            this._actionsText.text = lm.get('PortfolioDialog', 'Actions');
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        let tm = TradingManager.instance;
        tm.APIState.ProductInfos.forEach((productInfo, productId) => {
            let productItem = new PortfolioProductsItem(this._accountId, productId);
            this._productItems.appendChild(productItem);
        });
    }
}
window.customElements.define('a-portfolio-products', PortfolioProducts);
