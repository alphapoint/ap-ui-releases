import { AContainer, AButton, AFontAwesomeIcon, AImageManager, ALanguageManager } from '../a/index.js';
import { TradingManager } from '../managers/TradingManager.js';
import { InstrumentSelector } from './InstrumentSelector.js';
export class InstrumentSelect extends AContainer {
    constructor() {
        super();
        this._instrumentId = null;
    }
    _build() {
        super._build();
        this._button = new AButton();
        let menuButtonDownIcon = new AFontAwesomeIcon();
        menuButtonDownIcon.addClass('down');
        menuButtonDownIcon.value = ['fal', 'fa-angle-down'];
        this._button.appendChild(menuButtonDownIcon);
        this.appendChild(this._button);
        this._instrumentSelector = new InstrumentSelector();
        this._instrumentSelector.visible = false;
        this.appendChild(this._instrumentSelector);
        this._closeTimer = null;
        this._closeTimeout = 1000;
    }
    _registerListeners() {
        super._registerListeners();
        this._onButtonClicked = this._onButtonClicked.bind(this);
        this._button.addEventListener('click', this._onButtonClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._button.removeEventListener('click', this._onButtonClicked);
        document.removeEventListener('mousedown', this._onDocumentMouseDown);
        document.removeEventListener('keydown', this._onKeyDown);
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            let instrumentInfo = TradingManager.instance.APIState.InstrumentInfos.get(this._instrumentId);
            if (instrumentInfo) {
                this._button.icon = null;
                this._button.image = AImageManager.instance.get(`/images/currency/${instrumentInfo.Product1Symbol.toLowerCase()}.png`, '/images/currency/generic.png');
                this._button.label = instrumentInfo.Symbol;
            }
            else {
                this._button.icon = null;
                this._button.image = null;
                this._button.label = this._defaultText;
            }
            this._instrumentSelector.instrumentId = this._instrumentId;
            this._instrumentSelector.invalidate();
            return true;
        }
        return false;
    }
    _openInstrumentSelector() {
        this._button.addClass('is-open');
        this._instrumentSelector.style.left = this._button.offsetLeft + 'px';
        this._instrumentSelector.visible = true;
        this._instrumentSelector.invalidate();
    }
    _closeInstrumentSelector() {
        this._button.removeClass('is-open');
        this._instrumentSelector.visible = false;
    }
    _onButtonClicked(event) {
        if (!this._instrumentSelector.visible) {
            this._openInstrumentSelector();
        }
        else {
            this._closeInstrumentSelector();
        }
    }
    _onDocumentMouseDown(event) {
        let select = event.target.closest('a-instrument-select');
        if (!select) {
            this._closeInstrumentSelector();
        }
    }
    _onKeyDown(event) {
        if (event.key === 'Escape' && this._instrumentSelector.visible) {
            this._closeInstrumentSelector();
        }
    }
    get defaultText() {
        return this._defaultText;
    }
    set defaultText(d) {
        if (this._defaultText !== d) {
            this._defaultText = d;
            this.invalidate();
        }
    }
    get instrumentId() {
        return this._instrumentId;
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            this.invalidate();
            this._closeInstrumentSelector();
        }
    }
}
window.customElements.define('a-instrument-select', InstrumentSelect);
