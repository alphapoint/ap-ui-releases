import { ALanguageManagerEvent, ALanguageManager, AButtonBar, AButtonBarEvent, AContainer, AHeader, AMenuButtonBar, AMenuButtonBarEvent, AMenuData, AMenuDataItem, AText, ATextInput } from '../a/index.js';
import { InstrumentSelectorItem } from './InstrumentSelectorItem.js';
import { TradingManager } from '../managers/TradingManager.js';
export class InstrumentSelector extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._instrumentIdChanged = true;
        this._instrumentId = null;
        this._instrumentIDs = [];
        this._filterSymbol = null;
        this._filterText = null;
        this._scrollInstrumentIntoView = false;
        this._selectedItem = null;
        this._header = new AHeader();
        this.appendChild(this._header);
        this._productButtons = new AMenuButtonBar();
        this._header.appendChild(this._productButtons);
        this._filterHeader = new AContainer();
        this._filterHeader.addClass('filter-header');
        this._header.appendChild(this._filterHeader);
        this._filterInput = new ATextInput();
        this._filterHeader.appendChild(this._filterInput);
        this._changeVolumeButtons = new AButtonBar();
        this._changeVolumeButtons.labels = ['Chg', 'Vol'];
        this._changeVolumeButtons.selectable = true;
        this._changeVolumeButtons.selectedIndex = 0;
        this._filterHeader.appendChild(this._changeVolumeButtons);
        this._gridHeader = new AContainer();
        this._gridHeader.addClass('grid-header');
        this._header.appendChild(this._gridHeader);
        this._instrumentHeaderItem = new AText();
        this._gridHeader.appendChild(this._instrumentHeaderItem);
        this._lastPriceHeaderItem = new AText();
        this._gridHeader.appendChild(this._lastPriceHeaderItem);
        this._changeHighHeaderText = new AText();
        this._gridHeader.appendChild(this._changeHighHeaderText);
        this._content = new AContainer();
        this.appendChild(this._content);
    }
    _registerListeners() {
        super._registerListeners();
        let lm = ALanguageManager.instance;
        this._onLanguageChanged = this._onLanguageChanged.bind(this);
        lm.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        this._onUIConfigReady = this._onUIConfigReady.bind(this);
        tm.UIConfigReady.SubscribeEvent(this._onUIConfigReady);
        this._onThemeChanged = this._onThemeChanged.bind(this);
        tm.ThemeChanged.SubscribeEvent(this._onThemeChanged);
        this._onProductsMarketDataChanged = this._onProductsMarketDataChanged.bind(this);
        tm.ProductsMarketDataChanged.SubscribeEvent(this._onProductsMarketDataChanged);
        this._onProductButtonsChanged = this._onProductButtonsChanged.bind(this);
        this._productButtons.addEventListener(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, this._onProductButtonsChanged);
        this._onChangeVolumeButtonsChanged = this._onChangeVolumeButtonsChanged.bind(this);
        this._changeVolumeButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onChangeVolumeButtonsChanged);
        this._onFilterTextInputInputted = this._onFilterTextInputInputted.bind(this);
        this._filterInput.addEventListener('input', this._onFilterTextInputInputted);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let lm = ALanguageManager.instance;
        lm.removeEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, this._onLanguageChanged);
        let tm = TradingManager.instance;
        tm.UIConfigReady.UnsubscribeEvent(this._onUIConfigReady);
        tm.ThemeChanged.UnsubscribeEvent(this._onThemeChanged);
        tm.ProductsMarketDataChanged.UnsubscribeEvent(this._onProductsMarketDataChanged);
        this._productButtons.removeEventListener(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, this._onProductButtonsChanged);
        this._changeVolumeButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onChangeVolumeButtonsChanged);
        this._filterInput.removeEventListener('input', this._onFilterTextInputInputted);
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this._filterInput.label = lm.get('InstrumentSelector', 'Search');
            this._changeVolumeButtons.labels = [lm.get('InstrumentSelector', 'Chg'), lm.get('InstrumentSelector', 'Vol')];
            this._instrumentHeaderItem.text = lm.get('InstrumentSelector', 'Instrument');
            this._lastPriceHeaderItem.text = lm.get('InstrumentSelector', 'Last Price');
            this._changeHighHeaderText.text = this._changeVolumeButtons.selectedIndex === 0 ? lm.get('InstrumentSelector', '24hr Change') : lm.get('InstrumentSelector', '24hr Vol');
            let tm = TradingManager.instance;
            if (this._instrumentIDs.length !== tm.APIState.InstrumentInfos.size && tm.APIState.InstrumentInfos.size > 0) {
                let instrumentInfos = Array.from(tm.APIState.InstrumentInfos.values());
                this._instrumentIDs = instrumentInfos.filter((instrumentInfo) => {
                    return !instrumentInfo.IsDisable && instrumentInfo.SessionStatus === 'Running';
                }).sort((one, two) => {
                    if (one.Product2Symbol < two.Product2Symbol) {
                        return -1;
                    }
                    else if (one.Product2Symbol > two.Product2Symbol) {
                        return 1;
                    }
                    else {
                        if (one.Product1Symbol < two.Product1Symbol) {
                            return -1;
                        }
                        else if (one.Product1Symbol > two.Product1Symbol) {
                            return 1;
                        }
                        else {
                            return 0;
                        }
                    }
                }).map((instrumentInfo) => {
                    return instrumentInfo.InstrumentId;
                });
                if (this._content.children.length < this._instrumentIDs.length) {
                    while (this._content.children.length < this._instrumentIDs.length) {
                        this._content.appendChild(new InstrumentSelectorItem());
                    }
                }
                this._scrollInstrumentIntoView = true;
            }
            for (let i = 0; i < this._content.children.length; i++) {
                let instrumentItem = this._content.getChildAt(i);
                instrumentItem.instrumentID = this._instrumentIDs[i];
                let showItem = true;
                let selectItem = false;
                let instrumentSymbol = instrumentItem.instrumentSymbol;
                let symbol1 = instrumentItem.product1Symbol;
                let symbol2 = instrumentItem.product2Symbol;
                if (this._filterSymbol !== null) {
                    if (symbol1 !== this._filterSymbol && symbol2 !== this._filterSymbol) {
                        showItem = false;
                    }
                }
                if (this._filterText !== null) {
                    if (!instrumentSymbol.includes(this._filterText) && !symbol1.includes(this._filterText) && !symbol2.includes(this._filterText)) {
                        showItem = false;
                    }
                }
                if (instrumentItem.instrumentID === this.instrumentId) {
                    selectItem = true;
                }
                let typeClass = this._changeVolumeButtons.selectedIndex === 0 ? 'day-change' : 'day-volume';
                instrumentItem.removeClasses('day-change', 'day-volume');
                instrumentItem.addClass(typeClass);
                instrumentItem.visible = showItem;
                instrumentItem.isSelected = selectItem;
                instrumentItem.invalidate();
                if (selectItem) {
                    this._selectedItem = instrumentItem;
                }
            }
            if (this._scrollInstrumentIntoView) {
                this._scrollInstrumentIntoView = false;
                if (this._selectedItem !== null && this._selectedItem.visible) {
                    this._selectedItem.scrollIntoView({
                        behavior: 'auto',
                        block: 'nearest'
                    });
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._onUIConfigReady();
    }
    _onLanguageChanged() {
        this.invalidate();
    }
    _onUIConfigReady() {
        let tm = TradingManager.instance;
        if (tm.UIConfig && tm.UIConfig.hasOwnProperty('InstrumentSelectorFilters') && tm.UIConfig.InstrumentSelectorFilters.constructor === Array) {
            let buttonData = [];
            let firstItem = null;
            tm.UIConfig.InstrumentSelectorFilters.forEach((topItem) => {
                if (topItem.hasOwnProperty('GroupName') && topItem.hasOwnProperty('Filters')) {
                    let group = new AMenuData(null, topItem.GroupName, []);
                    topItem.Filters.forEach((item) => {
                        group.items.push(new AMenuDataItem(null, item.Name, item.FilterText));
                    });
                    buttonData.push(group);
                }
                else if (topItem.hasOwnProperty('Name') && topItem.hasOwnProperty('FilterText')) {
                    let menuItem = new AMenuDataItem(null, topItem.Name, topItem.FilterText);
                    buttonData.push(menuItem);
                    if (firstItem === null) {
                        firstItem = menuItem;
                    }
                }
            });
            if (buttonData.length > 0) {
                this._productButtons.data = buttonData;
                this._productButtons.visible = true;
                if (firstItem) {
                    this._productButtons.selectedMenuDataItem = firstItem;
                }
                return;
            }
        }
        this._productButtons.visible = false;
    }
    _onThemeChanged() {
        this.invalidate();
    }
    _onProductsMarketDataChanged() {
        this.invalidate();
    }
    _onProductButtonsChanged(event) {
        this._filterSymbol = this._productButtons.selectedMenuDataItem.data !== null ? (this._productButtons.selectedMenuDataItem.data).toLowerCase() : null;
        this._scrollInstrumentIntoView = true;
        this.invalidate();
    }
    _onFilterTextInputInputted(event) {
        let inputValue = String(this._filterInput.value).trim().toLowerCase();
        this._filterText = inputValue.length > 0 ? inputValue : null;
        this._scrollInstrumentIntoView = true;
        this.invalidate();
    }
    _onChangeVolumeButtonsChanged() {
        this.invalidate();
    }
    scrollInstrumentIntoView() {
        setTimeout(() => {
            this._scrollInstrumentIntoView = true;
            this.invalidate();
        }, 100);
    }
    get instrumentId() {
        return this._instrumentId;
    }
    set instrumentId(id) {
        if (this._instrumentId !== id) {
            this._instrumentId = id;
            this.scrollInstrumentIntoView();
        }
    }
}
window.customElements.define('a-instrument-selector', InstrumentSelector);
