import { AEventDispatcher } from '../events/AEventDispatcher.js';
export class AImageManager extends AEventDispatcher {
    constructor() {
        super();
        this._baseURI = '';
        this._imageMap = new Map();
        this._canvas = document.createElement('canvas');
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new AImageManager();
        }
        return this._instance;
    }
    get(url, fallbackURL = null) {
        if (this._imageMap.has(url)) {
            return this._imageMap.get(url);
        }
        else {
            let tries = 0;
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.src = `${this._baseURI}${url}`;
            tries++;
            img.onload = () => {
                this._canvas.width = img.naturalWidth;
                this._canvas.height = img.naturalHeight;
                this._canvas.getContext('2d').drawImage(img, 0, 0);
                this._imageMap.set(url, this._canvas.toDataURL('image/png'));
                img.onload = null;
                img.onerror = null;
            };
            if (fallbackURL !== null) {
                img.onerror = () => {
                    if (tries < 2) {
                        img.src = `${this._baseURI}${fallbackURL}`;
                        tries++;
                    }
                    else if (tries < 3) {
                        img.src = `${this._baseURI}/images/fail.png`;
                        tries++;
                    }
                    else {
                        img.onload = null;
                        img.onerror = null;
                    }
                };
            }
            return `${this._baseURI}${url}`;
        }
    }
    get baseURI() {
        return this._baseURI;
    }
    set baseURI(u) {
        this._baseURI = u;
    }
}
