import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { ALanguageManagerEvent } from '../events/ALanguageManagerEvent.js';
export class ALanguageManager extends AEventDispatcher {
    constructor() {
        super();
        this._configuration = new Map();
        this._currentLanguageID = null;
        this._currentLanguageName = null;
        this._languages = new Map();
        this._languageIDs = [];
        this._languageNames = [];
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ALanguageManager();
        }
        return this._instance;
    }
    _processConfig(data) {
        data.Languages.forEach((entry) => {
            this._configuration.set(entry.Id, entry);
            this._languageIDs.push(entry.Id);
            this._languageNames.push(entry.Name);
            if (data.PreferredLanguageID === entry.Id) {
                this._loadLanguage(entry.Id);
            }
        });
    }
    _loadLanguage(id) {
        this._currentLanguageID = id;
        if (!this._languages.has(this._currentLanguageID)) {
            fetch(`./language/${this._currentLanguageID}/index.json`)
                .then(response => response.json())
                .then((data) => {
                let languageMap = new Map();
                this._languages.set(this._currentLanguageID, languageMap);
                for (let i in data) {
                    let namespaceMap = new Map();
                    for (let j = 0; j < data[i].length; j++) {
                        namespaceMap.set(data[i][j][0], data[i][j][1]);
                    }
                    languageMap.set(i, namespaceMap);
                }
                this._languageLoaded();
            });
        }
        else {
            this._languageLoaded();
        }
    }
    _languageLoaded() {
        this._currentLanguageName = this._configuration.get(this._currentLanguageID).Name;
        this.dispatchEvent(new ALanguageManagerEvent(ALanguageManagerEvent.BEFORE_LANGUAGE_CHANGED));
        setTimeout(() => {
            this.dispatchEvent(new ALanguageManagerEvent(ALanguageManagerEvent.LANGUAGE_CHANGED));
        });
    }
    get(namespace, key) {
        if (this._languages.has(this._currentLanguageID)) {
            let l = this._languages.get(this._currentLanguageID);
            if (l.has(namespace)) {
                let n = l.get(namespace);
                if (n.has(key)) {
                    return n.get(key);
                }
            }
        }
        return '';
    }
    setConfig(c) {
        this._processConfig(c);
    }
    get languageID() {
        return this._currentLanguageID;
    }
    set languageID(id) {
        if (this._currentLanguageID !== id) {
            this._loadLanguage(id);
        }
    }
    get languageName() {
        return this._currentLanguageName;
    }
    get languageIDs() {
        return this._languageIDs;
    }
    get languageNames() {
        return this._languageNames;
    }
}
