import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { ADialogContainer, AContextItemContainer } from '../components/index.js';
export class ASystemManager extends AEventDispatcher {
    constructor() {
        super();
        this._build();
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ASystemManager();
        }
        return this._instance;
    }
    _build() {
        this._dialogContainer = new ADialogContainer();
        document.body.appendChild(this._dialogContainer);
        this._contextItemContainer = new AContextItemContainer();
        document.body.appendChild(this._contextItemContainer);
    }
    showNoticeDialog(message = '') {
        return this._dialogContainer.showNoticeDialog(message);
    }
    showAlertDialog(message, okCallback = null) {
        return this._dialogContainer.showAlertDialog(message, okCallback);
    }
    showConfirmDialog(message = '', okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showConfirmDialog(message, okCallback, cancelCallback);
    }
    showPromptDialog(message = '', inputLabel = null, okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showPromptDialog(message, inputLabel, okCallback, cancelCallback);
    }
    showAuthenticateUsernamePasswordDialog(okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showAuthenticateUsernamePasswordDialog(okCallback, cancelCallback);
    }
    showAuthenticateTwoFADialog(okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showAuthenticateTwoFADialog(okCallback, cancelCallback);
    }
    showSetupTwoFADialog(qrData, okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showSetupTwoFADialog(qrData, okCallback, cancelCallback);
    }
    showRegisterDialog(okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showRegisterDialog(okCallback, cancelCallback);
    }
    showForgotPasswordDialog(okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showForgotPasswordDialog(okCallback, cancelCallback);
    }
    showCustomDialog(content = null, okCallback = null, cancelCallback = null) {
        return this._dialogContainer.showCustomDialog(content, okCallback, cancelCallback);
    }
    dismissDialog() {
        this._dialogContainer.dismissDialog();
    }
    dismissAllDialogs() {
        this._dialogContainer.dismissAllDialogs();
    }
    showMenu(x, y, menuData, selectedCallback = null) {
        this._contextItemContainer.showMenu(x, y, menuData, selectedCallback);
    }
    registerContextMenu(targetComponent, menuData, selectedCallback = null) {
        this._contextItemContainer.registerContextMenu(targetComponent, menuData, selectedCallback);
    }
    registerContextWidget(targetComponent, contextWidget) {
        this._contextItemContainer.registerContextWidget(targetComponent, contextWidget);
    }
    unregisterContextItem(targetComponent) {
        this._contextItemContainer.unregisterContextItem(targetComponent);
    }
    get isShowingDialog() {
        return this._dialogContainer.isShowingDialog;
    }
    get isShowingContextItem() {
        return this._contextItemContainer.isShowingContextItem;
    }
}
setTimeout(() => {
    ASystemManager.instance;
});
