import { AEventDispatcher, ARenderManagerEvent } from '../events/index.js';
import { AUtil } from '../core/AUtil.js';
export class ARenderManager extends AEventDispatcher {
    constructor() {
        super();
        this._renderTimeout = 15;
        this._renderCalls = [];
        this._renderTimestamp = 0;
        this._isVisible = !document.hidden;
        this._isRendering = false;
        this._pixelRatio = window.devicePixelRatio;
        this._registerListeners();
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ARenderManager();
        }
        return this._instance;
    }
    _registerListeners() {
        this._onMutationObserved = this._onMutationObserved.bind(this);
        this._mutationObserver = new MutationObserver(this._onMutationObserved);
        this._mutationObserver.observe(window.document.body, {
            attributes: false,
            childList: true,
            subtree: true
        });
        this._doAnimationFrame = this._doAnimationFrame.bind(this);
        if (window) {
            this._onResize = AUtil.throttle(this, () => {
                this.requestAnimationFrame(() => {
                    this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE));
                });
            }, this._renderTimeout).bind(this);
            window.addEventListener('resize', this._onResize);
            this._onResizeEnd = AUtil.debounce(this, () => {
                this.requestAnimationFrame(() => {
                    this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE_END));
                });
            }, 100, false).bind(this);
            window.addEventListener('resize', this._onResizeEnd);
        }
        if (document) {
            this._onVisibilityChange = this._onVisibilityChange.bind(this);
            document.addEventListener('visibilitychange', this._onVisibilityChange);
        }
    }
    _onMutationObserved() {
        window.requestAnimationFrame(this._doAnimationFrame);
        this._isRendering = true;
    }
    _onResize() {
    }
    _onResizeEnd() {
    }
    _onVisibilityChange() {
        this._isVisible = document.visibilityState === 'visible';
        this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.VISIBILITY_CHANGE));
    }
    invalidate() {
        this.requestAnimationFrame(() => {
            this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE_END));
        });
    }
    requestAnimationFrame(f = null) {
        if (f != null) {
            this._renderCalls.push(f);
        }
        window.requestAnimationFrame(this._doAnimationFrame);
    }
    _doAnimationFrame(time) {
        if (this._renderCalls.length > 0) {
            if ((window.performance.now() - this._renderTimestamp) > this._renderTimeout) {
                this._renderTimestamp = time;
                for (let i = 0; i < this._renderCalls.length; i++) {
                    (this._renderCalls[i])();
                }
                this._renderCalls = [];
                this._isRendering = false;
            }
            else {
                window.requestAnimationFrame(this._doAnimationFrame);
            }
        }
    }
    get renderTimeout() {
        return this._renderTimeout;
    }
    set renderTimeout(t) {
        this._renderTimeout = t;
    }
    get isVisible() {
        return this._isVisible;
    }
    get pixelRatio() {
        return this._pixelRatio;
    }
}
