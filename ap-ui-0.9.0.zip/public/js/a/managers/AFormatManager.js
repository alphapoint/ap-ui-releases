import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { ALanguageManager } from './ALanguageManager.js';
export var NumberFormatType;
(function (NumberFormatType) {
    NumberFormatType["PRICE"] = "PRICE";
    NumberFormatType["QUANTITY"] = "QUANTITY";
    NumberFormatType["PERCENT"] = "PERCENT";
})(NumberFormatType || (NumberFormatType = {}));
export class AFormatManager extends AEventDispatcher {
    constructor() {
        super();
        this._numberFormatters = new Map();
    }
    static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new AFormatManager();
        }
        return this._instance;
    }
    getDecimalPlaceCount(n) {
        var s = '' + (+n);
        var match = /(?:\.(\d+))?(?:[eE]([+\-]?\d+))?$/.exec(s);
        if (!match) {
            return 0;
        }
        return Math.max(0, (match[1] == '0' ? 0 : (match[1] || '').length)
            - (Number(match[2]) || 0));
    }
    registerNumberFormatter(key, type, minimumFractionDigits, maximumFractionDigits) {
        let numberFormatter = this._numberFormatters.get(key);
        if (!numberFormatter) {
            numberFormatter = {
                minimumFractionDigits: minimumFractionDigits,
                maximumFractionDigits: maximumFractionDigits,
                languageCollection: new Map()
            };
            this._numberFormatters.set(key, numberFormatter);
        }
        ALanguageManager.instance.languageIDs.forEach((languageID) => {
            let formatCollection = numberFormatter.languageCollection.get(languageID);
            if (!formatCollection) {
                formatCollection = new Map();
                numberFormatter.languageCollection.set(languageID, formatCollection);
            }
            let numberFormat = formatCollection.get(type);
            if (!numberFormat) {
                let style;
                if (type === NumberFormatType.PRICE) {
                    style = 'decimal';
                }
                else if (type === NumberFormatType.QUANTITY) {
                    style = 'decimal';
                }
                else if (type === NumberFormatType.PERCENT) {
                    style = 'percent';
                }
                numberFormat = new Intl.NumberFormat(languageID, {
                    minimumFractionDigits: minimumFractionDigits,
                    maximumFractionDigits: maximumFractionDigits,
                    style: style
                });
                formatCollection.set(type, numberFormat);
            }
        });
    }
    format(key, type, value) {
        let formatter = this._numberFormatters.get(key)?.
            languageCollection.get('en-US')?.
            get(type);
        if (formatter) {
            if (!Object.is(value, NaN)) {
                return formatter.format(value);
            }
            else {
                return '';
            }
        }
        else {
            return String(value);
        }
    }
}
