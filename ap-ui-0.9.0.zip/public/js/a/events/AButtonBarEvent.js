import { AEvent } from './AEvent.js';
export class AButtonBarEvent extends AEvent {
}
AButtonBarEvent.SELECTED_INDEX_CHANGE = 'buttonBarSelectedIndexChange';
AButtonBarEvent.BUTTON_HOVER = 'buttonBarButtonHover';
AButtonBarEvent.BUTTON_CLICK = 'buttonBarButtonClick';
