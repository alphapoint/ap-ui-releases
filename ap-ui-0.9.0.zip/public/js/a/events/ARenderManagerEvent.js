import { AEvent } from './AEvent.js';
export class ARenderManagerEvent extends AEvent {
}
ARenderManagerEvent.RESIZE = 'renderManagerResize';
ARenderManagerEvent.RESIZE_END = 'renderManagerResizeEnd';
ARenderManagerEvent.VISIBILITY_CHANGE = 'renderManagerVisibilityChange';
ARenderManagerEvent.DIAGNOSTICS = 'renderManagerDiagnostics';
