import { AEvent } from './AEvent.js';
export class ADataGridEvent extends AEvent {
}
ADataGridEvent.ROW_RENDER = 'dataGridRowRender';
ADataGridEvent.SELECTED_INDEX_CHANGED = 'dataGridSelectedIndexChanged';
ADataGridEvent.ROW_CLICK = 'dataGridRowClick';
ADataGridEvent.ROW_DOUBLE_CLICK = 'dataGridRowDoubleClick';
