import { AEvent } from './AEvent.js';
export class AMenuButtonBarEvent extends AEvent {
}
AMenuButtonBarEvent.ITEM_CLICKED = 'menuButtonBarItemClicked';
AMenuButtonBarEvent.SELECTED_ITEM_CHANGE = 'menuButtonBarSelectedItemChange';
