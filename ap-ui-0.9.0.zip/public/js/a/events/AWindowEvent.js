import { AEvent } from './AEvent.js';
export class AWindowEvent extends AEvent {
}
AWindowEvent.DRAG_START = 'windowDragStart';
AWindowEvent.DRAG = 'windowDrag';
AWindowEvent.DRAG_END = 'windowDragEnd';
AWindowEvent.RESIZE_START = 'windowResizeStart';
AWindowEvent.RESIZE = 'windowResize';
AWindowEvent.RESIZE_END = 'windowResizeEnd';
AWindowEvent.DESTROYED = 'windowDestroyed';
AWindowEvent.MINIMIZE_CLICKED = 'windowMinimizeClicked';
AWindowEvent.MAXIMIZE_CLICKED = 'windowMaximizeClicked';
AWindowEvent.CLOSE_CLICKED = 'windowCloseClicked';
AWindowEvent.HEADER_DOUBLE_CLICKED = 'windowHeaderDoubleClicked';
