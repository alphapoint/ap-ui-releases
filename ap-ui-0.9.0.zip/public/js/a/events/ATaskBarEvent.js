import { AEvent } from './AEvent.js';
export class ATaskBarEvent extends AEvent {
}
ATaskBarEvent.SELECTED_WINDOW_CHANGED = 'taskBarSelectedWindowChange';
