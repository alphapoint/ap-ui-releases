import { AEvent } from './AEvent.js';
export class AScrollbarEvent extends AEvent {
}
AScrollbarEvent.SCROLL = 'scroll';
