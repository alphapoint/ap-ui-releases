import { AEvent } from './AEvent.js';
export class AWindowContainerEvent extends AEvent {
}
AWindowContainerEvent.WINDOW_ADDED = 'windowAdded';
AWindowContainerEvent.WINDOW_REMOVED = 'windowRemoved';
AWindowContainerEvent.WINDOW_FOCUSED = 'windowFocused';
AWindowContainerEvent.WINDOW_MINIMIZED = 'windowMinimized';
AWindowContainerEvent.WINDOW_MAXIMIZED = 'windowMaximized';
