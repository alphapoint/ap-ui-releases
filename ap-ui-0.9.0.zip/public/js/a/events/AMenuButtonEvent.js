import { AEvent } from './AEvent.js';
export class AMenuButtonEvent extends AEvent {
}
AMenuButtonEvent.ITEM_SELECTED = 'menuButtonItemSelected';
