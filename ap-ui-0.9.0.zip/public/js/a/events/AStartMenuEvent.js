import { AEvent } from './AEvent.js';
export class AStartMenuEvent extends AEvent {
}
AStartMenuEvent.ITEM_CLICKED = 'startMenuItemClicked';
