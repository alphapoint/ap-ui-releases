import { AEvent } from './AEvent.js';
export class AComponentEvent extends AEvent {
}
AComponentEvent.ATTACHED = 'attached';
AComponentEvent.DETACHED = 'detached';
AComponentEvent.ATTRIBUTE_CHANGED = 'attributeChanged';
AComponentEvent.BUILD_COMPLETE = 'buildComplete';
AComponentEvent.REGISTER_LISTENERS_COMPLETE = 'registerListenersComplete';
AComponentEvent.UNREGISTER_LISTENERS_COMPLETE = 'unregisterListenersComplete';
AComponentEvent.RENDER_COMPLETE = 'renderComplete';
AComponentEvent.INSTANTIATION_COMPLETE = 'instantiationComplete';
AComponentEvent.CHILD_APPENDED = 'childAppended';
AComponentEvent.CHILD_APPENDED_AT = 'childAppendedAt';
AComponentEvent.CHILD_REMOVED = 'childRemoved';
AComponentEvent.CHILD_REMOVED_AT = 'childRemovedAt';
AComponentEvent.ALL_CHILDREN_REMOVED = 'allChildrenRemoved';
AComponentEvent.DESTROYED = 'destroyed';
