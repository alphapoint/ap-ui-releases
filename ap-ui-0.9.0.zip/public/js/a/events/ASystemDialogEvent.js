import { AEvent } from './AEvent.js';
export class ASystemDialogEvent extends AEvent {
}
ASystemDialogEvent.OK = 'systemDialogOK';
ASystemDialogEvent.CANCEL = 'systemDialogCancel';
