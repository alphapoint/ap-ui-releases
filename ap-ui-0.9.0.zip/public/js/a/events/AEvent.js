export class AEvent extends CustomEvent {
}
