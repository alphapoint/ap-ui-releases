import { AEvent } from './AEvent.js';
export class APanelEvent extends AEvent {
}
APanelEvent.DRAG_START = 'panelDragStart';
APanelEvent.DRAG = 'panelDrag';
APanelEvent.DRAG_END = 'panelDragEnd';
APanelEvent.RESIZE_START = 'panelResizeStart';
APanelEvent.RESIZE = 'panelResize';
APanelEvent.RESIZE_END = 'panelResizeEnd';
APanelEvent.DESTROYED = 'panelDestroyed';
APanelEvent.MENU_ICON_CLICKED = 'panelMenuIconClicked';
