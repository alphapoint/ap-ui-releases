import { AEvent } from './AEvent.js';
export class ADataProviderEvent extends AEvent {
}
ADataProviderEvent.ADD = 'dataProviderAdd';
ADataProviderEvent.REMOVE = 'dataProviderRemove';
ADataProviderEvent.CHANGE = 'dataProviderChange';
