import { AEvent } from './AEvent.js';
export class AWizardStepEvent extends AEvent {
}
AWizardStepEvent.ACTION = 'wizardStepAction';
AWizardStepEvent.CHANGE = 'wizardStepChange';
