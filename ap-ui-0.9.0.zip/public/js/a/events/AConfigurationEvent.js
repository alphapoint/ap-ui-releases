import { AEvent } from './AEvent.js';
export class AConfigurationEvent extends AEvent {
}
AConfigurationEvent.LOADED = 'configurationLoaded';
AConfigurationEvent.ERROR = 'configurationError';
