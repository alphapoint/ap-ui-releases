import { AEvent } from './AEvent.js';
export class ATabViewEvent extends AEvent {
}
ATabViewEvent.SELECTED_INDEX_CHANGE = 'tabViewSelectedIndexChange';
