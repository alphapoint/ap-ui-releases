import { AEvent } from './AEvent.js';
export class AMenuBarEvent extends AEvent {
}
AMenuBarEvent.CLOSED = 'menuBarClosed';
AMenuBarEvent.ITEM_CLICKED = 'menuBarItemClicked';
AMenuBarEvent.ITEM_MOUSED_OVER = 'menuBarItemMousedOver';
AMenuBarEvent.ITEM_MOUSED_OUT = 'menuBarItemMousedOut';
