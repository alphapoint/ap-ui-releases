import { AEvent } from './AEvent.js';
export class AWebsocketWorkerEvent extends AEvent {
}
AWebsocketWorkerEvent.CONNECTED = 'websocketWorkerConnected';
AWebsocketWorkerEvent.MESSAGE = 'websocketWorkerMessage';
AWebsocketWorkerEvent.DISCONNECTED = 'websocketWorkerDisconnected';
AWebsocketWorkerEvent.ERROR = 'websocketWorkerError';
