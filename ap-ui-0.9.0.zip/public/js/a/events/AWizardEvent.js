import { AEvent } from './AEvent.js';
export class AWizardEvent extends AEvent {
}
AWizardEvent.ACTION = 'wizardAction';
AWizardEvent.PREVIOUS_STEP = 'wizardPreviousStep';
AWizardEvent.NEXT_STEP = 'wizardNextStep';
AWizardEvent.CANCEL = 'wizardCancel';
AWizardEvent.COMPLETE = 'wizardComplete';
