import { AEvent } from './AEvent.js';
export class AMenuEvent extends AEvent {
}
AMenuEvent.ITEM_CLICKED = 'menuItemClicked';
AMenuEvent.ITEM_MOUSED_OVER = 'menuItemMousedOver';
AMenuEvent.ITEM_MOUSED_OUT = 'menuItemMousedOut';
