import { AEvent } from './AEvent.js';
export class ATreeEvent extends AEvent {
}
ATreeEvent.NODE_SELECTED = 'treeNodeSelected';
ATreeEvent.NODE_CLICKED = 'treeNodeClicked';
ATreeEvent.NODE_DOUBLE_CLICKED = 'treeNodeDoubleClicked';
ATreeEvent.NODE_ACTION = 'treeNodeAction';
ATreeEvent.NODE_OPENED = 'treeNodeOpened';
ATreeEvent.NODE_CLOSED = 'treeNodeClosed';
