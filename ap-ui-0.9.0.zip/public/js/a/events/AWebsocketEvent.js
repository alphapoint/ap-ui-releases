import { AEvent } from './AEvent.js';
export class AWebsocketEvent extends AEvent {
}
AWebsocketEvent.OPEN = 'websocketOpen';
AWebsocketEvent.CLOSE = 'websocketClose';
AWebsocketEvent.MESSAGE = 'websocketMessage';
AWebsocketEvent.ERROR = 'websocketError';
