import { AEvent } from './AEvent.js';
export class ATabBarEvent extends AEvent {
}
ATabBarEvent.SELECTED_INDEX_CHANGE = 'tabBarSelectedIndexChange';
ATabBarEvent.TAB_HOVER = 'tabBarTabHover';
