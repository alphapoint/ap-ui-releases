import { AEvent } from './AEvent.js';
export class ALanguageManagerEvent extends AEvent {
}
ALanguageManagerEvent.BEFORE_LANGUAGE_CHANGED = 'languageManagerBeforeLanguageChanged';
ALanguageManagerEvent.LANGUAGE_CHANGED = 'languageManagerLanguageChanged';
