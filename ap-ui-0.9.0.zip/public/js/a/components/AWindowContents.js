import { AContainer } from './AContainer.js';
export class AWindowContents extends AContainer {
    constructor() {
        super();
        this.icon = null;
        this.handleMenuItemClick = this.handleMenuItemClick.bind(this);
    }
    handleMenuItemClick(event) {
    }
    get window() {
        return this._window;
    }
    set window(w) {
        if (this._window !== w) {
            this._window = w;
            this._window.menuData = this._menuData;
        }
    }
    get menuData() {
        return this._menuData;
    }
    set menuData(m) {
        if (this._menuData !== m) {
            this._menuData = m;
            if (this._window !== undefined && this._window !== null) {
                this._window.menuData = this._menuData;
            }
        }
    }
}
window.customElements.define('a-window-contents', AWindowContents);
