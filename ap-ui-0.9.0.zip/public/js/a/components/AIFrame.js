import { AContainer } from './AContainer.js';
export class AIFrame extends AContainer {
    constructor(uri = null) {
        super();
        this._uri = uri;
    }
    _build() {
        super._build();
        this._iframe = document.createElement('iframe');
        this._iframe.setAttribute('allowtransparency', 'true');
        this.appendChild(this._iframe);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        if (this._uri !== null) {
            this.uri = this._uri;
        }
    }
    reload() {
        this._iframe.contentDocument.location.reload(true);
    }
    get contentDocument() {
        return this._iframe.contentDocument;
    }
    get uri() {
        return this._uri;
    }
    set uri(u) {
        if (this._uri !== u) {
            this._uri = u;
            this._iframe.src = this._uri;
        }
    }
}
window.customElements.define('a-iframe', AIFrame);
