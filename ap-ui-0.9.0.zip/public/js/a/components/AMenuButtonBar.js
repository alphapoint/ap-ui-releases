import { AContainer } from './AContainer.js';
import { AMenuButtonBarEvent } from '../events/AMenuButtonBarEvent.js';
import { AButton } from './AButton.js';
import { AMenuData, AMenuDataItem } from '../data/index.js';
import { AMenu } from './AMenu.js';
import { AMenuEvent } from '../events/index.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
export class AMenuButtonBar extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._data = [];
        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);
        this._closeTimer = null;
        this._closeTimeout = 1000;
        this._selectable = true;
        this._selectedMenuDataItem = null;
    }
    _registerListeners() {
        super._registerListeners();
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);
        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('click', this._onClick);
        this.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
        document.removeEventListener('mousedown', this._onDocumentMouseDown);
        this.removeEventListener('mouseleave', this._onMouseLeave);
        this.removeEventListener('mouseenter', this._onMouseEnter);
    }
    _render() {
        if (super._render()) {
            let count = this._data ? this._data.length : 0;
            let buttons = this.querySelectorAll('a-button');
            if (buttons.length !== count) {
                if (buttons.length < count) {
                    for (let i = 0; i < count - buttons.length; i++) {
                        this.appendChild(new AButton());
                    }
                }
                else if (buttons.length > count) {
                    for (let i = 0; i < buttons.length - count; i++) {
                        this.removeChild(this.querySelector('a-button'));
                    }
                }
            }
            buttons = this.querySelectorAll('a-button');
            for (let i = 0; i < count; i++) {
                let button = buttons.item(i);
                button.dataset.index = i.toString();
                let downIcon = button.querySelector('a-font-awesome-icon.down');
                let data = this._data[i];
                if (data.constructor === AMenuData) {
                    if (!downIcon) {
                        downIcon = new AFontAwesomeIcon();
                        downIcon.addClass('down');
                        downIcon.value = ['fal', 'fa-angle-down'];
                        button.appendChild(downIcon);
                    }
                    if (this._selectable) {
                        if (data.items.includes(this._selectedMenuDataItem)) {
                            button.label = this._selectedMenuDataItem.label;
                            button.addClass('selected');
                        }
                        else {
                            button.label = data.label;
                            button.removeClass('selected');
                        }
                    }
                    else {
                        button.label = data.label;
                        button.removeClass('selected');
                    }
                }
                else if (data.constructor === AMenuDataItem) {
                    button.label = data.label;
                    if (downIcon) {
                        button.removeChild(downIcon);
                    }
                    if (this._selectable && this._selectedMenuDataItem === data) {
                        button.addClass('selected');
                    }
                    else {
                        button.removeClass('selected');
                    }
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _openMenu(x, data) {
        this._menu.data = data;
        this._menu.style.left = `${x}px`;
        this._menu.visible = true;
    }
    _closeMenu() {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
    }
    _onClick(event) {
        let button = event.target.closest('a-button');
        if (button) {
            let data = this._data[parseInt(button.dataset.index)];
            if (data.constructor === AMenuData) {
                if (!this._menu.visible) {
                    this._openMenu(button.offsetLeft, data);
                }
                else {
                    this._closeMenu();
                }
            }
            else if (data.constructor === AMenuDataItem) {
                this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.ITEM_CLICKED, { bubbles: true, detail: { menuDataItem: data } }));
                if (this._selectable) {
                    this._selectedMenuDataItem = data;
                    this.invalidate();
                    this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, { bubbles: true, detail: { menuDataItem: data } }));
                }
            }
        }
    }
    _onMenuItemClicked(event) {
        this._closeMenu();
        this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.ITEM_CLICKED, { bubbles: true, detail: { menuDataItem: event.detail.menuDataItem } }));
        if (this._selectable) {
            this._selectedMenuDataItem = event.detail.menuDataItem;
            this.invalidate();
            this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, { bubbles: true, detail: { menuDataItem: event.detail.menuDataItem } }));
        }
    }
    _onDocumentMouseDown(event) {
        this._closeMenu();
    }
    _onMouseLeave(event) {
        if (this._menu.visible) {
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }
    _onMouseEnter(event) {
        if (this._menu.visible) {
            window.clearTimeout(this._closeTimer);
        }
    }
    get data() {
        return this._data;
    }
    set data(data) {
        if (this._data !== data) {
            this._data = data || null;
            this._selectedMenuDataItem = null;
            this.invalidate();
        }
    }
    get selectable() {
        return this._selectable;
    }
    set selectable(s) {
        if (this._selectable !== s) {
            this._selectable = s;
            this.invalidate();
        }
    }
    get selectedMenuDataItem() {
        return this._selectedMenuDataItem;
    }
    set selectedMenuDataItem(i) {
        if (this._selectedMenuDataItem !== i) {
            this._selectedMenuDataItem = i || null;
            this.invalidate();
        }
    }
}
window.customElements.define('a-menu-button-bar', AMenuButtonBar);
