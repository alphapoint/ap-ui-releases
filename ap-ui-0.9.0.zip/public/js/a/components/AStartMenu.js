import { AContainer } from './AContainer.js';
import { AMenu } from './AMenu.js';
import { AMenuEvent } from '../events/AMenuEvent.js';
import { AMenuData } from '../data/AMenuData.js';
import { AStartMenuEvent } from '../events/AStartMenuEvent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
export class AStartMenu extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._startIcon = new AFontAwesomeIcon();
        this._startIcon.title = 'Start';
        this.appendChild(this._startIcon);
        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);
        this._data = null;
        this._closeTimer = null;
        this._closeTimeout = 1000;
    }
    _registerListeners() {
        super._registerListeners();
        this._onStartIconClick = this._onStartIconClick.bind(this);
        this._startIcon.draggable = false;
        this._startIcon.addEventListener('click', this._onStartIconClick);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);
        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        return false;
    }
    _openMenu() {
        this._menu.data = this._data;
        this._menu.style.bottom = `${this.offsetHeight}px`;
        this._menu.style.left = `${this._startIcon.offsetLeft + 1}px`;
        this._menu.visible = true;
    }
    _closeMenu() {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
    }
    _onStartIconClick(event) {
        if (!this._menu.visible) {
            this._openMenu();
        }
        else {
            this._closeMenu();
        }
    }
    _onMenuItemClicked(event) {
        this.dispatchEvent(new AStartMenuEvent(AStartMenuEvent.ITEM_CLICKED, { bubbles: true, detail: { menuData: this._menu.data, menuDataItem: event.detail.menuDataItem } }));
        this._closeMenu();
    }
    _onDocumentMouseDown() {
        this._closeMenu();
        window.clearTimeout(this._closeTimer);
    }
    _onMouseEnter(event) {
        if (this._menu.visible) {
            window.clearTimeout(this._closeTimer);
        }
    }
    _onMouseLeave(event) {
        if (this._menu.visible) {
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }
    get data() {
        return this._data;
    }
    set data(data) {
        if (this._data !== data) {
            this._data = data || null;
            this.invalidate();
        }
    }
    get startIcon() {
        return this._startIcon.value;
    }
    set startIcon(i) {
        this._startIcon.value = i;
    }
}
window.customElements.define('a-start-menu', AStartMenu);
