import { AComponent } from './AComponent.js';
import { AScrollBarButton } from './AScrollBarButton.js';
import { AScrollBarTrack } from './AScrollBarTrack.js';
import { AScrollBarHandle } from './AScrollBarHandle.js';
import { AScrollbarEvent } from '../events/AScrollbarEvent.js';
export class AScrollBar extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._upIcon = ['fas', 'fa-caret-up'];
        this._downIcon = ['fas', 'fa-caret-down'];
        this._leftIcon = ['fas', 'fa-caret-left'];
        this._rightIcon = ['fas', 'fa-caret-right'];
        this._upLeftButton = new AScrollBarButton();
        this._upLeftButton.addClasses('up-left');
        this.appendChild(this._upLeftButton);
        this._scrollTrack = new AScrollBarTrack();
        this.appendChild(this._scrollTrack);
        this._scrollHandle = new AScrollBarHandle();
        this._scrollTrack.appendChild(this._scrollHandle);
        this._downRightButton = new AScrollBarButton();
        this._downRightButton.addClasses('down-right');
        this.appendChild(this._downRightButton);
        this._scrollTrackWidth = 1;
        this._scrollTrackHeight = 1;
        this._scrollHandleWidth = 1;
        this._scrollHandleHeight = 1;
        this._isScrollHandleDown = false;
        this.orientation = AScrollBar.VERTICAL;
        this._contentRatio = .25;
        this._scrollAmount = 0;
        this._scrollIncrement = .01;
    }
    _registerListeners() {
        super._registerListeners();
        this._onUpLeftClicked = this._onUpLeftClicked.bind(this);
        this._upLeftButton.addEventListener('click', this._onUpLeftClicked);
        this._onDownRightClicked = this._onDownRightClicked.bind(this);
        this._downRightButton.addEventListener('click', this._onDownRightClicked);
        this._onTrackClicked = this._onTrackClicked.bind(this);
        this._scrollTrack.addEventListener('click', this._onTrackClicked);
        this._onHandleDown = this._onHandleDown.bind(this);
        this._scrollHandle.addEventListener('mousedown', this._onHandleDown);
        this._onHandleUp = this._onHandleUp.bind(this);
        document.addEventListener('mouseup', this._onHandleUp);
        this._onHandleMove = this._onHandleMove.bind(this);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._upLeftButton.removeEventListener('click', this._onUpLeftClicked);
        this._downRightButton.removeEventListener('click', this._onDownRightClicked);
        this._scrollTrack.removeEventListener('click', this._onTrackClicked);
        this._scrollHandle.removeEventListener('mousedown', this._onHandleDown);
        document.removeEventListener('mouseup', this._onHandleUp);
        document.removeEventListener('mousemove', this._onHandleMove);
    }
    _render() {
        if (super._render()) {
            let track = this._scrollTrack;
            let handle = this._scrollHandle;
            let handleStyle = handle.style;
            if (this._orientation === AScrollBar.VERTICAL) {
                let trackHeight = track.offsetHeight;
                let handleHeight = trackHeight * this._contentRatio;
                handleStyle.height = `${handleHeight}px`;
                handleStyle.top = `${(trackHeight - handleHeight) * this._scrollAmount}px`;
                handleStyle.left = '0px';
            }
            else if (this._orientation === AScrollBar.HORIZONTAL) {
                let trackWidth = track.offsetWidth;
                let handleWidth = trackWidth * this._contentRatio;
                handleStyle.width = `${handleWidth}px`;
                handleStyle.left = `${(trackWidth - handleWidth) * this._scrollAmount}px`;
                handleStyle.top = '0px';
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onUpLeftClicked() {
        let scrollAmount = this._scrollAmount - this._scrollIncrement;
        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);
        if (this._scrollAmount !== scrollAmount) {
            this._scrollAmount = scrollAmount;
            this.invalidate();
            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));
        }
    }
    _onDownRightClicked() {
        let scrollAmount = this._scrollAmount + this._scrollIncrement;
        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);
        if (this._scrollAmount !== scrollAmount) {
            this._scrollAmount = scrollAmount;
            this.invalidate();
            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));
        }
    }
    _onTrackClicked(event) {
        event.stopPropagation();
        event.stopImmediatePropagation();
    }
    _onHandleDown(event) {
        event.stopPropagation();
        event.stopImmediatePropagation();
        this._scrollTrackWidth = this._scrollTrack.offsetWidth;
        this._scrollTrackHeight = this._scrollTrack.offsetHeight;
        this._scrollHandleWidth = this._scrollHandle.offsetWidth;
        this._scrollHandleHeight = this._scrollHandle.offsetHeight;
        this._isScrollHandleDown = true;
        if (this._orientation === AScrollBar.VERTICAL) {
            this._scrollHandlePointerOffset = event.clientY - this._scrollHandle.offsetTop;
        }
        else if (this._orientation === AScrollBar.HORIZONTAL) {
            this._scrollHandlePointerOffset = event.clientX - this._scrollHandle.offsetLeft;
        }
        document.addEventListener('mousemove', this._onHandleMove);
    }
    _onHandleMove(event) {
        let scrollAmount = 0;
        if (this._orientation === AScrollBar.VERTICAL) {
            let top = event.clientY - this._scrollHandlePointerOffset;
            let height = this._scrollTrackHeight - this._scrollHandleHeight;
            scrollAmount = top / height;
        }
        else if (this._orientation === AScrollBar.HORIZONTAL) {
            let left = event.clientX - this._scrollHandlePointerOffset;
            let width = this._scrollTrackWidth - this._scrollHandleWidth;
            scrollAmount = left / width;
        }
        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);
        if (this._scrollAmount !== scrollAmount) {
            this._scrollAmount = scrollAmount;
            this.invalidate();
            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));
        }
    }
    _onHandleUp(event) {
        if (this._isScrollHandleDown) {
            this._isScrollHandleDown = false;
            document.removeEventListener('mousemove', this._onHandleMove);
        }
    }
    get orientation() {
        return this._orientation;
    }
    set orientation(orientation) {
        if (this._orientation !== orientation && (orientation === AScrollBar.VERTICAL || orientation === AScrollBar.HORIZONTAL)) {
            this._orientation = orientation;
            if (this._orientation === AScrollBar.VERTICAL) {
                this.removeClass('horizontal');
                this.addClass('vertical');
                this._upLeftButton.removeClasses(...this._leftIcon);
                this._upLeftButton.addClasses(...this._upIcon);
                this._downRightButton.removeClasses(...this._rightIcon);
                this._downRightButton.addClasses(...this._downIcon);
            }
            else if (this._orientation === AScrollBar.HORIZONTAL) {
                this.removeClass('vertical');
                this.addClass('horizontal');
                this._upLeftButton.removeClasses(...this._upIcon);
                this._upLeftButton.addClasses(...this._leftIcon);
                this._downRightButton.removeClasses(...this._downIcon);
                this._downRightButton.addClasses(...this._rightIcon);
            }
            this.invalidate();
        }
    }
    get contentRatio() {
        return this._contentRatio;
    }
    set contentRatio(r) {
        r = Math.max(Math.min(r, 1), 0);
        if (this._contentRatio !== r) {
            this._contentRatio = r;
            this.invalidate();
        }
    }
    get scrollIncrement() {
        return this._scrollIncrement;
    }
    set scrollIncrement(i) {
        i = Math.max(Math.min(i, 1), 0);
        if (this._scrollIncrement !== i) {
            this._scrollIncrement = i;
        }
    }
    get scrollAmount() {
        return this._scrollAmount;
    }
    set scrollAmount(a) {
        a = Math.max(Math.min(a, 1), 0);
        if (this._scrollAmount !== a) {
            this._scrollAmount = a;
            this.invalidate();
        }
    }
}
AScrollBar.VERTICAL = Symbol('vertical');
AScrollBar.HORIZONTAL = Symbol('horizontal');
window.customElements.define('a-scroll-bar', AScrollBar);
