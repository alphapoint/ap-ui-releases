import { AContainer } from './AContainer.js';
import { AButtonBar } from './AButtonBar.js';
import { AMenu } from './AMenu.js';
import { AButtonBarEvent } from '../events/AButtonBarEvent.js';
import { AMenuEvent } from '../events/AMenuEvent.js';
import { AMenuData } from '../data/AMenuData.js';
import { AMenuBarEvent } from '../events/AMenuBarEvent.js';
export class AMenuBar extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._menuButtonBar = new AButtonBar();
        this.appendChild(this._menuButtonBar);
        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);
        this._prevMenuBarIndex = null;
        this._data = [];
        this._closeTimer = null;
        this._closeTimeout = 1000;
    }
    _registerListeners() {
        super._registerListeners();
        this._onMenuBarMouseDown = this._onMenuBarMouseDown.bind(this);
        this._menuButtonBar.addEventListener('mousedown', this._onMenuBarMouseDown);
        this._onMenuBarIndexChanged = this._onMenuBarIndexChanged.bind(this);
        this._menuButtonBar.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onMenuBarIndexChanged);
        this._onMenuBarButtonHover = this._onMenuBarButtonHover.bind(this);
        this._menuButtonBar.addEventListener(AButtonBarEvent.BUTTON_HOVER, this._onMenuBarButtonHover);
        this._onMenuItemMouseOver = this._onMenuItemMouseOver.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_MOUSED_OVER, this._onMenuItemMouseOver);
        this._onMenuItemMouseOut = this._onMenuItemMouseOut.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_MOUSED_OVER, this._onMenuItemMouseOut);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);
        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._menuButtonBar.removeEventListener('mousedown', this._onMenuBarMouseDown);
        this._menuButtonBar.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onMenuBarIndexChanged);
        this._menuButtonBar.removeEventListener(AButtonBarEvent.BUTTON_HOVER, this._onMenuBarButtonHover);
        this._menu.removeEventListener(AMenuEvent.ITEM_MOUSED_OVER, this._onMenuItemMouseOver);
        this._menu.removeEventListener(AMenuEvent.ITEM_MOUSED_OUT, this._onMenuItemMouseOut);
        this._menu.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
        document.removeEventListener('mousedown', this._onDocumentMouseDown);
        this.removeEventListener('mouseleave', this._onMouseLeave);
        this.removeEventListener('mouseenter', this._onMouseEnter);
    }
    _onMouseLeave(event) {
        if (this._menu.visible) {
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }
    _onMouseEnter(event) {
        if (this._menu.visible) {
            window.clearTimeout(this._closeTimer);
        }
    }
    _render() {
        if (super._render()) {
            let labels = this._data.map((item) => item.label);
            let icons = this._data.map((item) => item.icon);
            this._menuButtonBar.icons = icons;
            this._menuButtonBar.labels = labels;
            return true;
        }
        return false;
    }
    _openMenu(index) {
        this._menu.data = this._data[index];
        this._menu.style.left = this._menuButtonBar.getChildAt(index).offsetLeft + 'px';
        this._menu.visible = true;
        this._prevMenuBarIndex = index;
    }
    _closeMenu() {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
        this._menuButtonBar.selectedIndex = null;
        this._prevMenuBarIndex = null;
        this.dispatchEvent(new AMenuBarEvent(AMenuBarEvent.CLOSED));
    }
    _onMenuBarMouseDown(event) {
    }
    _onMenuBarIndexChanged() {
        this._menu.visible = false;
        let index = this._menuButtonBar.selectedIndex;
        if (index === null || this._prevMenuBarIndex === index) {
            this._closeMenu();
        }
        else if (index !== null) {
            this._openMenu(index);
        }
    }
    _onMenuBarButtonHover(event) {
        if (this._menu.visible) {
            this._menuButtonBar.selectedIndex = event.detail.index;
            this._openMenu(event.detail.index);
        }
    }
    _onMenuItemMouseOver(event) {
        this.dispatchEvent(new AMenuBarEvent(AMenuBarEvent.ITEM_MOUSED_OVER, { detail: { menuData: this._menu.data, menuDataItem: event.detail.menuDataItem } }));
    }
    _onMenuItemMouseOut(event) {
        this.dispatchEvent(new AMenuBarEvent(AMenuBarEvent.ITEM_MOUSED_OUT, { detail: { menuData: this._menu.data, menuDataItem: event.detail.menuDataItem } }));
    }
    _onMenuItemClicked(event) {
        this.dispatchEvent(new AMenuBarEvent(AMenuBarEvent.ITEM_CLICKED, { detail: { menuData: this._menu.data, menuDataItem: event.detail.menuDataItem } }));
        this._closeMenu();
    }
    _onDocumentMouseDown(event) {
        this._closeMenu();
    }
    get data() {
        return this._data;
    }
    set data(data) {
        if (this._data !== data) {
            this._data = data || [];
            this.invalidate();
        }
    }
}
window.customElements.define('a-menu-bar', AMenuBar);
