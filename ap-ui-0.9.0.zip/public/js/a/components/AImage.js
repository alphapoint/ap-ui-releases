import { AComponent } from './AComponent.js';
export class AImage extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._img = document.createElement('img');
        this.appendChild(this._img);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    get src() {
        return this._img.src;
    }
    set src(s) {
        this._img.src = s;
    }
    get onload() {
        return this._img.onload;
    }
    set onload(loadHandler) {
        this._img.onload = loadHandler;
    }
    get onerror() {
        return this._img.onerror;
    }
    set onerror(errorHandler) {
        this._img.onerror = errorHandler;
    }
    get img() {
        return this._img;
    }
}
window.customElements.define('a-image', AImage);
