import { AContainer } from './AContainer.js';
export class APanelContentsContainer extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-panel-contents-container', APanelContentsContainer);
