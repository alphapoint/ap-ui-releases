import { AContainer } from './AContainer.js';
import { AMenuData } from '../data/AMenuData.js';
import { AMenuItem } from './AMenuItem.js';
import { AMenuDataItem } from '../data/AMenuDataItem.js';
import { AMenuEvent } from '../events/AMenuEvent.js';
export class AMenu extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._data = new AMenuData();
        this._selectedIndex = null;
    }
    _registerListeners() {
        super._registerListeners();
        this._onMouseOver = this._onMouseOver.bind(this);
        this.addEventListener('mouseover', this._onMouseOver);
        this._onMouseOut = this._onMouseOut.bind(this);
        this.addEventListener('mouseout', this._onMouseOut);
        this._onMouseDown = this._onMouseDown.bind(this);
        this.addEventListener('mousedown', this._onMouseDown);
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('mouseover', this._onMouseOver);
        this.removeEventListener('mouseout', this._onMouseOut);
        this.removeEventListener('mousedown', this._onMouseDown);
        this.removeEventListener('click', this._onClick);
    }
    _render() {
        if (super._render()) {
            while (this.data.items.length !== this.childElementCount) {
                if (this.data.items.length > this.childElementCount) {
                    this.appendChild(new AMenuItem());
                }
                else if (this.data.items.length < this.childElementCount) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }
            this.data.items.forEach((dataItem, index) => {
                this.getChildAt(index).setAttribute('data-index', index.toString());
                let menuItem = this.getChildAt(index);
                menuItem.data = dataItem;
                menuItem.enabled = dataItem.enabled;
                if (dataItem.selected) {
                    menuItem.addClass('selected');
                }
                else {
                    menuItem.removeClass('selected');
                }
            });
            return true;
        }
        else {
            return false;
        }
    }
    _onMouseOver(event) {
        if (event.target.constructor === AMenuItem) {
            let index = Number(event.target.getAttribute('data-index'));
            if (index >= 0 && index < this.childElementCount) {
                let menuDataItem = this._data.items[index];
                if (menuDataItem.constructor === AMenuDataItem) {
                    if (menuDataItem && menuDataItem.enabled) {
                        this.dispatchEvent(new AMenuEvent(AMenuEvent.ITEM_MOUSED_OVER, { bubbles: true, detail: { index: index, menuDataItem: this._data.items[index] } }));
                    }
                }
            }
        }
    }
    _onMouseOut(event) {
        if (event.target.constructor === AMenuItem) {
            let index = Number(event.target.getAttribute('data-index'));
            if (index >= 0 && index < this.childElementCount) {
                let menuDataItem = this._data.items[index];
                if (menuDataItem.constructor === AMenuDataItem) {
                    if (menuDataItem && menuDataItem.enabled) {
                        this.dispatchEvent(new AMenuEvent(AMenuEvent.ITEM_MOUSED_OUT, { bubbles: true, detail: { index: index, menuDataItem: this._data.items[index] } }));
                    }
                }
            }
        }
    }
    _onMouseDown(event) {
        event.stopPropagation();
    }
    _onClick(event) {
        if (event.target.constructor === AMenuItem) {
            let index = Number(event.target.getAttribute('data-index'));
            if (index >= 0 && index < this.childElementCount) {
                let menuDataItem = this._data.items[index];
                if (menuDataItem.constructor === AMenuDataItem) {
                    if (menuDataItem && menuDataItem.enabled) {
                        this.dispatchEvent(new AMenuEvent(AMenuEvent.ITEM_CLICKED, { bubbles: true, detail: { index: index, menuDataItem: this._data.items[index] } }));
                    }
                }
            }
        }
    }
    get data() {
        return this._data || new AMenuData();
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d;
            this._render();
        }
    }
}
window.customElements.define('a-menu', AMenu);
