import { AContainer } from './AContainer.js';
import { AButtonBarEvent } from '../events/AButtonBarEvent.js';
import { AButton } from './AButton.js';
export class AButtonBar extends AContainer {
    constructor() {
        super();
        this._labels = [];
        this._icons = [];
    }
    _build() {
        super._build();
        this._selectable = true;
        this._selectedIndex = null;
    }
    _registerListeners() {
        super._registerListeners();
        this._onMouseOver = this._onMouseOver.bind(this);
        this.addEventListener('mouseover', this._onMouseOver);
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('mouseover', this._onMouseOver);
        this.removeEventListener('click', this._onClick);
    }
    _render() {
        if (super._render()) {
            let count = Math.max(this._labels.length, this._icons.length);
            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                }
                else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }
            for (let i = 0; i < count; i++) {
                let button = this.getChildAt(i);
                button.setAttribute('data-index', i.toString());
                button.icon = this._icons[i];
                button.label = this._labels[i];
                if (this._selectable && this._selectedIndex !== null && i > -1 && i < this._labels.length && this._selectedIndex === i) {
                    button.addClass('selected');
                }
                else {
                    button.removeClass('selected');
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _setSelectedIndex(index) {
        if (this._selectedIndex !== index) {
            if (this._selectable) {
                this._selectedIndex = index;
            }
            else {
                this._selectedIndex = null;
            }
        }
        this.invalidate();
    }
    _onMouseOver(event) {
        if (event.target.constructor === AButton) {
            this._onButtonHover(event.target);
        }
    }
    _onClick(event) {
        if (event.target.constructor === AButton) {
            this._onButtonClick(event.target);
        }
    }
    _onButtonClick(button) {
        this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.BUTTON_CLICK, { detail: { index: Number(button.getAttribute('data-index')) } }));
        if (this._selectable) {
            this._setSelectedIndex(Number(this._selectable ? button.getAttribute('data-index') : null));
            this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.SELECTED_INDEX_CHANGE));
        }
    }
    _onButtonHover(element) {
        this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.BUTTON_HOVER, { detail: { index: Number(element.getAttribute('data-index')) } }));
    }
    get icons() {
        return this._icons;
    }
    set icons(d) {
        if (this._icons !== d) {
            this._icons = d || [];
            this.invalidate();
        }
    }
    get labels() {
        return this._labels;
    }
    set labels(d) {
        if (this._labels !== d) {
            this._labels = d || [];
            this.invalidate();
        }
    }
    get selectable() {
        return this._selectable;
    }
    set selectable(s) {
        if (this._selectable !== s) {
            this._selectable = s;
            this.invalidate();
        }
    }
    get selectedIndex() {
        return this._selectedIndex !== null && this._selectedIndex > -1 && this._selectedIndex < this._labels.length ? this._selectedIndex : null;
    }
    set selectedIndex(i) {
        this._setSelectedIndex(i);
    }
}
window.customElements.define('a-button-bar', AButtonBar);
