import { AScrollbarEvent } from '../events/index.js';
import { ADataGridEvent } from '../events/ADataGridEvent.js';
import { AContainer } from './AContainer.js';
import { ADataGridRowsContainer } from './ADataGridRowsContainer.js';
import { ADataGridHeader } from './ADataGridHeader.js';
import { AScrollBar } from './AScrollBar.js';
import { ADataGridRow } from './ADataGridRow.js';
import { ADataGridHeaderItem } from './ADataGridHeaderItem.js';
export var ADataGridSortDirection;
(function (ADataGridSortDirection) {
    ADataGridSortDirection["NONE"] = "NONE";
    ADataGridSortDirection["ASCENDING"] = "ASCENDING";
    ADataGridSortDirection["DESCENDING"] = "DESCENDING";
})(ADataGridSortDirection || (ADataGridSortDirection = {}));
export class ADataGrid extends AContainer {
    constructor() {
        super();
        this._selectable = true;
        this._selectedIndex = null;
        this._rowRenderer = ADataGridRow;
    }
    _build() {
        super._build();
        this._data = [];
        this._filteredSortedData = [];
        this._header = new ADataGridHeader();
        this.appendChild(this._header);
        this._rowContainer = new ADataGridRowsContainer();
        this.appendChild(this._rowContainer);
        this._verticalScrollbar = new AScrollBar();
        this._verticalScrollbar.orientation = AScrollBar.VERTICAL;
        this.appendChild(this._verticalScrollbar);
        this._verticallyScrollable = true;
        this._verticalScrollAmount = 0;
        this._horizontalScrollbar = new AScrollBar();
        this._horizontalScrollbar.orientation = AScrollBar.HORIZONTAL;
        this.appendChild(this._horizontalScrollbar);
        this._horizontallyScrollable = false;
        this._horizontalScrollAmount = 0;
        this._filterTextInput = null;
        this._viewHeight = 0;
        this._rowCount = 0;
        this._visibleRows = 0;
        this._allRowsHeight = 0;
        this._visibleRowsHeight = 0;
        this._additionalScrollingRows = 4;
        this._rowHeight = 0;
        this._dataScrollOffset = 0;
        this._inverted = false;
        this._sortable = false;
        this._sortDirection = ADataGridSortDirection.NONE;
        this._sortColumnIndex = -1;
        this._filterText = null;
        this._rowsDraggable = false;
        this.addClass('hide-horizontal-scrollbar');
    }
    _registerListeners() {
        super._registerListeners();
        this._onResizeObserved = this._onResizeObserved.bind(this);
        this._resizeObserver = new ResizeObserver(this._onResizeObserved);
        this._resizeObserver.observe(this, {
            box: 'border-box'
        });
        this._onMouseWheel = this._onMouseWheel.bind(this);
        this.addEventListener('mousewheel', this._onMouseWheel);
        this._onVerticalScroll = this._onVerticalScroll.bind(this);
        this._verticalScrollbar.addEventListener(AScrollbarEvent.SCROLL, this._onVerticalScroll);
        this._onHorizontalScroll = this._onHorizontalScroll.bind(this);
        this._horizontalScrollbar.addEventListener(AScrollbarEvent.SCROLL, this._onHorizontalScroll);
        this._onHeaderClick = this._onHeaderClick.bind(this);
        this._header.addEventListener('click', this._onHeaderClick);
        this._onRowContainerClick = this._onRowContainerClick.bind(this);
        this._rowContainer.addEventListener('click', this._onRowContainerClick);
        this._onRowContainerDoubleClick = this._onRowContainerDoubleClick.bind(this);
        this._rowContainer.addEventListener('dblclick', this._onRowContainerDoubleClick);
        this._onFilterTextInputChange = this._onFilterTextInputChange.bind(this);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._resizeObserver.unobserve(this);
        this._resizeObserver.disconnect();
        this.removeEventListener('mousewheel', this._onMouseWheel);
        this._verticalScrollbar.removeEventListener(AScrollbarEvent.SCROLL, this._onVerticalScroll);
        this._horizontalScrollbar.removeEventListener(AScrollbarEvent.SCROLL, this._onHorizontalScroll);
        this._header.removeEventListener('click', this._onHeaderClick);
        this._rowContainer.removeEventListener('click', this._onRowContainerClick);
        this._rowContainer.removeEventListener('dblclick', this._onRowContainerDoubleClick);
        if (this._filterTextInput !== null) {
            this._filterTextInput.removeEventListener('input', this._onFilterTextInputChange);
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._rowHeight = parseFloat(getComputedStyle(this).getPropertyValue('--row-height')) * parseFloat(getComputedStyle(document.documentElement).fontSize);
    }
    _render() {
        if (super._render()) {
            if (this._header.columnLabels.length > 0) {
                this.removeClass('hide-header');
                if (this._sortable) {
                    let headerLen = this._header.childNodes.length;
                    for (let i = 0; i < headerLen; i++) {
                        let headerItem = this._header.getChildAt(i);
                        if (this._sortColumnIndex === i) {
                            headerItem.sortDirection = this._sortDirection;
                        }
                        else {
                            headerItem.sortDirection = ADataGridSortDirection.NONE;
                        }
                    }
                }
            }
            else {
                this.addClass('hide-header');
            }
            let dataLength = this._filteredSortedData.length;
            this._viewHeight = Math.max(this._rowContainer.offsetHeight, 1);
            this._visibleRows = Math.ceil(this._viewHeight / this._rowHeight);
            this._rowCount = this._visibleRows;
            this._allRowsHeight = dataLength * this._rowHeight;
            this._visibleRowsHeight = this._visibleRows * this._rowHeight;
            let willVerticalScroll = false;
            if (this._verticallyScrollable && this._allRowsHeight > this._viewHeight) {
                this._rowCount = this._visibleRows + Math.max(Math.min(this._additionalScrollingRows, dataLength - this._visibleRows), 1);
                willVerticalScroll = true;
            }
            else {
                this._verticalScrollAmount = 0;
            }
            let verticalScrollAmount = this.verticalScrollAmount;
            let additionalRows = this._rowCount - this._visibleRows;
            let additionalRowsHeight = additionalRows * this._rowHeight;
            while (this._rowContainer.childElementCount !== this._rowCount) {
                if (this._rowContainer.childElementCount < this._rowCount) {
                    this._addRow();
                }
                else if (this._rowContainer.childElementCount > this._rowCount) {
                    this._removeRow();
                }
            }
            let dataScrollOffset = 0;
            let scrollMargin = 0;
            if (willVerticalScroll) {
                let scrollOffset = (verticalScrollAmount * (this._allRowsHeight - this._viewHeight)) / additionalRowsHeight;
                dataScrollOffset = Math.floor(scrollOffset) * additionalRows;
                scrollMargin = (scrollOffset > 1 ? scrollOffset % 1 : scrollOffset) * additionalRowsHeight;
                if (scrollMargin > additionalRowsHeight) {
                    scrollMargin = scrollMargin - additionalRowsHeight;
                }
            }
            this._dataScrollOffset = dataScrollOffset;
            for (let i = 0; i < this._rowContainer.childElementCount; i++) {
                let row = this._rowContainer.getChildAt(i);
                let dataIndex = this._dataScrollOffset + i;
                row.data = this._filteredSortedData[dataIndex];
                row.index = i;
                row.selected = dataIndex === this._selectedIndex;
                row.draggable = this._rowsDraggable;
                row.style.transform = `translateY(${willVerticalScroll ? -scrollMargin : 0}px)`;
            }
            if (this._verticallyScrollable && willVerticalScroll) {
                this._verticalScrollbar.scrollIncrement = this._rowHeight / (this._allRowsHeight - this._viewHeight);
                this._verticalScrollbar.scrollAmount = this._verticalScrollAmount;
                this._verticalScrollbar.contentRatio = this._viewHeight / this._allRowsHeight;
                this.removeClass('hide-vertical-scrollbar');
            }
            else {
                this.addClass('hide-vertical-scrollbar');
            }
            if (this._horizontallyScrollable && (this._header.scrollWidth > this.offsetWidth || this._rowContainer.scrollWidth > this.offsetWidth)) {
                let scrollWidth = Math.max(this._header.scrollWidth, this._rowContainer.scrollWidth);
                let visibleWidth = Math.max(this._header.offsetWidth, this._rowContainer.offsetWidth);
                let totalHorizontalScroll = scrollWidth - visibleWidth;
                this._horizontalScrollbar.scrollIncrement = 1 / (scrollWidth - visibleWidth);
                this._horizontalScrollbar.scrollAmount = this._horizontalScrollAmount;
                this._horizontalScrollbar.contentRatio = visibleWidth / scrollWidth;
                this._header.scrollLeft = this._horizontalScrollbar.scrollAmount * totalHorizontalScroll;
                this._rowContainer.scrollLeft = this._horizontalScrollbar.scrollAmount * totalHorizontalScroll;
                this.removeClass('hide-horizontal-scrollbar');
            }
            else {
                this.addClass('hide-horizontal-scrollbar');
            }
            return true;
        }
        else {
            return false;
        }
    }
    _addRow() {
        let row = new this._rowRenderer();
        row.index = this._rowContainer.childElementCount;
        this._rowContainer.appendChild(row);
        return row;
    }
    _removeRow() {
        let index = this._rowContainer.childElementCount - 1;
        let row = this._rowContainer.getChildAt(index);
        this._rowContainer.removeChildAt(index);
        row.destroy();
    }
    _setSort(columnIndex = null) {
        if (columnIndex === -1) {
            this._sortColumnIndex = -1;
            this._sortDirection = ADataGridSortDirection.NONE;
        }
        else if (this._sortColumnIndex !== columnIndex) {
            this._sortColumnIndex = columnIndex;
            this._sortDirection = ADataGridSortDirection.DESCENDING;
        }
        else {
            if (this._sortDirection === ADataGridSortDirection.DESCENDING) {
                this._sortDirection = ADataGridSortDirection.ASCENDING;
            }
            else if (this._sortDirection === ADataGridSortDirection.ASCENDING) {
                this._sortColumnIndex = -1;
                this._sortDirection = ADataGridSortDirection.NONE;
            }
            else if (this._sortDirection === ADataGridSortDirection.NONE) {
                this._sortDirection = ADataGridSortDirection.DESCENDING;
            }
        }
        this._filterAndSortData();
    }
    _setFilterText(filterText = null) {
        this._filterText = filterText;
        this._filterAndSortData();
    }
    _filterAndSortData() {
        if (((!this._sortable || this._sortColumnIndex === -1) && this._filterText === null) || this._data.length === 0) {
            if (this._filteredSortedData !== this._data) {
                this._filteredSortedData = this._data;
            }
        }
        else {
            let output = JSON.parse(JSON.stringify(this._data));
            if (this._filterText !== null) {
                output = output.filter((rowData) => {
                    return String(rowData).toLowerCase().includes(this._filterText);
                });
            }
            if (this._sortColumnIndex !== null && this._sortDirection !== ADataGridSortDirection.NONE) {
                output.sort((one, two) => {
                    let oneRaw = one[this._sortColumnIndex];
                    let itemOne = oneRaw.constructor === String ? String(oneRaw).toLowerCase() : Number(oneRaw);
                    let twoRaw = two[this._sortColumnIndex];
                    let itemTwo = twoRaw.constructor === String ? String(twoRaw).toLowerCase() : Number(twoRaw);
                    if (itemOne < itemTwo) {
                        return this._sortDirection === ADataGridSortDirection.DESCENDING ? -1 : 1;
                    }
                    else if (itemOne > itemTwo) {
                        return this._sortDirection === ADataGridSortDirection.DESCENDING ? 1 : -1;
                    }
                    else {
                        return 0;
                    }
                });
            }
            this._filteredSortedData = output;
        }
        if (this._filteredSortedData.length === 0) {
            this._selectedIndex = null;
        }
    }
    _onResizeObserved(entries, observer) {
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].target === this) {
                this.invalidate();
                return;
            }
        }
    }
    _onVerticalScroll(event) {
        this.verticalScrollAmount = event.target.scrollAmount;
    }
    _onHorizontalScroll(event) {
        this.horizontalScrollAmount = event.target.scrollAmount;
    }
    _onMouseWheel(event) {
        event.preventDefault();
        if (event.deltaY > 0) {
            this.verticalScrollAmount = this._verticalScrollbar.scrollAmount + this._verticalScrollbar.scrollIncrement;
        }
        else if (event.deltaY < 0) {
            this.verticalScrollAmount = this._verticalScrollbar.scrollAmount - this._verticalScrollbar.scrollIncrement;
        }
    }
    _onHeaderClick(event) {
        if (this._sortable) {
            let columnIndex = -1;
            let headerItem = event.target.closest('a-data-grid-header-item');
            if (headerItem.constructor === ADataGridHeaderItem) {
                let len = this._header.childNodes.length;
                for (let i = 0; i < len; i++) {
                    if (this._header.getChildAt(i) === headerItem) {
                        columnIndex = i;
                        break;
                    }
                }
            }
            this._setSort(columnIndex);
        }
    }
    _onRowContainerClick(event) {
        let path = event.composedPath();
        for (let i = 0; i < path.length; i++) {
            if (this._rowRenderer.prototype.isPrototypeOf(path[i])) {
                this._onRowClick(event.target, path[i]);
                break;
            }
        }
    }
    _onRowContainerDoubleClick(event) {
        let path = event.composedPath();
        for (let i = 0; i < path.length; i++) {
            if (this._rowRenderer.prototype.isPrototypeOf(path[i])) {
                this._onRowDoubleClick(event.target, path[i]);
                break;
            }
        }
    }
    _onRowClick(src, row) {
        if (row.index >= 0 && row.index < this._rowContainer.childElementCount) {
            let newDataIndex = this._dataScrollOffset + row.index;
            src.dispatchEvent(new ADataGridEvent(ADataGridEvent.ROW_CLICK, { bubbles: true, detail: { index: newDataIndex } }));
            if (this._selectable) {
                let oldDataIndex = this._selectedIndex;
                if (oldDataIndex !== newDataIndex) {
                    this._selectedIndex = newDataIndex;
                    this.invalidate();
                    this.dispatchEvent(new ADataGridEvent(ADataGridEvent.SELECTED_INDEX_CHANGED));
                }
            }
        }
    }
    _onRowDoubleClick(src, row) {
    }
    _onFilterTextInputChange(event) {
        let t = event.target.value.trim();
        this._setFilterText(t.length > 0 ? t.toLowerCase() : null);
    }
    getRowAt(index) {
        return this._rowContainer.getChildAt(index);
    }
    getItemAt(index) {
        if (index >= 0 && index < this._data.length) {
            return this._data[index];
        }
        else {
            return null;
        }
    }
    addItem(item) {
        this.addItemAt(this._data.length, item);
    }
    addItemAt(index, item) {
        if (index >= 0 && index <= this._data.length) {
            this._data.splice(index, 0, item);
            this._filterAndSortData();
            this.invalidate();
        }
    }
    removeItemAt(index) {
        if (index >= 0 && index < this._data.length) {
            this._data.splice(index, 1);
            this._filterAndSortData();
            this.invalidate();
        }
    }
    removeAllItems() {
        this._data = [];
        this._filterAndSortData();
        this.invalidate();
    }
    setItems(data) {
        this._data = data || [];
        this._filterAndSortData();
        this.invalidate();
    }
    setItemAt(index, item) {
        if (index >= 0 && index <= this._data.length) {
            this._data[index] = item;
            if (index >= this._dataScrollOffset && index <= this._dataScrollOffset + this._rowCount) {
                let row = this._rowContainer.getChildAt(index - this._dataScrollOffset);
                row.data = this._data[index];
            }
            this._filterAndSortData();
        }
    }
    get rowCount() {
        return this._rowCount;
    }
    get length() {
        return this._data.length;
    }
    get selectable() {
        return this._selectable;
    }
    set selectable(s) {
        if (this._selectable !== s) {
            this._selectedIndex = null;
            this._selectable = s;
            this.invalidate();
        }
    }
    get selectedIndex() {
        return this._selectedIndex !== null && this._selectedIndex >= 0 && this._selectedIndex < this._data.length ? this._selectedIndex : null;
    }
    set selectedIndex(i) {
        if ((this._selectedIndex !== i && i >= 0 && i < this._data.length) || i === null) {
            this._selectedIndex = i;
            this.invalidate();
        }
    }
    get selectedItem() {
        return this._data[this._selectedIndex] || null;
    }
    get columnLabels() {
        return this._header.columnLabels;
    }
    set columnLabels(c) {
        if (this._header.columnLabels !== c) {
            this._header.columnLabels = c;
            this.invalidate();
        }
    }
    get rowRenderer() {
        return this._rowRenderer;
    }
    set rowRenderer(renderer) {
        if (this._rowRenderer !== renderer) {
            this._rowRenderer = renderer;
            this.invalidate();
        }
    }
    get inverted() {
        return this._inverted;
    }
    set inverted(i) {
        if (this._inverted !== i) {
            this._inverted = i;
            this.invalidate();
        }
    }
    get verticallyScrollable() {
        return this._verticallyScrollable;
    }
    set verticallyScrollable(s) {
        if (this._verticallyScrollable !== s) {
            this._verticallyScrollable = s;
            this.invalidate();
        }
    }
    get verticalScrollAmount() {
        return this._verticalScrollAmount;
    }
    set verticalScrollAmount(amount) {
        amount = Math.max(Math.min(amount, 1), 0);
        if (this._verticalScrollAmount !== amount) {
            this._verticalScrollAmount = amount;
            this._render();
        }
    }
    get horizontallyScrollable() {
        return this._horizontallyScrollable;
    }
    set horizontallyScrollable(s) {
        if (this._horizontallyScrollable !== s) {
            this._horizontallyScrollable = s;
            this.invalidate();
        }
    }
    get horizontalScrollAmount() {
        return this._horizontalScrollAmount;
    }
    set horizontalScrollAmount(amount) {
        amount = Math.max(Math.min(amount, 1), 0);
        if (this._horizontalScrollAmount !== amount) {
            this._horizontalScrollAmount = amount;
            this._render();
        }
    }
    get sortable() {
        return this._sortable;
    }
    set sortable(s) {
        if (this._sortable !== s) {
            this._sortable = s;
            this.invalidate();
        }
    }
    get rowsDraggable() {
        return this._rowsDraggable;
    }
    set rowsDraggable(d) {
        if (this._rowsDraggable !== d) {
            this._rowsDraggable = d;
            this.invalidate();
        }
    }
    get filterTextInput() {
        return this._filterTextInput;
    }
    set filterTextInput(t) {
        if (this._filterTextInput !== t) {
            if (this._filterTextInput !== null) {
                this._filterTextInput.removeEventListener('input', this._onFilterTextInputChange);
            }
            else {
                this._onFilterTextInputChange = this._onFilterTextInputChange.bind(this);
            }
            this._filterTextInput = t;
            this._filterTextInput.addEventListener('input', this._onFilterTextInputChange);
        }
    }
}
window.customElements.define('a-data-grid', ADataGrid);
