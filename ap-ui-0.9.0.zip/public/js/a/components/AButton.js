import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AText } from './AText.js';
import { AImage } from './AImage.js';
export class AButton extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._iconValue = null;
        this._imageValue = null;
        this._labelText = null;
        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);
        this._image = new AImage();
        this.appendChild(this._image);
        this._label = new AText();
        this.appendChild(this._label);
        this._iconValue = null;
        this._labelText = null;
    }
    _registerListeners() {
        super._registerListeners();
        this._imageError = this._imageError.bind(this);
        this._image.addEventListener('error', this._imageError);
        this._imageLoad = this._imageLoad.bind(this);
        this._image.addEventListener('load', this._imageLoad);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._image.removeEventListener('error', this._imageError);
    }
    _render() {
        if (super._render()) {
            if (this._iconValue !== null) {
                this._icon.value = this._iconValue;
                this._icon.visible = true;
            }
            else {
                this._icon.visible = false;
            }
            if (this._imageValue !== null) {
                this._image.visible = true;
            }
            else {
                this._image.visible = false;
            }
            if (this._labelText !== null) {
                this._label.text = this._labelText;
                this._label.visible = true;
            }
            else {
                this._label.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _imageError(event) {
        this._imageValue = null;
        this.invalidate();
    }
    _imageLoad(event) {
        this.invalidate();
    }
    get icon() {
        return this._iconValue;
    }
    set icon(i) {
        if (this._iconValue !== i) {
            if (i === undefined) {
                i = null;
            }
            this._iconValue = i;
            this.invalidate();
        }
    }
    get image() {
        return this._imageValue;
    }
    set image(i) {
        if (this._imageValue !== i) {
            if (i === undefined) {
                i = null;
            }
            this._imageValue = i;
            this._image.src = i;
        }
    }
    get label() {
        return this._labelText;
    }
    set label(l) {
        if (this._labelText != l) {
            this._labelText = l;
            this.invalidate();
        }
    }
}
window.customElements.define('a-button', AButton);
