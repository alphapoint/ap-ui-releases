import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { ALabel } from './ALabel.js';
export class ASelect extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._label = new ALabel();
        this.appendChild(this._label);
        this._select = document.createElement('select');
        this._select.size = 1;
        this.appendChild(this._select);
        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _render() {
        if (super._render()) {
            this._label.visible = Boolean(this._label.text);
            this._icon.visible = this._icon.value !== null && this._icon.value.length > 0;
        }
        else {
            return false;
        }
    }
    focus() {
        this._select.focus();
    }
    get value() {
        return this._select.value;
    }
    set value(v) {
        if (this._select.value !== v) {
            this._select.value = v;
            this.invalidate();
        }
    }
    get options() {
        return this._select.innerHTML;
    }
    set options(o) {
        if (this._select.innerHTML !== o) {
            this._select.innerHTML = o;
            this.invalidate();
        }
    }
    get label() {
        return this._label.text;
    }
    set label(l) {
        if (this._label.text !== l) {
            this._label.text = l;
            this.invalidate();
        }
    }
    get icon() {
        return this._icon.value;
    }
    set icon(i) {
        if (this._icon.value !== i) {
            this._icon.value = i;
            this.invalidate();
        }
    }
}
window.customElements.define('a-select', ASelect);
