import { AContainer } from './AContainer.js';
import { APanelHeader } from './APanelHeader.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { APanelEvent } from '../events/APanelEvent.js';
import { APanelContentsContainer } from './APanelContentsContainer.js';
import { APanelResizeTargets } from './APanelResizeTargets.js';
import { ARectangle } from '../geometry/index.js';
import { ASystemManager } from '../managers/index.js';
export class APanel extends AContainer {
    constructor() {
        super();
        this._panelGrid = null;
    }
    _build() {
        super._build();
        this._showHeader = true;
        this._showMenu = true;
        this._showTitle = true;
        this._isDragging = false;
        this._isResizing = false;
        this._resizeDirection = '';
        this._isMaximized = false;
        this._isDraggable = true;
        this._isResizable = true;
        this._isMaximizable = true;
        this._resizeTargets = new APanelResizeTargets();
        this.appendChild(this._resizeTargets);
        this._header = new APanelHeader();
        this.appendChild(this._header);
        this._menuIcon = new AFontAwesomeIcon();
        this._menuIcon.value = ['far', 'fa-ellipsis-v'];
        this._header.appendChild(this._menuIcon);
        this._titleText = new AText();
        this._header.appendChild(this._titleText);
        this._headerContents = new AContainer();
        this._header.appendChild(this._headerContents);
        this._panelContents = new APanelContentsContainer();
        this.appendChild(this._panelContents);
    }
    _registerListeners() {
        super._registerListeners();
        this._resizeTargets.ondragstart = () => { return false; };
        this._onMouseDown = this._onMouseDown.bind(this);
        this.addEventListener('mousedown', this._onMouseDown);
        this._onMouseUp = this._onMouseUp.bind(this);
        document.addEventListener('mouseup', this._onMouseUp);
        this._onHeaderMouseDown = this._onHeaderMouseDown.bind(this);
        this._header.addEventListener('mousedown', this._onHeaderMouseDown);
        this._onMenuIconMouseDown = this._onMenuIconMouseDown.bind(this);
        this._menuIcon.addEventListener('mousedown', this._onMenuIconMouseDown);
        this._onMenuIconClicked = this._onMenuIconClicked.bind(this);
        this._menuIcon.addEventListener('click', this._onMenuIconClicked);
        this._onMenuItemSelected = this._onMenuItemSelected.bind(this);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._resizeTargets.ondragstart = null;
        this.removeEventListener('mousedown', this._onMouseDown);
        document.removeEventListener('mouseup', this._onMouseUp);
        this._header.removeEventListener('mousedown', this._onHeaderMouseDown);
        this._menuIcon.removeEventListener('mousedown', this._onMenuIconMouseDown);
        this._menuIcon.removeEventListener('click', this._onMenuIconClicked);
    }
    _render() {
        if (super._render()) {
            this._header.visible = this._showHeader;
            this._menuIcon.visible = this._showHeader && this._showMenu;
            this._titleText.visible = this._showHeader && this._showTitle;
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.doLater(() => {
            let gridArea = window.getComputedStyle(this).getPropertyValue('--grid-area');
            if (gridArea !== '') {
                this.style.gridArea = gridArea;
            }
        });
    }
    _onHeaderMouseDown(event) {
        if (this._isDraggable) {
            this._isDragging = true;
            this.dispatchEvent(new APanelEvent(APanelEvent.DRAG_START, { detail: { pageX: event.pageX, pageY: event.pageY } }));
        }
    }
    _onResizerMouseDown(event, dir) {
        if (this._isResizable) {
            this._isResizing = true;
            this._resizeDirection = dir;
            this.dispatchEvent(new APanelEvent(APanelEvent.RESIZE_START, { detail: { pageX: event.pageX, pageY: event.pageY } }));
        }
    }
    _onMouseDown(event) {
        let element = event.target;
        if (element.nodeName === 'B') {
            this._onResizerMouseDown(event, element.getAttribute('data-direction'));
        }
    }
    _onMouseUp(event) {
        if (this._isDraggable && this._isDragging) {
            this.dispatchEvent(new APanelEvent(APanelEvent.DRAG_END));
            this._isDragging = false;
        }
        else if (this._isResizable && this._isResizing) {
            this.dispatchEvent(new APanelEvent(APanelEvent.RESIZE_END));
            this._isResizing = false;
        }
    }
    _onMenuIconMouseDown(event) {
        event.stopPropagation();
    }
    _onMenuIconClicked(event) {
        event.stopPropagation();
        ASystemManager.instance.showMenu(event.pageX, event.pageY, this._menuData, this._onMenuItemSelected);
    }
    _onMenuItemSelected(item) {
    }
    destroy() {
        super.destroy();
        this._panelGrid = null;
    }
    get panelGrid() {
        return this._panelGrid;
    }
    set panelGrid(p) {
        this._panelGrid = p;
    }
    get menuData() {
        return this._menuData || null;
    }
    set menuData(d) {
        if (this._menuData !== d) {
            this._menuData = d || null;
        }
    }
    get title() {
        return this._titleText.text;
    }
    set title(t) {
        if (this._titleText.text !== t) {
            this._titleText.text = t;
        }
    }
    get showHeader() {
        return this._showHeader;
    }
    set showHeader(s) {
        if (this._showHeader !== s) {
            this._showHeader = s;
            this.invalidate();
        }
    }
    get showMenu() {
        return this._showMenu;
    }
    set showMenu(s) {
        if (this._showMenu !== s) {
            this._showMenu = s;
            this.invalidate();
        }
    }
    get showTitle() {
        return this._showTitle;
    }
    set showTitle(s) {
        if (this._showTitle !== s) {
            this._showTitle = s;
            this.invalidate();
        }
    }
    get isDragging() {
        return this._isDragging;
    }
    get isResizing() {
        return this._isResizing;
    }
    get resizeDirection() {
        return this._resizeDirection;
    }
    get draggable() {
        return this._isDraggable;
    }
    set draggable(d) {
        if (this._isDraggable !== d) {
            this._isDraggable = d;
            if (d) {
                this.removeClass('non-draggable');
            }
            else {
                this.addClass('non-draggable');
            }
        }
    }
    get resizable() {
        return this._isResizable;
    }
    set resizable(r) {
        if (this._isResizable !== r) {
            this._isResizable = r;
            if (r) {
                this.removeClass('non-resizeable');
            }
            else {
                this.addClass('non-resizeable');
            }
        }
    }
    get maximizable() {
        return this._isMaximizable;
    }
    set maximizable(m) {
        if (this._isMaximizable !== m) {
            this._isMaximizable = m;
            if (m) {
                this.removeClass('non-maximizable');
            }
            else {
                this.addClass('non-maximizable');
            }
            if (!m) {
                this.removeClass('maximized');
            }
        }
    }
    get maximized() {
        return this._isMaximized;
    }
    set maximized(m) {
        if (this._isMaximized !== m) {
            this._isMaximized = m;
            if (m) {
                this.addClass('maximized');
            }
            else {
                this.removeClass('maximized');
            }
            this.invalidate();
        }
    }
    get dimensions() {
        let r = new ARectangle();
        r.x = this.offsetLeft;
        r.y = this.offsetTop;
        r.width = this.offsetWidth;
        r.height = this.offsetHeight;
        return r;
    }
}
window.customElements.define('a-panel', APanel);
