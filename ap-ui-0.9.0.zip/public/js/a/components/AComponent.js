import { ARenderManager } from '../managers/ARenderManager.js';
export class AComponent extends HTMLElement {
    constructor() {
        super();
        this._visible = true;
        this._enabled = true;
        this._buildComplete = false;
        this._registerListenersComplete = false;
        this._instantiationComplete = false;
        this._renderIsPending = false;
        this.addClass('instantiating');
        this._build();
    }
    _build() {
        this._visible = true;
        this._enabled = true;
        this.doLater(() => {
            this._buildComplete = true;
            this._registerListeners();
        });
    }
    _registerListeners() {
        this.doLater(() => {
            this._registerListenersComplete = true;
            this._finalizeInstantiation();
        });
    }
    _unregisterListeners() {
    }
    _finalizeInstantiation() {
        this.doLater(() => {
            this._instantiationComplete = true;
            this._render();
            this.removeClass('instantiating');
        });
    }
    _render() {
        this._renderIsPending = false;
        return this._buildComplete && this._registerListenersComplete && this._instantiationComplete;
    }
    invalidate(invalidateChildren = false) {
        if (!this._renderIsPending) {
            this._renderIsPending = true;
            this.doLater(() => {
                this._render();
                if (invalidateChildren) {
                    for (var i = 0; i < this.childNodes.length; i++) {
                        let child = this.childNodes[i];
                        if (child.invalidate) {
                            child.invalidate(invalidateChildren);
                        }
                    }
                }
            });
        }
    }
    doLater(task) {
        ARenderManager.instance.requestAnimationFrame(task);
    }
    appendChildAt(index, child) {
        index = Math.max(0, Math.min(this.childElementCount - 1, index));
        this.insertBefore(child, this.getChildAt(index));
        return child;
    }
    removeChildAt(index) {
        if (index > -1 && index < this.childElementCount) {
            let child = this.childNodes[index];
            if (child) {
                this.removeChild(child);
            }
            return child || null;
        }
    }
    removeAllChildren() {
        let children = this.childNodes;
        for (var i = 0; i < children.length; i++) {
            this.removeChild(children[i]);
        }
    }
    destroy() {
        this._unregisterListeners();
        let children = this.childNodes;
        for (var i = 0; i < children.length; i++) {
            const child = children[i];
            if (child.destroy) {
                child.destroy();
            }
            this.removeChild(child);
        }
    }
    destroyAllChildren() {
        let children = this.childNodes;
        for (var i = 0; i < children.length; i++) {
            const child = children[i];
            if (child.destroy) {
                child.destroy();
            }
            this.removeChild(child);
        }
    }
    hasChild(child) {
        return child && child.parentElement === this;
    }
    getChildAt(i) {
        return this.children[i] || null;
    }
    addClass(className) {
        this.classList.add(className);
    }
    addClasses(...classNames) {
        this.classList.add(...classNames);
    }
    removeClass(className) {
        this.classList.remove(className);
    }
    removeClasses(...classNames) {
        this.classList.remove(...classNames);
    }
    hasClass(className) {
        return this.classList.contains(className);
    }
    get visible() {
        return this._visible;
    }
    set visible(v) {
        this._visible = v;
        if (v) {
            this.classList.remove('invisible');
        }
        else {
            this.classList.add('invisible');
        }
    }
    get enabled() {
        return this._enabled;
    }
    set enabled(e) {
        if (this._enabled !== e) {
            this._enabled = e;
            if (e) {
                this.classList.remove('disabled');
            }
            else {
                this.classList.add('disabled');
            }
        }
    }
    get hasFocus() {
        return document.activeElement === this;
    }
}
window.customElements.define('a-component', AComponent);
