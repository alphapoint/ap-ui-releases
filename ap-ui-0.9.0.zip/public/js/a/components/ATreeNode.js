import { AComponent } from './AComponent.js';
import { AContainer } from './AContainer.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AText } from './AText.js';
export class ATreeNode extends AComponent {
    constructor(id, icon = null, label, actionText = null) {
        super();
        this._id = id;
        this.dataset.id = id;
        this._icon = icon;
        this._label = label;
        this._actionText = actionText;
    }
    _build() {
        super._build();
        this._isSelected = false;
        this._isOpen = false;
        this._node = new AContainer();
        this._node.addClass('node');
        this.appendChild(this._node);
        this._openCloseIcon = new AFontAwesomeIcon();
        this._openCloseIcon.addClass('open-close');
        this._node.appendChild(this._openCloseIcon);
        this._iconIcon = new AFontAwesomeIcon();
        this._iconIcon.addClass('icon');
        this._iconIcon.visible = false;
        this._node.appendChild(this._iconIcon);
        this._labelText = new AText();
        this._labelText.addClass('label');
        this._node.appendChild(this._labelText);
        this._actionTextText = new AText();
        this._actionTextText.addClass('action-text');
        this._actionTextText.visible = false;
        this._node.appendChild(this._actionTextText);
        this._childNodeContainer = new AContainer();
        this._childNodeContainer.addClass('child-nodes');
        this._childNodeContainer.visible = false;
        this.appendChild(this._childNodeContainer);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _render() {
        if (super._render()) {
            this._openCloseIcon.visible = this._childNodeContainer.childElementCount > 0;
            this._openCloseIcon.value = this._isOpen ? ['fas', 'fa-chevron-down'] : ['fas', 'fa-chevron-right'];
            this._iconIcon.visible = this._icon !== null;
            this._iconIcon.value = this._icon;
            this._labelText.text = this._label;
            this._actionTextText.visible = this._actionText !== null;
            this._actionTextText.text = this._actionText;
            if (this._isSelected) {
                if (!this.hasClass('selected')) {
                    this.addClass('selected');
                }
            }
            else {
                if (this.hasClass('selected')) {
                    this.removeClass('selected');
                }
            }
            this._childNodeContainer.visible = this._isOpen && this._childNodeContainer.childElementCount > 0;
            return true;
        }
        else {
            return false;
        }
    }
    addChildTreeNode(treeNode) {
        this._childNodeContainer.appendChild(treeNode);
        this.invalidate();
    }
    removeChildTreeNode(treeNode) {
        this._childNodeContainer.removeChild(treeNode);
        this.invalidate();
    }
    get isSelected() {
        return this._isSelected;
    }
    set isSelected(isSelected) {
        if (this._isSelected !== isSelected) {
            this._isSelected = isSelected;
            this.invalidate();
        }
    }
    get hasChildTreeNodes() {
        return this._childNodeContainer.childElementCount > 0;
    }
    get id() {
        return this._id;
    }
    get isOpen() {
        return this._isOpen;
    }
    set isOpen(i) {
        if (this._isOpen !== i) {
            this._isOpen = i;
            this.invalidate();
        }
    }
    get icon() {
        return this._icon;
    }
    set icon(i) {
        if (this._icon !== i) {
            this._icon = i;
            this.invalidate();
        }
    }
    get label() {
        return this._label;
    }
    set label(l) {
        if (this._label !== l) {
            this._label = l;
            this.invalidate();
        }
    }
    get actionText() {
        return this._actionText;
    }
    set actionText(a) {
        if (this._actionText !== a) {
            this._actionText = a;
            this.invalidate();
        }
    }
}
window.customElements.define('a-tree-node', ATreeNode);
