import { AComponent } from './AComponent.js';
export class AProgressbar extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._progressbar = document.createElement('progress');
        this.appendChild(this._progressbar);
    }
    set value(val) {
        this._progressbar.value = val;
    }
    get type() {
        return this.getAttribute('type');
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
}
window.customElements.define('a-progress-bar', AProgressbar);
