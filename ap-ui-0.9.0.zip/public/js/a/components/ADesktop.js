import { AMenuEvent } from '../events/AMenuEvent.js';
import { AStartMenuEvent, AWindowContainerEvent, ATaskBarEvent } from '../events/index.js';
import { AStartMenu } from './AStartMenu.js';
import { ATaskBar } from './ATaskBar.js';
import { AWindowContainer } from './AWindowContainer.js';
import { AFooter } from './AFooter.js';
import { AApplication } from './AApplication.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AMenu } from './AMenu.js';
export class ADesktop extends AApplication {
    constructor() {
        super();
        this._buildDesktopComplete = false;
        this._registerDesktopListenersComplete = false;
    }
    _build() {
        super._build();
        this._applicationRegistry = new Map();
        this._windowContainer = new AWindowContainer();
        this.appendChild(this._windowContainer);
        this._footer = new AFooter();
        this.appendChild(this._footer);
        this._startMenu = new AStartMenu();
        this._footer.appendChild(this._startMenu);
        this._taskBar = new ATaskBar();
        this._footer.appendChild(this._taskBar);
        this._fullscreenIcon = new AFontAwesomeIcon();
        this._fullscreenIcon.draggable = false;
        this._fullscreenIcon.value = document.fullscreenElement !== null ? ['fal', 'fa-compress-wide'] : ['fal', 'fa-expand-wide'];
        this._fullscreenIcon.title = 'Fullscreen';
        this._footer.appendChild(this._fullscreenIcon);
        this._tileIcon = new AFontAwesomeIcon();
        this._tileIcon.draggable = false;
        this._tileIcon.value = ['fal', 'fa-th-large'];
        this._tileIcon.title = 'Tile Windows';
        this._footer.appendChild(this._tileIcon);
        this._contextMenu = new AMenu();
        this._contextMenu.visible = false;
        this.appendChild(this._contextMenu);
    }
    _registerListeners() {
        super._registerListeners();
        this._onWindowAdded = this._onWindowAdded.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_ADDED, this._onWindowAdded);
        this._onWindowRemoved = this._onWindowRemoved.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_REMOVED, this._onWindowRemoved);
        this._onWindowFocused = this._onWindowFocused.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_FOCUSED, this._onWindowFocused);
        this._onWindowMinimized = this._onWindowMinimized.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_MINIMIZED, this._onWindowMinimized);
        this._onWindowMaximized = this._onWindowMaximized.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_MAXIMIZED, this._onWindowMaximized);
        this._onStartMenuItemClicked = this._onStartMenuItemClicked.bind(this);
        this._startMenu.addEventListener(AStartMenuEvent.ITEM_CLICKED, this._onStartMenuItemClicked);
        this._onTaskBarSelectedWindowChanged = this._onTaskBarSelectedWindowChanged.bind(this);
        this._taskBar.addEventListener(ATaskBarEvent.SELECTED_WINDOW_CHANGED, this._onTaskBarSelectedWindowChanged);
        this._onContextMenuItemClicked = this._onContextMenuItemClicked.bind(this);
        this._contextMenu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onContextMenuItemClicked);
        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);
        this._onFullscreenIconClicked = this._onFullscreenIconClicked.bind(this);
        this._fullscreenIcon.addEventListener('click', this._onFullscreenIconClicked);
        this._onTileIconClicked = this._onTileIconClicked.bind(this);
        this._tileIcon.addEventListener('click', this._onTileIconClicked);
        this._onFullscreenChange = this._onFullscreenChange.bind(this);
        document.addEventListener('fullscreenchange', this._onFullscreenChange);
    }
    _onConfigurationError(event) {
    }
    _onStartMenuItemClicked(event) {
        let menuData = event.detail.menuData;
        let menuDataItem = event.detail.menuDataItem;
    }
    _onTaskBarSelectedWindowChanged(event) {
        if (this._taskBar.selectedWindow.minimizable && !this._taskBar.selectedWindow.minimized && this._taskBar.selectedWindow === this._windowContainer.focusedWindow) {
            this._windowContainer.minimizeWindow(this._taskBar.selectedWindow);
        }
        else {
            this._windowContainer.focusedWindow = this._taskBar.selectedWindow;
        }
    }
    _onWindowAdded(event) {
        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }
    _onWindowRemoved(event) {
        let application = event.detail.contentClass;
        if (this._applicationRegistry.has(application)) {
            this._applicationRegistry.delete(application);
        }
        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }
    _onWindowFocused(event) {
        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }
    _onWindowMinimized(event) {
        if (this._taskBar.selectedWindow === event.detail.window) {
            this._taskBar.selectedWindow = null;
        }
    }
    _onWindowMaximized(event) {
    }
    _onContextMenuItemClicked(event) {
        if (event.detail.menuDataItem.data && event.detail.menuDataItem.data.call !== undefined) {
            event.detail.menuDataItem.data.call();
        }
        this.hideContextMenu();
    }
    _onDocumentMouseDown(event) {
        this.hideContextMenu();
    }
    _onFullscreenIconClicked(event) {
        this._toggleFullscreen();
    }
    _onTileIconClicked(event) {
        this._windowContainer.tileWindows();
    }
    _onFullscreenChange(event) {
        this._fullscreenIcon.value = document.fullscreenElement !== null ? ['fal', 'fa-compress-wide'] : ['fal', 'fa-expand-wide'];
    }
    _onContextMenu(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    _toggleFullscreen() {
        if (!window.document.fullscreenElement) {
            this.requestFullscreen();
        }
        else {
            document.exitFullscreen();
        }
    }
    openWindow(windowContent = null, title = '') {
        if (windowContent !== null) {
            this._windowContainer.addWindow(windowContent, title);
        }
    }
    openApplication(applicationClass = null, title = '') {
        if (applicationClass !== null && !this._applicationRegistry.has(applicationClass)) {
            let application = new applicationClass();
            this._applicationRegistry.set(applicationClass, application);
            this.openWindow(application, title);
            return application;
        }
        else {
            let application = this._applicationRegistry.get(applicationClass);
            this._windowContainer.addWindow(application);
            return application;
        }
    }
    showContextMenu(menuData, x, y) {
        this._contextMenu.data = menuData;
        this._contextMenu.visible = true;
        let menuX = Math.min(x, this.offsetWidth - this._contextMenu.offsetWidth);
        let menuY = Math.min(y, this.offsetWidth - this._contextMenu.offsetWidth);
        this._contextMenu.style.left = `${menuX}px`;
        this._contextMenu.style.top = `${menuY}px`;
    }
    hideContextMenu() {
        this._contextMenu.data = null;
        this._contextMenu.visible = false;
    }
    hasWindowTitle(title) {
        return this._windowContainer.hasWindowTitle(title);
    }
    getWindowByTitle(title) {
        return this._windowContainer.getWindowByTitle(title);
    }
    get focusedWindow() {
        return this._windowContainer.focusedWindow;
    }
    set focusedWindow(win) {
        if (win !== null) {
            this._windowContainer.focusedWindow = win;
        }
    }
    get startIcon() {
        return this._startMenu.startIcon;
    }
    set startIcon(i) {
        this._startMenu.startIcon = i;
    }
    get startMenuData() {
        return this._startMenu.data;
    }
    set startMenuData(d) {
        this._startMenu.data = d;
    }
    get showStartMenu() {
        return this._startMenu.visible;
    }
    set showStartMenu(s) {
        this._startMenu.visible = s;
    }
    get showFullScreen() {
        return this._fullscreenIcon.visible;
    }
    set showFullScreen(s) {
        this._fullscreenIcon.visible = s;
    }
}
window.customElements.define('a-desktop', ADesktop);
