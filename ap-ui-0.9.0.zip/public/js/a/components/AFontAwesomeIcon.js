import { AComponent } from './AComponent.js';
export class AFontAwesomeIcon extends AComponent {
    constructor() {
        super(...arguments);
        this._value = [];
    }
    get value() {
        return this._value;
    }
    set value(v) {
        if (this._value !== v) {
            if (this._value !== null && this._value.length > 0) {
                this.removeClasses(...this._value);
            }
            this._value = v;
            if (this._value !== undefined && this._value !== null) {
                this.addClasses(...this._value);
            }
            else {
                this._value = null;
            }
        }
    }
}
window.customElements.define('a-font-awesome-icon', AFontAwesomeIcon);
