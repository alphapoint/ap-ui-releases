import { AComponent } from './AComponent.js';
export class AContextWidget extends AComponent {
    constructor() {
        super();
    }
    get isViewable() {
        return true;
    }
}
window.customElements.define('a-context-widget', AContextWidget);
