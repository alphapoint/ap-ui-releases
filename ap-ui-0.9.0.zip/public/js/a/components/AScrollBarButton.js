import { AButton } from './AButton.js';
export class AScrollBarButton extends AButton {
    constructor() {
        super();
    }
}
window.customElements.define('a-scroll-bar-button', AScrollBarButton);
