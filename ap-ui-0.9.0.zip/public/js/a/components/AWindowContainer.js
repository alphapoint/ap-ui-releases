import { AContainer } from './AContainer.js';
import { ARectangle } from '../geometry/index.js';
import { AWindow } from './AWindow.js';
import { AWindowEvent, AWindowContainerEvent } from '../events/index.js';
export class AWindowContainer extends AContainer {
    constructor() {
        super();
        this._transformingWindow = null;
        this._transformingWindowStartDimensions = null;
        this._lastWindowDimensions = new ARectangle(11, 11, 640, 320);
        this._focusedWindow = null;
        this._focusOrder = new Set();
        this._pointerDragStartX = 0;
        this._pointerDragStartY = 0;
        this._pointerX = 1;
        this._pointerY = 1;
        this._pointerDragDistanceX = 0;
        this._pointerDragDistanceY = 0;
        this._zIndex = 100;
    }
    _build() {
        super._build();
        this._windowRegistry = new Map();
    }
    _onMouseMove(event) {
        if (this._transformingWindow !== null) {
            this._pointerX = event.pageX;
            this._pointerY = event.pageY;
            this._pointerDragDistanceX = Math.round(this._pointerX - this._pointerDragStartX);
            this._pointerDragDistanceY = Math.round(this._pointerY - this._pointerDragStartY);
            this._transformWindow();
        }
    }
    _registerListeners() {
        super._registerListeners();
        this._onMouseMove = this._onMouseMove.bind(this);
    }
    _registerWindowListeners(window) {
        this._onWindowTransformEnd = this._onWindowTransformEnd.bind(this);
        this._onWindowMouseDown = this._onWindowMouseDown.bind(this);
        window.addEventListener('mousedown', this._onWindowMouseDown);
        this._onWindowMinimizeClicked = this._onWindowMinimizeClicked.bind(this);
        window.addEventListener(AWindowEvent.MINIMIZE_CLICKED, this._onWindowMinimizeClicked);
        this._onWindowMaximizeClicked = this._onWindowMaximizeClicked.bind(this);
        window.addEventListener(AWindowEvent.MAXIMIZE_CLICKED, this._onWindowMaximizeClicked);
        this._onWindowCloseClicked = this._onWindowCloseClicked.bind(this);
        window.addEventListener(AWindowEvent.CLOSE_CLICKED, this._onWindowCloseClicked);
        this._onWindowHeaderDoubleClicked = this._onWindowHeaderDoubleClicked.bind(this);
        window.addEventListener(AWindowEvent.HEADER_DOUBLE_CLICKED, this._onWindowHeaderDoubleClicked);
        this._onWindowDragStart = this._onWindowDragStart.bind(this);
        this._onWindowDragEnd = this._onWindowDragEnd.bind(this);
        window.addEventListener(AWindowEvent.DRAG_START, this._onWindowDragStart);
        window.addEventListener(AWindowEvent.DRAG_END, this._onWindowDragEnd);
        this._onWindowResizeStart = this._onWindowResizeStart.bind(this);
        this._onWindowResizeEnd = this._onWindowResizeEnd.bind(this);
        window.addEventListener(AWindowEvent.RESIZE_START, this._onWindowResizeStart);
        window.addEventListener(AWindowEvent.RESIZE_END, this._onWindowResizeEnd);
    }
    _unregisterWindowListeners(window) {
        window.removeEventListener('mousedown', this._onWindowMouseDown);
        window.removeEventListener(AWindowEvent.MINIMIZE_CLICKED, this._onWindowMinimizeClicked);
        window.removeEventListener(AWindowEvent.MAXIMIZE_CLICKED, this._onWindowMaximizeClicked);
        window.removeEventListener(AWindowEvent.CLOSE_CLICKED, this._onWindowCloseClicked);
        window.removeEventListener(AWindowEvent.HEADER_DOUBLE_CLICKED, this._onWindowHeaderDoubleClicked);
        window.removeEventListener(AWindowEvent.DRAG_START, this._onWindowDragStart);
        window.removeEventListener(AWindowEvent.DRAG_END, this._onWindowDragEnd);
        window.removeEventListener(AWindowEvent.RESIZE_START, this._onWindowResizeStart);
        window.removeEventListener(AWindowEvent.RESIZE_END, this._onWindowResizeEnd);
    }
    _render() {
        if (super._render()) {
            for (var i = 0; i < this.childNodes.length; i++) {
                let win = this.childNodes[i];
                win.focused = this._focusedWindow === win;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onWindowMouseDown(event) {
        let win = event.target.closest('a-window');
        if (win !== null) {
            win.style.zIndex = (this._zIndex++).toString();
        }
        this.focusedWindow = win;
    }
    _onWindowMinimizeClicked(event) {
        this.minimizeWindow(event.target);
    }
    _onWindowMaximizeClicked(event) {
        let win = event.target;
        this.focusedWindow = win;
        this.maximizeWindow(win);
    }
    _onWindowCloseClicked(event) {
        this.removeWindow(event.target);
    }
    _onWindowHeaderDoubleClicked(event) {
        let win = event.target;
        if (win.maximizable) {
            win.maximized = !win.maximized;
        }
    }
    _onWindowDragStart(event) {
        this._onWindowTransformStart(event);
    }
    _onWindowDragEnd(event) {
        this._onWindowTransformEnd(event);
    }
    _onWindowResizeStart(event) {
        this._onWindowTransformStart(event);
    }
    _onWindowResizeEnd(event) {
        this._onWindowTransformEnd(event);
    }
    _onWindowTransformStart(event) {
        window.addEventListener('mousemove', this._onMouseMove);
        let win = event.target;
        this._pointerX = event.detail.pageX;
        this._pointerY = event.detail.pageY;
        this._pointerDragStartX = event.detail.pageX;
        this._pointerDragStartY = event.detail.pageY;
        this._pointerDragDistanceX = 0;
        this._pointerDragDistanceY = 0;
        this._transformingWindow = win;
        this._transformingWindowStartDimensions = win.dimensions;
        win.addClass('transforming');
        win.style.zIndex = (this._zIndex++).toString();
        this._transformWindow();
        this.focusedWindow = win;
        this.addClass('window-transforming');
        this.doLater(() => {
            this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED));
        });
    }
    _onWindowTransformEnd(event) {
        window.removeEventListener('mousemove', this._onMouseMove);
        let win = event.target;
        if (this._transformingWindow === win) {
            this._transformingWindow.removeClasses('transforming', 'maximized', 'outbound');
            this._transformingWindow = null;
            this._transformingWindowStartDimensions = null;
            this.removeClass('window-transforming');
            win.invalidate(true);
        }
    }
    _transformWindow() {
        let win = this._transformingWindow;
        let windowX = this._transformingWindowStartDimensions.x;
        let windowY = this._transformingWindowStartDimensions.y;
        let windowXOffset = 0;
        let windowYOffset = 0;
        let windowWidth = this._transformingWindowStartDimensions.width;
        let windowHeight = this._transformingWindowStartDimensions.height;
        let windowWidthOffset = 0;
        let windowHeightOffset = 0;
        let offsetLeft = this.parentElement.offsetLeft;
        let offsetTop = this.parentElement.offsetTop;
        let offsetWidth = this.offsetWidth;
        let offsetHeight = this.offsetHeight;
        let leftBound = offsetLeft;
        let topBound = offsetTop;
        let rightBound = offsetLeft + offsetWidth;
        let bottomBound = offsetTop + offsetHeight;
        if (win.isDragging) {
            windowXOffset = this._pointerDragDistanceX;
            windowYOffset = this._pointerDragDistanceY;
            if (this._pointerX <= leftBound || this._pointerX >= rightBound || this._pointerY <= topBound || this._pointerY >= bottomBound) {
                win.addClass('outbound');
                leftBound = leftBound + (offsetWidth / 4);
                topBound = topBound + (offsetHeight / 4);
                rightBound = rightBound - (offsetWidth / 4);
                bottomBound = bottomBound - (offsetHeight / 4);
                if (this._pointerX <= leftBound || this._pointerX >= rightBound) {
                    if (this._pointerX <= leftBound) {
                        windowXOffset = -windowX;
                    }
                    else if (this._pointerX >= rightBound) {
                        windowXOffset = (offsetWidth / 2) - windowX;
                    }
                    windowWidthOffset = (offsetWidth / 2) - windowWidth;
                }
                else {
                    windowXOffset = -windowX;
                    windowWidthOffset = offsetWidth - windowWidth;
                }
                if (this._pointerY <= topBound || this._pointerY >= bottomBound) {
                    if (this._pointerY <= topBound) {
                        windowYOffset = -windowY;
                    }
                    else if (this._pointerY >= bottomBound) {
                        windowYOffset = (this.offsetHeight / 2) - windowY;
                    }
                    windowHeightOffset = (offsetHeight / 2) - windowHeight;
                }
                else {
                    windowYOffset = -windowY;
                    windowHeightOffset = offsetHeight - windowHeight;
                }
            }
            else {
                win.removeClass('outbound');
            }
        }
        else if (win.isResizing) {
            let dir = win.resizeDirection;
            if (dir.indexOf('n') > -1) {
                windowYOffset = this._pointerDragDistanceY;
                windowHeightOffset = -this._pointerDragDistanceY;
            }
            if (dir.indexOf('s') > -1) {
                windowHeightOffset = this._pointerDragDistanceY;
            }
            if (dir.indexOf('w') > -1) {
                windowXOffset = this._pointerDragDistanceX;
                windowWidthOffset = -this._pointerDragDistanceX;
            }
            if (dir.indexOf('e') > -1) {
                windowWidthOffset = this._pointerDragDistanceX;
            }
        }
        let newWindowWidth = windowWidth + windowWidthOffset;
        let newWindowHeight = windowHeight + windowHeightOffset;
        let newWindowX = windowX + windowXOffset;
        let newWindowY = windowY + windowYOffset;
        win.style.left = `${newWindowX}px`;
        win.style.top = `${newWindowY}px`;
        win.style.width = `${newWindowWidth}px`;
        win.style.height = `${newWindowHeight}px`;
        this._lastWindowDimensions = new ARectangle(newWindowX, newWindowY, newWindowWidth, newWindowHeight);
        if (win.isResizing || (win.isDragging && win.hasClass('outbound'))) {
            win.querySelectorAll('a-data-grid').forEach((dataGrid) => {
                dataGrid.invalidate();
            });
        }
    }
    _focusWindow(win) {
        if (win.minimized) {
            win.minimized = false;
        }
        this._focusedWindow = win;
        this._focusedWindow.style.zIndex = (this._zIndex++).toString();
        this._focusOrder.add(win);
        this.invalidate();
        this.doLater(() => {
            this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED, { detail: { window: win } }));
        });
    }
    addWindow(component, title = null, cssClass = null, singleInstance = false) {
        if (!this._windowRegistry.has(component)) {
            let win = new AWindow();
            if (cssClass !== null) {
                win.addClass(cssClass);
            }
            win.title = title;
            win.content = component;
            this.appendChild(win);
            this._registerWindowListeners(win);
            this._windowRegistry.set(component, win);
            this._lastWindowDimensions.x += 11;
            this._lastWindowDimensions.y += 11;
            win.style.left = `${this._lastWindowDimensions.x + 11}px`;
            win.style.top = `${this._lastWindowDimensions.y + 11}px`;
            win.style.width = `${this._lastWindowDimensions.width}px`;
            win.style.height = `${this._lastWindowDimensions.height}px`;
            win.style.zIndex = (this._zIndex++).toString();
            this.focusedWindow = win;
            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_ADDED, { detail: { window: win } }));
            });
        }
        else {
            let win = this._windowRegistry.get(component);
            if (title !== null) {
                win.title = title;
            }
            win.style.zIndex = (this._zIndex++).toString();
            this.focusedWindow = win;
            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED, { detail: { window: win } }));
            });
        }
    }
    removeWindow(win) {
        this._windowRegistry.forEach((win, component) => {
            if (event.target === win) {
                this._windowRegistry.delete(component);
                this._unregisterWindowListeners(win);
                win.destroy();
                win.remove();
                this._focusOrder.delete(win);
                if (this._focusedWindow === win) {
                    let wins = Array.from(this._focusOrder.values());
                    this.focusedWindow = wins[wins.length - 1] || null;
                }
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_REMOVED, { detail: { contentClass: component.constructor } }));
            }
        });
    }
    minimizeWindow(win) {
        if (win.minimizable) {
            win.minimized = true;
            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_MINIMIZED, { detail: { window: win } }));
            });
        }
    }
    maximizeWindow(win) {
        if (win.maximizable) {
            win.maximized = !win.maximized;
            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_MAXIMIZED, { detail: { window: win } }));
            });
        }
    }
    hasWindowContent(component) {
        return this._windowRegistry.has(component);
    }
    hasWindowTitle(title) {
        let hasWindow = false;
        this._windowRegistry.forEach((win) => {
            if (win.title === title) {
                hasWindow = true;
            }
        });
        return hasWindow;
    }
    getWindowByTitle(title) {
        let window = null;
        this._windowRegistry.forEach((win) => {
            if (win.title === title) {
                window = win;
            }
        });
        return window;
    }
    invalidateLayout() {
        this.doLater(() => {
            let children = this.childNodes;
            for (var i = 0; i < children.length; i++) {
                const child = children[i];
                child.style.removeProperty('grid-area');
                let gridArea = window.getComputedStyle(child).getPropertyValue('--grid-area');
                if (gridArea !== '') {
                    child.style.gridArea = gridArea;
                }
                child.invalidate(true);
            }
        });
    }
    invalidateWindows() {
        for (let i = 0; i < this.childElementCount; i++) {
            let win = this.getChildAt(i);
            win.invalidate(true);
        }
    }
    tileWindows() {
        let containerWidth = this.offsetWidth;
        let containerHeight = this.offsetHeight;
        let wins = Array.from(this._windowRegistry.values());
        let numberOfWindows = wins.length;
        let winWidth = 0;
        let winHeight = 0;
        let done = false;
        let rows = 1;
        let columns = 1;
        while (!done) {
            winHeight = containerHeight / rows;
            winWidth = winHeight * 1.5;
            if (winWidth * Math.floor(numberOfWindows / rows) <= containerWidth) {
                columns = Math.ceil(numberOfWindows / rows);
                done = true;
            }
            if (rows > 20) {
                done = true;
                return;
            }
            else {
                rows++;
            }
        }
        let winIndex = 0;
        winWidth = containerWidth / columns;
        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < columns; x++) {
                let win = wins[winIndex];
                if (win) {
                    win.style.left = `${x * winWidth}px`;
                    win.style.top = `${y * winHeight}px`;
                    win.style.width = `${winWidth}px`;
                    win.style.height = `${winHeight}px`;
                    winIndex++;
                }
            }
        }
    }
    getNextZIndex() {
        this._zIndex++;
        return this._zIndex;
    }
    get windows() {
        return Array.from(this._windowRegistry.values());
    }
    get focusedWindow() {
        return this._focusedWindow;
    }
    set focusedWindow(win) {
        if (win !== null) {
            this._focusWindow(win);
        }
    }
}
window.customElements.define('a-window-container', AWindowContainer);
