import { AComponent } from './AComponent.js';
import { AText } from './AText.js';
export class ACheckBox extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._checkbox = document.createElement('input');
        this._checkbox.setAttribute('is', 'a-checkbox-input');
        this._checkbox.setAttribute('type', 'checkbox');
        this.appendChild(this._checkbox);
        this._label = new AText();
        this.appendChild(this._label);
    }
    get type() {
        return this.getAttribute('type');
    }
    _registerListeners() {
        super._registerListeners();
        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('click', this._onClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('click', this._onClicked);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _onClicked(event) {
        if (event.target !== this._checkbox) {
            this.checked = !this.checked;
        }
    }
    get checked() {
        return this._checkbox.checked;
    }
    set checked(c) {
        this._checkbox.checked = c;
    }
    get label() {
        return this._label.text;
    }
    set label(l) {
        this._label.text = l;
    }
}
window.customElements.define('a-checkbox', ACheckBox);
