import { AComponent } from './AComponent.js';
export class AScrollBarTrack extends AComponent {
    constructor() {
        super();
    }
}
window.customElements.define('a-scroll-bar-track', AScrollBarTrack);
