import { ADialog } from '../ADialog.js';
import { AText } from '../AText.js';
export class AAlertDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._messageText = new AText();
        this._content.appendChild(this._messageText);
        this.icon = ['fal', 'fa-exclamation'];
        this.showCancel = false;
    }
    get message() {
        return this._messageText.text;
    }
    set message(t) {
        if (this._messageText.text !== t) {
            this._messageText.text = t;
        }
    }
}
window.customElements.define('a-alert-dialog', AAlertDialog);
