import { ADialog } from '../ADialog.js';
import { ATextInput } from '../ATextInput.js';
import { AText } from '../AText.js';
import { ALanguageManager } from '../../managers/ALanguageManager.js';
export class AForgotPasswordDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this.icon = ['fal', 'fa-unlock'];
        this._messageText = new AText();
        this._content.appendChild(this._messageText);
        this._usernameInput = new ATextInput();
        this._content.appendChild(this._usernameInput);
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this.title = lm.get('ForgotPasswordDialog', 'Recover Password');
            this._messageText.text = lm.get('ForgotPasswordDialog', 'Please enter your username to receive an\nemail with password reset instructions');
            this._usernameInput.label = lm.get('ForgotPasswordDialog', 'Username');
            this._okButton.label = lm.get('ForgotPasswordDialog', 'OK');
            this._cancelButton.label = lm.get('ForgotPasswordDialog', 'Cancel');
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._usernameInput.focus();
    }
    get message() {
        return this._messageText.text;
    }
    set message(t) {
        if (this._messageText.text !== t) {
            this._messageText.text = t;
        }
    }
    get usernameLabel() {
        return this._usernameInput.label;
    }
    set usernameLabel(l) {
        this._usernameInput.label = l;
    }
    get usernameInputValue() {
        return this._usernameInput.value;
    }
    set usernameInputValue(v) {
        this._usernameInput.value = v;
    }
}
window.customElements.define('a-forgot-password-dialog', AForgotPasswordDialog);
