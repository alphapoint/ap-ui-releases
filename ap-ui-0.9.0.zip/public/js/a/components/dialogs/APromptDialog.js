import { ADialog } from '../ADialog.js';
import { ATextInput } from '../ATextInput.js';
import { AText } from '../AText.js';
export class APromptDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._messageText = new AText();
        this._content.appendChild(this._messageText);
        this._input = new ATextInput();
        this._content.appendChild(this._input);
        this.icon = ['fal', 'fa-comment-alt-edit'];
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._input.focus();
    }
    get message() {
        return this._messageText.text;
    }
    set message(t) {
        if (this._messageText.text !== t) {
            this._messageText.text = t;
        }
    }
    get inputLabel() {
        return this._input.label;
    }
    set inputLabel(l) {
        this._input.label = l;
    }
    get inputValue() {
        return this._input.value;
    }
    set inputValue(v) {
        this._input.value = v;
    }
}
window.customElements.define('a-prompt-dialog', APromptDialog);
