import { ADialog } from '../ADialog.js';
import { AText } from '../AText.js';
export class ANoticeDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this.icon = ['fal', 'fa-info'];
        this._messageText = new AText();
        this._content.appendChild(this._messageText);
        this.showCancel = false;
    }
    get message() {
        return this._messageText.text;
    }
    set message(t) {
        if (this._messageText.text !== t) {
            this._messageText.text = t;
        }
    }
}
window.customElements.define('a-notice-dialog', ANoticeDialog);
