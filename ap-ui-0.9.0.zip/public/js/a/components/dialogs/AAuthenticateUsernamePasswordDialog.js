import { AText } from '../AText.js';
import { ATextInput } from '../ATextInput.js';
import { ALanguageManager, ASystemManager } from '../../managers/index.js';
import { ADialog } from '../ADialog.js';
export class AAuthenticateUsernamePasswordDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._formIsValid = false;
        this._usernameInput = new ATextInput();
        this._content.appendChild(this._usernameInput);
        this._passwordInput = new ATextInput();
        this._passwordInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordInput);
        this._forgotPasswordText = new AText();
        this._forgotPasswordText.addClass('forgot-password');
        this._content.appendChild(this._forgotPasswordText);
        this._registerText = new AText();
        this._registerText.addClass('register');
        this._content.appendChild(this._registerText);
    }
    _registerListeners() {
        super._registerListeners();
        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);
        this._forgotPasswordClicked = this._forgotPasswordClicked.bind(this);
        this._forgotPasswordText.addEventListener('click', this._forgotPasswordClicked);
        this._registerClicked = this._registerClicked.bind(this);
        this._registerText.addEventListener('click', this._registerClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('input', this._onInput);
        this._forgotPasswordText.removeEventListener('click', this._forgotPasswordClicked);
        this._registerText.removeEventListener('click', this._registerClicked);
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._usernameInput.focus();
        this._usernameInput.select();
        this._okButton.enabled = false;
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this.title = lm.get('AuthenticateDialog', 'Authenticate');
            this._usernameInput.label = lm.get('AuthenticateDialog', 'Username');
            this._passwordInput.label = lm.get('AuthenticateDialog', 'Password');
            this._forgotPasswordText.text = lm.get('AuthenticateDialog', 'Forgot password?');
            this._registerText.text = lm.get('AuthenticateDialog', 'Register');
            this._okButton.label = lm.get('AuthenticateDialog', 'OK');
            this._cancelButton.label = lm.get('AuthenticateDialog', 'Cancel');
            this._registerText.visible = ASystemManager.instance.AllowRegistration;
            this._okButton.enabled = this._formIsValid;
            return true;
        }
        else {
            return false;
        }
    }
    _onInput(event) {
        if (this._usernameInput.value.length > 0 && this._passwordInput.value.length > 0) {
            this._formIsValid = true;
        }
        else {
            this._formIsValid = false;
        }
        this.invalidate();
        return true;
    }
    _forgotPasswordClicked(event) {
        let sm = ASystemManager.instance;
        if (sm.ForgotPasswordOverride) {
            sm.ForgotPasswordOverride();
        }
        else {
            sm.showForgotPasswordDialog();
        }
    }
    _registerClicked() {
        let sm = ASystemManager.instance;
        if (sm.RegisterOverride) {
            sm.RegisterOverride();
        }
        else {
            sm.showRegisterDialog();
        }
    }
    get usernameLabel() {
        return this._usernameInput.label;
    }
    set usernameLabel(l) {
        this._usernameInput.label = l;
    }
    get usernameInputValue() {
        return this._usernameInput.value;
    }
    set usernameInputValue(v) {
        this._usernameInput.value = v;
    }
    get passwordLabel() {
        return this._passwordInput.label;
    }
    set passwordLabel(l) {
        this._passwordInput.label = l;
    }
    get passwordInputValue() {
        return this._passwordInput.value;
    }
    set passwordInputValue(v) {
        this._passwordInput.value = v;
    }
}
window.customElements.define('a-authenticate-username-password-dialog', AAuthenticateUsernamePasswordDialog);
