import { ADialog } from '../ADialog.js';
import { AText } from '../AText.js';
import { AQRCode, ATextInput } from '../index.js';
export class ASetupTwoFADialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this.title = '2FA Setup';
        this._formIsValid = false;
        this._qrData = null;
        let instruction = new AText();
        instruction.text = `1. Download a Two-Factor Authentication app to\nyour phone such as Authy or Google Authenticator.\n
        2. Use the app to scan QR code.\n
        3. Type in code from your phone.`;
        this._content.appendChild(instruction);
        this._qrCode = new AQRCode();
        this._content.appendChild(this._qrCode);
        this._twoFAInput = new ATextInput();
        this._twoFAInput.label = '2FA Code';
        this._content.appendChild(this._twoFAInput);
    }
    _registerListeners() {
        super._registerListeners();
        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('input', this._onInput);
    }
    _render() {
        if (super._render()) {
            this._okButton.enabled = this._formIsValid;
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._twoFAInput.focus();
        this._twoFAInput.select();
        this._okButton.enabled = false;
    }
    _onInput(event) {
        if (this._twoFAInput.value.length > 0) {
            this._formIsValid = true;
        }
        else {
            this._formIsValid = false;
        }
        this.invalidate();
    }
    get qrData() {
        return this._qrData;
    }
    set qrData(c) {
        if (this._qrData !== c) {
            this._qrData = c;
            this._qrCode.data = this._qrData;
        }
    }
    get twoFACodeInputValue() {
        return this._twoFAInput.value;
    }
    set twoFACodeInputValue(v) {
        this._twoFAInput.value = v;
    }
}
window.customElements.define('a-setup-twofa-dialog', ASetupTwoFADialog);
