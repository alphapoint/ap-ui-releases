import { ADialog } from '../ADialog.js';
import { AText } from '../AText.js';
export class AConfirmDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this.icon = ['fal', 'fa-question'];
        this._messageText = new AText();
        this._content.appendChild(this._messageText);
        this.okLabel = 'Yes';
        this.cancelLabel = 'No';
    }
    get message() {
        return this._messageText.text;
    }
    set message(t) {
        if (this._messageText.text !== t) {
            this._messageText.text = t;
        }
    }
}
window.customElements.define('a-confirm-dialog', AConfirmDialog);
