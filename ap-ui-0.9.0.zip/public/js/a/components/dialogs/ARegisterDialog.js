import { ATextInput } from '../ATextInput.js';
import { ALanguageManager } from '../../managers/index.js';
import { ADialog } from '../ADialog.js';
export class ARegisterDialog extends ADialog {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._formIsValid = false;
        this._usernameInput = new ATextInput();
        this._content.appendChild(this._usernameInput);
        this._emailInput = new ATextInput();
        this._emailInput.type = ATextInput.EMAIL;
        this._content.appendChild(this._emailInput);
        this._passwordInput = new ATextInput();
        this._passwordInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordInput);
        this._passwordTwoInput = new ATextInput();
        this._passwordTwoInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordTwoInput);
    }
    _registerListeners() {
        super._registerListeners();
        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('input', this._onInput);
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._usernameInput.focus();
        this._usernameInput.select();
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this.title = lm.get('RegisterDialog', 'Register');
            this._usernameInput.label = lm.get('RegisterDialog', 'Username');
            this._emailInput.label = lm.get('RegisterDialog', 'Email');
            this._passwordInput.label = lm.get('RegisterDialog', 'Password');
            this._passwordTwoInput.label = lm.get('RegisterDialog', 'Re-type Password');
            this._okButton.label = lm.get('RegisterDialog', 'OK');
            this._cancelButton.label = lm.get('RegisterDialog', 'Cancel');
            this._okButton.enabled = this._formIsValid;
            return true;
        }
        else {
            return false;
        }
    }
    _onInput(event) {
        if (this._usernameInput.value.length > 0 && this._emailInput.value.match(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) && this._passwordInput.value.length > 0 && this._passwordInput.value === this._passwordTwoInput.value) {
            this._formIsValid = true;
        }
        else {
            this._formIsValid = false;
        }
        this.invalidate();
    }
    get usernameLabel() {
        return this._usernameInput.label;
    }
    set usernameLabel(l) {
        this._usernameInput.label = l;
    }
    get usernameInputValue() {
        return this._usernameInput.value;
    }
    set usernameInputValue(v) {
        this._usernameInput.value = v;
    }
    get emailLabel() {
        return this._emailInput.label;
    }
    set emailLabel(l) {
        this._emailInput.label = l;
    }
    get emailInputValue() {
        return this._emailInput.value;
    }
    set emailInputValue(v) {
        this._emailInput.value = v;
    }
    get passwordLabel() {
        return this._passwordInput.label;
    }
    set passwordLabel(l) {
        this._passwordInput.label = l;
    }
    get passwordInputValue() {
        return this._passwordInput.value;
    }
    set passwordInputValue(v) {
        this._passwordInput.value = v;
    }
    get passwordTwoLabel() {
        return this._passwordTwoInput.label;
    }
    set passwordTwoLabel(l) {
        this._passwordTwoInput.label = l;
    }
    get passwordTwoInputValue() {
        return this._passwordTwoInput.value;
    }
    set passwordTwoInputValue(v) {
        this._passwordTwoInput.value = v;
    }
}
window.customElements.define('a-register-dialog', ARegisterDialog);
