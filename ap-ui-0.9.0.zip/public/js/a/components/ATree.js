import { ATreeEvent } from '../events/ATreeEvent.js';
import { AContainer } from './AContainer.js';
export class ATree extends AContainer {
    constructor() {
        super();
        this._selectable = false;
    }
    _build() {
        super._build();
    }
    _registerListeners() {
        super._registerListeners();
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
        this._onDoubleClick = this._onDoubleClick.bind(this);
        this.addEventListener('dblclick', this._onDoubleClick);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('click', this._onClick);
        this.removeEventListener('dblclick', this._onDoubleClick);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _onClick(event) {
        let target = event.target;
        let treeNode = event.target.closest('a-tree-node');
        if (treeNode) {
            if (target.hasClass('open-close')) {
                if (!treeNode.isOpen) {
                    treeNode.isOpen = true;
                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_OPENED, { bubbles: true, detail: { treeNode: treeNode } }));
                }
                else {
                    treeNode.isOpen = false;
                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLOSED, { bubbles: true, detail: { treeNode: treeNode } }));
                }
            }
            else if (target.hasClass('action-text')) {
                this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_ACTION, { bubbles: true, detail: { treeNode: treeNode } }));
            }
            else if (!target.hasClass('child-nodes')) {
                this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLICKED, { bubbles: true, detail: { treeNode: treeNode } }));
                if (this._selectable) {
                    this.invalidate();
                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_SELECTED, { bubbles: true, detail: { treeNode: treeNode } }));
                }
            }
        }
    }
    _onDoubleClick(event) {
        let target = event.target;
        let treeNode = target.closest('a-tree-node');
        if (treeNode) {
            if (!target.hasClass('open-close') && !target.hasClass('action-text') && !target.hasClass('child-nodes')) {
                if (!treeNode.hasChildTreeNodes) {
                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_DOUBLE_CLICKED, { bubbles: true, detail: { treeNode: treeNode } }));
                }
                else {
                    if (!treeNode.isOpen) {
                        treeNode.isOpen = true;
                        this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_OPENED, { bubbles: true, detail: { treeNode: treeNode } }));
                    }
                    else {
                        treeNode.isOpen = false;
                        this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLOSED, { bubbles: true, detail: { treeNode: treeNode } }));
                    }
                }
            }
        }
    }
    addChildTreeNode(treeNode) {
        this.appendChild(treeNode);
    }
    removeChildTreeNode(treeNode) {
        this.removeChild(treeNode);
    }
    getTreeNodeByID(id) {
        let treeNode = this.querySelector(`a-tree-node[data-id='${id}']`);
        return treeNode || null;
    }
    get selectable() {
        return this._selectable;
    }
    set selectable(s) {
        if (this._selectable !== s) {
            this._selectable = s;
            this.invalidate();
        }
    }
    get hasChildTreeNodes() {
        return this.childElementCount > 0;
    }
}
window.customElements.define('a-tree', ATree);
