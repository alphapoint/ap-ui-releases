import { AContainer } from './AContainer.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AWindowEvent } from '../events/AWindowEvent.js';
import { AWindowResizeTargets } from './AWindowResizeTargets.js';
import { AWindowHeader } from './AWindowHeader.js';
import { AMenuBar } from './AMenuBar.js';
import { AMenuEvent } from '../events/index.js';
import { ARectangle } from '../geometry/index.js';
export class AWindow extends AContainer {
    constructor() {
        super();
        this._isDragging = false;
        this._isResizing = false;
        this._resizeDirection = '';
        this._isMaximized = false;
        this._isMinimized = false;
        this._isFocused = false;
        this._isDraggable = true;
        this._isResizable = true;
        this._isMaximizable = true;
        this._isMinimizable = true;
    }
    _build() {
        super._build();
        this.appendChild(new AWindowResizeTargets());
        this._header = new AWindowHeader();
        this.appendChild(this._header);
        this._menuBar = new AMenuBar();
        this._menuBar.visible = false;
        this._header.appendChild(this._menuBar);
        let iconTitleContainer = new AContainer();
        iconTitleContainer.addClass('icon-title');
        this._header.appendChild(iconTitleContainer);
        this._icon = new AFontAwesomeIcon();
        iconTitleContainer.appendChild(this._icon);
        this._title = new AText();
        iconTitleContainer.appendChild(this._title);
        let windowControlsContainer = new AContainer();
        windowControlsContainer.addClass('window-controls');
        this._header.appendChild(windowControlsContainer);
        this._minimize = new AFontAwesomeIcon();
        this._minimize.addClass('minimize');
        this._minimize.value = ['fal', 'fa-window-minimize'];
        windowControlsContainer.appendChild(this._minimize);
        this._maximize = new AFontAwesomeIcon();
        this._maximize.addClass('maximize');
        this._maximize.value = ['fal', 'fa-window-maximize'];
        windowControlsContainer.appendChild(this._maximize);
        this._close = new AFontAwesomeIcon();
        this._close.addClass('close');
        this._close.value = ['fal', 'fa-times'];
        windowControlsContainer.appendChild(this._close);
    }
    _registerListeners() {
        super._registerListeners();
        this._onMouseDown = this._onMouseDown.bind(this);
        this.addEventListener('mousedown', this._onMouseDown);
        this._onMouseUp = this._onMouseUp.bind(this);
        document.addEventListener('mouseup', this._onMouseUp);
        this._onHeaderMouseDown = this._onHeaderMouseDown.bind(this);
        this._header.addEventListener('mousedown', this._onHeaderMouseDown);
        this._onHeaderDoubleClick = this._onHeaderDoubleClick.bind(this);
        this._header.addEventListener('dblclick', this._onHeaderDoubleClick);
        this._onMinimizeMouseDown = this._onMinimizeMouseDown.bind(this);
        this._minimize.addEventListener('mousedown', this._onMinimizeMouseDown);
        this._onMinimizeClicked = this._onMinimizeClicked.bind(this);
        this._minimize.addEventListener('click', this._onMinimizeClicked);
        this._onMaximizeMouseDown = this._onMaximizeMouseDown.bind(this);
        this._maximize.addEventListener('mousedown', this._onMaximizeMouseDown);
        this._onMaximizeClicked = this._onMaximizeClicked.bind(this);
        this._maximize.addEventListener('click', this._onMaximizeClicked);
        this._onCloseMouseDown = this._onCloseMouseDown.bind(this);
        this._close.addEventListener('mousedown', this._onCloseMouseDown);
        this._onCloseClicked = this._onCloseClicked.bind(this);
        this._close.addEventListener('click', this._onCloseClicked);
        this._onTransitionEnd = this._onTransitionEnd.bind(this);
        this.addEventListener('transitionend', this._onTransitionEnd);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this.removeEventListener('mousedown', this._onMouseDown);
        document.removeEventListener('mouseup', this._onMouseUp);
        this._header.removeEventListener('mousedown', this._onHeaderMouseDown);
        this._header.removeEventListener('dblclick', this._onHeaderDoubleClick);
        this._minimize.removeEventListener('mousedown', this._onMinimizeMouseDown);
        this._minimize.removeEventListener('click', this._onMinimizeClicked);
        this._maximize.removeEventListener('mousedown', this._onMaximizeMouseDown);
        this._maximize.removeEventListener('click', this._onMaximizeClicked);
        this._close.removeEventListener('mousedown', this._onCloseMouseDown);
        this._close.removeEventListener('click', this._onCloseClicked);
        this.removeEventListener('transitionend', this._onTransitionEnd);
        this.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
    }
    _render() {
        if (super._render()) {
            this._maximize.value = this._isMaximized ? ['fal', 'fa-window-restore'] : ['fal', 'fa-window-maximize'];
            if (this._content) {
                if (this._content.icon) {
                    this._icon.value = this._content.icon;
                }
                this._content.invalidate();
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onHeaderMouseDown(event) {
        if (this._isDraggable && !this._isMaximized) {
            this._isDragging = true;
            this.addClass('dragging');
            this.dispatchEvent(new AWindowEvent(AWindowEvent.DRAG_START, { detail: { pageX: event.pageX, pageY: event.pageY, clientX: event.clientX, clientY: event.clientY } }));
        }
    }
    _onHeaderDoubleClick(event) {
        this.dispatchEvent(new AWindowEvent(AWindowEvent.HEADER_DOUBLE_CLICKED));
    }
    _onMinimizeMouseDown(event) {
        event.stopPropagation();
    }
    _onMinimizeClicked(event) {
        event.stopPropagation();
        this.dispatchEvent(new AWindowEvent(AWindowEvent.MINIMIZE_CLICKED));
    }
    _onMaximizeMouseDown(event) {
        event.stopPropagation();
    }
    _onMaximizeClicked(event) {
        event.stopPropagation();
        this.dispatchEvent(new AWindowEvent(AWindowEvent.MAXIMIZE_CLICKED));
    }
    _onCloseMouseDown(event) {
        event.stopPropagation();
    }
    _onCloseClicked(event) {
        event.stopPropagation();
        this.dispatchEvent(new AWindowEvent(AWindowEvent.CLOSE_CLICKED));
    }
    _onResizerMouseDown(event, dir) {
        if (this._isResizable && !this._isMaximized) {
            this._isResizing = true;
            this._resizeDirection = dir;
            this.addClass('resizing');
            this.dispatchEvent(new AWindowEvent(AWindowEvent.RESIZE_START, { detail: { pageX: event.pageX, pageY: event.pageY, clientX: event.clientX, clientY: event.clientY } }));
        }
    }
    _onMouseDown(event) {
        let element = event.target;
        if (element.nodeName === 'B') {
            this._onResizerMouseDown(event, element.getAttribute('data-direction'));
        }
    }
    _onMouseUp(event) {
        if (this._isDraggable && this._isDragging) {
            this.dispatchEvent(new AWindowEvent(AWindowEvent.DRAG_END));
            this._isDragging = false;
        }
        else if (this._isResizable && this._isResizing) {
            this.dispatchEvent(new AWindowEvent(AWindowEvent.RESIZE_END));
            this._isResizing = false;
        }
        this.removeClasses('dragging', 'resizing');
    }
    _onTransitionEnd(event) {
        this.doLater(() => {
            for (let grid of this.getElementsByTagName('a-data-grid')) {
                grid.invalidate();
            }
        });
    }
    _onMenuItemClicked(event) {
        if (this.content && this.content.handleMenuItemClick) {
            this.content.handleMenuItemClick(event);
        }
    }
    get icon() {
        return this._content.icon || [];
    }
    get menuData() {
        return this._menuBar.data;
    }
    set menuData(m) {
        if (m !== null) {
            this._menuBar.data = m;
            this._menuBar.visible = true;
        }
        else {
            this._menuBar.visible = false;
        }
    }
    get title() {
        return this._title.text;
    }
    set title(t) {
        if (this._title) {
            if (this._title.text !== t) {
                this._title.text = t;
            }
        }
    }
    get content() {
        return this._content;
    }
    set content(component) {
        if (this._content !== component && !this.hasChild(component)) {
            if (this._content !== null && this.hasChild(this._content)) {
                this.removeChild(this._content);
            }
            this._content = component;
            this._content.window = this;
            this.menuData = this._content.menuData;
            this.appendChild(this._content);
        }
    }
    get isDragging() {
        return this._isDragging;
    }
    get isResizing() {
        return this._isResizing;
    }
    get resizeDirection() {
        return this._resizeDirection;
    }
    get draggable() {
        return this._isDraggable;
    }
    set draggable(d) {
        if (this._isDraggable !== d) {
            this._isDraggable = d;
            if (d) {
                this.removeClass('non-draggable');
            }
            else {
                this.addClass('non-draggable');
            }
        }
    }
    get resizable() {
        return this._isResizable;
    }
    set resizable(r) {
        if (this._isResizable !== r) {
            this._isResizable = r;
            if (r) {
                this.removeClass('non-resizeable');
            }
            else {
                this.addClass('non-resizeable');
            }
        }
    }
    get minimizable() {
        return this._isMinimizable;
    }
    set minimizable(m) {
        if (this._isMinimizable !== m) {
            this._isMinimizable = m;
            if (m) {
                this.removeClass('non-minimizable');
            }
            else {
                this.addClass('non-minimizable');
            }
            if (!m) {
                this.removeClass('minimized');
            }
        }
    }
    get minimized() {
        return this._isMinimized;
    }
    set minimized(m) {
        if (this._isMinimized !== m) {
            this._isMinimized = m;
            if (m) {
                this.addClass('minimized');
            }
            else {
                this.removeClass('minimized');
            }
            this.invalidate();
        }
    }
    get maximizable() {
        return this._isMaximizable;
    }
    set maximizable(m) {
        if (this._isMaximizable !== m) {
            this._isMaximizable = m;
            if (m) {
                this.removeClass('non-maximizable');
            }
            else {
                this.addClass('non-maximizable');
            }
            if (!m) {
                this.removeClass('maximized');
            }
        }
    }
    get maximized() {
        return this._isMaximized;
    }
    set maximized(m) {
        if (this._isMaximized !== m) {
            this._isMaximized = m;
            if (m) {
                this.addClass('maximized');
            }
            else {
                this.removeClass('maximized');
            }
            this.invalidate();
        }
    }
    get focused() {
        return this._isFocused;
    }
    set focused(f) {
        if (f) {
            this.addClass('focused');
        }
        else {
            this.removeClass('focused');
        }
    }
    get dimensions() {
        let r = new ARectangle();
        r.x = this.offsetLeft;
        r.y = this.offsetTop;
        r.width = this.offsetWidth;
        r.height = this.offsetHeight;
        return r;
    }
}
window.customElements.define('a-window', AWindow);
