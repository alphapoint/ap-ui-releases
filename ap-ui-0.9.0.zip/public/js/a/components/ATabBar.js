import { AContainer } from './AContainer.js';
import { ATabBarEvent } from '../events/ATabBarEvent.js';
import { AButton } from './AButton.js';
export class ATabBar extends AContainer {
    constructor() {
        super();
        this._labels = [];
        this._icons = [];
        this._selectedIndex = 0;
    }
    _build() {
        super._build();
    }
    _registerListeners() {
        super._registerListeners();
        this._onMouseOver = this._onMouseOver.bind(this);
        this.addEventListener('mouseover', this._onMouseOver);
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }
    _render() {
        if (super._render()) {
            let count = Math.max(this._labels.length, this._icons.length);
            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                }
                else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }
            for (let i = 0; i < count; i++) {
                let button = this.getChildAt(i);
                button.setAttribute('data-index', i.toString());
                button.icon = this._icons[i];
                button.label = this._labels[i];
                if (this._selectedIndex !== null && this._selectedIndex === i) {
                    button.addClass('selected');
                }
                else {
                    button.removeClass('selected');
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _setSelectedIndex(index) {
        if (this._selectedIndex !== index && index > -1 && index < this._labels.length) {
            this._selectedIndex = index;
        }
        else if (index === null) {
            this._selectedIndex = null;
        }
        this.invalidate();
    }
    _onMouseOver(event) {
        if (event.target.constructor === AButton) {
            this._onButtonHover(event.target);
        }
    }
    _onClick(event) {
        if (event.target.constructor === AButton) {
            this._onButtonClick(event.target);
        }
    }
    _onButtonClick(button) {
        this._setSelectedIndex(Number(button.getAttribute('data-index')));
        this.dispatchEvent(new ATabBarEvent(ATabBarEvent.SELECTED_INDEX_CHANGE));
    }
    _onButtonHover(element) {
        this.dispatchEvent(new ATabBarEvent(ATabBarEvent.TAB_HOVER, { detail: { index: Number(element.getAttribute('data-index')) } }));
    }
    get icons() {
        return this._icons;
    }
    set icons(d) {
        if (this._icons !== d) {
            this._icons = d || [];
            this.invalidate();
        }
    }
    get labels() {
        return this._labels;
    }
    set labels(d) {
        if (this._labels !== d) {
            this._labels = d || [];
            this.invalidate();
        }
    }
    get selectedIndex() {
        return this._selectedIndex;
    }
    set selectedIndex(i) {
        this._setSelectedIndex(i);
    }
}
window.customElements.define('a-tab-bar', ATabBar);
