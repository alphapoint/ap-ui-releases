import { AComponent } from './AComponent.js';
import { ADataGridRowItem } from './ADataGridRowItem.js';
export class ADataGridRow extends AComponent {
    constructor() {
        super();
        this._index = null;
        this._order = null;
        this._data = null;
        this._selected = false;
    }
    _build() {
        super._build();
        this._updateRowItem = this._updateRowItem.bind(this);
    }
    _render() {
        if (super._render()) {
            if (this._data !== null) {
                while (this.childElementCount !== this._data.length) {
                    if (this.childElementCount < this._data.length) {
                        let item = new ADataGridRowItem();
                        this.appendChild(item);
                    }
                    else if (this.childElementCount > this._data.length) {
                        this.removeChildAt(this.childElementCount - 1);
                    }
                }
                this._data.forEach(this._updateRowItem);
            }
            return true;
        }
        else {
            return false;
        }
    }
    _updateRowItem(itemData, index) {
        itemData = String(itemData);
        let rowItem = this.getChildAt(index);
        if (rowItem !== null) {
            if (rowItem.innerHTML !== itemData) {
                rowItem.innerHTML = itemData;
                rowItem.title = itemData;
            }
        }
    }
    get index() {
        return this._index;
    }
    set index(i) {
        if (this._index !== i) {
            this._index = i;
        }
    }
    get order() {
        return this._order;
    }
    set order(o) {
        if (this._order !== o) {
            this._order = o;
            this.style.order = o.toString();
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || [];
            this.invalidate();
        }
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        if (this._selected !== s) {
            this._selected = s;
            if (s) {
                this.addClass('selected');
            }
            else {
                this.removeClass('selected');
            }
        }
    }
}
window.customElements.define('a-data-grid-row', ADataGridRow);
