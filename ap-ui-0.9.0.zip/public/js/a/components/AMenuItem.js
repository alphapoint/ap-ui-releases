import { AComponent } from './AComponent.js';
import { AMenuDataItem } from '../data/AMenuDataItem.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AMenuDataDividerItem } from '../data/AMenuDataDividerItem.js';
import { AMenuDataLabelItem } from '../data/index.js';
export class AMenuItem extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._data = null;
        this._faIcon = new AFontAwesomeIcon();
        this.appendChild(this._faIcon);
        this._text = new AText();
        this.appendChild(this._text);
    }
    _render() {
        if (super._render()) {
            if (this._data) {
                if (this._data.constructor === AMenuDataItem) {
                    if (this._data.icon === null) {
                        this._faIcon.visible = false;
                    }
                    else if (this._data.icon.constructor === Array) {
                        this._faIcon.visible = true;
                        this._faIcon.value = this._data.icon;
                    }
                    this._text.visible = true;
                    this._text.text = this._data.label;
                    this.enabled = this._data.enabled;
                    this.removeClasses('is-divider', 'is-label');
                }
                else if (this._data.constructor === AMenuDataDividerItem) {
                    this._faIcon.visible = false;
                    this._text.visible = false;
                    this.removeClass('is-label');
                    this.addClass('is-divider');
                }
                else if (this._data.constructor === AMenuDataLabelItem) {
                    this._faIcon.visible = false;
                    this._text.visible = true;
                    this._text.text = this._data.label;
                    this.removeClass('is-divider');
                    this.addClass('is-label');
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d || null;
            this._render();
        }
    }
    get isDivider() {
        return this._data.constructor === AMenuDataDividerItem;
    }
}
window.customElements.define('a-menu-item', AMenuItem);
