import { AButton } from './AButton.js';
export class AScrollBarHandle extends AButton {
    constructor() {
        super();
    }
}
window.customElements.define('a-scroll-bar-handle', AScrollBarHandle);
