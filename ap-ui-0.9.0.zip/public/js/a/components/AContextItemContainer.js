import { AMenuData } from '../data/index.js';
import { AMenuEvent } from '../events/index.js';
import { AContainer } from './AContainer.js';
import { AMenu } from './AMenu.js';
export var ContextItemType;
(function (ContextItemType) {
    ContextItemType["MENU"] = "MENU";
    ContextItemType["WIDGET"] = "WIDGET";
})(ContextItemType || (ContextItemType = {}));
export class AContextItemContainer extends AContainer {
    constructor() {
        super();
        this._contextItemRegistrations = new Map();
        this._currentContextItemRegistration = null;
    }
    _build() {
        super._build();
        this._menu = new AMenu();
        this.appendChild(this._menu);
    }
    _registerListeners() {
        super._registerListeners();
        this._onContextMenu = this._onContextMenu.bind(this);
        document.oncontextmenu = this._onContextMenu;
        this._onMouseDown = this._onMouseDown.bind(this);
        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);
        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        document.removeEventListener('mousedown', this._onMouseDown);
        document.removeEventListener('keydown', this._onKeyDown);
        this._menu.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
    }
    _render() {
        if (super._render()) {
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.visible = false;
    }
    _onContextMenu(event) {
        if (event.target.closest('a-system-context-item-container') === this) {
            return false;
        }
        this._menu.visible = false;
        this._contextItemRegistrations.forEach((contextRegistration) => {
            if (contextRegistration.type === ContextItemType.WIDGET) {
                contextRegistration.contextWidget.visible = false;
            }
        });
        let component = event.target;
        let hasRegistration = false;
        while (component.parentElement && component.parentElement !== document.body) {
            if (this._contextItemRegistrations.has(component)) {
                hasRegistration = true;
                break;
            }
            else {
                component = component.parentElement;
            }
        }
        if (hasRegistration) {
            event.preventDefault();
            event.stopPropagation();
            this._handleContextItem(component, event.clientX, event.clientY);
            return false;
        }
        else {
            this.dismiss();
            return true;
        }
    }
    _handleContextItem(component, x, y) {
        this._currentContextItemRegistration = this._contextItemRegistrations.get(component);
        this.visible = true;
        let contextItem = null;
        if (this._currentContextItemRegistration.type === ContextItemType.MENU && this._currentContextItemRegistration.menuData && this._currentContextItemRegistration.menuData.items.length > 0) {
            this._menu.data = this._currentContextItemRegistration.menuData || new AMenuData();
            contextItem = this._menu;
        }
        else if (this._currentContextItemRegistration.type === ContextItemType.WIDGET && this._currentContextItemRegistration.contextWidget.isViewable) {
            this._currentContextItemRegistration.contextWidget.invalidate();
            contextItem = this._currentContextItemRegistration.contextWidget;
        }
        else {
            this.dismiss();
            return;
        }
        contextItem.visible = true;
        contextItem.style.left = `${x}px`;
        contextItem.style.top = `${y}px`;
        contextItem.invalidate();
        this.doLater(() => {
            let contextItemWidth = contextItem.offsetWidth;
            let contextItemHeight = contextItem.offsetHeight;
            if (x + contextItemWidth > this.offsetWidth) {
                contextItem.style.left = `${x - contextItemWidth}px`;
            }
            if (y + contextItemHeight > this.offsetHeight) {
                contextItem.style.top = `${y - contextItemHeight}px`;
            }
        });
        document.addEventListener('mousedown', this._onMouseDown);
    }
    _onMouseDown(event) {
        if (event.target.closest('a-context-item-container') !== this) {
            this.dismiss();
        }
    }
    _onKeyDown(event) {
        if (event.key === 'Escape' && this._menu !== null) {
            this.dismiss();
        }
    }
    _onMenuItemClicked(event) {
        if (this._currentContextItemRegistration !== null) {
            if (this._currentContextItemRegistration.selectedCallback) {
                this._currentContextItemRegistration.selectedCallback(event.detail.menuDataItem);
            }
        }
        else if (this._singleMenuSelectedCallback) {
            this._singleMenuSelectedCallback(event.detail.menuDataItem);
        }
        this.dismiss();
    }
    dismiss() {
        this.visible = false;
        this._menu.visible = false;
        this._contextItemRegistrations.forEach((contextRegistration) => {
            if (contextRegistration.type === ContextItemType.WIDGET) {
                contextRegistration.contextWidget.visible = false;
            }
        });
        this._currentContextItemRegistration = null;
        this._singleMenuSelectedCallback = null;
        document.removeEventListener('mousedown', this._onMouseDown);
    }
    showMenu(x, y, menuData = null, selectedCallback = null) {
        if (menuData && selectedCallback) {
            this._singleMenuSelectedCallback = selectedCallback;
            this.visible = true;
            this._menu.data = menuData;
            this._menu.visible = true;
            this._menu.style.left = `${x}px`;
            this._menu.style.top = `${y}px`;
            this._menu.invalidate();
            document.addEventListener('mousedown', this._onMouseDown);
        }
    }
    registerContextMenu(targetComponent, menuData, selectedCallback = null) {
        this._contextItemRegistrations.set(targetComponent, {
            type: ContextItemType.MENU,
            targetComponent: targetComponent,
            menuData: menuData,
            selectedCallback: selectedCallback
        });
    }
    registerContextWidget(targetComponent, contextWidget) {
        contextWidget.visible = false;
        this._contextItemRegistrations.set(targetComponent, {
            type: ContextItemType.WIDGET,
            targetComponent: targetComponent,
            contextWidget: contextWidget
        });
        if (!this.hasChild(contextWidget)) {
            this.appendChild(contextWidget);
        }
    }
    unregisterContextItem(targetComponent) {
        let registration = this._contextItemRegistrations.get(targetComponent);
        if (registration) {
            registration.targetComponent = undefined;
            registration.menuData = undefined;
            registration.selectedCallback = undefined;
            if (registration.type === ContextItemType.WIDGET && this.hasChild(registration.contextWidget)) {
                this.removeChild(registration.contextWidget);
            }
            registration.contextWidget = undefined;
            this._contextItemRegistrations.delete(targetComponent);
        }
    }
    hasContextItemRegistered(targetComponent) {
        return this._contextItemRegistrations.has(targetComponent);
    }
    get isShowingContextItem() {
        return this.visible;
    }
}
window.customElements.define('a-context-item-container', AContextItemContainer);
