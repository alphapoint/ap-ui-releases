import { ASystemDialogEvent } from '../events/index.js';
import { AContainer } from './AContainer.js';
import { ACustomDialog } from './ACustomDialog.js';
import { AAlertDialog } from './dialogs/AAlertDialog.js';
import { AAuthenticateTwoFADialog } from './dialogs/AAuthenticateTwoFADialog.js';
import { ASetupTwoFADialog } from './dialogs/ASetupTwoFADialog.js';
import { AAuthenticateUsernamePasswordDialog } from './dialogs/AAuthenticateUsernamePasswordDialog.js';
import { AConfirmDialog } from './dialogs/AConfirmDialog.js';
import { AForgotPasswordDialog } from './dialogs/AForgotPasswordDialog.js';
import { ANoticeDialog } from './dialogs/ANoticeDialog.js';
import { APromptDialog } from './dialogs/APromptDialog.js';
import { ARegisterDialog } from './dialogs/ARegisterDialog.js';
export class ADialogContainer extends AContainer {
    constructor() {
        super();
        this._dialogs = [];
    }
    _build() {
        super._build();
        this._mask = new AContainer();
        this.appendChild(this._mask);
    }
    _registerListeners() {
        super._registerListeners();
        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);
        this._okClicked = this._okClicked.bind(this);
        this.addEventListener(ASystemDialogEvent.OK, this._okClicked);
        this._cancelClicked = this._cancelClicked.bind(this);
        this.addEventListener(ASystemDialogEvent.CANCEL, this._cancelClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        document.removeEventListener('keydown', this._onKeyDown);
        this.removeEventListener(ASystemDialogEvent.OK, this._okClicked);
        this.removeEventListener(ASystemDialogEvent.CANCEL, this._cancelClicked);
    }
    _render() {
        if (super._render()) {
            if (this._dialogs.length > 0) {
                let topDialog = this._dialogs[this._dialogs.length - 1];
                if (topDialog.backgroundOverride !== null) {
                    this._mask.style.setProperty('background-color', topDialog.backgroundOverride);
                }
                else {
                    this._mask.style.removeProperty('background-color');
                }
                this.appendChild(this._mask);
                this.appendChild(topDialog);
                this.visible = true;
            }
            else {
                this.visible = false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onKeyDown(event) {
        if (this._dialogs.length > 0) {
            let topDialog = this._dialogs[this._dialogs.length - 1];
            if (event.key === 'Enter' && topDialog.showOK) {
                topDialog.forceOkayClick();
            }
            else if (event.key === 'Escape') {
                this.dismissDialog();
            }
        }
    }
    _okClicked(event) {
        let dialog = event.detail.dialog;
        let okCallback = dialog.okCallback;
        if (dialog && okCallback) {
            okCallback();
        }
        this.dismissDialog();
    }
    _cancelClicked(event) {
        let dialog = event.detail.dialog;
        let cancelCallback = dialog.cancelCallback;
        if (dialog && cancelCallback) {
            cancelCallback();
        }
        this.dismissDialog();
    }
    showNoticeDialog(message = '') {
        let dialog = new ANoticeDialog();
        dialog.message = message;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showAlertDialog(message = '', okCallback = null) {
        let dialog = new AAlertDialog();
        dialog.message = message;
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback();
            };
        }
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showConfirmDialog(message = '', okCallback = null, cancelCallback = null) {
        let dialog = new AConfirmDialog();
        dialog.message = message;
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback();
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showPromptDialog(message = '', inputLabel = null, okCallback = null, cancelCallback = null) {
        let dialog = new APromptDialog();
        dialog.message = message;
        dialog.inputLabel = inputLabel;
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.inputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showAuthenticateUsernamePasswordDialog(okCallback = null, cancelCallback = null) {
        let dialog = new AAuthenticateUsernamePasswordDialog();
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.usernameInputValue, dialog.passwordInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showAuthenticateTwoFADialog(okCallback = null, cancelCallback = null) {
        let dialog = new AAuthenticateTwoFADialog();
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.twoFACodeInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showSetupTwoFADialog(qrData, okCallback = null, cancelCallback = null) {
        let dialog = new ASetupTwoFADialog();
        dialog.qrData = qrData;
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.twoFACodeInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showRegisterDialog(okCallback = null, cancelCallback = null) {
        let dialog = new ARegisterDialog();
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.usernameInputValue, dialog.emailInputValue, dialog.passwordInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showForgotPasswordDialog(okCallback = null, cancelCallback = null) {
        let dialog = new AForgotPasswordDialog();
        if (okCallback) {
            dialog.okCallback = () => {
                okCallback(dialog.usernameInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    showCustomDialog(content = null, okCallback = null, cancelCallback = null) {
        let dialog = new ACustomDialog();
        if (content !== null) {
            dialog.innerContent = content;
        }
        dialog.okCallback = okCallback;
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);
        this._dialogs.push(dialog);
        this.invalidate();
        return dialog;
    }
    dismissDialog() {
        if (this._dialogs.length > 0) {
            let dialog = this._dialogs.pop();
            this.doLater(() => {
                this.removeChild(dialog);
                dialog.destroy();
                this.invalidate();
            });
        }
    }
    dismissAllDialogs() {
        while (this._dialogs.length > 0) {
            let dialog = this._dialogs.pop();
            this.removeChild(dialog);
            dialog.destroy();
        }
        this.invalidate();
    }
    get isShowingDialog() {
        return this.visible;
    }
}
window.customElements.define('a-dialog-container', ADialogContainer);
