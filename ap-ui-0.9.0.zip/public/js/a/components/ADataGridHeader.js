import { AContainer } from './AContainer.js';
import { ADataGridHeaderItem } from './ADataGridHeaderItem.js';
import { ADataGridSortDirection } from './ADataGrid.js';
export class ADataGridHeader extends AContainer {
    constructor() {
        super();
        this._columnLabels = [];
    }
    _render() {
        if (super._render()) {
            let count = this._columnLabels.length;
            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new ADataGridHeaderItem());
                }
                else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }
            for (let i = 0; i < count; i++) {
                let headerItem = this.getChildAt(i);
                headerItem.index = i;
                headerItem.text = this._columnLabels[i];
                headerItem.title = this._columnLabels[i];
                if (this._sortColumnIndex === i) {
                    headerItem.sortDirection = this._sortDirection;
                }
                else {
                    headerItem.sortDirection = ADataGridSortDirection.NONE;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    setSort(index = -1, direction = ADataGridSortDirection.NONE) {
        if (this._sortColumnIndex !== index || this._sortDirection !== direction) {
            this._sortColumnIndex = index;
            this._sortDirection = direction;
            this.invalidate();
        }
    }
    get columnLabels() {
        return this._columnLabels;
    }
    set columnLabels(l) {
        if (this._columnLabels !== l) {
            this._columnLabels = l || [];
            this.invalidate();
        }
    }
}
window.customElements.define('a-data-grid-header', ADataGridHeader);
