import { AContainer } from './AContainer.js';
import { ATabViewEvent, ATabBarEvent } from '../events/index.js';
import { ATabBar } from './ATabBar.js';
export class ATabView extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._tabBar = new ATabBar();
        this._tabBar.selectedIndex = 0;
        this.appendChild(this._tabBar);
        this._content = new AContainer();
        this.appendChild(this._content);
    }
    _registerListeners() {
        super._registerListeners();
        this._onButtonBarChange = this._onButtonBarChange.bind(this);
        this._tabBar.addEventListener(ATabBarEvent.SELECTED_INDEX_CHANGE, this._onButtonBarChange);
    }
    _render() {
        if (super._render()) {
            if (this._tabBar.labels.length === 1) {
                this._tabBar.visible = false;
            }
            for (var i = 0; i < this._content.childNodes.length; i++) {
                let child = this._content.childNodes[i];
                if (this._tabBar.selectedIndex === i) {
                    child.removeClass('invisible');
                    child.invalidate();
                }
                else {
                    child.addClass('invisible');
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onButtonBarChange(event) {
        this.invalidate();
        this.dispatchEvent(new ATabViewEvent(ATabViewEvent.SELECTED_INDEX_CHANGE));
    }
    get icons() {
        return this._tabBar.icons;
    }
    set icons(i) {
        this._tabBar.icons = i;
    }
    get labels() {
        return this._tabBar.labels;
    }
    set labels(l) {
        this._tabBar.labels = l;
    }
    get selectedIndex() {
        return this._tabBar.selectedIndex;
    }
    set selectedIndex(i) {
        if (this._tabBar.selectedIndex !== i) {
            this._tabBar.selectedIndex = i;
            this.invalidate();
        }
    }
    get content() {
        return this._content;
    }
}
window.customElements.define('a-tab-view', ATabView);
