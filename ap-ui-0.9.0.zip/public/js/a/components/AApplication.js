import { AWindowContents } from './AWindowContents.js';
export class AApplication extends AWindowContents {
    constructor() {
        super();
    }
}
window.customElements.define('a-application', AApplication);
