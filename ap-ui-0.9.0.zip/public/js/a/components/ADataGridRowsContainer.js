import { AContainer } from './AContainer.js';
export class ADataGridRowsContainer extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-data-grid-rows-container', ADataGridRowsContainer);
