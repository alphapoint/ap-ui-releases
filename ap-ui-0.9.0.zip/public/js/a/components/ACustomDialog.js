import { ADialog } from './ADialog.js';
export class ACustomDialog extends ADialog {
    constructor() {
        super();
    }
    get innerContent() {
        return this._innerContent;
    }
    set innerContent(c) {
        if (this._innerContent !== c) {
            this._content.removeAllChildren();
            this._content.appendChild(c);
            this._innerContent = c;
        }
    }
}
window.customElements.define('a-custom-dialog', ACustomDialog);
