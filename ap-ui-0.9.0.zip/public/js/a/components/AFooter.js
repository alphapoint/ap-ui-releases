import { AContainer } from './AContainer.js';
export class AFooter extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-footer', AFooter);
