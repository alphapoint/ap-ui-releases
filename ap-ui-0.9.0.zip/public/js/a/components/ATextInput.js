import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { ALabel } from './ALabel.js';
export class ATextInput extends AComponent {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._label = new ALabel();
        this.appendChild(this._label);
        this._textInput = document.createElement('input');
        this._textInput.type = 'text';
        this.appendChild(this._textInput);
        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);
    }
    _registerListeners() {
        super._registerListeners();
    }
    _unregisterListeners() {
        super._unregisterListeners();
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _render() {
        if (super._render()) {
            this._label.visible = Boolean(this._label.text);
            this._icon.visible = this._icon.value !== null && this._icon.value.length > 0;
        }
        else {
            return false;
        }
    }
    select() {
        this._textInput.select();
    }
    focus() {
        this._textInput.focus();
    }
    get type() {
        return this._textInput.type;
    }
    set type(t) {
        this._textInput.type = t;
        if (t === ATextInput.PASSWORD) {
            this._textInput.name = t;
        }
    }
    get inputMode() {
        return this._textInput.inputMode;
    }
    set inputMode(m) {
        this._textInput.inputMode = m;
    }
    get placeholder() {
        return this._textInput.placeholder;
    }
    set placeholder(p) {
        this._textInput.placeholder = p;
    }
    get value() {
        return this._textInput.value;
    }
    set value(v) {
        if (this._textInput.value !== v) {
            this._textInput.value = v;
            this.invalidate();
        }
    }
    get label() {
        return this._label.text;
    }
    set label(l) {
        if (this._label.text !== l) {
            this._label.text = l;
            this.invalidate();
        }
    }
    get icon() {
        return this._icon.value;
    }
    set icon(i) {
        if (this._icon.value !== i) {
            this._icon.value = i;
            this.invalidate();
        }
    }
    get readonly() {
        return this._textInput.readOnly;
    }
    set readonly(r) {
        this._textInput.readOnly = r;
    }
    get min() {
        return this._textInput.min;
    }
    set min(m) {
        this._textInput.min = m;
    }
    get max() {
        return this._textInput.max;
    }
    set max(m) {
        this._textInput.max = m;
    }
    get step() {
        return this._textInput.step;
    }
    set step(s) {
        this._textInput.step = s;
    }
}
ATextInput.NUMBER = 'number';
ATextInput.DATE = 'date';
ATextInput.TIME = 'time';
ATextInput.DATETIME = 'datetime-local';
ATextInput.URL = 'url';
ATextInput.TEXT = 'text';
ATextInput.TELEPHONE = 'tel';
ATextInput.EMAIL = 'email';
ATextInput.PASSWORD = 'password';
ATextInput.COLOR = 'color';
window.customElements.define('a-text-input', ATextInput);
