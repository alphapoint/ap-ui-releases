import { AContainer } from './AContainer.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AHeader } from './AHeader.js';
import { AButton } from './AButton.js';
import { AFooter } from './AFooter.js';
import { ASystemDialogEvent } from '../events/index.js';
export class ADialog extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._okCallback = null;
        this._cancelCallback = null;
        this._backgroundOverride = null;
        this._header = new AHeader();
        this.appendChild(this._header);
        let iconTitleContainer = new AContainer();
        iconTitleContainer.addClass('icon-title');
        this._header.appendChild(iconTitleContainer);
        this._headerIcon = new AFontAwesomeIcon();
        iconTitleContainer.appendChild(this._headerIcon);
        this._titleText = new AText();
        iconTitleContainer.appendChild(this._titleText);
        this._xIcon = new AFontAwesomeIcon();
        this._xIcon.addClass('close');
        this._xIcon.value = ['fal', 'fa-times'];
        this._xIcon.visible = false;
        this._header.appendChild(this._xIcon);
        this._content = new AContainer();
        this.appendChild(this._content);
        this._footer = new AFooter();
        this.appendChild(this._footer);
        this._okButton = new AButton();
        this._okButton.addClass('ok');
        this._okButton.label = 'OK';
        this._footer.appendChild(this._okButton);
        this._cancelButton = new AButton();
        this._cancelButton.addClass('cancel');
        this._cancelButton.label = 'Cancel';
        this._footer.appendChild(this._cancelButton);
    }
    _registerListeners() {
        super._registerListeners();
        this._xIcon.addEventListener('click', this._cancelClicked);
        this._okClicked = this._okClicked.bind(this);
        this._okButton.addEventListener('click', this._okClicked);
        this._cancelClicked = this._cancelClicked.bind(this);
        this._cancelButton.addEventListener('click', this._cancelClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._okButton.removeEventListener('click', this._okClicked);
        this._cancelButton.removeEventListener('click', this._cancelClicked);
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
    }
    _render() {
        if (super._render()) {
            this._footer.visible = this._okButton.visible || this._cancelButton.visible;
            return true;
        }
        else {
            return false;
        }
    }
    _okClicked(event) {
        this.dispatchEvent(new ASystemDialogEvent(ASystemDialogEvent.OK, {
            bubbles: true,
            detail: {
                dialog: this
            }
        }));
    }
    _cancelClicked(event) {
        this.dispatchEvent(new ASystemDialogEvent(ASystemDialogEvent.CANCEL, {
            bubbles: true,
            detail: {
                dialog: this
            }
        }));
    }
    forceOkayClick() {
        if (this._okButton.enabled) {
            this._okClicked(null);
        }
    }
    get icon() {
        return this._headerIcon.value;
    }
    set icon(i) {
        if (this._headerIcon.value !== i) {
            this._headerIcon.value = i;
        }
    }
    get title() {
        return this._titleText.text;
    }
    set title(t) {
        if (this._titleText.text !== t) {
            this._titleText.text = t;
        }
    }
    get showX() {
        return this._xIcon.visible;
    }
    set showX(s) {
        this._xIcon.visible = s;
    }
    get showOK() {
        return this._okButton.visible;
    }
    set showOK(s) {
        this._okButton.visible = s;
        this.invalidate();
    }
    get okLabel() {
        return this._okButton.label;
    }
    set okLabel(l) {
        this._okButton.label = l;
    }
    get okCallback() {
        return this._okCallback;
    }
    set okCallback(c) {
        this._okCallback = c;
    }
    get showCancel() {
        return this._cancelButton.visible;
    }
    set showCancel(s) {
        this._cancelButton.visible = s;
        this.invalidate();
    }
    get cancelLabel() {
        return this._cancelButton.label;
    }
    set cancelLabel(l) {
        this._cancelButton.label = l;
    }
    get cancelCallback() {
        return this._cancelCallback;
    }
    set cancelCallback(c) {
        this._cancelCallback = c;
    }
    get backgroundOverride() {
        return this._backgroundOverride;
    }
    set backgroundOverride(b) {
        this._backgroundOverride = b;
    }
}
window.customElements.define('a-dialog', ADialog);
