import { AContainer } from './AContainer.js';
export class AForm extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-form', AForm);
