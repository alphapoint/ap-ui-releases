import { AContainer } from './AContainer.js';
export class APanelResizeTargets extends AContainer {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this.innerHTML = `
            <b data-direction="nw"></b>
            <b data-direction="n"></b>
            <b data-direction="ne"></b>
            <b data-direction="w"></b>
            <b data-direction="e"></b>
            <b data-direction="sw"></b>
            <b data-direction="s"></b>
            <b data-direction="se"></b>
        `;
    }
}
window.customElements.define('a-panel-resize-targets', APanelResizeTargets);
