import { AContainer } from './AContainer.js';
export class AHeader extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-header', AHeader);
