import { AComponent } from './AComponent.js';
export class ADataGridRowItem extends AComponent {
    constructor() {
        super();
    }
}
window.customElements.define('a-data-grid-row-item', ADataGridRowItem);
