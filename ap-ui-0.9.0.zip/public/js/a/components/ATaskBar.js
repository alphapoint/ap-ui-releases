import { AContainer } from './AContainer.js';
import { AButton } from './AButton.js';
import { ATaskBarEvent } from '../events/ATaskBarEvent.js';
export class ATaskBar extends AContainer {
    constructor() {
        super();
        this._windows = [];
        this._selectedWindow = null;
    }
    _build() {
        super._build();
    }
    _registerListeners() {
        super._registerListeners();
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }
    _render() {
        if (super._render()) {
            let count = this._windows.length;
            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                }
                else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }
            for (let i = 0; i < count; i++) {
                let win = this._windows[i];
                let button = this.getChildAt(i);
                button.setAttribute('data-index', i.toString());
                button.icon = win.icon;
                button.label = win.title;
                if (this._selectedWindow !== null && this._selectedWindow === win) {
                    button.addClass('selected');
                }
                else {
                    button.removeClass('selected');
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    _onClick(event) {
        if (event.target.constructor === AButton) {
            this._onButtonClick(event.target);
        }
    }
    _onButtonClick(button) {
        this._selectedWindow = this._windows[Number(button.getAttribute('data-index'))] || null;
        this.invalidate();
        this.dispatchEvent(new ATaskBarEvent(ATaskBarEvent.SELECTED_WINDOW_CHANGED));
    }
    get windows() {
        return this._windows;
    }
    set windows(wins) {
        if (this._windows !== wins) {
            this._windows = wins || [];
            this.invalidate();
        }
    }
    get selectedWindow() {
        return this._selectedWindow;
    }
    set selectedWindow(win) {
        if (this._selectedWindow !== win) {
            this._selectedWindow = win;
            this.invalidate();
        }
    }
}
window.customElements.define('a-task-bar', ATaskBar);
