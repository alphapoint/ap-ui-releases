import { AContainer } from './AContainer.js';
export class APanelHeader extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-panel-header', APanelHeader);
