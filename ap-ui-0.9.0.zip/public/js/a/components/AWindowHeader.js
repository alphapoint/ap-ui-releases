import { AContainer } from './AContainer.js';
export class AWindowHeader extends AContainer {
    constructor() {
        super();
    }
}
window.customElements.define('a-window-header', AWindowHeader);
