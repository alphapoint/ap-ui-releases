import { AComponent } from './AComponent.js';
export class AText extends AComponent {
    constructor() {
        super();
        this._text = '';
    }
    _render() {
        if (super._render()) {
            this.innerText = this._text;
            return true;
        }
        else {
            return false;
        }
    }
    get text() {
        return this._text;
    }
    set text(t) {
        if (this._text !== t) {
            this._text = t;
            this.invalidate();
        }
    }
}
window.customElements.define('a-text', AText);
