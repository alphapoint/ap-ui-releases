import { APoint } from './APoint.js';
export class ARectangle {
    constructor(x = 0, y = 0, w = 1, h = 1) {
        this._topLeft = new APoint(x, y);
        this._bottomRight = new APoint(x + w, y + h);
    }
    clone() {
        return new ARectangle(this._topLeft.x, this._topLeft.y, this._bottomRight.x - this._topLeft.x, this._bottomRight.y - this._topLeft.y);
    }
    isEmpty() {
        return this._topLeft.x >= this._bottomRight.x || this._topLeft.y >= this._bottomRight.y;
    }
    translate(x, y) {
        this._topLeft.x += x;
        this._bottomRight.x += x;
        this._topLeft.y += y;
        this._bottomRight.y += y;
        return this;
    }
    scale(xScale, yScale) {
        this._topLeft.x *= xScale;
        this._bottomRight.x *= xScale;
        this._topLeft.y *= yScale;
        this._bottomRight.y *= yScale;
        return this;
    }
    contains(rect) {
        return (rect.left >= this._topLeft.x && rect.right <= this._bottomRight.x && rect.top >= this._topLeft.y && rect.bottom <= this._bottomRight.y);
    }
    intersects(rect) {
        let x1 = Math.max(this._topLeft.x, rect.left);
        let x2 = Math.min(this._bottomRight.x, rect.right);
        let y1 = Math.max(this._topLeft.y, rect.top);
        let y2 = Math.min(this._bottomRight.y, rect.bottom);
        return x1 < x2 && y1 < y2;
    }
    get x() {
        return this._topLeft.x;
    }
    set x(x) {
        let w = this.width;
        this._topLeft.x = x;
        this._bottomRight.x = x + w;
    }
    get y() {
        return this._topLeft.y;
    }
    set y(y) {
        let h = this.height;
        this._topLeft.y = y;
        this._bottomRight.y = y + h;
    }
    get width() {
        return this._bottomRight.x - this._topLeft.x;
    }
    set width(w) {
        this._bottomRight.x = this._topLeft.x + w;
    }
    get height() {
        return this._bottomRight.y - this._topLeft.y;
    }
    set height(h) {
        this._bottomRight.y = this._topLeft.y + h;
    }
    get top() {
        return this.y;
    }
    set top(t) {
        this.y = t;
    }
    get right() {
        return this._bottomRight.x;
    }
    set right(r) {
        this._bottomRight.x = r;
    }
    get bottom() {
        return this._bottomRight.y;
    }
    set bottom(b) {
        this._bottomRight.x = b;
    }
    get left() {
        return this.x;
    }
    set left(l) {
        this.x = l;
    }
    get center() {
        return new APoint(this._topLeft.x + (this._bottomRight.x - this._topLeft.x) / 2, this._topLeft.y + (this._bottomRight.y - this._topLeft.y) / 2);
    }
}
