export class APoint {
    constructor(x = 0, y = 0) {
        this.x = x;
        this.y = y;
    }
    clone() {
        return new APoint(this.x, this.y);
    }
}
