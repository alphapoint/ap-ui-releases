import { AEventDispatcher, ADataProviderEvent } from '../events/index.js';
export class ADataProvider extends AEventDispatcher {
    constructor(data = null) {
        super();
        this._data = data || [];
    }
    from(data) {
        this._data = data || [];
        this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.ADD, { detail: { index: 0 } }));
    }
    getItemAt(index) {
        if (index >= 0 && index < this._data.length) {
            return this._data[index];
        }
        else {
            return null;
        }
    }
    addItem(item) {
        this.addItemAt(this._data.length, item);
    }
    addItemAt(index, item) {
        if (index >= 0 && index <= this._data.length) {
            this._data.splice(index, 0, item);
            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.ADD, { detail: { index: index } }));
            return true;
        }
        return false;
    }
    removeItemAt(index) {
        if (index >= 0 && index < this._data.length) {
            this._data.splice(index, 1);
            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.REMOVE, { detail: { index: index } }));
            return true;
        }
        return false;
    }
    removeAllItems() {
        this._data = [];
        this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.REMOVE, { detail: { index: 0 } }));
        return true;
    }
    setItemAt(index, item) {
        let isDirty = false;
        if (this._data.length <= index) {
            while (this._data.length <= index) {
                this._data.push([]);
            }
        }
        if (this._data[index] === undefined) {
            this._data[index] = item;
            isDirty = true;
        }
        else if (index >= 0 && index < this._data.length) {
            this._data[index] = item;
            isDirty = true;
        }
        if (isDirty) {
            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.CHANGE, { detail: { index: index } }));
        }
    }
    findIndex(comparison) {
        return this._data.findIndex(comparison);
    }
    hasItemAt(index) {
        return this._data[index] !== undefined;
    }
    destroy() {
        this._data = [];
    }
    get length() {
        return this._data.length;
    }
}
