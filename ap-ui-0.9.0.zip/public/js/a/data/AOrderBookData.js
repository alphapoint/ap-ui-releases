import { AOrderBookDataMap, AOrderBookDataMapDirection } from './AOrderBookDataMap.js';
import { AEventDispatcher } from '../events/AEventDispatcher.js';
export var AOrderBookDataType;
(function (AOrderBookDataType) {
    AOrderBookDataType["BID"] = "bid";
    AOrderBookDataType["ASK"] = "ask";
})(AOrderBookDataType || (AOrderBookDataType = {}));
export class AOrderBookData extends AEventDispatcher {
    constructor() {
        super();
        this._askData = new AOrderBookDataMap(AOrderBookDataMapDirection.ASCENDING);
        this._bidData = new AOrderBookDataMap(AOrderBookDataMapDirection.DESCENDING);
        this._aggregation = .01;
    }
    parse(asks, bids) {
        if (asks.length > 0) {
            asks.forEach(element => {
                this._askData.add(element[0], element[1]);
            });
        }
        if (bids.length > 0) {
            bids.forEach(element => {
                this._bidData.add(element[0], element[1]);
            });
        }
    }
    add(type, price, quantity) {
        if (type === AOrderBookDataType.ASK) {
            this._askData.add(price, quantity);
        }
        else if (type === AOrderBookDataType.BID) {
            this._bidData.add(price, quantity);
        }
    }
    getClosestItem(type, price) {
        if (type === AOrderBookDataType.ASK) {
            return this._askData.getClosestItem(price);
        }
        else if (type === AOrderBookDataType.BID) {
            return this._bidData.getClosestItem(price);
        }
        return null;
    }
    destroy() {
        this._askData.destroy();
        this._bidData.destroy();
    }
    clearAll() {
        this._askData.clearAll();
        this._bidData.clearAll();
    }
    get aggregation() {
        return this._aggregation;
    }
    set aggregation(a) {
        if (this._aggregation !== a) {
            this._aggregation = a;
            this._askData.aggregation = a;
            this._bidData.aggregation = a;
        }
    }
    get hasData() {
        return this._askData.hasData && this._bidData.hasData;
    }
    get askData() {
        return this._askData;
    }
    get bidData() {
        return this._bidData;
    }
    get lowerPriceBound() {
        return this._bidData.lowerPriceBound;
    }
    get upperPriceBound() {
        return this._askData.upperPriceBound;
    }
    get upperQuantityBound() {
        return Math.max(this._askData.upperQuantityBound, this._bidData.upperQuantityBound);
    }
    get spread() {
        return this._askData.lowerPriceBound - this._bidData.upperPriceBound;
    }
}
