import { AEventDispatcher, AConfigurationEvent } from '../events/index.js';
export class AConfiguration extends AEventDispatcher {
    constructor() {
        super();
        this._uri = null;
        this._data = null;
    }
    _loadConfiguration() {
        fetch(this._uri)
            .then((response) => {
            return response.json();
        })
            .then((json) => {
            this._data = json;
            this.dispatchEvent(new AConfigurationEvent(AConfigurationEvent.LOADED));
        }).catch(() => {
            this._data = null;
            this.dispatchEvent(new AConfigurationEvent(AConfigurationEvent.ERROR));
        });
    }
    get uri() {
        return this._uri;
    }
    set uri(uri) {
        if (uri && this._uri !== uri) {
            this._uri = uri;
            this._loadConfiguration();
        }
    }
    get data() {
        return this._data;
    }
}
