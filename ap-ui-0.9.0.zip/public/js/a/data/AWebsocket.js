import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { AWebsocketEvent } from '../events/AWebsocketEvent.js';
import { ARenderManager } from '../managers/ARenderManager.js';
export class AWebsocket extends AEventDispatcher {
    constructor() {
        super();
        this._uri = null;
        this._websocket = null;
        this._receiveQueue = [];
        this._parseQueue = this._parseQueue.bind(this);
    }
    _parseQueue() {
        while (this._receiveQueue.length > 0) {
            this._onMessage(this._receiveQueue.shift());
        }
    }
    _onOpen(event) {
        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.OPEN, { detail: event }));
    }
    _onMessage(event) {
        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.MESSAGE, { detail: event }));
    }
    _onError(event) {
        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.ERROR, { detail: event }));
    }
    _onClose(event) {
        if (event.code === 1006) {
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.ERROR, { detail: event }));
        }
        else {
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.CLOSE, { detail: event }));
        }
    }
    connect(uri) {
        this.disconnect();
        this._uri = uri;
        try {
            this._websocket = new WebSocket(this._uri);
            this._websocket.binaryType = 'arraybuffer';
            this._websocket.onopen = (event) => {
                this._onOpen(event);
            };
            this._websocket.onmessage = (event) => {
                this._receiveQueue[this._receiveQueue.length] = event;
                ARenderManager.instance.requestAnimationFrame(this._parseQueue);
            };
            this._websocket.onerror = (event) => {
                this._onError(event);
            };
            this._websocket.onclose = (event) => {
                this._onClose(event);
            };
        }
        catch (error) {
            console.log(error);
        }
    }
    disconnect() {
        if (this._websocket !== null) {
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.CLOSE, { detail: event }));
            this._receiveQueue = [];
            this._websocket.onopen = null;
            this._websocket.onmessage = null;
            this._websocket.onerror = null;
            this._websocket.onclose = null;
            this._websocket.close();
            this._websocket = null;
        }
    }
    reconnect() {
        if (this.connected) {
            this.disconnect();
        }
        this.connect(this._uri);
    }
    send(data = null) {
        if (this.connected && data !== null && data.length > 0) {
            this._websocket.send(data);
        }
    }
    destroy() {
        this.disconnect();
    }
    get connected() {
        if (this._websocket) {
            if (this._websocket.readyState === 1) {
                return true;
            }
        }
        return false;
    }
    get uri() {
        return this._uri;
    }
    get bufferedAmount() {
        if (this._websocket) {
            return this._websocket.bufferedAmount;
        }
        return 0;
    }
}
