export class ATreeNodeData extends Object {
    constructor(id, childTreeNodeData = null) {
        super();
        this._id = id;
        this._childTreeData = childTreeNodeData !== null ? childTreeNodeData : [];
        this._enabled = true;
        this._isOpen = false;
        this._iconBack = null;
        this._iconFront = null;
        this._label = null;
        this._actionText = null;
    }
    get ID() {
        return this._id;
    }
    get childTreeData() {
        return this._childTreeData;
    }
    set childTreeData(c) {
        this._childTreeData = c;
    }
    get enabled() {
        return this._enabled;
    }
    set enabled(e) {
        this._enabled = e;
    }
    get isOpen() {
        return this._isOpen;
    }
    set isOpen(i) {
        this._isOpen = i;
    }
    get iconBack() {
        return this._iconBack;
    }
    set iconBack(i) {
        this._iconBack = i;
    }
    get iconFront() {
        return this._iconFront;
    }
    set iconFront(i) {
        this._iconFront = i;
    }
    get label() {
        return this._label;
    }
    set label(l) {
        this._label = l;
    }
    get actionText() {
        return this._actionText;
    }
    set actionText(a) {
        this._actionText = a;
    }
}
