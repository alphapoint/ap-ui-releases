export class AMenuDataItem extends Object {
    constructor(icon = null, label = '', data = null, enabled = true, selected = false) {
        super();
        this._icon = icon;
        this._label = label;
        this._data = data;
        this._enabled = enabled;
        this._selected = selected;
    }
    get icon() {
        return this._icon;
    }
    set icon(i) {
        this._icon = i;
    }
    get label() {
        return this._label;
    }
    set label(l) {
        if (this._label !== l) {
            this._label = l;
        }
    }
    get data() {
        return this._data;
    }
    set data(d) {
        if (this._data !== d) {
            this._data = d;
        }
    }
    get enabled() {
        return this._enabled;
    }
    set enabled(e) {
        this._enabled = e;
    }
    get selected() {
        return this._selected;
    }
    set selected(s) {
        this._selected = s;
    }
}
