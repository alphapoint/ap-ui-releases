export class AOrderBookDataMapItem extends Object {
    constructor(price = 0, quantity = 0, cumulativeQuantity = 0, cumulativeCost = 0) {
        super();
        this._previous = null;
        this._next = null;
        this._price = price;
        this._quantity = quantity;
        this._cumulativeQuantity = cumulativeQuantity;
        this._cumulativeCost = cumulativeCost;
    }
    get previous() {
        return this._previous;
    }
    set previous(p) {
        this._previous = p;
    }
    get next() {
        return this._next;
    }
    set next(n) {
        this._next = n;
    }
    get price() {
        return this._price;
    }
    set price(p) {
        this._price = p;
    }
    get quantity() {
        return this._quantity;
    }
    set quantity(c) {
        this._quantity = c;
    }
    get cumulativeQuantity() {
        return this._cumulativeQuantity;
    }
    set cumulativeQuantity(c) {
        this._cumulativeQuantity = c;
    }
    get cumulativeCost() {
        return this._cumulativeCost;
    }
    set cumulativeCost(c) {
        this._cumulativeCost = c;
    }
}
