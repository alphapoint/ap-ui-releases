import { AOrderBookDataMapItem } from './AOrderBookDataMapItem.js';
export var AOrderBookDataMapDirection;
(function (AOrderBookDataMapDirection) {
    AOrderBookDataMapDirection["ASCENDING"] = "ascending";
    AOrderBookDataMapDirection["DESCENDING"] = "descending";
})(AOrderBookDataMapDirection || (AOrderBookDataMapDirection = {}));
export class AOrderBookDataMap extends Object {
    constructor(dir = AOrderBookDataMapDirection.ASCENDING) {
        super();
        this._data = new Map();
        this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
        this._upperPriceBound = 0;
        this._upperQuantityBound = 0;
        this._aggregation = .01;
        this._data = new Map();
        this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
        this._upperPriceBound = 0;
        this._upperQuantityBound = 0;
        this._firstItem = null;
        this._lastItem = null;
        this._currentItem = null;
        this._aggregation = .01;
        this._direction = dir;
    }
    _updateItem(item, quantity) {
        item.quantity = quantity;
        this._currentItem = item;
    }
    _insertItem(item) {
        let referenceItem = this._currentItem;
        while (referenceItem !== item) {
            if (item.price < referenceItem.price) {
                if (referenceItem.previous !== null) {
                    if (item.price < referenceItem.previous.price) {
                        referenceItem = referenceItem.previous;
                        continue;
                    }
                    else {
                        item.previous = referenceItem.previous;
                        item.next = referenceItem;
                        referenceItem.previous.next = item;
                        referenceItem.previous = item;
                        this._currentItem = item;
                        return;
                    }
                }
                else {
                    referenceItem.previous = item;
                    item.next = referenceItem;
                    this._firstItem = item;
                    this._currentItem = item;
                    return;
                }
            }
            else if (item.price > referenceItem.price) {
                if (referenceItem.next !== null) {
                    if (item.price > referenceItem.next.price) {
                        referenceItem = referenceItem.next;
                        continue;
                    }
                    else {
                        item.previous = referenceItem;
                        item.next = referenceItem.next;
                        referenceItem.next.previous = item;
                        referenceItem.next = item;
                        this._currentItem = item;
                        return;
                    }
                }
                else {
                    referenceItem.next = item;
                    item.previous = referenceItem;
                    this._lastItem = item;
                    this._currentItem = item;
                    return;
                }
            }
        }
    }
    _deleteItem(item) {
        let key = item.price.toString();
        if (this._data.has(key)) {
            let previousItem = item.previous;
            let nextItem = item.next;
            if (previousItem !== null && nextItem !== null) {
                previousItem.next = nextItem;
                nextItem.previous = previousItem;
                this._currentItem = previousItem;
            }
            else if (nextItem !== null) {
                nextItem.previous = null;
                this._firstItem = nextItem;
                this._currentItem = nextItem;
            }
            else if (previousItem !== null) {
                previousItem.next = null;
                this._lastItem = previousItem;
                this._currentItem = previousItem;
            }
        }
        item.next = null;
        item.previous = null;
        this._data.delete(key);
        if (this._data.size === 0) {
            this._currentItem = null;
            this._firstItem = null;
            this._lastItem = null;
            this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
            this._upperPriceBound = 0;
            this._upperQuantityBound = 0;
        }
        else {
            this._computeBounds();
        }
    }
    _computeBounds() {
        if (this._data.size > 0) {
            this._lowerPriceBound = this._firstItem.price;
            this._upperPriceBound = this._lastItem.price;
            this._upperQuantityBound = this._direction === AOrderBookDataMapDirection.ASCENDING ? this._lastItem.cumulativeQuantity : this._firstItem.cumulativeQuantity;
        }
        else {
            this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
            this._upperPriceBound = 0;
            this._upperQuantityBound = 0;
        }
    }
    add(price, quantity) {
        let key = price.toString();
        let item;
        if (this._data.size === 0) {
            let item = new AOrderBookDataMapItem(price, quantity, quantity);
            this._firstItem = item;
            this._lastItem = item;
            this._data.set(key, item);
            this._currentItem = item;
        }
        else {
            if (this._data.has(key)) {
                let referenceItem = this._data.get(key);
                if (quantity > 0) {
                    if (referenceItem.quantity !== quantity) {
                        this._updateItem(referenceItem, quantity);
                    }
                }
                else {
                    this._deleteItem(referenceItem);
                }
            }
            else if (quantity > 0) {
                let item = new AOrderBookDataMapItem(price, quantity, quantity);
                this._data.set(key, item);
                this._insertItem(item);
            }
        }
        this._computeBounds();
    }
    getClosestItem(price) {
        if (this._data.has(price.toString())) {
            this._data.get(price.toString());
        }
        else if (this._firstItem !== null && this._firstItem.price > price) {
            return this._firstItem;
        }
        else if (this._lastItem !== null && this._lastItem.price < price) {
            return this._lastItem;
        }
        else {
            let fromFirst = this._firstItem;
            let fromLast = this._lastItem;
            while (fromFirst !== null && fromLast !== null) {
                if (fromFirst.next !== null) {
                    if (price > fromFirst.next.price) {
                        fromFirst = fromFirst.next;
                    }
                    else {
                        return Math.abs(fromFirst.next.price - price) > Math.abs(fromFirst.price - price) ? fromFirst : fromFirst.next;
                    }
                }
                else {
                    fromFirst = null;
                }
                if (fromLast.previous !== null) {
                    if (price < fromLast.previous.price) {
                        fromLast = fromLast.previous;
                    }
                    else {
                        return Math.abs(fromLast.previous.price - price) > Math.abs(fromLast.price - price) ? fromLast : fromLast.previous;
                    }
                }
                else {
                    fromLast = null;
                }
            }
            return null;
        }
    }
    destroy() {
        this.clearAll();
    }
    clearAll() {
        this._data.clear();
        this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
        this._upperPriceBound = 0;
        this._upperQuantityBound = 0;
        this._firstItem = null;
        this._lastItem = null;
        this._currentItem = null;
    }
    [Symbol.iterator]() {
        let direction = this._direction;
        let referenceItem = direction === AOrderBookDataMapDirection.ASCENDING ? this._firstItem : this._lastItem;
        let cumulativeCost = 0;
        let cumulativeQuantity = 0;
        return {
            next: () => {
                if (referenceItem !== null) {
                    let prevReferenceItem = referenceItem;
                    cumulativeQuantity = cumulativeQuantity + prevReferenceItem.quantity;
                    cumulativeCost = prevReferenceItem.cumulativeCost + (prevReferenceItem.quantity * prevReferenceItem.price);
                    prevReferenceItem.cumulativeQuantity = cumulativeQuantity;
                    prevReferenceItem.cumulativeCost = cumulativeCost;
                    referenceItem = direction === AOrderBookDataMapDirection.ASCENDING ? referenceItem.next : referenceItem.previous;
                    return { value: prevReferenceItem.valueOf(), done: false };
                }
                else {
                    return { value: undefined, done: true };
                }
            }
        };
    }
    ;
    get hasData() {
        return this._data.size > 0;
    }
    get length() {
        return this._data.size;
    }
    get firstItem() {
        return this._firstItem;
    }
    get lastItem() {
        return this._lastItem;
    }
    get aggregation() {
        return this._aggregation;
    }
    set aggregation(a) {
        if (this._aggregation !== a) {
            this._aggregation = a;
        }
    }
    get lowerPriceBound() {
        return this._data.size > 0 ? this._lowerPriceBound : 0;
    }
    get upperPriceBound() {
        return this._data.size > 0 ? this._upperPriceBound : 0;
    }
    get upperQuantityBound() {
        return this._data.size > 0 ? this._upperQuantityBound : 0;
    }
}
