export class AMenuDataLabelItem extends Object {
    constructor(label = '') {
        super();
        this._label = label;
    }
    get label() {
        return this._label;
    }
    set label(l) {
        if (this._label !== l) {
            this._label = l;
        }
    }
}
