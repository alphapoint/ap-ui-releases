export class AMenuDataDividerItem extends Object {
    constructor() {
        super();
    }
}
