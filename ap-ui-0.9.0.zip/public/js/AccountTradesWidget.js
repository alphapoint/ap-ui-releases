import { ADataGrid, AMenuData, AMenuDataItem, AButton, ALanguageManager } from './a/index.js';
import TradesDataGridRow from './renderers/TradesDataGridRow.js';
import { TradingManager } from './managers/TradingManager.js';
import { TradingPanel } from './components/TradingPanel.js';
export class AccountTradesWidget extends TradingPanel {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._reportsButton = new AButton();
        this._headerContents.appendChild(this._reportsButton);
        this._dataBufferLength = 100;
        this._tradeGrid = new ADataGrid();
        this._tradeGrid.rowRenderer = TradesDataGridRow;
        this._panelContents.appendChild(this._tradeGrid);
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        this._onReportsButtonClicked = this._onReportsButtonClicked.bind(this);
        this._reportsButton.addEventListener('click', this._onReportsButtonClicked);
        let tm = TradingManager.instance;
        this._onNewTrade = this._onNewTrade.bind(this);
        tm.APIState.Account_NewTradeEvent.SubscribeEvent(this._onNewTrade);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let tm = TradingManager.instance;
        this._reportsButton.removeEventListener('click', this._onReportsButtonClicked);
        tm.APIState.Account_NewTradeEvent.UnsubscribeEvent(this._onNewTrade);
    }
    _render() {
        if (super._render()) {
            this._reportsButton.visible = TradingManager.instance.ReadyState.AccountsReady;
            let lm = ALanguageManager.instance;
            this.title = lm.get('AccountTradesWidget', 'Account Trades');
            this._reportsButton.label = lm.get('AccountTradesWidget', 'View Reports');
            this._tradeGrid.columnLabels = [
                `${lm.get('AccountTradesWidget', 'Price')}`,
                `${lm.get('AccountTradesWidget', 'Amount')}`,
                `${lm.get('AccountTradesWidget', 'Time')}`
            ];
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.requireAuthentication = true;
    }
    _onInstrumentIdChanged() {
        super._onInstrumentIdChanged();
        this._tradeGrid.removeAllItems();
        let instrumentInfo = TradingManager.instance.APIState.InstrumentInfos.get(this.instrumentId);
        if (instrumentInfo) {
            this._tradeGrid.columnLabels = [`Price (${instrumentInfo.Product2Symbol})`, `Qty (${instrumentInfo.Product1Symbol})`, `Time`];
            let tm = TradingManager.instance;
            let accountState = TradingManager.instance.APIState.AccountStates.get(this.accountId);
            if (accountState) {
                accountState.RecentTrades.forEach((trade) => {
                    if (trade.InstrumentId === this.instrumentId) {
                        this._onNewTrade(accountState, trade);
                    }
                });
            }
        }
    }
    _onReportsButtonClicked(event) {
        TradingManager.instance.ShowReportsDialog();
    }
    _onNewTrade(accountState, trade) {
        if (this.instrumentId !== trade.InstrumentId) {
            return;
        }
        this._tradeGrid.addItemAt(0, [trade]);
        while (this._tradeGrid.length > this._dataBufferLength) {
            this._tradeGrid.removeItemAt(this._tradeGrid.length - 1);
        }
    }
}
window.customElements.define('a-account-trades-widget', AccountTradesWidget);
