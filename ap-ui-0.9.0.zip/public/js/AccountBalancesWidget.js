import { AMenuData, AMenuDataItem, AHeader, AContainer, AText, AButton, ASystemManager, AMenuDataLabelItem, ALanguageManager } from './a/index.js';
import { TradingManager, TransactionType } from './managers/TradingManager.js';
import { TradingPanel } from './components/TradingPanel.js';
import { AccountBalancesItem } from './components/AccountBalancesItem.js';
export class AccountBalancesWidget extends TradingPanel {
    constructor() {
        super();
        this._accountBalanceItemMap = new Map();
    }
    _build() {
        super._build();
        this._accountBalancesHeader = new AHeader();
        this._panelContents.appendChild(this._accountBalancesHeader);
        this._productHeaderItem = new AText();
        this._accountBalancesHeader.appendChild(this._productHeaderItem);
        this._totalHeaderItem = new AText();
        this._accountBalancesHeader.appendChild(this._totalHeaderItem);
        this._availableHeaderItem = new AText();
        this._accountBalancesHeader.appendChild(this._availableHeaderItem);
        this._accountBalancesContent = new AContainer();
        this._panelContents.appendChild(this._accountBalancesContent);
        this._contextMenuData = new AMenuData();
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        let tm = TradingManager.instance;
        this._onProductStateUpdate = this._onProductStateUpdate.bind(this);
        tm.APIState.Account_ProductStateUpdatedEvent.SubscribeEvent(this._onProductStateUpdate);
        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
        this._onItemMouseUp = this._onItemMouseUp.bind(this);
        this.addEventListener('mouseup', this._onItemMouseUp);
        this._onContextMenuSelected = this._onContextMenuSelected.bind(this);
        ASystemManager.instance.registerContextMenu(this._accountBalancesContent, this._contextMenuData, this._onContextMenuSelected);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let tm = TradingManager.instance;
        tm.APIState.Account_ProductStateUpdatedEvent.UnsubscribeEvent(this._onProductStateUpdate);
        this.removeEventListener('click', this._onClick);
        this.removeEventListener('mouseup', this._onItemMouseUp);
        ASystemManager.instance.unregisterContextItem(this._accountBalancesContent);
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this.title = lm.get('AccountBalancesWidget', 'Account Balances');
            this._productHeaderItem.text = lm.get('AccountBalancesWidget', 'Product');
            this._totalHeaderItem.text = lm.get('AccountBalancesWidget', 'Total');
            this._availableHeaderItem.text = lm.get('AccountBalancesWidget', 'Available');
            let tm = TradingManager.instance;
            this._accountBalanceItemMap.forEach((item) => {
                let account = tm.APIState.AccountStates.get(this.accountId);
                if (account) {
                    let product = account.AccountProductStates.get(item.productID);
                    if (product) {
                        item.totalAmount = product.ProductAmount;
                        item.availableAmount = product.ProductAmount - product.ProductHold;
                    }
                    else {
                        item.totalAmount = null;
                        item.availableAmount = null;
                    }
                }
                else {
                    item.totalAmount = null;
                    item.availableAmount = null;
                }
            });
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.requireAuthentication = true;
    }
    _onTradingManagerReadyStateChanged() {
        super._onTradingManagerReadyStateChanged();
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstanceConfigReady && tm.ReadyState.AccountsReady) {
            this._createAccountBalances();
        }
    }
    _onProductStateUpdate(sender, data) {
        if (sender.AccountId === this.accountId) {
            this.invalidate();
        }
    }
    _onClick(event) {
        let target = event.target;
        let tm = TradingManager.instance;
        let productID = target.closest('a-account-balances-item').productID;
        if (target.constructor === AButton) {
            let action = target.dataset.action;
        }
        else {
            tm.ShowPortfolioDialog(productID);
        }
    }
    _onItemMouseUp(event) {
        let item = event.target.closest('a-account-balances-item');
        if (item) {
            let tm = TradingManager.instance;
            let accountState = tm.APIState.AccountStates.get(this.accountId);
            let productInfo = tm.APIState.ProductInfos.get(item.productID);
            if (accountState && productInfo) {
                let productState = accountState.AccountProductStates.get(item.productID);
                if (productState) {
                    this._contextMenuData.items = [
                        new AMenuDataLabelItem(productInfo.ProductFullName),
                        new AMenuDataItem(null, `Deposit`, item.productID),
                        new AMenuDataItem(null, `Withdraw`, item.productID, (productState.ProductAmount - productState.ProductHold) > 0)
                    ];
                    return;
                }
            }
        }
        this._contextMenuData.items = [];
    }
    _onContextMenuSelected(item) {
        if (item.label === 'Deposit') {
            TradingManager.instance.ShowTransactionDialog(TransactionType.DEPOSIT, this.accountId, item.data);
        }
        else if (item.label === 'Withdraw') {
            TradingManager.instance.ShowTransactionDialog(TransactionType.WITHDRAW, this.accountId, item.data);
        }
    }
    _createAccountBalances() {
        let tm = TradingManager.instance;
        tm.APIState.ProductInfos.forEach((productInfo, productID) => {
            if (!this._accountBalanceItemMap.has(productID)) {
                let accountBalanceItem = new AccountBalancesItem();
                accountBalanceItem.productID = productID;
                this._accountBalancesContent.appendChild(accountBalanceItem);
                this._accountBalanceItemMap.set(productID, accountBalanceItem);
            }
        });
    }
}
window.customElements.define('a-account-balances-widget', AccountBalancesWidget);
