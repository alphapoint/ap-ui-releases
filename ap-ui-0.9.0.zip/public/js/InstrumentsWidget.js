import { ALanguageManager, AMenuData, AMenuDataItem } from './a/index.js';
import { InstrumentSelector } from './components/InstrumentSelector.js';
import { TradingPanel } from './components/TradingPanel.js';
export class InstrumentsWidget extends TradingPanel {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._instrumentSelector = new InstrumentSelector();
        this._panelContents.appendChild(this._instrumentSelector);
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            this.title = lm.get('InstrumentsWidget', 'Instruments');
            return true;
        }
        else {
            return false;
        }
    }
    _onLanguageChanged() {
        super._onLanguageChanged();
        this._instrumentSelector.invalidate();
    }
    _onTradingManagerReadyStateChanged() {
        super._onTradingManagerReadyStateChanged();
        if (this._instrumentSelector) {
            this._instrumentSelector.scrollInstrumentIntoView();
        }
    }
    _onAccountIdChanged() {
        super._onAccountIdChanged();
    }
    _onInstrumentIdChanged() {
        super._onInstrumentIdChanged();
        this._instrumentSelector.instrumentId = this.instrumentId;
    }
}
window.customElements.define('a-instruments-widget', InstrumentsWidget);
