import { AMenuData, AMenuDataItem, ADataGrid, AButtonBar, AButtonBarEvent, ADataGridEvent, AFontAwesomeIcon, ASystemManager, ALanguageManager } from './a/index.js';
import { TradingPanel } from './components/TradingPanel.js';
import { TradingManager } from './managers/TradingManager.js';
import AccountOrdersDataGridRow from './renderers/AccountOrdersDataGridRow.js';
export class AccountOrdersWidget extends TradingPanel {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._orderStatusButtons = new AButtonBar();
        this._orderStatusButtons.selectedIndex = 0;
        this._headerContents.appendChild(this._orderStatusButtons);
        this._ordersGrid = new ADataGrid();
        this._ordersGrid.rowRenderer = AccountOrdersDataGridRow;
        this._ordersGrid.selectable = true;
        this._panelContents.appendChild(this._ordersGrid);
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        let tm = TradingManager.instance;
        this._onDataGridRowClicked = this._onDataGridRowClicked.bind(this);
        this._ordersGrid.addEventListener(ADataGridEvent.ROW_CLICK, this._onDataGridRowClicked);
        this._onOrderStatusButtonsChanged = this._onOrderStatusButtonsChanged.bind(this);
        this._orderStatusButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onOrderStatusButtonsChanged);
        this._onOrderStateChanged = this._onOrderStateChanged.bind(this);
        tm.APIState.Account_OrderStateChangedEvent.SubscribeEvent(this._onOrderStateChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._ordersGrid.removeEventListener(ADataGridEvent.ROW_CLICK, this._onDataGridRowClicked);
        this._orderStatusButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onOrderStatusButtonsChanged);
        let tm = TradingManager.instance;
        tm.APIState.Account_OrderStateChangedEvent.UnsubscribeEvent(this._onOrderStateChanged);
    }
    _render() {
        if (super._render()) {
            let lm = ALanguageManager.instance;
            if (this._invalidateLanguage) {
                this.title = lm.get('AccountOrdersWidget', 'Account Orders');
                this._ordersGrid.columnLabels = [
                    lm.get('AccountOrdersWidget', 'Date'),
                    lm.get('AccountOrdersWidget', 'Instrument'),
                    lm.get('AccountOrdersWidget', 'Type'),
                    lm.get('AccountOrdersWidget', 'Status'),
                    lm.get('AccountOrdersWidget', 'Orig Qty'),
                    lm.get('AccountOrdersWidget', 'Exec Qty'),
                    lm.get('AccountOrdersWidget', 'Rmng Qty'),
                    lm.get('AccountOrdersWidget', 'Lmt Price'),
                    lm.get('AccountOrdersWidget', 'Stop Price'),
                    lm.get('AccountOrdersWidget', 'Avg Exec Price'),
                    lm.get('AccountOrdersWidget', 'TIF'),
                    lm.get('AccountOrdersWidget', 'Actions')
                ];
                this._invalidateLanguage = false;
            }
            this._ordersGrid.removeAllItems();
            let tm = TradingManager.instance;
            let accountState = tm.APIState.AccountStates.get(this.accountId);
            if (!accountState) {
                this._orderStatusButtons.labels = [
                    lm.get('AccountOrdersWidget', 'Open Orders'),
                    lm.get('AccountOrdersWidget', 'Filled Orders'),
                    lm.get('AccountOrdersWidget', 'Inactive Orders')
                ];
                return;
            }
            let selectedOrderStatus = this._orderStatusButtons.selectedIndex || 0;
            if (selectedOrderStatus === 0 || selectedOrderStatus === 1) {
                accountState.OpenOrderStates.forEach((orderState) => {
                    if (selectedOrderStatus === 0 || (selectedOrderStatus === 1 && orderState.ExecutedQuantity > 0)) {
                        this._ordersGrid.addItem([
                            orderState
                        ]);
                    }
                });
            }
            if (selectedOrderStatus === 1 || selectedOrderStatus === 2) {
                accountState.ClosedOrderStates.forEach((orderState) => {
                    if (selectedOrderStatus === 2 || (selectedOrderStatus === 1 && orderState.ExecutedQuantity > 0)) {
                        this._ordersGrid.addItem([
                            orderState
                        ]);
                    }
                });
            }
            this._orderStatusButtons.labels = [
                `${lm.get('AccountOrdersWidget', 'Open Orders')}${accountState.OpenOrderStates.size > 0 ? '(' + accountState.OpenOrderStates.size + ')' : ''}`,
                `${lm.get('AccountOrdersWidget', 'Filled Orders')}`,
                `${lm.get('AccountOrdersWidget', 'Inactive Orders')}${accountState.ClosedOrderStates.length > 0 ? '(' + accountState.ClosedOrderStates.length + ')' : ''}`
            ];
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.requireAuthentication = true;
    }
    _onLanguageChanged() {
        this._invalidateLanguage = true;
        super._onLanguageChanged();
    }
    _onDataGridRowClicked(event) {
        if (event.target.constructor === AFontAwesomeIcon) {
            let icon = event.target;
            let orderID = this._ordersGrid.getItemAt(event.detail.index)[0].OrderId;
            if (icon.hasClass('cancel')) {
                this._cancelOrder(orderID);
            }
            else if (icon.hasClass('execute-at-market')) {
                this._executeOrderAtMarket(orderID);
            }
            else if (icon.hasClass('edit')) {
                this._editOrder(orderID);
            }
        }
    }
    _onOrderStatusButtonsChanged(event) {
        this.invalidate();
        this._ordersGrid.selectedIndex = null;
        this._ordersGrid.verticalScrollAmount = 0;
    }
    _onOrderStateChanged(sender, data) {
        this.invalidate();
    }
    _cancelOrder(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
            let dialog = ASystemManager.instance.showConfirmDialog(`Are you sure you want to cancel order ${Number(orderID)}?`, () => {
                tm.SendCancelOrderByServerOrderId(this.accountId, orderState.InstrumentId, orderID);
            }, null);
            dialog.title = 'Cancel Order';
            dialog.okLabel = 'Yes';
            dialog.cancelLabel = 'No';
        }
    }
    _executeOrderAtMarket(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
        }
    }
    _editOrder(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
        }
    }
}
window.customElements.define('a-account-orders-widget', AccountOrdersWidget);
