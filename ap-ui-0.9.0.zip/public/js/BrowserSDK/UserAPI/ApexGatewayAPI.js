import { QuickEvent } from './index.js';
export class ApexGatewayAPIRequestEntry extends Object {
    constructor() {
        super(...arguments);
        this.method = null;
        this.successCallback = null;
        this.failureCallback = null;
        this.requestTime = null;
        this.sendPayload = null;
    }
}
export class ApexGatewayAPI {
    constructor() {
        this._sequenceID = 0;
        this._requestTimeout = 10000;
        this._requestTimer = null;
        this._requiresTwoFAAuthentication = false;
        this._authenticated = false;
        this.readyStateChanged = new QuickEvent();
        this.messageReceived = new QuickEvent();
        this._ws = null;
        this._wsURI = null;
        this._requestEntries = new Map();
        this._omsID = 1;
        this._userID = null;
        this._userEmail = null;
        this._sessionToken = null;
        this.authenticatedCallback = this.authenticatedCallback.bind(this);
    }
    get ReadyStateChanged() { return this.readyStateChanged.Expose(); }
    get MessageReceived() { return this.messageReceived.Expose(); }
    Destroy() {
        this.readyStateChanged.Destroy();
        this.readyStateChanged = undefined;
        this._authcB = undefined;
        this._ws.onopen = undefined;
        this._ws.onmessage = undefined;
        this._ws.onclose = undefined;
        this._ws.close();
        this._wsURI = undefined;
        this._requestEntries.clear();
        this._requestEntries = undefined;
    }
    Connect(wsuri) {
        this._wsURI = wsuri;
        if (this._ws !== null) {
            this._ws.onopen = undefined;
            this._ws.onmessage = undefined;
            this._ws.onclose = undefined;
            this._ws.close();
        }
        this._ws = new WebSocket(this._wsURI);
        this._ws.onmessage = (event) => {
            this._onMessageReceived(event);
        };
        this._ws.onopen = (event) => {
            this.onWebsocketOpened();
        };
        this._ws.onclose = (event) => {
            this.onWebsocketClosed();
        };
    }
    Authenticate(username = null, password = null, sessionToken = null, authcallback = () => { }) {
        this._authcB = authcallback;
        if (sessionToken !== null) {
            this.Request('WebAuthenticateUser', {
                SessionToken: sessionToken
            }, this.authenticatedCallback);
        }
        else {
            this.Request('WebAuthenticateUser', {
                UserName: username,
                Password: password
            }, this.authenticatedCallback);
        }
    }
    AuthenticateTwoFA(twoFACode, authcallback = () => { }) {
        this._authcB = authcallback;
        this.Request('Authenticate2FA', {
            Code: twoFACode
        }, this.authenticatedCallback);
    }
    ConnectAndAuthenticate(wsuri, username = null, password = null, sessionToken = null, authcallback = () => { }) {
        this._authcB = authcallback;
        this._wsURI = wsuri;
        if (this._ws !== null) {
            this._ws.onopen = undefined;
            this._ws.onmessage = undefined;
            this._ws.onclose = undefined;
            this._ws.close();
        }
        this._ws = new WebSocket(this._wsURI);
        this._ws.onmessage = (event) => {
            this._onMessageReceived(event);
        };
        this._ws.onopen = (event) => {
            if (sessionToken !== null) {
                this.Request('WebAuthenticateUser', {
                    SessionToken: sessionToken
                }, this.authenticatedCallback);
            }
            else {
                this.Request('WebAuthenticateUser', {
                    UserName: username,
                    Password: password
                }, this.authenticatedCallback);
            }
            this.onWebsocketOpened();
        };
        this._ws.onclose = (event) => {
            this.onWebsocketClosed();
        };
    }
    authenticatedCallback(data) {
        if (data.hasOwnProperty('Authenticated') && data.Authenticated) {
            if (data.hasOwnProperty('Requires2FA') && data.Requires2FA) {
                this._authenticated = false;
                this._requiresTwoFAAuthentication = true;
            }
            else if (data.hasOwnProperty('SessionToken') && data.SessionToken) {
                this._authenticated = true;
                this._requiresTwoFAAuthentication = false;
                this._sessionToken = data.SessionToken;
                this._userID = data.UserId;
            }
            if (this._authcB) {
                this._authcB(true);
                this._authcB = null;
            }
        }
        else {
            this._authenticated = false;
            this._requiresTwoFAAuthentication = false;
            if (this._authcB) {
                this._authcB(false);
                this._authcB = null;
            }
        }
        this.readyStateChanged.DispatchEvent(this);
    }
    _onMessageReceived(msgEvent) {
        let newMsg = msgEvent.data;
        try {
            let payload = JSON.parse(newMsg);
            payload.o = JSON.parse(payload.o);
            if (this._requestEntries.has(payload.i)) {
                let requestEntry = this._requestEntries.get(payload.i);
                this._requestEntries.delete(payload.i);
                requestEntry.successCallback(payload.o);
            }
            else {
                this.messageReceived.DispatchEvent(payload);
            }
        }
        catch (ex) {
            console.log(ex);
        }
    }
    onWebsocketOpened() {
        this.readyStateChanged.DispatchEvent(this);
    }
    onWebsocketClosed() {
        this.readyStateChanged.DispatchEvent(this);
    }
    SendMessage(command = null, parameters = {}) {
        if (command !== null && parameters !== undefined && parameters !== null) {
            this._sequenceID = this._sequenceID + 2;
            try {
                let payload = {
                    m: 0,
                    i: this._sequenceID,
                    n: command,
                    o: JSON.stringify(Object.assign({
                        OMSId: this._omsID || null
                    }, parameters))
                };
                this._ws.send(JSON.stringify(payload));
                return payload;
            }
            catch (error) {
                throw error;
            }
        }
    }
    Request(method = null, requestParameters = {}, successCallback = () => { }, failureCallback = () => { }) {
        if (method !== null && requestParameters !== undefined && requestParameters !== null) {
            try {
                let payload = this.SendMessage(method, requestParameters);
                let requestEntry = {
                    method: method,
                    successCallback: successCallback,
                    failureCallback: failureCallback,
                    requestTime: Date.now(),
                    sendPayload: payload
                };
                if (this._requestEntries.has(this._sequenceID)) {
                    this._requestEntries.get(this._sequenceID).failureCallback();
                    this._requestEntries.delete(this._sequenceID);
                }
                this._requestEntries.set(this._sequenceID, requestEntry);
            }
            catch (error) {
                failureCallback(error);
            }
        }
    }
    get IsConnected() {
        return this._ws.readyState === 1;
    }
    ;
    get IsAuthenticated() {
        return this._authenticated;
    }
    get requiresTwoFAAuthentication() {
        return this._requiresTwoFAAuthentication;
    }
    get SessionToken() {
        return this._sessionToken || null;
    }
    get UserId() {
        return this._userID;
    }
    get UserEmail() {
        return this._userEmail;
    }
}
