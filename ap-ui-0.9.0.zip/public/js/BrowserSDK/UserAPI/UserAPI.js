import { ApexGatewayAPI, OrderCurrentState, User_InputMessageHeader, User_MessageType_ToInstanceHelper, User_MessageType, User_AddLimitOrder_Input_Offsets, User_AddLimitOrder_Input, User_CancelOrderByClientOrderId_Input_Offsets, User_CancelOrderByClientOrderId_Input, User_CancelOrderByServerOrderId_Input_Offsets, User_CancelOrderByServerOrderId_Input, User_SubscribeMDTrades_Input, User_SubscribeL2_Input, User_CancelAllOrders_Input_Offsets, User_CancelAllOrders_Input, User_AddMarketOrder_Input_Offsets, User_AddMarketOrder_Input, User_AddOrderEx_Input_Offsets, User_AddOrderEx_Input, User_ControlMessage_Output, User_ControlMessage_Action, AccountCredentialObject_AuthMethodEnum, QuickEvent, QuickEvent2, InstrumentMarketData, UserAPI_GlobalInstrumentData_Connection, UserAPI_MarketData_Connection } from './index.js';
export class Configuration_Public {
}
export class APIState {
    constructor() {
        this.AccountStates = new Map();
        this.InstrumentStates = new Map();
        this.DefaultAccount = null;
        this.InstrumentInfos = new Map();
        this.ProductInfos = new Map();
        this._md_newTradeEvent = new QuickEvent2();
        this._md_orderBookFullUpdateEvent = new QuickEvent2();
        this._md_orderBookDeltaUpdateEvent = new QuickEvent2();
        this._account_OrderStateChangedEvent = new QuickEvent2();
        this._account_NewTradeEvent = new QuickEvent2();
        this._account_ProductStateUpdatedEvent = new QuickEvent2();
        setInterval(() => {
            this.InstrumentStates.forEach((instrumentMarketData) => {
                instrumentMarketData.CheckConnectionHealth();
            });
        }, 100);
    }
    get ProductInfosChangedEvent() { return this.productInfosChangedEvent.Expose(); }
    get InstrumentInfosChangedEvent() { return this.instrumentInfosChangedEvent.Expose(); }
    get MD_NewTradeEvent() { return this._md_newTradeEvent.Expose(); }
    get MD_OrderBookFullUpdateEvent() { return this._md_orderBookFullUpdateEvent.Expose(); }
    get MD_OrderBookDeltaUpdateEvent() { return this._md_orderBookDeltaUpdateEvent.Expose(); }
    get Account_OrderStateChangedEvent() { return this._account_OrderStateChangedEvent.Expose(); }
    get Account_NewTradeEvent() { return this._account_NewTradeEvent.Expose(); }
    get Account_ProductStateUpdatedEvent() { return this._account_ProductStateUpdatedEvent.Expose(); }
    GetAccountState(accountId) {
        let accState = this.AccountStates.get(accountId);
        if (accState == null) {
            accState = new UserAccountState(this);
            accState.AccountId = accountId;
            this.AccountStates.set(accountId, accState);
            if (this.DefaultAccount == null)
                this.DefaultAccount = accState;
        }
        return accState;
    }
    GetInstrumentState(instrumentId) {
        let insState = this.InstrumentStates.get(instrumentId);
        if (insState == null) {
            insState = new InstrumentMarketData(this);
            insState.InstrumentId = instrumentId;
            this.InstrumentStates.set(instrumentId, insState);
        }
        return insState;
    }
}
export class UserAccountState {
    constructor(parentObj) {
        this.processAccountProductState_HA_ServerSequenceNumber = 0n;
        this.processUserOrderState_HA_ServerSequenceNumber = 0n;
        this.processUserOrderTradeState_HA_ServerSequenceNumber = 0n;
        this.parentObj = parentObj;
        this.AccountId = null;
        this.OpenOrderStates = new Map();
        this.OpenOrdersByPrice = new Map();
        this.ClosedOrderStates = new Array();
        this.AccountProductStates = new Map();
        this.RecentTrades = [];
        this.account_OrderStateChangedEvent = new QuickEvent2();
        this.account_NewTradeEvent = new QuickEvent2();
        this.account_ProductStateUpdatedEvent = new QuickEvent2();
    }
    get Account_OrderStateChangedEvent() { return this.account_OrderStateChangedEvent.Expose(); }
    get Account_NewTradeEvent() { return this.account_NewTradeEvent.Expose(); }
    get Account_ProductStateUpdatedEvent() { return this.account_ProductStateUpdatedEvent.Expose(); }
    _ProcessAccountProductState(accountProductState) {
        if (accountProductState.Header.HA_ServerSequenceNumber >= 0) {
            if (this.processAccountProductState_HA_ServerSequenceNumber >= accountProductState.Header.HA_ServerSequenceNumber)
                return;
            this.processAccountProductState_HA_ServerSequenceNumber = accountProductState.Header.HA_ServerSequenceNumber;
        }
        this.AccountProductStates.set(accountProductState.ProductId, accountProductState);
        this.account_ProductStateUpdatedEvent.DispatchEvent(this, accountProductState);
        this.parentObj._account_ProductStateUpdatedEvent.DispatchEvent(this, accountProductState);
    }
    _ProcessUserOrderState(userOrderState) {
        if (userOrderState.Header.HA_ServerSequenceNumber >= 0) {
            if (this.processUserOrderState_HA_ServerSequenceNumber >= userOrderState.Header.HA_ServerSequenceNumber)
                return;
            this.processUserOrderState_HA_ServerSequenceNumber = userOrderState.Header.HA_ServerSequenceNumber;
        }
        if (userOrderState.CurrentOrderState != OrderCurrentState.Working) {
            let origOrder = this.OpenOrderStates.get(userOrderState.OrderId);
            if (origOrder != null) {
                let ordersAtPriceMap = this.OpenOrdersByPrice.get(origOrder.LimitPrice);
                if (ordersAtPriceMap != null) {
                    ordersAtPriceMap.delete(userOrderState.OrderId);
                    if (ordersAtPriceMap.size == 0) {
                        this.OpenOrdersByPrice.delete(origOrder.LimitPrice);
                    }
                }
            }
            this.OpenOrderStates.delete(userOrderState.OrderId);
            this.ClosedOrderStates.unshift(userOrderState);
            if (this.ClosedOrderStates.length > 100)
                this.ClosedOrderStates.pop();
        }
        else {
            let origOrder = this.OpenOrderStates.get(userOrderState.OrderId);
            let ordersAtPriceMap = null;
            if (origOrder != null) {
                ordersAtPriceMap = this.OpenOrdersByPrice.get(origOrder.LimitPrice);
            }
            else {
                ordersAtPriceMap = this.OpenOrdersByPrice.get(userOrderState.LimitPrice);
            }
            if (ordersAtPriceMap != null) {
                ordersAtPriceMap.delete(userOrderState.OrderId);
                if (origOrder != null && origOrder.LimitPrice != userOrderState.LimitPrice) {
                    ordersAtPriceMap = this.OpenOrdersByPrice.get(userOrderState.LimitPrice);
                }
            }
            if (ordersAtPriceMap == null) {
                ordersAtPriceMap = new Map();
                this.OpenOrdersByPrice.set(userOrderState.LimitPrice, ordersAtPriceMap);
            }
            ordersAtPriceMap.set(userOrderState.OrderId, userOrderState);
            this.OpenOrderStates.set(userOrderState.OrderId, userOrderState);
        }
        this.account_OrderStateChangedEvent.DispatchEvent(this, userOrderState);
        this.parentObj._account_OrderStateChangedEvent.DispatchEvent(this, userOrderState);
    }
    _ProcessUserOrderTrade(userOrderTrade) {
        if (userOrderTrade.Header.HA_ServerSequenceNumber >= 0) {
            if (this.processUserOrderTradeState_HA_ServerSequenceNumber >= userOrderTrade.Header.HA_ServerSequenceNumber)
                return;
            this.processUserOrderTradeState_HA_ServerSequenceNumber = userOrderTrade.Header.HA_ServerSequenceNumber;
        }
        this.RecentTrades.unshift(userOrderTrade);
        if (this.RecentTrades.length > 100)
            this.RecentTrades.pop();
        this.account_NewTradeEvent.DispatchEvent(this, userOrderTrade);
        this.parentObj._account_NewTradeEvent.DispatchEvent(this, userOrderTrade);
    }
}
export class UserAPI_Account_Connection {
    constructor(parentObj, wsUrl) {
        this.wsUrl = wsUrl;
        this.ws = null;
        this.parentObj = parentObj;
        this.isReady = false;
        this.onOpen = this.onOpen.bind(this);
        this.onMessage = this.onMessage.bind(this);
        this.onClose = this.onClose.bind(this);
        this.onError = this.onError.bind(this);
    }
    GetAccountState(accountId) {
        return this.parentObj.APIState.GetAccountState(accountId);
    }
    TryConnect() {
        if (this.parentObj.internalGetAccountCredentialsObject().AuthMethod == AccountCredentialObject_AuthMethodEnum.None)
            return;
        this.resetLocalWebsocket();
        this.ws = new WebSocket(this.wsUrl);
        this.ws.binaryType = 'arraybuffer';
        this.ws.onopen = this.onOpen;
        this.ws.onmessage = this.onMessage;
        this.ws.onclose = this.onClose;
        this.ws.onerror = this.onError;
    }
    IsConnecting() {
        if (!this.ws)
            return false;
        if (this.ws.readyState == this.ws.CONNECTING)
            return true;
        return false;
    }
    IsConnected() {
        if (!this.ws)
            return false;
        if (this.ws.readyState == this.ws.OPEN)
            return true;
        return false;
    }
    IsReady() {
        return this.IsConnected() && this.isReady;
    }
    onOpen(event) {
        console.log('UserAPI_Account_Connection WS Connection Opened');
        let accountCredentials = this.parentObj.internalGetAccountCredentialsObject();
        let internalAuthHelperObj = this.parentObj.internalGetAuthHelperObject();
        if (accountCredentials.AuthMethod == AccountCredentialObject_AuthMethodEnum.SessionToken) {
            this.ws.send(JSON.stringify({
                MT: 'UserAuthBySessionToken',
                InstanceId: this.parentObj.InstanceId,
                ApexSessionToken: accountCredentials.SessionToken
            }));
        }
        else if (accountCredentials.AuthMethod == AccountCredentialObject_AuthMethodEnum.UserNameAndPassword) {
            if (internalAuthHelperObj.HasSessionToken) {
                this.ws.send(JSON.stringify({
                    MT: 'UserAuthBySessionToken',
                    InstanceId: this.parentObj.InstanceId,
                    ApexSessionToken: accountCredentials.SessionToken
                }));
            }
            else if (internalAuthHelperObj.StartedUPAuth == false) {
                internalAuthHelperObj.StartedUPAuth = true;
                this.ws.send(JSON.stringify({
                    MT: 'UserAuthByUP',
                    InstanceId: this.parentObj.InstanceId,
                    User: accountCredentials.UserName,
                    Password: accountCredentials.Password
                }));
            }
            else {
                internalAuthHelperObj.ReceivedSessionTokenEvent.SubscribeEvent(this.receivedSessionTokenEventHandler.bind(this));
            }
        }
    }
    receivedSessionTokenEventHandler(data) {
        let accountCredentials = this.parentObj.internalGetAccountCredentialsObject();
        let internalAuthHelperObj = this.parentObj.internalGetAuthHelperObject();
        if (internalAuthHelperObj.HasSessionToken) {
            this.ws.send(JSON.stringify({
                MT: 'UserAuthBySessionToken',
                InstanceId: this.parentObj.InstanceId,
                ApexSessionToken: accountCredentials.SessionToken
            }));
        }
    }
    onMessage(event) {
        let data = event.data;
        let serverMessageDV = null;
        if (typeof data === 'string') {
            let parsedMsg = JSON.parse(data);
            if (parsedMsg.IsAuthenticated) {
                let accCredObj = this.parentObj.internalGetAccountCredentialsObject();
                accCredObj.SessionToken = parsedMsg.ApexSessionToken;
                let authHelper = this.parentObj.internalGetAuthHelperObject();
                authHelper.triggerReceivedSessionToken(this.parentObj);
                if (parsedMsg.GapFillComplete) {
                    parsedMsg.AccountIDs.forEach((accountId) => {
                        this.GetAccountState(accountId);
                    });
                    this.isReady = true;
                    this.parentObj.internalAccountConnectionReady(this);
                }
            }
            else {
                this.parentObj.internalAccountConnectionClosed(this);
                return;
            }
        }
        else if (data instanceof ArrayBuffer) {
            serverMessageDV = new DataView(data);
        }
        if (serverMessageDV != null) {
            let userMsgType = User_InputMessageHeader.GetMessageType(serverMessageDV);
            let output = User_MessageType_ToInstanceHelper.User_MessageType_ToInstance(serverMessageDV);
            if (userMsgType == User_MessageType.User_AccountProductState_Output) {
                let msg = output;
                let accState = this.GetAccountState(msg.AccountId);
                accState._ProcessAccountProductState(output);
            }
            else if (userMsgType == User_MessageType.User_OrderState_Output) {
                let msg = output;
                let accState = this.GetAccountState(msg.AccountId);
                if (msg.CurrentOrderState == OrderCurrentState.Rejected) {
                }
                accState._ProcessUserOrderState(msg);
            }
            else if (userMsgType == User_MessageType.User_OrderTrade_Output) {
                let msg = output;
                let accState = this.GetAccountState(msg.AccountId);
                accState._ProcessUserOrderTrade(msg);
            }
        }
    }
    onClose(event) {
        console.log('UserAPI_Account_Connection WS Connection Closed');
        this.isReady = false;
        this.parentObj.internalAccountConnectionClosed(this);
    }
    onError(event) {
        console.log('UserAPI_Account_Connection WS Connection Error', event);
        this.isReady = false;
        this.parentObj.internalAccountConnectionClosed(this);
    }
    resetLocalWebsocket() {
        try {
            if (this.ws !== null) {
                this.ws.onopen = null;
                this.ws.onmessage = null;
                this.ws.onclose = null;
                this.ws.onerror = null;
                this.ws.close();
                this.ws = null;
            }
        }
        catch (err) {
        }
    }
    Destroy() {
        this.resetLocalWebsocket();
    }
    SendBinaryMessage(data) {
        try {
            if (!this.ws)
                return;
            if (this.ws.readyState != this.ws.OPEN)
                return;
            this.ws.send(data);
        }
        catch (err) {
            console.log("Error in Account Connection SendBinaryMessage: " + this.wsUrl + err);
        }
    }
}
export class ReadyStateInfo {
    constructor() {
        this._willDispatch = false;
        this._stateChanged = new QuickEvent();
        this._marketDataReady = this.PreviousMarketDataReady = false;
        this._accountsReady = this.PreviousAccountsReady = false;
        this._instanceConfigReady = this.PreviousInstanceConfigReady = false;
        this._apexGatewayReady = this.PreviousApexGatewayReady = false;
        this._apexGatewayAuthenticated = this.PreviousApexGatewayAuthenticated = false;
        this._instrumentDataSummaryReady = this.PreviousInstrumentDataSummaryReady = false;
        this._globalInstrumentDataFXReady = this.PreviousGlobalInstrumentDataFXReady = false;
    }
    get StateChanged() { return this._stateChanged.Expose(); }
    get MarketDataReady() {
        return this._marketDataReady;
    }
    set MarketDataReady(r) {
        if (this._marketDataReady !== r) {
            this.PreviousMarketDataReady = this._marketDataReady;
            this._marketDataReady = r;
            this.DispatchStateChanged();
        }
    }
    get AccountsReady() {
        return this._accountsReady;
    }
    set AccountsReady(r) {
        if (this._accountsReady !== r) {
            this.PreviousAccountsReady = this._accountsReady;
            this._accountsReady = r;
            this.DispatchStateChanged();
        }
    }
    get InstanceConfigReady() {
        return this._instanceConfigReady;
    }
    set InstanceConfigReady(r) {
        if (this._instanceConfigReady !== r) {
            this.PreviousInstanceConfigReady = this._instanceConfigReady;
            this._instanceConfigReady = r;
            this.DispatchStateChanged();
        }
    }
    get ApexGatewayReady() {
        return this._apexGatewayReady;
    }
    set ApexGatewayReady(r) {
        if (this._apexGatewayReady !== r) {
            this.PreviousApexGatewayReady = this._apexGatewayReady;
            this._apexGatewayReady = r;
            this.DispatchStateChanged();
        }
    }
    get ApexGatewayAuthenticated() {
        return this._apexGatewayAuthenticated;
    }
    set ApexGatewayAuthenticated(a) {
        if (this._apexGatewayAuthenticated !== a) {
            this.PreviousApexGatewayAuthenticated = this._apexGatewayAuthenticated;
            this._apexGatewayAuthenticated = a;
            this.DispatchStateChanged();
        }
    }
    get InstrumentDataSummaryReady() {
        return this._instrumentDataSummaryReady;
    }
    set InstrumentDataSummaryReady(r) {
        if (this._instrumentDataSummaryReady !== r) {
            this.PreviousInstrumentDataSummaryReady = this._instrumentDataSummaryReady;
            this._instrumentDataSummaryReady = r;
            this.DispatchStateChanged();
        }
    }
    get GlobalInstrumentDataFXReady() {
        return this._globalInstrumentDataFXReady;
    }
    set GlobalInstrumentDataFXReady(r) {
        if (this._globalInstrumentDataFXReady !== r) {
            this.PreviousGlobalInstrumentDataFXReady = this._globalInstrumentDataFXReady;
            this._globalInstrumentDataFXReady = r;
            this.DispatchStateChanged();
        }
    }
    Destroy() {
        this._stateChanged.Destroy();
    }
    DispatchStateChanged() {
        this._stateChanged.DispatchEvent(this);
    }
}
export class AccountCredentialsObject {
    constructor() {
        this.AuthMethod = AccountCredentialObject_AuthMethodEnum.None;
        this.UserName = null;
        this.Password = null;
        this.SessionToken = null;
    }
}
export class internalAuthHelperObject {
    constructor() {
        this.receivedSessionTokenEvent = new QuickEvent2();
        this.HasSessionToken = false;
        this.StartedUPAuth = false;
    }
    get ReceivedSessionTokenEvent() { return this.receivedSessionTokenEvent.Expose(); }
    triggerReceivedSessionToken(parent) {
        this.HasSessionToken = true;
        this.receivedSessionTokenEvent.DispatchEvent(parent, this);
    }
}
export class UserAPI {
    constructor() {
        this.connectTimerCounter = 0;
        this.ReferenceData_USD_Symbol = "USDT";
        this.APIState = new APIState();
        this.ReadyState = new ReadyStateInfo();
        this.InstanceConfig = null;
        this.marketDataServers = new Array();
        this.accountServers = new Array();
        this.doConnectMarketData = false;
        this.doConnectAccount = false;
        this.minimumMarketDataServerConnections = 3;
        this.minimumAccountServerConnections = 3;
        this.subscribedInstrumentsL2 = new Set();
        this.subscribedInstrumentsTrades = new Set();
        this.AccountCredentials = null;
        this.internalAuthHelperObj = null;
        this.InstanceId = null;
        this.HA_ClientUserId = Math.floor(Math.random() * 2000000000) + 10000;
        this.HA_ClientSequenceNumber = 0n;
        this.GlobalInstrumentData = new UserAPI_GlobalInstrumentData_Connection(this);
        setInterval(this.connectTimerFcn.bind(this), 500);
    }
    GetConnectedMarketDataServersCount() {
        let connectedMarketDataServers = 0;
        for (let i = 0; i < this.marketDataServers.length; i++) {
            let marketDataServer = this.marketDataServers[i];
            if (marketDataServer.IsConnected())
                connectedMarketDataServers++;
        }
        return connectedMarketDataServers;
    }
    GetReadyAccountServersCount() {
        let connectedAccountServers = 0;
        for (let i = 0; i < this.accountServers.length; i++) {
            let accountServer = this.accountServers[i];
            if (accountServer.IsReady())
                connectedAccountServers++;
        }
        return connectedAccountServers;
    }
    get_Next_HA_ClientSequenceNumber() {
        this.HA_ClientSequenceNumber++;
        return this.HA_ClientSequenceNumber;
    }
    connectTimerFcn() {
        this.connectTimerCounter++;
        if (this.connectTimerCounter >= 100000) {
            this.connectTimerCounter = 0;
        }
        if (this.doConnectMarketData && this.ReadyState.InstanceConfigReady) {
            let connectedOrConnectingMarketDataServers = 0;
            for (let i = 0; i < this.marketDataServers.length; i++) {
                let marketDataServer = this.marketDataServers[i];
                if (marketDataServer.IsConnected() || marketDataServer.IsConnecting()) {
                    connectedOrConnectingMarketDataServers++;
                }
                if (marketDataServer.IsConnected()) {
                    if (this.connectTimerCounter % 100 == 0) {
                        let heartbeatMsg = new User_ControlMessage_Output();
                        heartbeatMsg.ControlMessageAction = User_ControlMessage_Action.Status_Heartbeat;
                        marketDataServer.SendBinaryMessage(heartbeatMsg.ToArrayBuffer());
                    }
                }
            }
            let connectionsRemainingToTry = this.minimumMarketDataServerConnections - connectedOrConnectingMarketDataServers;
            if (connectionsRemainingToTry > 0) {
                let localMarketDataServers = new Array(...this.marketDataServers);
                for (let i = 0; i < localMarketDataServers.length; i++) {
                    let randomNumberWithinRange = Math.floor(Math.random() * localMarketDataServers.length);
                    let marketDataServer = localMarketDataServers[randomNumberWithinRange];
                    if (marketDataServer.IsConnected() == false && marketDataServer.IsConnecting() == false) {
                        connectionsRemainingToTry--;
                        marketDataServer.TryConnect();
                    }
                    localMarketDataServers = localMarketDataServers.splice(randomNumberWithinRange, 1);
                    if (connectionsRemainingToTry == 0) {
                        break;
                    }
                }
            }
        }
        if (this.doConnectAccount && this.AccountCredentials != null) {
            let connectedOrConnectingAccountServers = 0;
            for (let i = 0; i < this.accountServers.length; i++) {
                let accServer = this.accountServers[i];
                if (accServer.IsConnected() || accServer.IsConnecting()) {
                    connectedOrConnectingAccountServers++;
                }
                if (accServer.IsConnected()) {
                    if (this.connectTimerCounter % 100 == 0) {
                        let heartbeatMsg = new User_ControlMessage_Output();
                        heartbeatMsg.ControlMessageAction = User_ControlMessage_Action.Status_Heartbeat;
                        accServer.SendBinaryMessage(heartbeatMsg.ToArrayBuffer());
                    }
                }
            }
            let connectionsRemainingToTry = this.minimumAccountServerConnections - connectedOrConnectingAccountServers;
            if (connectionsRemainingToTry > 0) {
                let localAccountServers = new Array(...this.accountServers);
                for (let i = 0; i < localAccountServers.length; i++) {
                    let randomNumberWithinRange = Math.floor(Math.random() * localAccountServers.length);
                    let accServer = localAccountServers[randomNumberWithinRange];
                    if (accServer.IsConnected() == false && accServer.IsConnecting() == false) {
                        connectionsRemainingToTry--;
                        accServer.TryConnect();
                    }
                    localAccountServers = localAccountServers.splice(randomNumberWithinRange, 1);
                    if (connectionsRemainingToTry == 0) {
                        break;
                    }
                }
            }
        }
    }
    Destroy() {
        this.ReadyState.Destroy();
    }
    SetAPIConfig(config, cbConfigUpdated) {
        this.APIConfig = config;
        if (config.APEXGateway) {
            this.initializeApexGatewayAPI();
        }
        this.GlobalInstrumentData.BaseFileServerUrl = config.GlobalInstrumentDataServer;
        this.updateInstanceConfig_part2(config.InstanceId, config.GatewayServers, cbConfigUpdated);
    }
    updateInstanceConfig(instanceId = null, cbConfigUpdated) {
        fetch('config.json')
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            let config = data;
            if (config != null) {
                this.APIConfig = config;
                this.initializeApexGatewayAPI();
                this.GlobalInstrumentData.BaseFileServerUrl = config.GlobalInstrumentDataServer;
                this.updateInstanceConfig_part2(config.InstanceId, config.GatewayServers, cbConfigUpdated);
            }
        }).catch((error) => {
            console.log('error getting config.json', error);
        });
    }
    initializeApexGatewayAPI() {
        if (this.APIConfig.hasOwnProperty('APEXGateway')) {
            if (this.apexGatewayAPI) {
                this.apexGatewayAPI.Destroy();
                this.ReadyState.ApexGatewayReady = false;
                this.ReadyState.ApexGatewayAuthenticated = false;
            }
            this.apexGatewayAPI = new ApexGatewayAPI();
            this.apexGatewayAPI.ReadyStateChanged.SubscribeEvent(() => {
                this.ReadyState.ApexGatewayReady = this.apexGatewayAPI.IsConnected;
                this.ReadyState.ApexGatewayAuthenticated = this.apexGatewayAPI.IsAuthenticated;
            });
            this.apexGatewayAPI.Connect(this.APIConfig.APEXGateway);
        }
    }
    updateInstanceConfig_part2(instanceId = null, centralServers, cbConfigUpdated) {
        this.InstanceId = instanceId;
        this.InstanceConfig = null;
        this.ReadyState.InstanceConfigReady = false;
        centralServers.forEach((value, index, array) => {
            let fetchUrl = value + '/instance_config/' + instanceId;
            fetch(fetchUrl)
                .then((response) => {
                return response.json();
            })
                .then((data) => {
                if (this.InstanceConfig == null) {
                    let config = data;
                    if (config.hasOwnProperty('InstanceId')) {
                        this.InstanceConfig = config;
                        if (config.InstrumentInfos) {
                            config.InstrumentInfos.sort((insA, insB) => {
                                if (insA.SortIndex > insB.SortIndex) {
                                    return 1;
                                }
                                else if (insA.SortIndex < insB.SortIndex) {
                                    return -1;
                                }
                                else {
                                    return 0;
                                }
                            });
                            for (let i = 0; i < config.InstrumentInfos.length; i++) {
                                let instrumentInfo = config.InstrumentInfos[i];
                                this.APIState.InstrumentInfos.set(instrumentInfo.InstrumentId, instrumentInfo);
                                this.APIState.GetInstrumentState(instrumentInfo.InstrumentId);
                            }
                        }
                        if (config.ProductInfos) {
                            for (let i = 0; i < config.ProductInfos.length; i++) {
                                let prodInfo = config.ProductInfos[i];
                                this.APIState.ProductInfos.set(prodInfo.ProductId, prodInfo);
                            }
                        }
                        this.marketDataServers = new Array();
                        this.accountServers = new Array();
                        if (config.Servers) {
                            for (let i = 0; i < config.Servers.length; i++) {
                                let server = config.Servers[i];
                                if (server.Feature_AccountsAndOrders) {
                                    let accServer = new UserAPI_Account_Connection(this, server.Url);
                                    this.accountServers.push(accServer);
                                }
                                if (server.Feature_MarketData) {
                                    let mdServer = new UserAPI_MarketData_Connection(this, server.Url);
                                    this.marketDataServers.push(mdServer);
                                }
                            }
                        }
                        this.ReadyState.InstanceConfigReady = true;
                        cbConfigUpdated(data);
                    }
                }
            }).catch((error) => {
                console.log('UpdateInstanceConfig Fetch Error on server ' + fetchUrl + ':', error);
            });
        });
    }
    InitializeInstance(instanceId, cbConfigUpdated) {
        this.updateInstanceConfig(instanceId, cbConfigUpdated);
    }
    SetConnectMarketData(enableConnection) {
        this.doConnectMarketData = enableConnection;
        setTimeout(() => { this.connectTimerFcn(); }, 1);
    }
    SetConnectAccount(enableConnection) {
        this.doConnectAccount = enableConnection;
        setTimeout(() => { this.connectTimerFcn(); }, 1);
    }
    SetAccountCredentials(accountCredentials) {
        if (accountCredentials.AuthMethod == AccountCredentialObject_AuthMethodEnum.SessionToken) {
            this.AccountCredentials = accountCredentials;
            this.internalAuthHelperObj = new internalAuthHelperObject();
        }
    }
    internalGetAccountCredentialsObject() {
        return this.AccountCredentials;
    }
    internalGetAuthHelperObject() {
        return this.internalAuthHelperObj;
    }
    RequestResetPassword(username) {
        this.apexGatewayAPI.SendMessage('ResetPassword', {
            UserName: username
        });
    }
    Register(username, email, password, successCallback, failureCallback) {
        this.apexGatewayAPI.Request('RegisterNewUser', {
            "UserInfo": {
                UserName: username,
                Email: email,
                PasswordHash: password
            }
        }, (data) => {
            if (data.hasOwnProperty('UserId')) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }, failureCallback);
    }
    VerifyEmail(userID, verifyCode, verifyURI, successCallback, failureCallback) {
        fetch(verifyURI + 'confirmemail', {
            method: 'POST',
            body: JSON.stringify({
                UserId: userID,
                VerifyEmailCode: verifyCode
            })
        })
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            if (data.hasOwnProperty('result') && data.result === true && !data.errorsmg) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }).catch((error) => {
            failureCallback();
        });
    }
    ResetPassword(userID, password, verifyCode, uri, successCallback, failureCallback) {
        fetch(uri + 'ResetPassword2', {
            method: 'POST',
            body: JSON.stringify({
                UserId: userID,
                Password: password,
                PendingCode: verifyCode
            })
        })
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            if (data.hasOwnProperty('result') && data.result === true && !data.errorsmg) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }).catch((error) => {
            failureCallback();
        });
    }
    ConfirmDevice(userID, hashCode, verifyCode, uri, successCallback, failureCallback) {
        fetch(uri + 'RegisterNewDevice', {
            method: 'POST',
            body: JSON.stringify({
                OMSId: 1,
                PendingEmailCode: verifyCode,
                UserId: userID,
                HashCode: hashCode
            })
        })
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            if (data.hasOwnProperty('result') && data.result === true && !data.errorsmg) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }).catch((error) => {
            failureCallback();
        });
    }
    VerifyWithdrawalAddress(userID, verifyCode, uri, successCallback, failureCallback) {
        fetch(uri + 'ConfirmWithdrawInfo', {
            method: 'POST',
            body: JSON.stringify({
                UserId: userID,
                verifyCode: verifyCode
            })
        })
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            if (data.hasOwnProperty('result') && data.result === true && !data.errorsmg) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }).catch((error) => {
            failureCallback();
        });
    }
    ConfirmWithdrawal(userID, verifyCode, uri, successCallback, failureCallback) {
        fetch(uri + 'confirmwithdraw', {
            method: 'POST',
            body: JSON.stringify({
                UserId: userID,
                verifyCode: verifyCode
            })
        })
            .then((response) => {
            return response.json();
        })
            .then((data) => {
            if (data.hasOwnProperty('result') && data.result === true && !data.errorsmg) {
                successCallback(data);
            }
            else {
                failureCallback();
            }
        }).catch((error) => {
            failureCallback();
        });
    }
    GetOrderFee(accountID, instrumentID, orderType, side, price, quantity, callback) {
        let instrumentInfo = this.APIState.InstrumentInfos.get(instrumentID);
        if (this.apexGatewayAPI.IsConnected && instrumentInfo) {
            this.apexGatewayAPI.Request('GetOrderFee', {
                omsId: 0,
                accountId: accountID,
                instrumentId: instrumentID,
                productId: instrumentInfo.Product1,
                amount: quantity,
                price: price,
                orderType: orderType,
                makerTaker: 0,
                side: side
            }, (data) => {
                callback(data.OrderFee || null);
            }, (error) => {
                callback(null);
            });
        }
        else {
            callback(null);
        }
    }
    SendOrderExtended(accountId, instrumentId, limitPrice, quantity, side, type, tif, stopPrice) {
        let userNewOrderDV = new DataView(new ArrayBuffer(User_AddOrderEx_Input_Offsets.MESSAGE_SIZE));
        User_AddOrderEx_Input.Set_Header_MessageType(userNewOrderDV, User_MessageType.User_AddOrderEx_Input);
        User_AddOrderEx_Input.Set_Header_MessageLength(userNewOrderDV, User_AddOrderEx_Input_Offsets.MESSAGE_SIZE);
        User_AddOrderEx_Input.Set_Header_HA_ClientUserId(userNewOrderDV, this.HA_ClientUserId);
        User_AddOrderEx_Input.Set_Header_HA_ClientSequenceNumber(userNewOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_AddOrderEx_Input.SetAccountId(userNewOrderDV, accountId);
        User_AddOrderEx_Input.SetInstrumentId(userNewOrderDV, instrumentId);
        User_AddOrderEx_Input.SetLimitPrice(userNewOrderDV, limitPrice);
        User_AddOrderEx_Input.SetQuantity(userNewOrderDV, quantity);
        User_AddOrderEx_Input.SetSideEnum(userNewOrderDV, side);
        User_AddOrderEx_Input.SetOrderTypeEnum(userNewOrderDV, type);
        User_AddOrderEx_Input.SetTIFEnum(userNewOrderDV, tif);
        User_AddOrderEx_Input.SetStopPrice(userNewOrderDV, stopPrice);
        let sendAB = userNewOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
    }
    SendLimitOrder(accountId, instrumentId, price, quantity, side, clientOrderId = 0n) {
        let userNewOrderDV = new DataView(new ArrayBuffer(User_AddLimitOrder_Input_Offsets.MESSAGE_SIZE));
        User_AddLimitOrder_Input.Set_Header_MessageType(userNewOrderDV, User_MessageType.User_AddLimitOrder_Input);
        User_AddLimitOrder_Input.Set_Header_MessageLength(userNewOrderDV, User_AddLimitOrder_Input_Offsets.MESSAGE_SIZE);
        User_AddLimitOrder_Input.Set_Header_HA_ClientUserId(userNewOrderDV, this.HA_ClientUserId);
        User_AddLimitOrder_Input.Set_Header_HA_ClientSequenceNumber(userNewOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_AddLimitOrder_Input.SetAccountId(userNewOrderDV, accountId);
        User_AddLimitOrder_Input.SetInstrumentId(userNewOrderDV, instrumentId);
        User_AddLimitOrder_Input.SetLimitPrice(userNewOrderDV, price);
        User_AddLimitOrder_Input.SetQuantity(userNewOrderDV, quantity);
        User_AddLimitOrder_Input.SetSideEnum(userNewOrderDV, side);
        User_AddLimitOrder_Input.SetClientOrderId(userNewOrderDV, clientOrderId);
        let sendAB = userNewOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
    }
    SendMarketOrder(accountId, instrumentId, quantity, side) {
        let userNewOrderDV = new DataView(new ArrayBuffer(User_AddMarketOrder_Input_Offsets.MESSAGE_SIZE));
        User_AddMarketOrder_Input.Set_Header_MessageType(userNewOrderDV, User_MessageType.User_AddMarketOrder_Input);
        User_AddMarketOrder_Input.Set_Header_MessageLength(userNewOrderDV, User_AddMarketOrder_Input_Offsets.MESSAGE_SIZE);
        User_AddMarketOrder_Input.Set_Header_HA_ClientUserId(userNewOrderDV, this.HA_ClientUserId);
        User_AddMarketOrder_Input.Set_Header_HA_ClientSequenceNumber(userNewOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_AddMarketOrder_Input.SetAccountId(userNewOrderDV, accountId);
        User_AddMarketOrder_Input.SetInstrumentId(userNewOrderDV, instrumentId);
        User_AddMarketOrder_Input.SetQuantity(userNewOrderDV, quantity);
        User_AddMarketOrder_Input.SetSideEnum(userNewOrderDV, side);
        let sendAB = userNewOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
    }
    SendCancelOrderByClientOrderId(accountId, instrumentId, clientOrderId) {
        let userCancelOrderDV = new DataView(new ArrayBuffer(User_CancelOrderByClientOrderId_Input_Offsets.MESSAGE_SIZE));
        User_CancelOrderByClientOrderId_Input.Set_Header_MessageType(userCancelOrderDV, User_MessageType.User_CancelOrderByClientOrderId_Input);
        User_CancelOrderByClientOrderId_Input.Set_Header_MessageLength(userCancelOrderDV, User_CancelOrderByClientOrderId_Input_Offsets.MESSAGE_SIZE);
        User_CancelOrderByClientOrderId_Input.Set_Header_HA_ClientUserId(userCancelOrderDV, this.HA_ClientUserId);
        User_CancelOrderByClientOrderId_Input.Set_Header_HA_ClientSequenceNumber(userCancelOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_CancelOrderByClientOrderId_Input.SetAccountId(userCancelOrderDV, accountId);
        User_CancelOrderByClientOrderId_Input.SetInstrumentId(userCancelOrderDV, instrumentId);
        User_CancelOrderByClientOrderId_Input.SetClientOrderId(userCancelOrderDV, clientOrderId);
        let sendAB = userCancelOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
    }
    SendCancelOrderByServerOrderId(accountId, instrumentId, serverOrderId) {
        let userCancelOrderDV = new DataView(new ArrayBuffer(User_CancelOrderByServerOrderId_Input_Offsets.MESSAGE_SIZE));
        User_CancelOrderByServerOrderId_Input.Set_Header_MessageType(userCancelOrderDV, User_MessageType.User_CancelOrderByServerOrderId_Input);
        User_CancelOrderByServerOrderId_Input.Set_Header_MessageLength(userCancelOrderDV, User_CancelOrderByServerOrderId_Input_Offsets.MESSAGE_SIZE);
        User_CancelOrderByServerOrderId_Input.Set_Header_HA_ClientUserId(userCancelOrderDV, this.HA_ClientUserId);
        User_CancelOrderByServerOrderId_Input.Set_Header_HA_ClientSequenceNumber(userCancelOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_CancelOrderByServerOrderId_Input.SetAccountId(userCancelOrderDV, accountId);
        User_CancelOrderByServerOrderId_Input.SetInstrumentId(userCancelOrderDV, instrumentId);
        User_CancelOrderByServerOrderId_Input.SetServerOrderId(userCancelOrderDV, serverOrderId);
        let sendAB = userCancelOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
        this.APIState.AccountStates.get(accountId).OpenOrderStates.delete(serverOrderId);
    }
    SendCancelAllOrders(accountId, instrumentId) {
        let userCancelOrderDV = new DataView(new ArrayBuffer(User_CancelAllOrders_Input_Offsets.MESSAGE_SIZE));
        User_CancelAllOrders_Input.Set_Header_MessageType(userCancelOrderDV, User_MessageType.User_CancelAllOrders_Input);
        User_CancelAllOrders_Input.Set_Header_MessageLength(userCancelOrderDV, User_CancelAllOrders_Input_Offsets.MESSAGE_SIZE);
        User_CancelAllOrders_Input.Set_Header_HA_ClientUserId(userCancelOrderDV, this.HA_ClientUserId);
        User_CancelAllOrders_Input.Set_Header_HA_ClientSequenceNumber(userCancelOrderDV, this.get_Next_HA_ClientSequenceNumber());
        User_CancelAllOrders_Input.SetAccountId(userCancelOrderDV, accountId);
        User_CancelAllOrders_Input.SetInstrumentId(userCancelOrderDV, instrumentId);
        let sendAB = userCancelOrderDV.buffer;
        for (let i = 0; i < this.accountServers.length; i++) {
            this.accountServers[i].SendBinaryMessage(sendAB);
        }
    }
    SendSubscribeUnsubscribeMDTrades(instrumentId, subscribe) {
        let msTradeSub = new User_SubscribeMDTrades_Input();
        msTradeSub.InstrumentId = instrumentId;
        msTradeSub.Subscribe = subscribe ? 1 : 0;
        let sendAB = msTradeSub.ToArrayBuffer();
        let insState = this.APIState.GetInstrumentState(instrumentId);
        for (let i = 0; i < this.marketDataServers.length; i++) {
            this.marketDataServers[i].SendBinaryMessage(sendAB);
        }
        if (subscribe) {
            insState.IsMDSubscribed = true;
            this.subscribedInstrumentsTrades.add(instrumentId);
        }
        else {
            this.subscribedInstrumentsTrades.delete(instrumentId);
            insState.internal_UnsubscribeMD();
        }
    }
    SendSubscribeUnsubscribeL2(instrumentId, subscribe) {
        let msL2Sub = new User_SubscribeL2_Input();
        msL2Sub.InstrumentId = instrumentId;
        msL2Sub.Subscribe = subscribe ? 1 : 0;
        let sendAB = msL2Sub.ToArrayBuffer();
        let insState = this.APIState.GetInstrumentState(instrumentId);
        insState.IsL2Subscribed = subscribe;
        for (let i = 0; i < this.marketDataServers.length; i++) {
            this.marketDataServers[i].SendBinaryMessage(sendAB);
        }
        if (subscribe) {
            this.subscribedInstrumentsL2.add(instrumentId);
        }
        else {
            this.subscribedInstrumentsL2.delete(instrumentId);
            insState.OrderBookAsks.clear();
            insState.OrderBookBids.clear();
        }
    }
    internalAccountConnectionReady(connection) {
        this.checkAndCallReadyStateChanged();
    }
    internalAccountConnectionClosed(connection) {
        this.checkAndCallReadyStateChanged();
    }
    internalMarketDataConnectionReady(connection) {
        setTimeout(() => {
            this.subscribedInstrumentsL2.forEach((value, value2, set) => {
                let insId = value;
                let msL2Sub = new User_SubscribeL2_Input();
                msL2Sub.InstrumentId = insId;
                msL2Sub.Subscribe = 1;
                connection.SendBinaryMessage(msL2Sub.ToArrayBuffer());
                console.log("resubscribing to: " + insId);
            });
            this.subscribedInstrumentsTrades.forEach((value, value2, set) => {
                let insId = value;
                let msg = new User_SubscribeMDTrades_Input();
                msg.InstrumentId = insId;
                msg.Subscribe = 1;
                connection.SendBinaryMessage(msg.ToArrayBuffer());
            });
        }, 100);
        this.checkAndCallReadyStateChanged();
    }
    internalMarketDataConnectionClosed(connection) {
        this.checkAndCallReadyStateChanged();
    }
    checkAndCallReadyStateChanged() {
        let didReadyStateChange = false;
        {
            let accServerReady = false;
            for (let i = 0; i < this.accountServers.length; i++) {
                let accServer = this.accountServers[i];
                if (accServer.IsReady())
                    accServerReady = true;
            }
            if (this.ReadyState.AccountsReady != accServerReady) {
                this.ReadyState.AccountsReady = accServerReady;
                didReadyStateChange = true;
            }
        }
        {
            let mdServerReady = false;
            for (let i = 0; i < this.marketDataServers.length; i++) {
                let mdServer = this.marketDataServers[i];
                if (mdServer.IsConnected())
                    mdServerReady = true;
            }
            if (this.ReadyState.MarketDataReady != mdServerReady) {
                this.ReadyState.MarketDataReady = mdServerReady;
                didReadyStateChange = true;
            }
        }
        if (didReadyStateChange) {
            console.log("readystate changed");
        }
    }
}
