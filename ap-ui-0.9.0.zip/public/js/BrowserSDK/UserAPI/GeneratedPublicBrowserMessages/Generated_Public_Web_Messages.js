export var User_MessageType;
(function (User_MessageType) {
    User_MessageType[User_MessageType["User_AddLimitOrder_Input"] = 10] = "User_AddLimitOrder_Input";
    User_MessageType[User_MessageType["User_AddMarketOrder_Input"] = 11] = "User_AddMarketOrder_Input";
    User_MessageType[User_MessageType["User_CancelReplaceLimitOrder_Input"] = 12] = "User_CancelReplaceLimitOrder_Input";
    User_MessageType[User_MessageType["User_CancelOrderByClientOrderId_Input"] = 13] = "User_CancelOrderByClientOrderId_Input";
    User_MessageType[User_MessageType["User_CancelOrderByServerOrderId_Input"] = 14] = "User_CancelOrderByServerOrderId_Input";
    User_MessageType[User_MessageType["User_SubscribeMDTrades_Input"] = 15] = "User_SubscribeMDTrades_Input";
    User_MessageType[User_MessageType["User_SubscribeL2_Input"] = 16] = "User_SubscribeL2_Input";
    User_MessageType[User_MessageType["User_CancelAllOrders_Input"] = 17] = "User_CancelAllOrders_Input";
    User_MessageType[User_MessageType["User_MDH_SubscribeBarItems_Input"] = 18] = "User_MDH_SubscribeBarItems_Input";
    User_MessageType[User_MessageType["User_AddOrderEx_Input"] = 19] = "User_AddOrderEx_Input";
    User_MessageType[User_MessageType["User_GenericReject_Output"] = 100] = "User_GenericReject_Output";
    User_MessageType[User_MessageType["User_OrderState_Output"] = 101] = "User_OrderState_Output";
    User_MessageType[User_MessageType["User_OrderTrade_Output"] = 102] = "User_OrderTrade_Output";
    User_MessageType[User_MessageType["User_AccountProductState_Output"] = 103] = "User_AccountProductState_Output";
    User_MessageType[User_MessageType["User_ControlMessage_Output"] = 104] = "User_ControlMessage_Output";
    User_MessageType[User_MessageType["User_MD_L2_ControlMessage_Output"] = 150] = "User_MD_L2_ControlMessage_Output";
    User_MessageType[User_MessageType["User_MD_L1_Update_Output"] = 152] = "User_MD_L1_Update_Output";
    User_MessageType[User_MessageType["User_MD_TradeUpdate_Output"] = 153] = "User_MD_TradeUpdate_Output";
    User_MessageType[User_MessageType["User_MD_OrderState_Output"] = 154] = "User_MD_OrderState_Output";
    User_MessageType[User_MessageType["User_MD_L2_LevelUpdateBid_Output"] = 155] = "User_MD_L2_LevelUpdateBid_Output";
    User_MessageType[User_MessageType["User_MD_L2_LevelUpdateAsk_Output"] = 156] = "User_MD_L2_LevelUpdateAsk_Output";
    User_MessageType[User_MessageType["User_MD_L2_LevelUpdateBatch1_Output"] = 157] = "User_MD_L2_LevelUpdateBatch1_Output";
    User_MessageType[User_MessageType["User_MD_TradeUpdateBatch1_Output"] = 158] = "User_MD_TradeUpdateBatch1_Output";
    User_MessageType[User_MessageType["User_MDH_BarHeader_BinaryObject_Header"] = 200] = "User_MDH_BarHeader_BinaryObject_Header";
    User_MessageType[User_MessageType["User_MDH_BarItem_Type1_BinaryObject_Item"] = 201] = "User_MDH_BarItem_Type1_BinaryObject_Item";
})(User_MessageType || (User_MessageType = {}));
export var RejectReason;
(function (RejectReason) {
    RejectReason[RejectReason["No_Response"] = 1000] = "No_Response";
    RejectReason[RejectReason["Invalid_Product_Pair"] = 10001] = "Invalid_Product_Pair";
    RejectReason[RejectReason["Invalid_Product_Id"] = 10002] = "Invalid_Product_Id";
    RejectReason[RejectReason["Invalid_Product_1_Id"] = 10003] = "Invalid_Product_1_Id";
    RejectReason[RejectReason["Invalid_Product_2_Id"] = 10004] = "Invalid_Product_2_Id";
    RejectReason[RejectReason["Invalid_Account_Id"] = 10005] = "Invalid_Account_Id";
    RejectReason[RejectReason["Invalid_Sub_Account_Id"] = 10006] = "Invalid_Sub_Account_Id";
    RejectReason[RejectReason["Invalid_OCO_Order_Id"] = 10007] = "Invalid_OCO_Order_Id";
    RejectReason[RejectReason["Invalid_Remaining_Quantity"] = 10008] = "Invalid_Remaining_Quantity";
    RejectReason[RejectReason["Invalid_Stop_Price"] = 10009] = "Invalid_Stop_Price";
    RejectReason[RejectReason["Invalid_Limit_Price"] = 10010] = "Invalid_Limit_Price";
    RejectReason[RejectReason["Invalid_ClientOrderId"] = 10011] = "Invalid_ClientOrderId";
    RejectReason[RejectReason["OMS_ID_IN_USE"] = 10012] = "OMS_ID_IN_USE";
    RejectReason[RejectReason["OMSIdNotFound"] = 10013] = "OMSIdNotFound";
    RejectReason[RejectReason["Invalid_Order_Quantity"] = 10014] = "Invalid_Order_Quantity";
    RejectReason[RejectReason["Invalid_Order_TickSize"] = 10015] = "Invalid_Order_TickSize";
    RejectReason[RejectReason["Another_Instrument_Already_Mapped_To_VenueInstrument"] = 10016] = "Another_Instrument_Already_Mapped_To_VenueInstrument";
    RejectReason[RejectReason["Invalid_Order_Id"] = 10017] = "Invalid_Order_Id";
    RejectReason[RejectReason["Invalid_Display_Qty"] = 10018] = "Invalid_Display_Qty";
    RejectReason[RejectReason["Invalid_Order_Exposure"] = 10019] = "Invalid_Order_Exposure";
    RejectReason[RejectReason["Less_Than_Minimum_Quantity"] = 10020] = "Less_Than_Minimum_Quantity";
    RejectReason[RejectReason["Less_Than_Minimum_Price"] = 10021] = "Less_Than_Minimum_Price";
    RejectReason[RejectReason["Invalid_Quantity_Add"] = 10022] = "Invalid_Quantity_Add";
    RejectReason[RejectReason["Invalid_Quantity_Subtract"] = 10023] = "Invalid_Quantity_Subtract";
    RejectReason[RejectReason["Invalid_Quote_AccountId_Side"] = 10024] = "Invalid_Quote_AccountId_Side";
    RejectReason[RejectReason["Instrument_Disabled"] = 10025] = "Instrument_Disabled";
    RejectReason[RejectReason["Already_Cancel_Replaced"] = 10026] = "Already_Cancel_Replaced";
    RejectReason[RejectReason["Unknown_Product_Pair"] = 10200] = "Unknown_Product_Pair";
    RejectReason[RejectReason["Unknown_Product_Id"] = 10201] = "Unknown_Product_Id";
    RejectReason[RejectReason["Unknown_Product_1_Id"] = 10202] = "Unknown_Product_1_Id";
    RejectReason[RejectReason["Unknown_Product_2_Id"] = 10203] = "Unknown_Product_2_Id";
    RejectReason[RejectReason["Unknown_Account_Id"] = 10204] = "Unknown_Account_Id";
    RejectReason[RejectReason["Unknown_Sub_Account_Id"] = 10205] = "Unknown_Sub_Account_Id";
    RejectReason[RejectReason["Unknown_Deposit_Mode"] = 10206] = "Unknown_Deposit_Mode";
    RejectReason[RejectReason["Unknown_Side"] = 10207] = "Unknown_Side";
    RejectReason[RejectReason["Unknown_Order_Type"] = 10208] = "Unknown_Order_Type";
    RejectReason[RejectReason["Unknown_Peg_Price_Type"] = 10209] = "Unknown_Peg_Price_Type";
    RejectReason[RejectReason["Unknown_Exchange_Risk_Mode"] = 10210] = "Unknown_Exchange_Risk_Mode";
    RejectReason[RejectReason["Unknown_Info_Message_Type"] = 10212] = "Unknown_Info_Message_Type";
    RejectReason[RejectReason["Unknown_Product_Venue_Id"] = 10213] = "Unknown_Product_Venue_Id";
    RejectReason[RejectReason["UnKnown_Margin_Adapter"] = 10214] = "UnKnown_Margin_Adapter";
    RejectReason[RejectReason["UnKnown_Margin_Product_Venue_Adapter_Id"] = 10215] = "UnKnown_Margin_Product_Venue_Adapter_Id";
    RejectReason[RejectReason["Unsupported_Peg_Price_Type"] = 10300] = "Unsupported_Peg_Price_Type";
    RejectReason[RejectReason["Unsupported_Normalized_Calc_Mode"] = 10301] = "Unsupported_Normalized_Calc_Mode";
    RejectReason[RejectReason["Unsupported_Operation"] = 10303] = "Unsupported_Operation";
    RejectReason[RejectReason["No_Buy_Side_Market"] = 10500] = "No_Buy_Side_Market";
    RejectReason[RejectReason["No_Sell_Side_Market"] = 10501] = "No_Sell_Side_Market";
    RejectReason[RejectReason["Not_Enough_Funds"] = 10502] = "Not_Enough_Funds";
    RejectReason[RejectReason["Not_Enough_Borrowing_Power"] = 10503] = "Not_Enough_Borrowing_Power";
    RejectReason[RejectReason["Not_Enough_Simple_Margin"] = 10504] = "Not_Enough_Simple_Margin";
    RejectReason[RejectReason["Not_Enough_Global_Margin"] = 10505] = "Not_Enough_Global_Margin";
    RejectReason[RejectReason["Not_Enough_Liquidity_To_Convert_Order"] = 10506] = "Not_Enough_Liquidity_To_Convert_Order";
    RejectReason[RejectReason["Not_Enough_Liquidity_To_Convert_Asset"] = 10507] = "Not_Enough_Liquidity_To_Convert_Asset";
    RejectReason[RejectReason["Margin_Not_Supported_On_This_Product"] = 10508] = "Margin_Not_Supported_On_This_Product";
    RejectReason[RejectReason["Order_Not_Found"] = 10509] = "Order_Not_Found";
    RejectReason[RejectReason["Too_Late_For_OCO"] = 10510] = "Too_Late_For_OCO";
    RejectReason[RejectReason["OCO_Not_From_Same_Account"] = 10511] = "OCO_Not_From_Same_Account";
    RejectReason[RejectReason["Edit_Not_Supported"] = 10512] = "Edit_Not_Supported";
    RejectReason[RejectReason["MarketOrder_Entered_With_LimitPrice"] = 10513] = "MarketOrder_Entered_With_LimitPrice";
    RejectReason[RejectReason["Conversion_Param_Not_Found"] = 10514] = "Conversion_Param_Not_Found";
    RejectReason[RejectReason["Remaining_Quantity_Below_Minimum"] = 10515] = "Remaining_Quantity_Below_Minimum";
    RejectReason[RejectReason["Display_Quantity_Below_Minimum"] = 10516] = "Display_Quantity_Below_Minimum";
    RejectReason[RejectReason["Exchange_Not_Found"] = 10517] = "Exchange_Not_Found";
    RejectReason[RejectReason["Client_OrderId_Not_Found"] = 10518] = "Client_OrderId_Not_Found";
    RejectReason[RejectReason["Invalid_Exposure"] = 10519] = "Invalid_Exposure";
    RejectReason[RejectReason["SelfTrading_Prevention"] = 10520] = "SelfTrading_Prevention";
    RejectReason[RejectReason["Allow_Only_Market_Maker_Counter_Party"] = 10523] = "Allow_Only_Market_Maker_Counter_Party";
    RejectReason[RejectReason["Invalid_Limit_Price_Below_Floor"] = 10524] = "Invalid_Limit_Price_Below_Floor";
    RejectReason[RejectReason["Invalid_Limit_Price_Above_Ceiling"] = 10525] = "Invalid_Limit_Price_Above_Ceiling";
    RejectReason[RejectReason["Invalid_Stop_Price_Below_Floor"] = 10526] = "Invalid_Stop_Price_Below_Floor";
    RejectReason[RejectReason["Invalid_Stop_Price_Above_Ceiling"] = 10527] = "Invalid_Stop_Price_Above_Ceiling";
    RejectReason[RejectReason["Margin_Quote_Not_Found"] = 10530] = "Margin_Quote_Not_Found";
    RejectReason[RejectReason["Margin_Not_Enough_Liquidity"] = 10531] = "Margin_Not_Enough_Liquidity";
    RejectReason[RejectReason["Margin_Initial_Requirement_Not_Met"] = 10532] = "Margin_Initial_Requirement_Not_Met";
    RejectReason[RejectReason["Margin_Not_Supported_On_This_Account"] = 10533] = "Margin_Not_Supported_On_This_Account";
    RejectReason[RejectReason["Margin_Account_State_Not_Available"] = 10558] = "Margin_Account_State_Not_Available";
    RejectReason[RejectReason["Margin_Account_Product_State_Not_Available"] = 10559] = "Margin_Account_Product_State_Not_Available";
    RejectReason[RejectReason["Margin_Account_Not_Enough_Available"] = 10560] = "Margin_Account_Not_Enough_Available";
    RejectReason[RejectReason["Margin_Acquisition_Halted"] = 10561] = "Margin_Acquisition_Halted";
    RejectReason[RejectReason["Margin_Position_Not_Open"] = 10562] = "Margin_Position_Not_Open";
    RejectReason[RejectReason["Margin_Position_Not_Found"] = 10563] = "Margin_Position_Not_Found";
    RejectReason[RejectReason["Not_Enough_Market_And_Not_Enough_Borrowed_Funds"] = 10564] = "Not_Enough_Market_And_Not_Enough_Borrowed_Funds";
    RejectReason[RejectReason["Remaining_Quantity_Not_Divisible_By_Increment"] = 10565] = "Remaining_Quantity_Not_Divisible_By_Increment";
    RejectReason[RejectReason["Margin_Rejected_With_Opposite_Side_Limit_Order_In_Book"] = 10566] = "Margin_Rejected_With_Opposite_Side_Limit_Order_In_Book";
    RejectReason[RejectReason["Margin_Account_State_Not_In_Correct_State"] = 10567] = "Margin_Account_State_Not_In_Correct_State";
    RejectReason[RejectReason["Account_Verification_Level_Not_Found"] = 10600] = "Account_Verification_Level_Not_Found";
    RejectReason[RejectReason["Exceeds_Daily_Limit"] = 10601] = "Exceeds_Daily_Limit";
    RejectReason[RejectReason["Exceeds_Daily_Deposit_Limit"] = 10602] = "Exceeds_Daily_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Daily_Withdraw_Limit"] = 10603] = "Exceeds_Daily_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Monthly_Withdraw_Limit"] = 10604] = "Exceeds_Monthly_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Available_Balance"] = 10605] = "Exceeds_Available_Balance";
    RejectReason[RejectReason["Exceeds_Monthly_Deposit_Limit"] = 10606] = "Exceeds_Monthly_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Yearly_Deposit_Limit"] = 10607] = "Exceeds_Yearly_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Yearly_Withdraw_Limit"] = 10608] = "Exceeds_Yearly_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Margin_Limit"] = 10609] = "Exceeds_Margin_Limit";
    RejectReason[RejectReason["Exceeds_Yearly_Notional_Deposit_Limit"] = 10610] = "Exceeds_Yearly_Notional_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Yearly_Notional_Withdraw_Limit"] = 10611] = "Exceeds_Yearly_Notional_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Monthly_Limit"] = 10612] = "Exceeds_Monthly_Limit";
    RejectReason[RejectReason["Invalid_Amount"] = 10613] = "Invalid_Amount";
    RejectReason[RejectReason["Exceeds_Daily_Notional_Limit"] = 10614] = "Exceeds_Daily_Notional_Limit";
    RejectReason[RejectReason["Exceeds_Monthly_Notional_Limit"] = 10615] = "Exceeds_Monthly_Notional_Limit";
    RejectReason[RejectReason["Exceeds_Yearly_Notional_Limit"] = 10616] = "Exceeds_Yearly_Notional_Limit";
    RejectReason[RejectReason["Exceeds_Daily_Notional_Withdraw_Limit"] = 10617] = "Exceeds_Daily_Notional_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Monthly_Notional_Withdraw_Limit"] = 10618] = "Exceeds_Monthly_Notional_Withdraw_Limit";
    RejectReason[RejectReason["Exceeds_Daily_Notional_Deposit_Limit"] = 10619] = "Exceeds_Daily_Notional_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Monthly_Notional_Deposit_Limit"] = 10620] = "Exceeds_Monthly_Notional_Deposit_Limit";
    RejectReason[RejectReason["Exceeds_Open_Order_Limit"] = 10621] = "Exceeds_Open_Order_Limit";
    RejectReason[RejectReason["Transfer_Transaction_Set_Failed"] = 10700] = "Transfer_Transaction_Set_Failed";
    RejectReason[RejectReason["Transfer_Account_No_Hold"] = 10701] = "Transfer_Account_No_Hold";
    RejectReason[RejectReason["Transfer_Account_Not_Found"] = 10702] = "Transfer_Account_Not_Found";
    RejectReason[RejectReason["Transfer_Account_Product_Not_Found"] = 10703] = "Transfer_Account_Product_Not_Found";
    RejectReason[RejectReason["Transfer_Not_Accepted"] = 10704] = "Transfer_Not_Accepted";
    RejectReason[RejectReason["Transfer_Failed"] = 10705] = "Transfer_Failed";
    RejectReason[RejectReason["Transfer_Negative_Balance"] = 10706] = "Transfer_Negative_Balance";
    RejectReason[RejectReason["Deposit_Transaction_Set_Failed"] = 10800] = "Deposit_Transaction_Set_Failed";
    RejectReason[RejectReason["Deposit_Account_Not_Found"] = 10801] = "Deposit_Account_Not_Found";
    RejectReason[RejectReason["Deposit_Product_Not_Found"] = 10802] = "Deposit_Product_Not_Found";
    RejectReason[RejectReason["Deposit_Not_Accepted"] = 10803] = "Deposit_Not_Accepted";
    RejectReason[RejectReason["Deposit_Failed"] = 10804] = "Deposit_Failed";
    RejectReason[RejectReason["Withdraw_Asset_Not_Found"] = 10899] = "Withdraw_Asset_Not_Found";
    RejectReason[RejectReason["Withdraw_Transaction_Set_Failed"] = 10900] = "Withdraw_Transaction_Set_Failed";
    RejectReason[RejectReason["Withdraw_Account_Not_Found"] = 10901] = "Withdraw_Account_Not_Found";
    RejectReason[RejectReason["Withdraw_Product_Not_Found"] = 10902] = "Withdraw_Product_Not_Found";
    RejectReason[RejectReason["Withdraw_Not_Accepted"] = 10903] = "Withdraw_Not_Accepted";
    RejectReason[RejectReason["Withdraw_Failed"] = 10904] = "Withdraw_Failed";
    RejectReason[RejectReason["Withdraw_Account_No_Hold"] = 10905] = "Withdraw_Account_No_Hold";
    RejectReason[RejectReason["Withdraw_Ticket_Invalid_State"] = 10906] = "Withdraw_Ticket_Invalid_State";
    RejectReason[RejectReason["Withdraw_Submission_Failed"] = 10907] = "Withdraw_Submission_Failed";
    RejectReason[RejectReason["Withdraw_AssetManager_Request_Failed"] = 10908] = "Withdraw_AssetManager_Request_Failed";
    RejectReason[RejectReason["Withdraw_AssetManager_Not_Connected"] = 10909] = "Withdraw_AssetManager_Not_Connected";
    RejectReason[RejectReason["Withdraw_Address_Not_Whitelisted"] = 10910] = "Withdraw_Address_Not_Whitelisted";
    RejectReason[RejectReason["Withdraw_Address_Not_Confirmed"] = 10911] = "Withdraw_Address_Not_Confirmed";
    RejectReason[RejectReason["Withdraw_AML_Failed"] = 10999] = "Withdraw_AML_Failed";
    RejectReason[RejectReason["Market_Closed"] = 11000] = "Market_Closed";
    RejectReason[RejectReason["Market_Paused"] = 11001] = "Market_Paused";
    RejectReason[RejectReason["AddHoldFailed"] = 11100] = "AddHoldFailed";
    RejectReason[RejectReason["ReverseHoldFailed"] = 11101] = "ReverseHoldFailed";
    RejectReason[RejectReason["Product_Already_Exists"] = 18000] = "Product_Already_Exists";
    RejectReason[RejectReason["Exceeds_Net_Owed"] = 19000] = "Exceeds_Net_Owed";
    RejectReason[RejectReason["Exceeds_Exposure"] = 19001] = "Exceeds_Exposure";
    RejectReason[RejectReason["Invalid_Credit_Tier"] = 19002] = "Invalid_Credit_Tier";
    RejectReason[RejectReason["Invalid_Risk_Type"] = 19003] = "Invalid_Risk_Type";
})(RejectReason || (RejectReason = {}));
export class User_MessageType_ToInstanceHelper {
    static User_MessageType_ToInstance(msgDV) {
        let msgType = msgDV.getInt16(2, true);
        if (User_MessageType.User_AddLimitOrder_Input == msgType) {
            let msgOut = User_AddLimitOrder_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_AddMarketOrder_Input == msgType) {
            let msgOut = User_AddMarketOrder_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_CancelReplaceLimitOrder_Input == msgType) {
            let msgOut = User_CancelReplaceLimitOrder_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_CancelOrderByClientOrderId_Input == msgType) {
            let msgOut = User_CancelOrderByClientOrderId_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_CancelOrderByServerOrderId_Input == msgType) {
            let msgOut = User_CancelOrderByServerOrderId_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_SubscribeMDTrades_Input == msgType) {
            let msgOut = User_SubscribeMDTrades_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_SubscribeL2_Input == msgType) {
            let msgOut = User_SubscribeL2_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_CancelAllOrders_Input == msgType) {
            let msgOut = User_CancelAllOrders_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MDH_SubscribeBarItems_Input == msgType) {
            let msgOut = User_MDH_SubscribeBarItems_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_AddOrderEx_Input == msgType) {
            let msgOut = User_AddOrderEx_Input.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_GenericReject_Output == msgType) {
            let msgOut = User_GenericReject_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_OrderState_Output == msgType) {
            let msgOut = User_OrderState_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_OrderTrade_Output == msgType) {
            let msgOut = User_OrderTrade_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_AccountProductState_Output == msgType) {
            let msgOut = User_AccountProductState_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_ControlMessage_Output == msgType) {
            let msgOut = User_ControlMessage_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_L2_ControlMessage_Output == msgType) {
            let msgOut = User_MD_L2_ControlMessage_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_L1_Update_Output == msgType) {
            let msgOut = User_MD_L1_Update_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_TradeUpdate_Output == msgType) {
            let msgOut = User_MD_TradeUpdate_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_OrderState_Output == msgType) {
            let msgOut = User_MD_OrderState_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_L2_LevelUpdateBid_Output == msgType) {
            let msgOut = User_MD_L2_LevelUpdateBid_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_L2_LevelUpdateAsk_Output == msgType) {
            let msgOut = User_MD_L2_LevelUpdateAsk_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_L2_LevelUpdateBatch1_Output == msgType) {
            let msgOut = User_MD_L2_LevelUpdateBatch1_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MD_TradeUpdateBatch1_Output == msgType) {
            let msgOut = User_MD_TradeUpdateBatch1_Output.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MDH_BarHeader_BinaryObject_Header == msgType) {
            let msgOut = User_MDH_BarHeader_BinaryObject_Header.FromBytes(msgDV);
            return msgOut;
        }
        else if (User_MessageType.User_MDH_BarItem_Type1_BinaryObject_Item == msgType) {
            let msgOut = User_MDH_BarItem_Type1_BinaryObject_Item.FromBytes(msgDV);
            return msgOut;
        }
        return null;
    }
}
export var User_InputMessageHeader_Offsets;
(function (User_InputMessageHeader_Offsets) {
    User_InputMessageHeader_Offsets[User_InputMessageHeader_Offsets["MESSAGE_SIZE"] = 16] = "MESSAGE_SIZE";
    User_InputMessageHeader_Offsets[User_InputMessageHeader_Offsets["MessageLength"] = 0] = "MessageLength";
    User_InputMessageHeader_Offsets[User_InputMessageHeader_Offsets["MessageType"] = 2] = "MessageType";
    User_InputMessageHeader_Offsets[User_InputMessageHeader_Offsets["HA_ClientUserId"] = 4] = "HA_ClientUserId";
    User_InputMessageHeader_Offsets[User_InputMessageHeader_Offsets["HA_ClientSequenceNumber"] = 8] = "HA_ClientSequenceNumber";
})(User_InputMessageHeader_Offsets || (User_InputMessageHeader_Offsets = {}));
export class User_InputMessageHeader {
    constructor() {
        this.MessageLength = 0;
        this.MessageType = 0;
        this.HA_ClientUserId = 0;
        this.HA_ClientSequenceNumber = 0n;
    }
    static FromBytes(dv) {
        let rv = new User_InputMessageHeader();
        rv.MessageLength = dv.getInt16(0, true);
        rv.MessageType = dv.getInt16(2, true);
        rv.HA_ClientUserId = dv.getInt32(4, true);
        rv.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(16);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.MessageLength, true);
        dv.setInt16(offset + 2, this.MessageType, true);
        dv.setInt32(offset + 4, this.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.HA_ClientSequenceNumber, true);
    }
    static GetMessageLength(dv) { return dv.getInt16(0, true); }
    static SetMessageLength(dv, val) { dv.setInt16(0, val, true); }
    static GetMessageType(dv) { return dv.getInt16(2, true); }
    static SetMessageType(dv, val) { dv.setInt16(2, val, true); }
    static GetHA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static SetHA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static GetHA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static SetHA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
}
export var User_OutputMessageHeader_Offsets;
(function (User_OutputMessageHeader_Offsets) {
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["MESSAGE_SIZE"] = 32] = "MESSAGE_SIZE";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["MessageLength"] = 0] = "MessageLength";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["MessageType"] = 2] = "MessageType";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["HA_ServerIdentifier"] = 4] = "HA_ServerIdentifier";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["HA_ServerSequenceNumber"] = 8] = "HA_ServerSequenceNumber";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["HA_ClientSequenceNumber"] = 16] = "HA_ClientSequenceNumber";
    User_OutputMessageHeader_Offsets[User_OutputMessageHeader_Offsets["OutputMessageTimeStamp"] = 24] = "OutputMessageTimeStamp";
})(User_OutputMessageHeader_Offsets || (User_OutputMessageHeader_Offsets = {}));
export class User_OutputMessageHeader {
    constructor() {
        this.MessageLength = 0;
        this.MessageType = 0;
        this.HA_ServerIdentifier = 0;
        this.HA_ServerSequenceNumber = 0n;
        this.HA_ClientSequenceNumber = 0n;
        this.OutputMessageTimeStamp = 0;
    }
    static FromBytes(dv) {
        let rv = new User_OutputMessageHeader();
        rv.MessageLength = dv.getInt16(0, true);
        rv.MessageType = dv.getInt16(2, true);
        rv.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.OutputMessageTimeStamp = dv.getFloat64(24, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(32);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.MessageLength, true);
        dv.setInt16(offset + 2, this.MessageType, true);
        dv.setInt32(offset + 4, this.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.OutputMessageTimeStamp, true);
    }
    static GetMessageLength(dv) { return dv.getInt16(0, true); }
    static SetMessageLength(dv, val) { dv.setInt16(0, val, true); }
    static GetMessageType(dv) { return dv.getInt16(2, true); }
    static SetMessageType(dv, val) { dv.setInt16(2, val, true); }
    static GetHA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static SetHA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static GetHA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static SetHA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetHA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static SetHA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetOutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static SetOutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
}
export var User_OutputMessageHeaderSmall_Offsets;
(function (User_OutputMessageHeaderSmall_Offsets) {
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["MESSAGE_SIZE"] = 24] = "MESSAGE_SIZE";
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["MessageLength"] = 0] = "MessageLength";
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["MessageType"] = 2] = "MessageType";
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["HA_ServerIdentifier"] = 4] = "HA_ServerIdentifier";
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["HA_ServerSequenceNumber"] = 8] = "HA_ServerSequenceNumber";
    User_OutputMessageHeaderSmall_Offsets[User_OutputMessageHeaderSmall_Offsets["HA_ClientSequenceNumber"] = 16] = "HA_ClientSequenceNumber";
})(User_OutputMessageHeaderSmall_Offsets || (User_OutputMessageHeaderSmall_Offsets = {}));
export class User_OutputMessageHeaderSmall {
    constructor() {
        this.MessageLength = 0;
        this.MessageType = 0;
        this.HA_ServerIdentifier = 0;
        this.HA_ServerSequenceNumber = 0n;
        this.HA_ClientSequenceNumber = 0n;
    }
    static FromBytes(dv) {
        let rv = new User_OutputMessageHeaderSmall();
        rv.MessageLength = dv.getInt16(0, true);
        rv.MessageType = dv.getInt16(2, true);
        rv.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(24);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.MessageLength, true);
        dv.setInt16(offset + 2, this.MessageType, true);
        dv.setInt32(offset + 4, this.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.HA_ClientSequenceNumber, true);
    }
    static GetMessageLength(dv) { return dv.getInt16(0, true); }
    static SetMessageLength(dv, val) { dv.setInt16(0, val, true); }
    static GetMessageType(dv) { return dv.getInt16(2, true); }
    static SetMessageType(dv, val) { dv.setInt16(2, val, true); }
    static GetHA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static SetHA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static GetHA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static SetHA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetHA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static SetHA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
}
export var User_GenericReject_Output_Offsets;
(function (User_GenericReject_Output_Offsets) {
    User_GenericReject_Output_Offsets[User_GenericReject_Output_Offsets["MESSAGE_SIZE"] = 40] = "MESSAGE_SIZE";
    User_GenericReject_Output_Offsets[User_GenericReject_Output_Offsets["Header"] = 0] = "Header";
    User_GenericReject_Output_Offsets[User_GenericReject_Output_Offsets["RejectId"] = 32] = "RejectId";
})(User_GenericReject_Output_Offsets || (User_GenericReject_Output_Offsets = {}));
export class User_GenericReject_Output {
    constructor() {
        this.RejectId = 0n;
        this.Header = new User_OutputMessageHeader();
        this.Header.MessageLength = User_GenericReject_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_GenericReject_Output;
        this.Header.OutputMessageTimeStamp = Date.now();
    }
    static FromBytes(dv) {
        let rv = new User_GenericReject_Output();
        rv.Header = new User_OutputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Header.OutputMessageTimeStamp = dv.getFloat64(24, true);
        rv.RejectId = dv.getBigInt64(32, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(40);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Header.OutputMessageTimeStamp, true);
        dv.setBigInt64(offset + 32, this.RejectId, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static Get_Header_OutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static Set_Header_OutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
    static GetRejectId(dv) { return dv.getBigInt64(32, true); }
    static SetRejectId(dv, val) { dv.setBigInt64(32, val, true); }
}
export var User_AddLimitOrder_Input_Offsets;
(function (User_AddLimitOrder_Input_Offsets) {
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["MESSAGE_SIZE"] = 50] = "MESSAGE_SIZE";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["Header"] = 0] = "Header";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["AccountId"] = 16] = "AccountId";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["InstrumentId"] = 20] = "InstrumentId";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["ClientOrderId"] = 24] = "ClientOrderId";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["LimitPrice"] = 32] = "LimitPrice";
    User_AddLimitOrder_Input_Offsets[User_AddLimitOrder_Input_Offsets["Quantity"] = 40] = "Quantity";
})(User_AddLimitOrder_Input_Offsets || (User_AddLimitOrder_Input_Offsets = {}));
export class User_AddLimitOrder_Input {
    constructor() {
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.ClientOrderId = 0n;
        this.LimitPrice = 0;
        this.Quantity = 0;
        this.Side = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_AddLimitOrder_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_AddLimitOrder_Input;
    }
    static FromBytes(dv) {
        let rv = new User_AddLimitOrder_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.AccountId = dv.getInt32(16, true);
        rv.InstrumentId = dv.getInt32(20, true);
        rv.ClientOrderId = dv.getBigInt64(24, true);
        rv.LimitPrice = dv.getFloat64(32, true);
        rv.Quantity = dv.getFloat64(40, true);
        rv.Side = dv.getInt16(48, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(50);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.AccountId, true);
        dv.setInt32(offset + 20, this.InstrumentId, true);
        dv.setBigInt64(offset + 24, this.ClientOrderId, true);
        dv.setFloat64(offset + 32, this.LimitPrice, true);
        dv.setFloat64(offset + 40, this.Quantity, true);
        dv.setInt16(offset + 48, this.Side, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetAccountId(dv) { return dv.getInt32(16, true); }
    static SetAccountId(dv, val) { dv.setInt32(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(20, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(20, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(24, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(24, val, true); }
    static GetLimitPrice(dv) { return dv.getFloat64(32, true); }
    static SetLimitPrice(dv, val) { dv.setFloat64(32, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(40, true); }
    static SetQuantity(dv, val) { dv.setFloat64(40, val, true); }
    static GetSideEnum(dv) { return dv.getInt16(48, true); }
    static SetSideEnum(dv, val) { dv.setInt16(48, val, true); }
}
export var User_AddMarketOrder_Input_Offsets;
(function (User_AddMarketOrder_Input_Offsets) {
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["MESSAGE_SIZE"] = 42] = "MESSAGE_SIZE";
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["Header"] = 0] = "Header";
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["AccountId"] = 16] = "AccountId";
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["InstrumentId"] = 20] = "InstrumentId";
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["ClientOrderId"] = 24] = "ClientOrderId";
    User_AddMarketOrder_Input_Offsets[User_AddMarketOrder_Input_Offsets["Quantity"] = 32] = "Quantity";
})(User_AddMarketOrder_Input_Offsets || (User_AddMarketOrder_Input_Offsets = {}));
export class User_AddMarketOrder_Input {
    constructor() {
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.ClientOrderId = 0n;
        this.Quantity = 0;
        this.Side = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_AddMarketOrder_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_AddMarketOrder_Input;
    }
    static FromBytes(dv) {
        let rv = new User_AddMarketOrder_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.AccountId = dv.getInt32(16, true);
        rv.InstrumentId = dv.getInt32(20, true);
        rv.ClientOrderId = dv.getBigInt64(24, true);
        rv.Quantity = dv.getFloat64(32, true);
        rv.Side = dv.getInt16(40, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(42);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.AccountId, true);
        dv.setInt32(offset + 20, this.InstrumentId, true);
        dv.setBigInt64(offset + 24, this.ClientOrderId, true);
        dv.setFloat64(offset + 32, this.Quantity, true);
        dv.setInt16(offset + 40, this.Side, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetAccountId(dv) { return dv.getInt32(16, true); }
    static SetAccountId(dv, val) { dv.setInt32(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(20, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(20, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(24, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(24, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(32, true); }
    static SetQuantity(dv, val) { dv.setFloat64(32, val, true); }
    static GetSideEnum(dv) { return dv.getInt16(40, true); }
    static SetSideEnum(dv, val) { dv.setInt16(40, val, true); }
}
export var User_AddOrderEx_Input_Offsets;
(function (User_AddOrderEx_Input_Offsets) {
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["MESSAGE_SIZE"] = 62] = "MESSAGE_SIZE";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["Header"] = 0] = "Header";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["AccountId"] = 16] = "AccountId";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["InstrumentId"] = 20] = "InstrumentId";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["ClientOrderId"] = 24] = "ClientOrderId";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["LimitPrice"] = 32] = "LimitPrice";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["StopPrice"] = 40] = "StopPrice";
    User_AddOrderEx_Input_Offsets[User_AddOrderEx_Input_Offsets["Quantity"] = 48] = "Quantity";
})(User_AddOrderEx_Input_Offsets || (User_AddOrderEx_Input_Offsets = {}));
export class User_AddOrderEx_Input {
    constructor() {
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.ClientOrderId = 0n;
        this.LimitPrice = 0;
        this.StopPrice = 0;
        this.Quantity = 0;
        this.Side = 0;
        this.TIF = 0;
        this.OrderType = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_AddOrderEx_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_AddOrderEx_Input;
    }
    static FromBytes(dv) {
        let rv = new User_AddOrderEx_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.AccountId = dv.getInt32(16, true);
        rv.InstrumentId = dv.getInt32(20, true);
        rv.ClientOrderId = dv.getBigInt64(24, true);
        rv.LimitPrice = dv.getFloat64(32, true);
        rv.StopPrice = dv.getFloat64(40, true);
        rv.Quantity = dv.getFloat64(48, true);
        rv.Side = dv.getInt16(56, true);
        rv.TIF = dv.getInt16(58, true);
        rv.OrderType = dv.getInt16(60, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(62);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.AccountId, true);
        dv.setInt32(offset + 20, this.InstrumentId, true);
        dv.setBigInt64(offset + 24, this.ClientOrderId, true);
        dv.setFloat64(offset + 32, this.LimitPrice, true);
        dv.setFloat64(offset + 40, this.StopPrice, true);
        dv.setFloat64(offset + 48, this.Quantity, true);
        dv.setInt16(offset + 56, this.Side, true);
        dv.setInt16(offset + 58, this.TIF, true);
        dv.setInt16(offset + 60, this.OrderType, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetAccountId(dv) { return dv.getInt32(16, true); }
    static SetAccountId(dv, val) { dv.setInt32(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(20, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(20, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(24, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(24, val, true); }
    static GetLimitPrice(dv) { return dv.getFloat64(32, true); }
    static SetLimitPrice(dv, val) { dv.setFloat64(32, val, true); }
    static GetStopPrice(dv) { return dv.getFloat64(40, true); }
    static SetStopPrice(dv, val) { dv.setFloat64(40, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(48, true); }
    static SetQuantity(dv, val) { dv.setFloat64(48, val, true); }
    static GetSideEnum(dv) { return dv.getInt16(56, true); }
    static SetSideEnum(dv, val) { dv.setInt16(56, val, true); }
    static GetTIFEnum(dv) { return dv.getInt16(58, true); }
    static SetTIFEnum(dv, val) { dv.setInt16(58, val, true); }
    static GetOrderTypeEnum(dv) { return dv.getInt16(60, true); }
    static SetOrderTypeEnum(dv, val) { dv.setInt16(60, val, true); }
}
export var User_CancelOrderByClientOrderId_Input_Offsets;
(function (User_CancelOrderByClientOrderId_Input_Offsets) {
    User_CancelOrderByClientOrderId_Input_Offsets[User_CancelOrderByClientOrderId_Input_Offsets["MESSAGE_SIZE"] = 32] = "MESSAGE_SIZE";
    User_CancelOrderByClientOrderId_Input_Offsets[User_CancelOrderByClientOrderId_Input_Offsets["Header"] = 0] = "Header";
    User_CancelOrderByClientOrderId_Input_Offsets[User_CancelOrderByClientOrderId_Input_Offsets["ClientOrderId"] = 16] = "ClientOrderId";
    User_CancelOrderByClientOrderId_Input_Offsets[User_CancelOrderByClientOrderId_Input_Offsets["AccountId"] = 24] = "AccountId";
    User_CancelOrderByClientOrderId_Input_Offsets[User_CancelOrderByClientOrderId_Input_Offsets["InstrumentId"] = 28] = "InstrumentId";
})(User_CancelOrderByClientOrderId_Input_Offsets || (User_CancelOrderByClientOrderId_Input_Offsets = {}));
export class User_CancelOrderByClientOrderId_Input {
    constructor() {
        this.ClientOrderId = 0n;
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_CancelOrderByClientOrderId_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_CancelOrderByClientOrderId_Input;
    }
    static FromBytes(dv) {
        let rv = new User_CancelOrderByClientOrderId_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.ClientOrderId = dv.getBigInt64(16, true);
        rv.AccountId = dv.getInt32(24, true);
        rv.InstrumentId = dv.getInt32(28, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(32);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.ClientOrderId, true);
        dv.setInt32(offset + 24, this.AccountId, true);
        dv.setInt32(offset + 28, this.InstrumentId, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(16, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(16, val, true); }
    static GetAccountId(dv) { return dv.getInt32(24, true); }
    static SetAccountId(dv, val) { dv.setInt32(24, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(28, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(28, val, true); }
}
export var User_CancelOrderByServerOrderId_Input_Offsets;
(function (User_CancelOrderByServerOrderId_Input_Offsets) {
    User_CancelOrderByServerOrderId_Input_Offsets[User_CancelOrderByServerOrderId_Input_Offsets["MESSAGE_SIZE"] = 32] = "MESSAGE_SIZE";
    User_CancelOrderByServerOrderId_Input_Offsets[User_CancelOrderByServerOrderId_Input_Offsets["Header"] = 0] = "Header";
    User_CancelOrderByServerOrderId_Input_Offsets[User_CancelOrderByServerOrderId_Input_Offsets["ServerOrderId"] = 16] = "ServerOrderId";
    User_CancelOrderByServerOrderId_Input_Offsets[User_CancelOrderByServerOrderId_Input_Offsets["AccountId"] = 24] = "AccountId";
    User_CancelOrderByServerOrderId_Input_Offsets[User_CancelOrderByServerOrderId_Input_Offsets["InstrumentId"] = 28] = "InstrumentId";
})(User_CancelOrderByServerOrderId_Input_Offsets || (User_CancelOrderByServerOrderId_Input_Offsets = {}));
export class User_CancelOrderByServerOrderId_Input {
    constructor() {
        this.ServerOrderId = 0n;
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_CancelOrderByServerOrderId_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_CancelOrderByServerOrderId_Input;
    }
    static FromBytes(dv) {
        let rv = new User_CancelOrderByServerOrderId_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.ServerOrderId = dv.getBigInt64(16, true);
        rv.AccountId = dv.getInt32(24, true);
        rv.InstrumentId = dv.getInt32(28, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(32);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.ServerOrderId, true);
        dv.setInt32(offset + 24, this.AccountId, true);
        dv.setInt32(offset + 28, this.InstrumentId, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetServerOrderId(dv) { return dv.getBigInt64(16, true); }
    static SetServerOrderId(dv, val) { dv.setBigInt64(16, val, true); }
    static GetAccountId(dv) { return dv.getInt32(24, true); }
    static SetAccountId(dv, val) { dv.setInt32(24, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(28, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(28, val, true); }
}
export var User_CancelAllOrders_Input_Offsets;
(function (User_CancelAllOrders_Input_Offsets) {
    User_CancelAllOrders_Input_Offsets[User_CancelAllOrders_Input_Offsets["MESSAGE_SIZE"] = 24] = "MESSAGE_SIZE";
    User_CancelAllOrders_Input_Offsets[User_CancelAllOrders_Input_Offsets["Header"] = 0] = "Header";
    User_CancelAllOrders_Input_Offsets[User_CancelAllOrders_Input_Offsets["AccountId"] = 16] = "AccountId";
    User_CancelAllOrders_Input_Offsets[User_CancelAllOrders_Input_Offsets["InstrumentId"] = 20] = "InstrumentId";
})(User_CancelAllOrders_Input_Offsets || (User_CancelAllOrders_Input_Offsets = {}));
export class User_CancelAllOrders_Input {
    constructor() {
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_CancelAllOrders_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_CancelAllOrders_Input;
    }
    static FromBytes(dv) {
        let rv = new User_CancelAllOrders_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.AccountId = dv.getInt32(16, true);
        rv.InstrumentId = dv.getInt32(20, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(24);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.AccountId, true);
        dv.setInt32(offset + 20, this.InstrumentId, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetAccountId(dv) { return dv.getInt32(16, true); }
    static SetAccountId(dv, val) { dv.setInt32(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(20, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(20, val, true); }
}
export var User_SubscribeMDTrades_Input_Offsets;
(function (User_SubscribeMDTrades_Input_Offsets) {
    User_SubscribeMDTrades_Input_Offsets[User_SubscribeMDTrades_Input_Offsets["MESSAGE_SIZE"] = 21] = "MESSAGE_SIZE";
    User_SubscribeMDTrades_Input_Offsets[User_SubscribeMDTrades_Input_Offsets["Header"] = 0] = "Header";
    User_SubscribeMDTrades_Input_Offsets[User_SubscribeMDTrades_Input_Offsets["InstrumentId"] = 16] = "InstrumentId";
    User_SubscribeMDTrades_Input_Offsets[User_SubscribeMDTrades_Input_Offsets["Subscribe"] = 20] = "Subscribe";
})(User_SubscribeMDTrades_Input_Offsets || (User_SubscribeMDTrades_Input_Offsets = {}));
export class User_SubscribeMDTrades_Input {
    constructor() {
        this.InstrumentId = 0;
        this.Subscribe = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_SubscribeMDTrades_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_SubscribeMDTrades_Input;
    }
    static FromBytes(dv) {
        let rv = new User_SubscribeMDTrades_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.InstrumentId = dv.getInt32(16, true);
        rv.Subscribe = dv.getUint8(20);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(21);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.InstrumentId, true);
        dv.setUint8(offset + 20, this.Subscribe);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(16, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(16, val, true); }
    static GetSubscribe(dv) { return dv.getUint8(20); }
    static SetSubscribe(dv, val) { dv.setUint8(20, val); }
}
export var User_SubscribeL2_Input_Offsets;
(function (User_SubscribeL2_Input_Offsets) {
    User_SubscribeL2_Input_Offsets[User_SubscribeL2_Input_Offsets["MESSAGE_SIZE"] = 21] = "MESSAGE_SIZE";
    User_SubscribeL2_Input_Offsets[User_SubscribeL2_Input_Offsets["Header"] = 0] = "Header";
    User_SubscribeL2_Input_Offsets[User_SubscribeL2_Input_Offsets["InstrumentId"] = 16] = "InstrumentId";
    User_SubscribeL2_Input_Offsets[User_SubscribeL2_Input_Offsets["Subscribe"] = 20] = "Subscribe";
})(User_SubscribeL2_Input_Offsets || (User_SubscribeL2_Input_Offsets = {}));
export class User_SubscribeL2_Input {
    constructor() {
        this.InstrumentId = 0;
        this.Subscribe = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_SubscribeL2_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_SubscribeL2_Input;
    }
    static FromBytes(dv) {
        let rv = new User_SubscribeL2_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.InstrumentId = dv.getInt32(16, true);
        rv.Subscribe = dv.getUint8(20);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(21);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.InstrumentId, true);
        dv.setUint8(offset + 20, this.Subscribe);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(16, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(16, val, true); }
    static GetSubscribe(dv) { return dv.getUint8(20); }
    static SetSubscribe(dv, val) { dv.setUint8(20, val); }
}
export var User_CancelReplaceLimitOrder_Input_Offsets;
(function (User_CancelReplaceLimitOrder_Input_Offsets) {
    User_CancelReplaceLimitOrder_Input_Offsets[User_CancelReplaceLimitOrder_Input_Offsets["MESSAGE_SIZE"] = 88] = "MESSAGE_SIZE";
    User_CancelReplaceLimitOrder_Input_Offsets[User_CancelReplaceLimitOrder_Input_Offsets["Header"] = 0] = "Header";
    User_CancelReplaceLimitOrder_Input_Offsets[User_CancelReplaceLimitOrder_Input_Offsets["OrigClientOrderId"] = 16] = "OrigClientOrderId";
    User_CancelReplaceLimitOrder_Input_Offsets[User_CancelReplaceLimitOrder_Input_Offsets["OrigOrderId"] = 24] = "OrigOrderId";
})(User_CancelReplaceLimitOrder_Input_Offsets || (User_CancelReplaceLimitOrder_Input_Offsets = {}));
export class User_CancelReplaceLimitOrder_Input {
    constructor() {
        this.OrigClientOrderId = 0n;
        this.OrigOrderId = 0n;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_CancelReplaceLimitOrder_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_CancelReplaceLimitOrder_Input;
    }
    static FromBytes(dv) {
        let rv = new User_CancelReplaceLimitOrder_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.OrigClientOrderId = dv.getBigInt64(16, true);
        rv.OrigOrderId = dv.getBigInt64(24, true);
        rv.NewLimitOrder = new User_AddLimitOrder_Input();
        rv.NewLimitOrder.Header = new User_InputMessageHeader();
        rv.NewLimitOrder.Header.MessageLength = dv.getInt16(32, true);
        rv.NewLimitOrder.Header.MessageType = dv.getInt16(34, true);
        rv.NewLimitOrder.Header.HA_ClientUserId = dv.getInt32(36, true);
        rv.NewLimitOrder.Header.HA_ClientSequenceNumber = dv.getBigInt64(40, true);
        rv.NewLimitOrder.AccountId = dv.getInt32(48, true);
        rv.NewLimitOrder.InstrumentId = dv.getInt32(52, true);
        rv.NewLimitOrder.ClientOrderId = dv.getBigInt64(56, true);
        rv.NewLimitOrder.LimitPrice = dv.getFloat64(64, true);
        rv.NewLimitOrder.Quantity = dv.getFloat64(72, true);
        rv.NewLimitOrder.Side = dv.getInt16(80, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(88);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.OrigClientOrderId, true);
        dv.setBigInt64(offset + 24, this.OrigOrderId, true);
        dv.setInt16(offset + 32, this.NewLimitOrder.Header.MessageLength, true);
        dv.setInt16(offset + 34, this.NewLimitOrder.Header.MessageType, true);
        dv.setInt32(offset + 36, this.NewLimitOrder.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 40, this.NewLimitOrder.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 48, this.NewLimitOrder.AccountId, true);
        dv.setInt32(offset + 52, this.NewLimitOrder.InstrumentId, true);
        dv.setBigInt64(offset + 56, this.NewLimitOrder.ClientOrderId, true);
        dv.setFloat64(offset + 64, this.NewLimitOrder.LimitPrice, true);
        dv.setFloat64(offset + 72, this.NewLimitOrder.Quantity, true);
        dv.setInt16(offset + 80, this.NewLimitOrder.Side, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetOrigClientOrderId(dv) { return dv.getBigInt64(16, true); }
    static SetOrigClientOrderId(dv, val) { dv.setBigInt64(16, val, true); }
    static GetOrigOrderId(dv) { return dv.getBigInt64(24, true); }
    static SetOrigOrderId(dv, val) { dv.setBigInt64(24, val, true); }
    static Get_NewLimitOrder_Header_MessageLength(dv) { return dv.getInt16(32, true); }
    static Set_NewLimitOrder_Header_MessageLength(dv, val) { dv.setInt16(32, val, true); }
    static Get_NewLimitOrder_Header_MessageType(dv) { return dv.getInt16(34, true); }
    static Set_NewLimitOrder_Header_MessageType(dv, val) { dv.setInt16(34, val, true); }
    static Get_NewLimitOrder_Header_HA_ClientUserId(dv) { return dv.getInt32(36, true); }
    static Set_NewLimitOrder_Header_HA_ClientUserId(dv, val) { dv.setInt32(36, val, true); }
    static Get_NewLimitOrder_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(40, true); }
    static Set_NewLimitOrder_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(40, val, true); }
    static Get_NewLimitOrder_AccountId(dv) { return dv.getInt32(48, true); }
    static Set_NewLimitOrder_AccountId(dv, val) { dv.setInt32(48, val, true); }
    static Get_NewLimitOrder_InstrumentId(dv) { return dv.getInt32(52, true); }
    static Set_NewLimitOrder_InstrumentId(dv, val) { dv.setInt32(52, val, true); }
    static Get_NewLimitOrder_ClientOrderId(dv) { return dv.getBigInt64(56, true); }
    static Set_NewLimitOrder_ClientOrderId(dv, val) { dv.setBigInt64(56, val, true); }
    static Get_NewLimitOrder_LimitPrice(dv) { return dv.getFloat64(64, true); }
    static Set_NewLimitOrder_LimitPrice(dv, val) { dv.setFloat64(64, val, true); }
    static Get_NewLimitOrder_Quantity(dv) { return dv.getFloat64(72, true); }
    static Set_NewLimitOrder_Quantity(dv, val) { dv.setFloat64(72, val, true); }
    static Get_NewLimitOrder_SideEnum(dv) { return dv.getInt16(80, true); }
    static Set_NewLimitOrder_SideEnum(dv, val) { dv.setInt16(80, val, true); }
}
export var User_AccountProductState_Output_Offsets;
(function (User_AccountProductState_Output_Offsets) {
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["MESSAGE_SIZE"] = 68] = "MESSAGE_SIZE";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["Header"] = 0] = "Header";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["AccountId"] = 32] = "AccountId";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["ProductId"] = 36] = "ProductId";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["ProductAmount"] = 40] = "ProductAmount";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["ProductHold"] = 48] = "ProductHold";
    User_AccountProductState_Output_Offsets[User_AccountProductState_Output_Offsets["AccountStateRevision"] = 56] = "AccountStateRevision";
})(User_AccountProductState_Output_Offsets || (User_AccountProductState_Output_Offsets = {}));
export class User_AccountProductState_Output {
    constructor() {
        this.AccountId = 0;
        this.ProductId = 0;
        this.ProductAmount = 0;
        this.ProductHold = 0;
        this.AccountStateRevision = 0n;
        this.ChangeReason = 0;
        this.Header = new User_OutputMessageHeader();
        this.Header.MessageLength = User_AccountProductState_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_AccountProductState_Output;
        this.Header.OutputMessageTimeStamp = Date.now();
    }
    static FromBytes(dv) {
        let rv = new User_AccountProductState_Output();
        rv.Header = new User_OutputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Header.OutputMessageTimeStamp = dv.getFloat64(24, true);
        rv.AccountId = dv.getInt32(32, true);
        rv.ProductId = dv.getInt32(36, true);
        rv.ProductAmount = dv.getFloat64(40, true);
        rv.ProductHold = dv.getFloat64(48, true);
        rv.AccountStateRevision = dv.getBigInt64(56, true);
        rv.ChangeReason = dv.getInt32(64, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(68);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Header.OutputMessageTimeStamp, true);
        dv.setInt32(offset + 32, this.AccountId, true);
        dv.setInt32(offset + 36, this.ProductId, true);
        dv.setFloat64(offset + 40, this.ProductAmount, true);
        dv.setFloat64(offset + 48, this.ProductHold, true);
        dv.setBigInt64(offset + 56, this.AccountStateRevision, true);
        dv.setInt32(offset + 64, this.ChangeReason, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static Get_Header_OutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static Set_Header_OutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
    static GetAccountId(dv) { return dv.getInt32(32, true); }
    static SetAccountId(dv, val) { dv.setInt32(32, val, true); }
    static GetProductId(dv) { return dv.getInt32(36, true); }
    static SetProductId(dv, val) { dv.setInt32(36, val, true); }
    static GetProductAmount(dv) { return dv.getFloat64(40, true); }
    static SetProductAmount(dv, val) { dv.setFloat64(40, val, true); }
    static GetProductHold(dv) { return dv.getFloat64(48, true); }
    static SetProductHold(dv, val) { dv.setFloat64(48, val, true); }
    static GetAccountStateRevision(dv) { return dv.getBigInt64(56, true); }
    static SetAccountStateRevision(dv, val) { dv.setBigInt64(56, val, true); }
    static GetChangeReasonEnum(dv) { return dv.getInt32(64, true); }
    static SetChangeReasonEnum(dv, val) { dv.setInt32(64, val, true); }
}
export var User_OrderState_Output_Offsets;
(function (User_OrderState_Output_Offsets) {
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["MESSAGE_SIZE"] = 129] = "MESSAGE_SIZE";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["Header"] = 0] = "Header";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["OrderId"] = 32] = "OrderId";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["AccountId"] = 40] = "AccountId";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["InstrumentId"] = 44] = "InstrumentId";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["LimitPrice"] = 48] = "LimitPrice";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["StopPrice"] = 56] = "StopPrice";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["OrigQuantity"] = 64] = "OrigQuantity";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["ClientOrderId"] = 72] = "ClientOrderId";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["ExecutedQuantity"] = 80] = "ExecutedQuantity";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["RemainingQuantity"] = 88] = "RemainingQuantity";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["ValueExecuted"] = 96] = "ValueExecuted";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["EntryTime"] = 104] = "EntryTime";
    User_OrderState_Output_Offsets[User_OrderState_Output_Offsets["RejectReason"] = 112] = "RejectReason";
})(User_OrderState_Output_Offsets || (User_OrderState_Output_Offsets = {}));
export class User_OrderState_Output {
    constructor() {
        this.OrderId = 0n;
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.LimitPrice = 0;
        this.StopPrice = 0;
        this.OrigQuantity = 0;
        this.ClientOrderId = 0n;
        this.ExecutedQuantity = 0;
        this.RemainingQuantity = 0;
        this.ValueExecuted = 0;
        this.EntryTime = 0;
        this.RejectReason = 0n;
        this.Side = 0;
        this.CurrentOrderState = 0;
        this.OrderStateChangeReason = 0;
        this.OrderType = 0;
        this.TIF = 0;
        this.Header = new User_OutputMessageHeader();
        this.Header.MessageLength = User_OrderState_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_OrderState_Output;
        this.Header.OutputMessageTimeStamp = Date.now();
    }
    static FromBytes(dv) {
        let rv = new User_OrderState_Output();
        rv.Header = new User_OutputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Header.OutputMessageTimeStamp = dv.getFloat64(24, true);
        rv.OrderId = dv.getBigInt64(32, true);
        rv.AccountId = dv.getInt32(40, true);
        rv.InstrumentId = dv.getInt32(44, true);
        rv.LimitPrice = dv.getFloat64(48, true);
        rv.StopPrice = dv.getFloat64(56, true);
        rv.OrigQuantity = dv.getFloat64(64, true);
        rv.ClientOrderId = dv.getBigInt64(72, true);
        rv.ExecutedQuantity = dv.getFloat64(80, true);
        rv.RemainingQuantity = dv.getFloat64(88, true);
        rv.ValueExecuted = dv.getFloat64(96, true);
        rv.EntryTime = dv.getFloat64(104, true);
        rv.RejectReason = dv.getBigInt64(112, true);
        rv.Side = dv.getInt16(120, true);
        rv.CurrentOrderState = dv.getUint8(122);
        rv.OrderStateChangeReason = dv.getInt16(123, true);
        rv.OrderType = dv.getInt16(125, true);
        rv.TIF = dv.getInt16(127, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(129);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Header.OutputMessageTimeStamp, true);
        dv.setBigInt64(offset + 32, this.OrderId, true);
        dv.setInt32(offset + 40, this.AccountId, true);
        dv.setInt32(offset + 44, this.InstrumentId, true);
        dv.setFloat64(offset + 48, this.LimitPrice, true);
        dv.setFloat64(offset + 56, this.StopPrice, true);
        dv.setFloat64(offset + 64, this.OrigQuantity, true);
        dv.setBigInt64(offset + 72, this.ClientOrderId, true);
        dv.setFloat64(offset + 80, this.ExecutedQuantity, true);
        dv.setFloat64(offset + 88, this.RemainingQuantity, true);
        dv.setFloat64(offset + 96, this.ValueExecuted, true);
        dv.setFloat64(offset + 104, this.EntryTime, true);
        dv.setBigInt64(offset + 112, this.RejectReason, true);
        dv.setInt16(offset + 120, this.Side, true);
        dv.setUint8(offset + 122, this.CurrentOrderState);
        dv.setInt16(offset + 123, this.OrderStateChangeReason, true);
        dv.setInt16(offset + 125, this.OrderType, true);
        dv.setInt16(offset + 127, this.TIF, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static Get_Header_OutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static Set_Header_OutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
    static GetOrderId(dv) { return dv.getBigInt64(32, true); }
    static SetOrderId(dv, val) { dv.setBigInt64(32, val, true); }
    static GetAccountId(dv) { return dv.getInt32(40, true); }
    static SetAccountId(dv, val) { dv.setInt32(40, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(44, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(44, val, true); }
    static GetLimitPrice(dv) { return dv.getFloat64(48, true); }
    static SetLimitPrice(dv, val) { dv.setFloat64(48, val, true); }
    static GetStopPrice(dv) { return dv.getFloat64(56, true); }
    static SetStopPrice(dv, val) { dv.setFloat64(56, val, true); }
    static GetOrigQuantity(dv) { return dv.getFloat64(64, true); }
    static SetOrigQuantity(dv, val) { dv.setFloat64(64, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(72, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(72, val, true); }
    static GetExecutedQuantity(dv) { return dv.getFloat64(80, true); }
    static SetExecutedQuantity(dv, val) { dv.setFloat64(80, val, true); }
    static GetRemainingQuantity(dv) { return dv.getFloat64(88, true); }
    static SetRemainingQuantity(dv, val) { dv.setFloat64(88, val, true); }
    static GetValueExecuted(dv) { return dv.getFloat64(96, true); }
    static SetValueExecuted(dv, val) { dv.setFloat64(96, val, true); }
    static GetEntryTime(dv) { return dv.getFloat64(104, true); }
    static SetEntryTime(dv, val) { dv.setFloat64(104, val, true); }
    static GetRejectReason(dv) { return dv.getBigInt64(112, true); }
    static SetRejectReason(dv, val) { dv.setBigInt64(112, val, true); }
    static GetSideEnum(dv) { return dv.getInt16(120, true); }
    static SetSideEnum(dv, val) { dv.setInt16(120, val, true); }
    static GetCurrentOrderStateEnum(dv) { return dv.getUint8(122); }
    static SetCurrentOrderStateEnum(dv, val) { dv.setUint8(122, val); }
    static GetOrderStateChangeReasonEnum(dv) { return dv.getInt16(123, true); }
    static SetOrderStateChangeReasonEnum(dv, val) { dv.setInt16(123, val, true); }
    static GetOrderTypeEnum(dv) { return dv.getInt16(125, true); }
    static SetOrderTypeEnum(dv, val) { dv.setInt16(125, val, true); }
    static GetTIFEnum(dv) { return dv.getInt16(127, true); }
    static SetTIFEnum(dv, val) { dv.setInt16(127, val, true); }
}
export var User_OrderTrade_Output_Offsets;
(function (User_OrderTrade_Output_Offsets) {
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["MESSAGE_SIZE"] = 88] = "MESSAGE_SIZE";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["Header"] = 0] = "Header";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["OrderId"] = 32] = "OrderId";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["ClientOrderId"] = 40] = "ClientOrderId";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["AccountId"] = 48] = "AccountId";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["InstrumentId"] = 52] = "InstrumentId";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["Price"] = 56] = "Price";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["Quantity"] = 64] = "Quantity";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["TradeId"] = 72] = "TradeId";
    User_OrderTrade_Output_Offsets[User_OrderTrade_Output_Offsets["TradeTime"] = 80] = "TradeTime";
})(User_OrderTrade_Output_Offsets || (User_OrderTrade_Output_Offsets = {}));
export class User_OrderTrade_Output {
    constructor() {
        this.OrderId = 0n;
        this.ClientOrderId = 0n;
        this.AccountId = 0;
        this.InstrumentId = 0;
        this.Price = 0;
        this.Quantity = 0;
        this.TradeId = 0n;
        this.TradeTime = 0;
        this.Header = new User_OutputMessageHeader();
        this.Header.MessageLength = User_OrderTrade_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_OrderTrade_Output;
        this.Header.OutputMessageTimeStamp = Date.now();
    }
    static FromBytes(dv) {
        let rv = new User_OrderTrade_Output();
        rv.Header = new User_OutputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Header.OutputMessageTimeStamp = dv.getFloat64(24, true);
        rv.OrderId = dv.getBigInt64(32, true);
        rv.ClientOrderId = dv.getBigInt64(40, true);
        rv.AccountId = dv.getInt32(48, true);
        rv.InstrumentId = dv.getInt32(52, true);
        rv.Price = dv.getFloat64(56, true);
        rv.Quantity = dv.getFloat64(64, true);
        rv.TradeId = dv.getBigInt64(72, true);
        rv.TradeTime = dv.getFloat64(80, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(88);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Header.OutputMessageTimeStamp, true);
        dv.setBigInt64(offset + 32, this.OrderId, true);
        dv.setBigInt64(offset + 40, this.ClientOrderId, true);
        dv.setInt32(offset + 48, this.AccountId, true);
        dv.setInt32(offset + 52, this.InstrumentId, true);
        dv.setFloat64(offset + 56, this.Price, true);
        dv.setFloat64(offset + 64, this.Quantity, true);
        dv.setBigInt64(offset + 72, this.TradeId, true);
        dv.setFloat64(offset + 80, this.TradeTime, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static Get_Header_OutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static Set_Header_OutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
    static GetOrderId(dv) { return dv.getBigInt64(32, true); }
    static SetOrderId(dv, val) { dv.setBigInt64(32, val, true); }
    static GetClientOrderId(dv) { return dv.getBigInt64(40, true); }
    static SetClientOrderId(dv, val) { dv.setBigInt64(40, val, true); }
    static GetAccountId(dv) { return dv.getInt32(48, true); }
    static SetAccountId(dv, val) { dv.setInt32(48, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(52, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(52, val, true); }
    static GetPrice(dv) { return dv.getFloat64(56, true); }
    static SetPrice(dv, val) { dv.setFloat64(56, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(64, true); }
    static SetQuantity(dv, val) { dv.setFloat64(64, val, true); }
    static GetTradeId(dv) { return dv.getBigInt64(72, true); }
    static SetTradeId(dv, val) { dv.setBigInt64(72, val, true); }
    static GetTradeTime(dv) { return dv.getFloat64(80, true); }
    static SetTradeTime(dv, val) { dv.setFloat64(80, val, true); }
}
export var User_MD_L2_LevelUpdateBatch1_Output_Offsets;
(function (User_MD_L2_LevelUpdateBatch1_Output_Offsets) {
    User_MD_L2_LevelUpdateBatch1_Output_Offsets[User_MD_L2_LevelUpdateBatch1_Output_Offsets["MESSAGE_SIZE"] = 35] = "MESSAGE_SIZE";
    User_MD_L2_LevelUpdateBatch1_Output_Offsets[User_MD_L2_LevelUpdateBatch1_Output_Offsets["Header"] = 0] = "Header";
    User_MD_L2_LevelUpdateBatch1_Output_Offsets[User_MD_L2_LevelUpdateBatch1_Output_Offsets["InstrumentId"] = 24] = "InstrumentId";
    User_MD_L2_LevelUpdateBatch1_Output_Offsets[User_MD_L2_LevelUpdateBatch1_Output_Offsets["NumberOfItems"] = 28] = "NumberOfItems";
    User_MD_L2_LevelUpdateBatch1_Output_Offsets[User_MD_L2_LevelUpdateBatch1_Output_Offsets["ItemSize"] = 32] = "ItemSize";
})(User_MD_L2_LevelUpdateBatch1_Output_Offsets || (User_MD_L2_LevelUpdateBatch1_Output_Offsets = {}));
export class User_MD_L2_LevelUpdateBatch1_Output {
    constructor() {
        this.InstrumentId = 0;
        this.NumberOfItems = 0;
        this.ItemSize = 0;
        this.ControlOptions = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_L2_LevelUpdateBatch1_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_L2_LevelUpdateBatch1_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L2_LevelUpdateBatch1_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.InstrumentId = dv.getInt32(24, true);
        rv.NumberOfItems = dv.getInt32(28, true);
        rv.ItemSize = dv.getInt16(32, true);
        rv.ControlOptions = dv.getUint8(34);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(35);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 24, this.InstrumentId, true);
        dv.setInt32(offset + 28, this.NumberOfItems, true);
        dv.setInt16(offset + 32, this.ItemSize, true);
        dv.setUint8(offset + 34, this.ControlOptions);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(24, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(24, val, true); }
    static GetNumberOfItems(dv) { return dv.getInt32(28, true); }
    static SetNumberOfItems(dv, val) { dv.setInt32(28, val, true); }
    static GetItemSize(dv) { return dv.getInt16(32, true); }
    static SetItemSize(dv, val) { dv.setInt16(32, val, true); }
    static GetControlOptionsEnum(dv) { return dv.getUint8(34); }
    static SetControlOptionsEnum(dv, val) { dv.setUint8(34, val); }
}
export var User_MD_L2_LevelUpdateBatch1_Item_Offsets;
(function (User_MD_L2_LevelUpdateBatch1_Item_Offsets) {
    User_MD_L2_LevelUpdateBatch1_Item_Offsets[User_MD_L2_LevelUpdateBatch1_Item_Offsets["MESSAGE_SIZE"] = 17] = "MESSAGE_SIZE";
    User_MD_L2_LevelUpdateBatch1_Item_Offsets[User_MD_L2_LevelUpdateBatch1_Item_Offsets["Side"] = 0] = "Side";
    User_MD_L2_LevelUpdateBatch1_Item_Offsets[User_MD_L2_LevelUpdateBatch1_Item_Offsets["Price"] = 1] = "Price";
    User_MD_L2_LevelUpdateBatch1_Item_Offsets[User_MD_L2_LevelUpdateBatch1_Item_Offsets["Quantity"] = 9] = "Quantity";
})(User_MD_L2_LevelUpdateBatch1_Item_Offsets || (User_MD_L2_LevelUpdateBatch1_Item_Offsets = {}));
export class User_MD_L2_LevelUpdateBatch1_Item {
    constructor() {
        this.Side = 0;
        this.Price = 0;
        this.Quantity = 0;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L2_LevelUpdateBatch1_Item();
        rv.Side = dv.getUint8(0);
        rv.Price = dv.getFloat64(1, true);
        rv.Quantity = dv.getFloat64(9, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(17);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setUint8(offset + 0, this.Side);
        dv.setFloat64(offset + 1, this.Price, true);
        dv.setFloat64(offset + 9, this.Quantity, true);
    }
    static GetSide(dv) { return dv.getUint8(0); }
    static SetSide(dv, val) { dv.setUint8(0, val); }
    static GetPrice(dv) { return dv.getFloat64(1, true); }
    static SetPrice(dv, val) { dv.setFloat64(1, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(9, true); }
    static SetQuantity(dv, val) { dv.setFloat64(9, val, true); }
}
export var User_MD_TradeUpdateBatch1_Output_Offsets;
(function (User_MD_TradeUpdateBatch1_Output_Offsets) {
    User_MD_TradeUpdateBatch1_Output_Offsets[User_MD_TradeUpdateBatch1_Output_Offsets["MESSAGE_SIZE"] = 34] = "MESSAGE_SIZE";
    User_MD_TradeUpdateBatch1_Output_Offsets[User_MD_TradeUpdateBatch1_Output_Offsets["Header"] = 0] = "Header";
    User_MD_TradeUpdateBatch1_Output_Offsets[User_MD_TradeUpdateBatch1_Output_Offsets["InstrumentId"] = 24] = "InstrumentId";
    User_MD_TradeUpdateBatch1_Output_Offsets[User_MD_TradeUpdateBatch1_Output_Offsets["NumberOfItems"] = 28] = "NumberOfItems";
    User_MD_TradeUpdateBatch1_Output_Offsets[User_MD_TradeUpdateBatch1_Output_Offsets["ItemSize"] = 32] = "ItemSize";
})(User_MD_TradeUpdateBatch1_Output_Offsets || (User_MD_TradeUpdateBatch1_Output_Offsets = {}));
export class User_MD_TradeUpdateBatch1_Output {
    constructor() {
        this.InstrumentId = 0;
        this.NumberOfItems = 0;
        this.ItemSize = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_TradeUpdateBatch1_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_TradeUpdateBatch1_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_TradeUpdateBatch1_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.InstrumentId = dv.getInt32(24, true);
        rv.NumberOfItems = dv.getInt32(28, true);
        rv.ItemSize = dv.getInt16(32, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(34);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 24, this.InstrumentId, true);
        dv.setInt32(offset + 28, this.NumberOfItems, true);
        dv.setInt16(offset + 32, this.ItemSize, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(24, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(24, val, true); }
    static GetNumberOfItems(dv) { return dv.getInt32(28, true); }
    static SetNumberOfItems(dv, val) { dv.setInt32(28, val, true); }
    static GetItemSize(dv) { return dv.getInt16(32, true); }
    static SetItemSize(dv, val) { dv.setInt16(32, val, true); }
}
export var User_MD_TradeUpdateBatch1_Item_Offsets;
(function (User_MD_TradeUpdateBatch1_Item_Offsets) {
    User_MD_TradeUpdateBatch1_Item_Offsets[User_MD_TradeUpdateBatch1_Item_Offsets["MESSAGE_SIZE"] = 17] = "MESSAGE_SIZE";
    User_MD_TradeUpdateBatch1_Item_Offsets[User_MD_TradeUpdateBatch1_Item_Offsets["Side"] = 0] = "Side";
    User_MD_TradeUpdateBatch1_Item_Offsets[User_MD_TradeUpdateBatch1_Item_Offsets["Price"] = 1] = "Price";
    User_MD_TradeUpdateBatch1_Item_Offsets[User_MD_TradeUpdateBatch1_Item_Offsets["Quantity"] = 9] = "Quantity";
})(User_MD_TradeUpdateBatch1_Item_Offsets || (User_MD_TradeUpdateBatch1_Item_Offsets = {}));
export class User_MD_TradeUpdateBatch1_Item {
    constructor() {
        this.Side = 0;
        this.Price = 0;
        this.Quantity = 0;
    }
    static FromBytes(dv) {
        let rv = new User_MD_TradeUpdateBatch1_Item();
        rv.Side = dv.getUint8(0);
        rv.Price = dv.getFloat64(1, true);
        rv.Quantity = dv.getFloat64(9, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(17);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setUint8(offset + 0, this.Side);
        dv.setFloat64(offset + 1, this.Price, true);
        dv.setFloat64(offset + 9, this.Quantity, true);
    }
    static GetSide(dv) { return dv.getUint8(0); }
    static SetSide(dv, val) { dv.setUint8(0, val); }
    static GetPrice(dv) { return dv.getFloat64(1, true); }
    static SetPrice(dv, val) { dv.setFloat64(1, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(9, true); }
    static SetQuantity(dv, val) { dv.setFloat64(9, val, true); }
}
export var User_MD_L2_ControlMessage_Output_Offsets;
(function (User_MD_L2_ControlMessage_Output_Offsets) {
    User_MD_L2_ControlMessage_Output_Offsets[User_MD_L2_ControlMessage_Output_Offsets["MESSAGE_SIZE"] = 29] = "MESSAGE_SIZE";
    User_MD_L2_ControlMessage_Output_Offsets[User_MD_L2_ControlMessage_Output_Offsets["Header"] = 0] = "Header";
    User_MD_L2_ControlMessage_Output_Offsets[User_MD_L2_ControlMessage_Output_Offsets["InstrumentId"] = 24] = "InstrumentId";
})(User_MD_L2_ControlMessage_Output_Offsets || (User_MD_L2_ControlMessage_Output_Offsets = {}));
export class User_MD_L2_ControlMessage_Output {
    constructor() {
        this.InstrumentId = 0;
        this.ControlMessageAction = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_L2_ControlMessage_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_L2_ControlMessage_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L2_ControlMessage_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.InstrumentId = dv.getInt32(24, true);
        rv.ControlMessageAction = dv.getUint8(28);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(29);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 24, this.InstrumentId, true);
        dv.setUint8(offset + 28, this.ControlMessageAction);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(24, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(24, val, true); }
    static GetControlMessageActionEnum(dv) { return dv.getUint8(28); }
    static SetControlMessageActionEnum(dv, val) { dv.setUint8(28, val); }
}
export var User_MD_L2_LevelUpdateBid_Output_Offsets;
(function (User_MD_L2_LevelUpdateBid_Output_Offsets) {
    User_MD_L2_LevelUpdateBid_Output_Offsets[User_MD_L2_LevelUpdateBid_Output_Offsets["MESSAGE_SIZE"] = 40] = "MESSAGE_SIZE";
    User_MD_L2_LevelUpdateBid_Output_Offsets[User_MD_L2_LevelUpdateBid_Output_Offsets["Header"] = 0] = "Header";
    User_MD_L2_LevelUpdateBid_Output_Offsets[User_MD_L2_LevelUpdateBid_Output_Offsets["Price"] = 24] = "Price";
    User_MD_L2_LevelUpdateBid_Output_Offsets[User_MD_L2_LevelUpdateBid_Output_Offsets["Qty"] = 32] = "Qty";
})(User_MD_L2_LevelUpdateBid_Output_Offsets || (User_MD_L2_LevelUpdateBid_Output_Offsets = {}));
export class User_MD_L2_LevelUpdateBid_Output {
    constructor() {
        this.Price = 0;
        this.Qty = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_L2_LevelUpdateBid_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_L2_LevelUpdateBid_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L2_LevelUpdateBid_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Price = dv.getFloat64(24, true);
        rv.Qty = dv.getFloat64(32, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(40);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Price, true);
        dv.setFloat64(offset + 32, this.Qty, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetPrice(dv) { return dv.getFloat64(24, true); }
    static SetPrice(dv, val) { dv.setFloat64(24, val, true); }
    static GetQty(dv) { return dv.getFloat64(32, true); }
    static SetQty(dv, val) { dv.setFloat64(32, val, true); }
}
export var User_MD_L2_LevelUpdateAsk_Output_Offsets;
(function (User_MD_L2_LevelUpdateAsk_Output_Offsets) {
    User_MD_L2_LevelUpdateAsk_Output_Offsets[User_MD_L2_LevelUpdateAsk_Output_Offsets["MESSAGE_SIZE"] = 40] = "MESSAGE_SIZE";
    User_MD_L2_LevelUpdateAsk_Output_Offsets[User_MD_L2_LevelUpdateAsk_Output_Offsets["Header"] = 0] = "Header";
    User_MD_L2_LevelUpdateAsk_Output_Offsets[User_MD_L2_LevelUpdateAsk_Output_Offsets["Price"] = 24] = "Price";
    User_MD_L2_LevelUpdateAsk_Output_Offsets[User_MD_L2_LevelUpdateAsk_Output_Offsets["Qty"] = 32] = "Qty";
})(User_MD_L2_LevelUpdateAsk_Output_Offsets || (User_MD_L2_LevelUpdateAsk_Output_Offsets = {}));
export class User_MD_L2_LevelUpdateAsk_Output {
    constructor() {
        this.Price = 0;
        this.Qty = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_L2_LevelUpdateAsk_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_L2_LevelUpdateAsk_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L2_LevelUpdateAsk_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Price = dv.getFloat64(24, true);
        rv.Qty = dv.getFloat64(32, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(40);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Price, true);
        dv.setFloat64(offset + 32, this.Qty, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetPrice(dv) { return dv.getFloat64(24, true); }
    static SetPrice(dv, val) { dv.setFloat64(24, val, true); }
    static GetQty(dv) { return dv.getFloat64(32, true); }
    static SetQty(dv, val) { dv.setFloat64(32, val, true); }
}
export var User_MD_L1_Update_Output_Offsets;
(function (User_MD_L1_Update_Output_Offsets) {
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["MESSAGE_SIZE"] = 100] = "MESSAGE_SIZE";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["Header"] = 0] = "Header";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["InstrumentId"] = 24] = "InstrumentId";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["LastTradePrice"] = 28] = "LastTradePrice";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["LastTradeQty"] = 36] = "LastTradeQty";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["LastTradeId"] = 44] = "LastTradeId";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["InsideAskQty"] = 52] = "InsideAskQty";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["InsideAskPrice"] = 60] = "InsideAskPrice";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["InsideBidQty"] = 68] = "InsideBidQty";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["InsideBidPrice"] = 76] = "InsideBidPrice";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["TwentyFourHrVolume"] = 84] = "TwentyFourHrVolume";
    User_MD_L1_Update_Output_Offsets[User_MD_L1_Update_Output_Offsets["TwentyFourHrPrice"] = 92] = "TwentyFourHrPrice";
})(User_MD_L1_Update_Output_Offsets || (User_MD_L1_Update_Output_Offsets = {}));
export class User_MD_L1_Update_Output {
    constructor() {
        this.InstrumentId = 0;
        this.LastTradePrice = 0;
        this.LastTradeQty = 0;
        this.LastTradeId = 0;
        this.InsideAskQty = 0;
        this.InsideAskPrice = 0;
        this.InsideBidQty = 0;
        this.InsideBidPrice = 0;
        this.TwentyFourHrVolume = 0;
        this.TwentyFourHrPrice = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_L1_Update_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_L1_Update_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_L1_Update_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.InstrumentId = dv.getInt32(24, true);
        rv.LastTradePrice = dv.getFloat64(28, true);
        rv.LastTradeQty = dv.getFloat64(36, true);
        rv.LastTradeId = dv.getFloat64(44, true);
        rv.InsideAskQty = dv.getFloat64(52, true);
        rv.InsideAskPrice = dv.getFloat64(60, true);
        rv.InsideBidQty = dv.getFloat64(68, true);
        rv.InsideBidPrice = dv.getFloat64(76, true);
        rv.TwentyFourHrVolume = dv.getFloat64(84, true);
        rv.TwentyFourHrPrice = dv.getFloat64(92, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(100);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 24, this.InstrumentId, true);
        dv.setFloat64(offset + 28, this.LastTradePrice, true);
        dv.setFloat64(offset + 36, this.LastTradeQty, true);
        dv.setFloat64(offset + 44, this.LastTradeId, true);
        dv.setFloat64(offset + 52, this.InsideAskQty, true);
        dv.setFloat64(offset + 60, this.InsideAskPrice, true);
        dv.setFloat64(offset + 68, this.InsideBidQty, true);
        dv.setFloat64(offset + 76, this.InsideBidPrice, true);
        dv.setFloat64(offset + 84, this.TwentyFourHrVolume, true);
        dv.setFloat64(offset + 92, this.TwentyFourHrPrice, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(24, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(24, val, true); }
    static GetLastTradePrice(dv) { return dv.getFloat64(28, true); }
    static SetLastTradePrice(dv, val) { dv.setFloat64(28, val, true); }
    static GetLastTradeQty(dv) { return dv.getFloat64(36, true); }
    static SetLastTradeQty(dv, val) { dv.setFloat64(36, val, true); }
    static GetLastTradeId(dv) { return dv.getFloat64(44, true); }
    static SetLastTradeId(dv, val) { dv.setFloat64(44, val, true); }
    static GetInsideAskQty(dv) { return dv.getFloat64(52, true); }
    static SetInsideAskQty(dv, val) { dv.setFloat64(52, val, true); }
    static GetInsideAskPrice(dv) { return dv.getFloat64(60, true); }
    static SetInsideAskPrice(dv, val) { dv.setFloat64(60, val, true); }
    static GetInsideBidQty(dv) { return dv.getFloat64(68, true); }
    static SetInsideBidQty(dv, val) { dv.setFloat64(68, val, true); }
    static GetInsideBidPrice(dv) { return dv.getFloat64(76, true); }
    static SetInsideBidPrice(dv, val) { dv.setFloat64(76, val, true); }
    static GetTwentyFourHrVolume(dv) { return dv.getFloat64(84, true); }
    static SetTwentyFourHrVolume(dv, val) { dv.setFloat64(84, val, true); }
    static GetTwentyFourHrPrice(dv) { return dv.getFloat64(92, true); }
    static SetTwentyFourHrPrice(dv, val) { dv.setFloat64(92, val, true); }
}
export var User_MD_TradeUpdate_Output_Offsets;
(function (User_MD_TradeUpdate_Output_Offsets) {
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["MESSAGE_SIZE"] = 54] = "MESSAGE_SIZE";
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["Header"] = 0] = "Header";
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["InstrumentId"] = 24] = "InstrumentId";
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["Price"] = 28] = "Price";
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["Quantity"] = 36] = "Quantity";
    User_MD_TradeUpdate_Output_Offsets[User_MD_TradeUpdate_Output_Offsets["TradeTime"] = 44] = "TradeTime";
})(User_MD_TradeUpdate_Output_Offsets || (User_MD_TradeUpdate_Output_Offsets = {}));
export class User_MD_TradeUpdate_Output {
    constructor() {
        this.InstrumentId = 0;
        this.Price = 0;
        this.Quantity = 0;
        this.TradeTime = 0;
        this.MakerSide = 0;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_MD_TradeUpdate_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_TradeUpdate_Output;
    }
    static FromBytes(dv) {
        let rv = new User_MD_TradeUpdate_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.InstrumentId = dv.getInt32(24, true);
        rv.Price = dv.getFloat64(28, true);
        rv.Quantity = dv.getFloat64(36, true);
        rv.TradeTime = dv.getFloat64(44, true);
        rv.MakerSide = dv.getInt16(52, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(54);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 24, this.InstrumentId, true);
        dv.setFloat64(offset + 28, this.Price, true);
        dv.setFloat64(offset + 36, this.Quantity, true);
        dv.setFloat64(offset + 44, this.TradeTime, true);
        dv.setInt16(offset + 52, this.MakerSide, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(24, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(24, val, true); }
    static GetPrice(dv) { return dv.getFloat64(28, true); }
    static SetPrice(dv, val) { dv.setFloat64(28, val, true); }
    static GetQuantity(dv) { return dv.getFloat64(36, true); }
    static SetQuantity(dv, val) { dv.setFloat64(36, val, true); }
    static GetTradeTime(dv) { return dv.getFloat64(44, true); }
    static SetTradeTime(dv, val) { dv.setFloat64(44, val, true); }
    static GetMakerSideEnum(dv) { return dv.getInt16(52, true); }
    static SetMakerSideEnum(dv, val) { dv.setInt16(52, val, true); }
}
export var User_MD_OrderState_Output_Offsets;
(function (User_MD_OrderState_Output_Offsets) {
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["MESSAGE_SIZE"] = 78] = "MESSAGE_SIZE";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["Header"] = 0] = "Header";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["OrderId"] = 32] = "OrderId";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["LimitPrice"] = 40] = "LimitPrice";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["OrigQuantity"] = 48] = "OrigQuantity";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["ExecutedQuantity"] = 56] = "ExecutedQuantity";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["RemainingQuantity"] = 64] = "RemainingQuantity";
    User_MD_OrderState_Output_Offsets[User_MD_OrderState_Output_Offsets["InstrumentId"] = 72] = "InstrumentId";
})(User_MD_OrderState_Output_Offsets || (User_MD_OrderState_Output_Offsets = {}));
export class User_MD_OrderState_Output {
    constructor() {
        this.OrderId = 0n;
        this.LimitPrice = 0;
        this.OrigQuantity = 0;
        this.ExecutedQuantity = 0;
        this.RemainingQuantity = 0;
        this.InstrumentId = 0;
        this.Side = 0;
        this.Header = new User_OutputMessageHeader();
        this.Header.MessageLength = User_MD_OrderState_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MD_OrderState_Output;
        this.Header.OutputMessageTimeStamp = Date.now();
    }
    static FromBytes(dv) {
        let rv = new User_MD_OrderState_Output();
        rv.Header = new User_OutputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.Header.OutputMessageTimeStamp = dv.getFloat64(24, true);
        rv.OrderId = dv.getBigInt64(32, true);
        rv.LimitPrice = dv.getFloat64(40, true);
        rv.OrigQuantity = dv.getFloat64(48, true);
        rv.ExecutedQuantity = dv.getFloat64(56, true);
        rv.RemainingQuantity = dv.getFloat64(64, true);
        rv.InstrumentId = dv.getInt32(72, true);
        rv.Side = dv.getInt16(76, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(78);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setFloat64(offset + 24, this.Header.OutputMessageTimeStamp, true);
        dv.setBigInt64(offset + 32, this.OrderId, true);
        dv.setFloat64(offset + 40, this.LimitPrice, true);
        dv.setFloat64(offset + 48, this.OrigQuantity, true);
        dv.setFloat64(offset + 56, this.ExecutedQuantity, true);
        dv.setFloat64(offset + 64, this.RemainingQuantity, true);
        dv.setInt32(offset + 72, this.InstrumentId, true);
        dv.setInt16(offset + 76, this.Side, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static Get_Header_OutputMessageTimeStamp(dv) { return dv.getFloat64(24, true); }
    static Set_Header_OutputMessageTimeStamp(dv, val) { dv.setFloat64(24, val, true); }
    static GetOrderId(dv) { return dv.getBigInt64(32, true); }
    static SetOrderId(dv, val) { dv.setBigInt64(32, val, true); }
    static GetLimitPrice(dv) { return dv.getFloat64(40, true); }
    static SetLimitPrice(dv, val) { dv.setFloat64(40, val, true); }
    static GetOrigQuantity(dv) { return dv.getFloat64(48, true); }
    static SetOrigQuantity(dv, val) { dv.setFloat64(48, val, true); }
    static GetExecutedQuantity(dv) { return dv.getFloat64(56, true); }
    static SetExecutedQuantity(dv, val) { dv.setFloat64(56, val, true); }
    static GetRemainingQuantity(dv) { return dv.getFloat64(64, true); }
    static SetRemainingQuantity(dv, val) { dv.setFloat64(64, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(72, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(72, val, true); }
    static GetSideEnum(dv) { return dv.getInt16(76, true); }
    static SetSideEnum(dv, val) { dv.setInt16(76, val, true); }
}
export var User_ControlMessage_Output_Offsets;
(function (User_ControlMessage_Output_Offsets) {
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["MESSAGE_SIZE"] = 89] = "MESSAGE_SIZE";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Header"] = 0] = "Header";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field1"] = 25] = "Field1";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field2"] = 33] = "Field2";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field3"] = 41] = "Field3";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field4"] = 49] = "Field4";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field5"] = 57] = "Field5";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field6"] = 65] = "Field6";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field7"] = 73] = "Field7";
    User_ControlMessage_Output_Offsets[User_ControlMessage_Output_Offsets["Field8"] = 81] = "Field8";
})(User_ControlMessage_Output_Offsets || (User_ControlMessage_Output_Offsets = {}));
export class User_ControlMessage_Output {
    constructor() {
        this.ControlMessageAction = 0;
        this.Field1 = 0;
        this.Field2 = 0;
        this.Field3 = 0;
        this.Field4 = 0;
        this.Field5 = 0n;
        this.Field6 = 0n;
        this.Field7 = 0n;
        this.Field8 = 0n;
        this.Header = new User_OutputMessageHeaderSmall();
        this.Header.MessageLength = User_ControlMessage_Output_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_ControlMessage_Output;
    }
    static FromBytes(dv) {
        let rv = new User_ControlMessage_Output();
        rv.Header = new User_OutputMessageHeaderSmall();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ServerIdentifier = dv.getInt32(4, true);
        rv.Header.HA_ServerSequenceNumber = dv.getBigInt64(8, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(16, true);
        rv.ControlMessageAction = dv.getUint8(24);
        rv.Field1 = dv.getFloat64(25, true);
        rv.Field2 = dv.getFloat64(33, true);
        rv.Field3 = dv.getFloat64(41, true);
        rv.Field4 = dv.getFloat64(49, true);
        rv.Field5 = dv.getBigInt64(57, true);
        rv.Field6 = dv.getBigInt64(65, true);
        rv.Field7 = dv.getBigInt64(73, true);
        rv.Field8 = dv.getBigInt64(81, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(89);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ServerIdentifier, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ServerSequenceNumber, true);
        dv.setBigInt64(offset + 16, this.Header.HA_ClientSequenceNumber, true);
        dv.setUint8(offset + 24, this.ControlMessageAction);
        dv.setFloat64(offset + 25, this.Field1, true);
        dv.setFloat64(offset + 33, this.Field2, true);
        dv.setFloat64(offset + 41, this.Field3, true);
        dv.setFloat64(offset + 49, this.Field4, true);
        dv.setBigInt64(offset + 57, this.Field5, true);
        dv.setBigInt64(offset + 65, this.Field6, true);
        dv.setBigInt64(offset + 73, this.Field7, true);
        dv.setBigInt64(offset + 81, this.Field8, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ServerIdentifier(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ServerIdentifier(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ServerSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ServerSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(16, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(16, val, true); }
    static GetControlMessageActionEnum(dv) { return dv.getUint8(24); }
    static SetControlMessageActionEnum(dv, val) { dv.setUint8(24, val); }
    static GetField1(dv) { return dv.getFloat64(25, true); }
    static SetField1(dv, val) { dv.setFloat64(25, val, true); }
    static GetField2(dv) { return dv.getFloat64(33, true); }
    static SetField2(dv, val) { dv.setFloat64(33, val, true); }
    static GetField3(dv) { return dv.getFloat64(41, true); }
    static SetField3(dv, val) { dv.setFloat64(41, val, true); }
    static GetField4(dv) { return dv.getFloat64(49, true); }
    static SetField4(dv, val) { dv.setFloat64(49, val, true); }
    static GetField5(dv) { return dv.getBigInt64(57, true); }
    static SetField5(dv, val) { dv.setBigInt64(57, val, true); }
    static GetField6(dv) { return dv.getBigInt64(65, true); }
    static SetField6(dv, val) { dv.setBigInt64(65, val, true); }
    static GetField7(dv) { return dv.getBigInt64(73, true); }
    static SetField7(dv, val) { dv.setBigInt64(73, val, true); }
    static GetField8(dv) { return dv.getBigInt64(81, true); }
    static SetField8(dv, val) { dv.setBigInt64(81, val, true); }
}
export var User_MDH_BarHeader_BinaryObject_Header_Offsets;
(function (User_MDH_BarHeader_BinaryObject_Header_Offsets) {
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["MESSAGE_SIZE"] = 39] = "MESSAGE_SIZE";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["MessageLength"] = 0] = "MessageLength";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["MessageType"] = 2] = "MessageType";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["InstrumentId"] = 4] = "InstrumentId";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["FirstItemTime"] = 8] = "FirstItemTime";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["LastItemTime"] = 16] = "LastItemTime";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["ItemIntervalSec"] = 24] = "ItemIntervalSec";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["NumberOfItems"] = 32] = "NumberOfItems";
    User_MDH_BarHeader_BinaryObject_Header_Offsets[User_MDH_BarHeader_BinaryObject_Header_Offsets["ItemSize"] = 36] = "ItemSize";
})(User_MDH_BarHeader_BinaryObject_Header_Offsets || (User_MDH_BarHeader_BinaryObject_Header_Offsets = {}));
export class User_MDH_BarHeader_BinaryObject_Header {
    constructor() {
        this.MessageLength = 0;
        this.MessageType = 0;
        this.InstrumentId = 0;
        this.FirstItemTime = 0n;
        this.LastItemTime = 0n;
        this.ItemIntervalSec = 0n;
        this.NumberOfItems = 0;
        this.ItemSize = 0;
    }
    static FromBytes(dv) {
        let rv = new User_MDH_BarHeader_BinaryObject_Header();
        rv.MessageLength = dv.getInt16(0, true);
        rv.MessageType = dv.getInt16(2, true);
        rv.InstrumentId = dv.getInt32(4, true);
        rv.FirstItemTime = dv.getBigInt64(8, true);
        rv.LastItemTime = dv.getBigInt64(16, true);
        rv.ItemIntervalSec = dv.getBigInt64(24, true);
        rv.NumberOfItems = dv.getInt32(32, true);
        rv.ItemSize = dv.getInt16(36, true);
        rv.BarItemType = dv.getUint8(38);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(39);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.MessageLength, true);
        dv.setInt16(offset + 2, this.MessageType, true);
        dv.setInt32(offset + 4, this.InstrumentId, true);
        dv.setBigInt64(offset + 8, this.FirstItemTime, true);
        dv.setBigInt64(offset + 16, this.LastItemTime, true);
        dv.setBigInt64(offset + 24, this.ItemIntervalSec, true);
        dv.setInt32(offset + 32, this.NumberOfItems, true);
        dv.setInt16(offset + 36, this.ItemSize, true);
        dv.setUint8(offset + 38, this.BarItemType);
    }
    static GetMessageLength(dv) { return dv.getInt16(0, true); }
    static SetMessageLength(dv, val) { dv.setInt16(0, val, true); }
    static GetMessageType(dv) { return dv.getInt16(2, true); }
    static SetMessageType(dv, val) { dv.setInt16(2, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(4, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(4, val, true); }
    static GetFirstItemTime(dv) { return dv.getBigInt64(8, true); }
    static SetFirstItemTime(dv, val) { dv.setBigInt64(8, val, true); }
    static GetLastItemTime(dv) { return dv.getBigInt64(16, true); }
    static SetLastItemTime(dv, val) { dv.setBigInt64(16, val, true); }
    static GetItemIntervalSec(dv) { return dv.getBigInt64(24, true); }
    static SetItemIntervalSec(dv, val) { dv.setBigInt64(24, val, true); }
    static GetNumberOfItems(dv) { return dv.getInt32(32, true); }
    static SetNumberOfItems(dv, val) { dv.setInt32(32, val, true); }
    static GetItemSize(dv) { return dv.getInt16(36, true); }
    static SetItemSize(dv, val) { dv.setInt16(36, val, true); }
    static GetBarItemTypeEnum(dv) { return dv.getUint8(38); }
    static SetBarItemTypeEnum(dv, val) { dv.setUint8(38, val); }
}
export var User_MDH_BarItem_Type1_BinaryObject_Item_Offsets;
(function (User_MDH_BarItem_Type1_BinaryObject_Item_Offsets) {
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["MESSAGE_SIZE"] = 52] = "MESSAGE_SIZE";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["Time"] = 0] = "Time";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["Open"] = 8] = "Open";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["High"] = 16] = "High";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["Low"] = 24] = "Low";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["Close"] = 32] = "Close";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["TradeVolumeValue"] = 40] = "TradeVolumeValue";
    User_MDH_BarItem_Type1_BinaryObject_Item_Offsets[User_MDH_BarItem_Type1_BinaryObject_Item_Offsets["TradesCount"] = 48] = "TradesCount";
})(User_MDH_BarItem_Type1_BinaryObject_Item_Offsets || (User_MDH_BarItem_Type1_BinaryObject_Item_Offsets = {}));
export class User_MDH_BarItem_Type1_BinaryObject_Item {
    constructor() {
        this.Time = 0;
        this.Open = 0;
        this.High = 0;
        this.Low = 0;
        this.Close = 0;
        this.TradeVolumeValue = 0;
        this.TradesCount = 0;
    }
    static FromBytes(dv) {
        let rv = new User_MDH_BarItem_Type1_BinaryObject_Item();
        rv.Time = dv.getFloat64(0, true);
        rv.Open = dv.getFloat64(8, true);
        rv.High = dv.getFloat64(16, true);
        rv.Low = dv.getFloat64(24, true);
        rv.Close = dv.getFloat64(32, true);
        rv.TradeVolumeValue = dv.getFloat64(40, true);
        rv.TradesCount = dv.getInt32(48, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(52);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setFloat64(offset + 0, this.Time, true);
        dv.setFloat64(offset + 8, this.Open, true);
        dv.setFloat64(offset + 16, this.High, true);
        dv.setFloat64(offset + 24, this.Low, true);
        dv.setFloat64(offset + 32, this.Close, true);
        dv.setFloat64(offset + 40, this.TradeVolumeValue, true);
        dv.setInt32(offset + 48, this.TradesCount, true);
    }
    static GetTime(dv) { return dv.getFloat64(0, true); }
    static SetTime(dv, val) { dv.setFloat64(0, val, true); }
    static GetOpen(dv) { return dv.getFloat64(8, true); }
    static SetOpen(dv, val) { dv.setFloat64(8, val, true); }
    static GetHigh(dv) { return dv.getFloat64(16, true); }
    static SetHigh(dv, val) { dv.setFloat64(16, val, true); }
    static GetLow(dv) { return dv.getFloat64(24, true); }
    static SetLow(dv, val) { dv.setFloat64(24, val, true); }
    static GetClose(dv) { return dv.getFloat64(32, true); }
    static SetClose(dv, val) { dv.setFloat64(32, val, true); }
    static GetTradeVolumeValue(dv) { return dv.getFloat64(40, true); }
    static SetTradeVolumeValue(dv, val) { dv.setFloat64(40, val, true); }
    static GetTradesCount(dv) { return dv.getInt32(48, true); }
    static SetTradesCount(dv, val) { dv.setInt32(48, val, true); }
}
export var User_MDH_SubscribeBarItems_Input_Offsets;
(function (User_MDH_SubscribeBarItems_Input_Offsets) {
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["MESSAGE_SIZE"] = 42] = "MESSAGE_SIZE";
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["Header"] = 0] = "Header";
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["InstrumentId"] = 16] = "InstrumentId";
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["ClientSubscriptionId"] = 22] = "ClientSubscriptionId";
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["StartTimeEpochUtc"] = 26] = "StartTimeEpochUtc";
    User_MDH_SubscribeBarItems_Input_Offsets[User_MDH_SubscribeBarItems_Input_Offsets["EndTimeEpochUtc"] = 34] = "EndTimeEpochUtc";
})(User_MDH_SubscribeBarItems_Input_Offsets || (User_MDH_SubscribeBarItems_Input_Offsets = {}));
export class User_MDH_SubscribeBarItems_Input {
    constructor() {
        this.InstrumentId = 0;
        this.BarInterval = 0;
        this.SubscribeAction = 0;
        this.ClientSubscriptionId = 0;
        this.StartTimeEpochUtc = 0;
        this.EndTimeEpochUtc = 0;
        this.Header = new User_InputMessageHeader();
        this.Header.MessageLength = User_MDH_SubscribeBarItems_Input_Offsets.MESSAGE_SIZE;
        this.Header.MessageType = User_MessageType.User_MDH_SubscribeBarItems_Input;
    }
    static FromBytes(dv) {
        let rv = new User_MDH_SubscribeBarItems_Input();
        rv.Header = new User_InputMessageHeader();
        rv.Header.MessageLength = dv.getInt16(0, true);
        rv.Header.MessageType = dv.getInt16(2, true);
        rv.Header.HA_ClientUserId = dv.getInt32(4, true);
        rv.Header.HA_ClientSequenceNumber = dv.getBigInt64(8, true);
        rv.InstrumentId = dv.getInt32(16, true);
        rv.BarInterval = dv.getUint8(20);
        rv.SubscribeAction = dv.getUint8(21);
        rv.ClientSubscriptionId = dv.getInt32(22, true);
        rv.StartTimeEpochUtc = dv.getFloat64(26, true);
        rv.EndTimeEpochUtc = dv.getFloat64(34, true);
        return rv;
    }
    ToArrayBuffer() {
        let rv = new ArrayBuffer(42);
        this.ToBytes(new DataView(rv), 0);
        return rv;
    }
    ToBytes(dv, offset) {
        dv.setInt16(offset + 0, this.Header.MessageLength, true);
        dv.setInt16(offset + 2, this.Header.MessageType, true);
        dv.setInt32(offset + 4, this.Header.HA_ClientUserId, true);
        dv.setBigInt64(offset + 8, this.Header.HA_ClientSequenceNumber, true);
        dv.setInt32(offset + 16, this.InstrumentId, true);
        dv.setUint8(offset + 20, this.BarInterval);
        dv.setUint8(offset + 21, this.SubscribeAction);
        dv.setInt32(offset + 22, this.ClientSubscriptionId, true);
        dv.setFloat64(offset + 26, this.StartTimeEpochUtc, true);
        dv.setFloat64(offset + 34, this.EndTimeEpochUtc, true);
    }
    static Get_Header_MessageLength(dv) { return dv.getInt16(0, true); }
    static Set_Header_MessageLength(dv, val) { dv.setInt16(0, val, true); }
    static Get_Header_MessageType(dv) { return dv.getInt16(2, true); }
    static Set_Header_MessageType(dv, val) { dv.setInt16(2, val, true); }
    static Get_Header_HA_ClientUserId(dv) { return dv.getInt32(4, true); }
    static Set_Header_HA_ClientUserId(dv, val) { dv.setInt32(4, val, true); }
    static Get_Header_HA_ClientSequenceNumber(dv) { return dv.getBigInt64(8, true); }
    static Set_Header_HA_ClientSequenceNumber(dv, val) { dv.setBigInt64(8, val, true); }
    static GetInstrumentId(dv) { return dv.getInt32(16, true); }
    static SetInstrumentId(dv, val) { dv.setInt32(16, val, true); }
    static GetBarIntervalEnum(dv) { return dv.getUint8(20); }
    static SetBarIntervalEnum(dv, val) { dv.setUint8(20, val); }
    static GetSubscribeActionEnum(dv) { return dv.getUint8(21); }
    static SetSubscribeActionEnum(dv, val) { dv.setUint8(21, val); }
    static GetClientSubscriptionId(dv) { return dv.getInt32(22, true); }
    static SetClientSubscriptionId(dv, val) { dv.setInt32(22, val, true); }
    static GetStartTimeEpochUtc(dv) { return dv.getFloat64(26, true); }
    static SetStartTimeEpochUtc(dv, val) { dv.setFloat64(26, val, true); }
    static GetEndTimeEpochUtc(dv) { return dv.getFloat64(34, true); }
    static SetEndTimeEpochUtc(dv, val) { dv.setFloat64(34, val, true); }
}
export var OrderSideEnum;
(function (OrderSideEnum) {
    OrderSideEnum[OrderSideEnum["Buy"] = 0] = "Buy";
    OrderSideEnum[OrderSideEnum["Sell"] = 1] = "Sell";
    OrderSideEnum[OrderSideEnum["Short"] = 2] = "Short";
    OrderSideEnum[OrderSideEnum["Unknown"] = 3] = "Unknown";
})(OrderSideEnum || (OrderSideEnum = {}));
export var OrderTIFEnum;
(function (OrderTIFEnum) {
    OrderTIFEnum[OrderTIFEnum["Unknown"] = 0] = "Unknown";
    OrderTIFEnum[OrderTIFEnum["GTC"] = 1] = "GTC";
    OrderTIFEnum[OrderTIFEnum["OPG"] = 2] = "OPG";
    OrderTIFEnum[OrderTIFEnum["IOC"] = 3] = "IOC";
    OrderTIFEnum[OrderTIFEnum["FOK"] = 4] = "FOK";
    OrderTIFEnum[OrderTIFEnum["GTX"] = 5] = "GTX";
    OrderTIFEnum[OrderTIFEnum["GTD"] = 6] = "GTD";
})(OrderTIFEnum || (OrderTIFEnum = {}));
export var OrderTypeEnum;
(function (OrderTypeEnum) {
    OrderTypeEnum[OrderTypeEnum["Unknown"] = 0] = "Unknown";
    OrderTypeEnum[OrderTypeEnum["Market"] = 1] = "Market";
    OrderTypeEnum[OrderTypeEnum["Limit"] = 2] = "Limit";
    OrderTypeEnum[OrderTypeEnum["StopMarket"] = 3] = "StopMarket";
    OrderTypeEnum[OrderTypeEnum["StopLimit"] = 4] = "StopLimit";
    OrderTypeEnum[OrderTypeEnum["TrailingStopMarket"] = 5] = "TrailingStopMarket";
    OrderTypeEnum[OrderTypeEnum["TrailingStopLimit"] = 6] = "TrailingStopLimit";
    OrderTypeEnum[OrderTypeEnum["BlockTrade"] = 7] = "BlockTrade";
})(OrderTypeEnum || (OrderTypeEnum = {}));
export var AccountChangeReason;
(function (AccountChangeReason) {
    AccountChangeReason[AccountChangeReason["Unknown"] = 0] = "Unknown";
    AccountChangeReason[AccountChangeReason["OrderPlaced"] = 1] = "OrderPlaced";
    AccountChangeReason[AccountChangeReason["OrderCancelled"] = 2] = "OrderCancelled";
    AccountChangeReason[AccountChangeReason["OrderExecution"] = 3] = "OrderExecution";
    AccountChangeReason[AccountChangeReason["Deposit"] = 4] = "Deposit";
    AccountChangeReason[AccountChangeReason["Withdraw"] = 5] = "Withdraw";
    AccountChangeReason[AccountChangeReason["Admin"] = 6] = "Admin";
    AccountChangeReason[AccountChangeReason["Fee"] = 7] = "Fee";
    AccountChangeReason[AccountChangeReason["OrderModified"] = 8] = "OrderModified";
    AccountChangeReason[AccountChangeReason["Manual"] = 9] = "Manual";
    AccountChangeReason[AccountChangeReason["Rebate"] = 10] = "Rebate";
    AccountChangeReason[AccountChangeReason["Transfer"] = 11] = "Transfer";
    AccountChangeReason[AccountChangeReason["MarginAssetsAddedToQuote"] = 12] = "MarginAssetsAddedToQuote";
    AccountChangeReason[AccountChangeReason["MarginUserTransfer"] = 13] = "MarginUserTransfer";
    AccountChangeReason[AccountChangeReason["MarginOperatorTransferToMarginAccount"] = 14] = "MarginOperatorTransferToMarginAccount";
    AccountChangeReason[AccountChangeReason["MarginOperatorTransferToAssetAccount"] = 15] = "MarginOperatorTransferToAssetAccount";
    AccountChangeReason[AccountChangeReason["Distribution"] = 16] = "Distribution";
    AccountChangeReason[AccountChangeReason["MarginAddQuoteRejected"] = 17] = "MarginAddQuoteRejected";
    AccountChangeReason[AccountChangeReason["MarginUpdateQuoteRejected"] = 18] = "MarginUpdateQuoteRejected";
    AccountChangeReason[AccountChangeReason["MarginPositionReverseByTrade"] = 19] = "MarginPositionReverseByTrade";
    AccountChangeReason[AccountChangeReason["MarginPositionReverseByAcquisition"] = 20] = "MarginPositionReverseByAcquisition";
    AccountChangeReason[AccountChangeReason["OperatorLent"] = 21] = "OperatorLent";
    AccountChangeReason[AccountChangeReason["OperatorReceived"] = 22] = "OperatorReceived";
    AccountChangeReason[AccountChangeReason["Reconciliation"] = 23] = "Reconciliation";
})(AccountChangeReason || (AccountChangeReason = {}));
export var OrderCurrentState;
(function (OrderCurrentState) {
    OrderCurrentState[OrderCurrentState["Unknown"] = 0] = "Unknown";
    OrderCurrentState[OrderCurrentState["Working"] = 1] = "Working";
    OrderCurrentState[OrderCurrentState["Rejected"] = 2] = "Rejected";
    OrderCurrentState[OrderCurrentState["Canceled"] = 3] = "Canceled";
    OrderCurrentState[OrderCurrentState["Expired"] = 4] = "Expired";
    OrderCurrentState[OrderCurrentState["FullyExecuted"] = 5] = "FullyExecuted";
})(OrderCurrentState || (OrderCurrentState = {}));
export var OrderStateChangeReason;
(function (OrderStateChangeReason) {
    OrderStateChangeReason[OrderStateChangeReason["Unknown"] = 0] = "Unknown";
    OrderStateChangeReason[OrderStateChangeReason["NewInputAccepted"] = 1] = "NewInputAccepted";
    OrderStateChangeReason[OrderStateChangeReason["NewInputRejected"] = 2] = "NewInputRejected";
    OrderStateChangeReason[OrderStateChangeReason["OtherRejected"] = 3] = "OtherRejected";
    OrderStateChangeReason[OrderStateChangeReason["Expired"] = 4] = "Expired";
    OrderStateChangeReason[OrderStateChangeReason["Trade"] = 5] = "Trade";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_NoMoreMarket"] = 6] = "SystemCanceled_NoMoreMarket";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_BelowMinimum"] = 7] = "SystemCanceled_BelowMinimum";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_PriceCollar"] = 8] = "SystemCanceled_PriceCollar";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_MarginFailed"] = 9] = "SystemCanceled_MarginFailed";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_OutOfPriceFloorCeilingLimits"] = 10] = "SystemCanceled_OutOfPriceFloorCeilingLimits";
    OrderStateChangeReason[OrderStateChangeReason["SystemCanceled_MarketHalted"] = 11] = "SystemCanceled_MarketHalted";
    OrderStateChangeReason[OrderStateChangeReason["SystemModified_PriceCollar"] = 12] = "SystemModified_PriceCollar";
    OrderStateChangeReason[OrderStateChangeReason["StopActivated"] = 13] = "StopActivated";
    OrderStateChangeReason[OrderStateChangeReason["UserModified"] = 100] = "UserModified";
})(OrderStateChangeReason || (OrderStateChangeReason = {}));
export var LevelUpdateBatch1ControlEnum;
(function (LevelUpdateBatch1ControlEnum) {
    LevelUpdateBatch1ControlEnum[LevelUpdateBatch1ControlEnum["DeltaUpdates"] = 0] = "DeltaUpdates";
    LevelUpdateBatch1ControlEnum[LevelUpdateBatch1ControlEnum["ClearBidAndAskFirst"] = 1] = "ClearBidAndAskFirst";
})(LevelUpdateBatch1ControlEnum || (LevelUpdateBatch1ControlEnum = {}));
export var User_MD_L2_ControlMessage_Action;
(function (User_MD_L2_ControlMessage_Action) {
    User_MD_L2_ControlMessage_Action[User_MD_L2_ControlMessage_Action["BeginBatchUpdate"] = 11] = "BeginBatchUpdate";
    User_MD_L2_ControlMessage_Action[User_MD_L2_ControlMessage_Action["EndBatchUpdate"] = 12] = "EndBatchUpdate";
    User_MD_L2_ControlMessage_Action[User_MD_L2_ControlMessage_Action["ClearAllBids"] = 13] = "ClearAllBids";
    User_MD_L2_ControlMessage_Action[User_MD_L2_ControlMessage_Action["ClearAllAsks"] = 14] = "ClearAllAsks";
})(User_MD_L2_ControlMessage_Action || (User_MD_L2_ControlMessage_Action = {}));
export var User_ControlMessage_Action;
(function (User_ControlMessage_Action) {
    User_ControlMessage_Action[User_ControlMessage_Action["Unknown"] = 1] = "Unknown";
    User_ControlMessage_Action[User_ControlMessage_Action["Status_Heartbeat"] = 2] = "Status_Heartbeat";
})(User_ControlMessage_Action || (User_ControlMessage_Action = {}));
export var User_MDH_BarHeader_Output_BarItemType;
(function (User_MDH_BarHeader_Output_BarItemType) {
    User_MDH_BarHeader_Output_BarItemType[User_MDH_BarHeader_Output_BarItemType["Type1"] = 1] = "Type1";
})(User_MDH_BarHeader_Output_BarItemType || (User_MDH_BarHeader_Output_BarItemType = {}));
export var User_MDH_SubscribeBarItems_BarInterval;
(function (User_MDH_SubscribeBarItems_BarInterval) {
    User_MDH_SubscribeBarItems_BarInterval[User_MDH_SubscribeBarItems_BarInterval["OneMinute"] = 1] = "OneMinute";
    User_MDH_SubscribeBarItems_BarInterval[User_MDH_SubscribeBarItems_BarInterval["OneDay"] = 10] = "OneDay";
})(User_MDH_SubscribeBarItems_BarInterval || (User_MDH_SubscribeBarItems_BarInterval = {}));
export var User_MDH_SubscribeBarItems_SubscribeAction;
(function (User_MDH_SubscribeBarItems_SubscribeAction) {
    User_MDH_SubscribeBarItems_SubscribeAction[User_MDH_SubscribeBarItems_SubscribeAction["Subscribe"] = 1] = "Subscribe";
    User_MDH_SubscribeBarItems_SubscribeAction[User_MDH_SubscribeBarItems_SubscribeAction["Unsubscribe"] = 2] = "Unsubscribe";
})(User_MDH_SubscribeBarItems_SubscribeAction || (User_MDH_SubscribeBarItems_SubscribeAction = {}));
