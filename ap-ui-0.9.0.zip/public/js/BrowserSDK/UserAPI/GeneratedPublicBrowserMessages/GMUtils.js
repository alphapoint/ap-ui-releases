export class Utils {
    static DotNetDecimalToNumber(dv, offset) {
        let scale = dv.getUint8(2 + offset);
        let sign = dv.getUint8(3 + offset);
        let hi32 = dv.getUint32(4 + offset, true);
        let low64 = dv.getBigUint64(8 + offset, true);
        let divisor = 1.0;
        while (scale-- > 0) {
            divisor *= 10;
        }
        if (sign > 0) {
            divisor *= -1;
        }
        let highPart = 0.0;
        if (hi32 > 0) {
            highPart = hi32 / divisor;
            highPart *= 4294967296.0;
            highPart *= 4294967296.0;
        }
        else {
            highPart = 0.0;
        }
        return (Number(low64) / divisor) + highPart;
    }
    static NumberToDotNetDecimal(dv, input, offset) {
        let sign = input < 0 ? 128 : 0;
        let inp2 = Math.abs(input);
        let scale = 0;
        if ((inp2 % 1) != 0) {
            let str = inp2.toString();
            if (str.indexOf('e-') > -1) {
                let [base, trail] = str.split('e-');
                let elen = parseInt(trail, 10);
                let idx = base.indexOf(".");
                scale = idx == -1 ? 0 + elen : (base.length - idx - 1) + elen;
            }
            else {
                let index = str.indexOf(".");
                scale = index == -1 ? 0 : (str.length - index - 1);
            }
            inp2 = parseInt(str.replace(".", ""));
        }
        let num = BigInt(inp2);
        dv.setUint8(2 + offset, scale);
        dv.setUint8(3 + offset, sign);
        dv.setBigUint64(8 + offset, num, true);
    }
    static GuidToString(dv, offset) {
        return null;
    }
    static StringToGuid(dv, input, offset) {
    }
    static BetterJSONStringify(obj) {
        try {
            return JSON.stringify(obj, (key, value) => {
                return typeof value === 'bigint' ? Number(value) : value;
            });
        }
        catch (error) {
            return "Unable to stringify: " + obj;
        }
    }
}
export class QuickEvent {
    constructor() {
        this.handlers = [];
    }
    SubscribeEvent(handler) {
        this.handlers.push(handler);
    }
    UnsubscribeEvent(handler) {
        this.handlers = this.handlers.filter(h => h !== handler);
    }
    UnsubscribeAllEvents() {
        this.handlers = [];
    }
    DispatchEvent(data) {
        let len = this.handlers.length;
        for (let i = 0; i < len; i++) {
            this.handlers[i](data);
        }
    }
    Destroy() {
        this.handlers = null;
    }
    Expose() {
        return this;
    }
}
export class QuickEvent2 {
    constructor() {
        this.handlers = [];
    }
    SubscribeEvent(handler) {
        this.handlers.push(handler);
    }
    UnsubscribeEvent(handler) {
        this.handlers = this.handlers.filter(h => h !== handler);
    }
    UnsubscribeAllEvents() {
        this.handlers = [];
    }
    DispatchEvent(sender, data) {
        let len = this.handlers.length;
        for (let i = 0; i < len; i++) {
            this.handlers[i](sender, data);
        }
    }
    Destroy() {
        this.handlers = null;
    }
    Expose() {
        return this;
    }
}
export class QuickEventWithSubscriberCount {
    constructor() {
        this.handlers = [];
        this.subscriberCountChanged = new QuickEvent();
    }
    get SubscriberCountChanged() { return this.subscriberCountChanged.Expose(); }
    SubscribeEvent(handler) {
        this.handlers.push(handler);
        this.subscriberCountChanged.DispatchEvent(this.handlers.length);
    }
    UnsubscribeEvent(handler) {
        this.handlers = this.handlers.filter(h => h !== handler);
        this.subscriberCountChanged.DispatchEvent(this.handlers.length);
    }
    UnsubscribeAllEvents() {
        this.handlers = [];
    }
    DispatchEvent(data) {
        for (let handler of this.handlers) {
            handler(data);
        }
    }
    Destroy() {
        this.UnsubscribeAllEvents();
        this.subscriberCountChanged.Destroy();
    }
    Expose() {
        return this;
    }
}
export class JSON2 {
    static stringify(obj) {
        return JSON.stringify(obj, (key, value) => typeof value === 'bigint'
            ? value.toString()
            : value);
    }
}
