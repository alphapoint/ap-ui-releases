import { LZ4, BTree, LevelUpdateBatch1ControlEnum, MapSeqNumberWrapper, OrderSideEnum, ProductType, QuickEvent2, User_InputMessageHeader, User_MDH_BarItem_Type1_BinaryObject_Item, User_MDH_BarItem_Type1_BinaryObject_Item_Offsets, User_MD_L2_LevelUpdateBatch1_Item, User_MD_L2_LevelUpdateBatch1_Output, User_MessageType, User_MessageType_ToInstanceHelper } from "./index.js";
export class InstrumentMarketDataConnectionData {
    constructor() {
        this.ServerSequenceNumber = 0n;
        this.OrderBookAsks = new BTree();
        this.OrderBookBids = new BTree(null, (a, b) => {
            if (a > b) {
                return -1;
            }
            else if (a < b) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }
}
export class InstrumentMarketData {
    constructor(parentObj) {
        this.parentObj = parentObj;
        this.InstrumentId = null;
        this.RecentMDTrades = [];
        this.newMDTradeEvent = new QuickEvent2();
        this.orderBookFullUpdateEvent = new QuickEvent2();
        this.orderBookDeltaUpdateEvent = new QuickEvent2();
        this.last_MDTrade_SeqNumber_ServerIdToSeq_Map = new Map();
        this.favoredMarketDataConnection = new InstrumentMarketDataConnectionData();
        this.InstrumentMarketDataConnectionDataMap = new Map();
        this.IsL2Subscribed = false;
        this.IsMDSubscribed = false;
    }
    get OrderBookAsks() {
        return this.favoredMarketDataConnection.OrderBookAsks;
    }
    get OrderBookBids() {
        return this.favoredMarketDataConnection.OrderBookBids;
    }
    get NewMDTradeEvent() { return this.newMDTradeEvent.Expose(); }
    get OrderBookFullUpdateEvent() { return this.orderBookFullUpdateEvent.Expose(); }
    get OrderBookDeltaUpdateEvent() { return this.orderBookDeltaUpdateEvent.Expose(); }
    internal_UnsubscribeMD() {
        this.IsMDSubscribed = false;
        this.last_MDTrade_SeqNumber_ServerIdToSeq_Map = new Map();
        this.RecentMDTrades = new Array();
    }
    CheckConnectionHealth() {
        this.InstrumentMarketDataConnectionDataMap.forEach((value, key, map) => {
            if (value == this.favoredMarketDataConnection)
                return;
            if (value.ServerSequenceNumber > this.favoredMarketDataConnection.ServerSequenceNumber) {
                this.favoredMarketDataConnection = value;
                this.orderBookFullUpdateEvent.DispatchEvent(this, null);
                this.parentObj._md_orderBookFullUpdateEvent.DispatchEvent(this, null);
            }
        });
    }
    _ProcessNewMDTrade(mdTrade) {
        if (this.IsMDSubscribed == false)
            return;
        let seqNumberWrapper = this.last_MDTrade_SeqNumber_ServerIdToSeq_Map.get(mdTrade.Header.HA_ServerIdentifier);
        if (seqNumberWrapper == null) {
            seqNumberWrapper = new MapSeqNumberWrapper();
            this.last_MDTrade_SeqNumber_ServerIdToSeq_Map.set(mdTrade.Header.HA_ServerIdentifier, seqNumberWrapper);
        }
        if (seqNumberWrapper.SeqNumberVal >= mdTrade.Header.HA_ServerSequenceNumber) {
            return;
        }
        seqNumberWrapper.SeqNumberVal = mdTrade.Header.HA_ServerSequenceNumber;
        this.RecentMDTrades.unshift(mdTrade);
        if (this.RecentMDTrades.length > 100)
            this.RecentMDTrades.pop();
        this.newMDTradeEvent.DispatchEvent(this, mdTrade);
        this.parentObj._md_newTradeEvent.DispatchEvent(this, mdTrade);
    }
    _ProcessL2UpdateBatch(sender, l2UpdateBatch) {
        if (this.IsL2Subscribed == false)
            return;
        let l2UpdateBatchDV = new DataView(l2UpdateBatch);
        let itemSize = User_MD_L2_LevelUpdateBatch1_Output.GetItemSize(l2UpdateBatchDV);
        let numOfItems = User_MD_L2_LevelUpdateBatch1_Output.GetNumberOfItems(l2UpdateBatchDV);
        let itemPos = User_MD_L2_LevelUpdateBatch1_Output.Get_Header_MessageLength(l2UpdateBatchDV);
        let controlOptions = User_MD_L2_LevelUpdateBatch1_Output.GetControlOptionsEnum(l2UpdateBatchDV);
        let serverSeqNumber = User_MD_L2_LevelUpdateBatch1_Output.Get_Header_HA_ServerSequenceNumber(l2UpdateBatchDV);
        let doFullUpdate = false;
        let MDCnx = this.InstrumentMarketDataConnectionDataMap.get(sender.SymbolObj);
        if (MDCnx == null) {
            MDCnx = new InstrumentMarketDataConnectionData();
            MDCnx.MDConnection = sender;
            this.InstrumentMarketDataConnectionDataMap.set(sender.SymbolObj, MDCnx);
        }
        MDCnx.ServerSequenceNumber = serverSeqNumber;
        if (this.favoredMarketDataConnection.ServerSequenceNumber == 0n) {
            this.favoredMarketDataConnection = MDCnx;
            doFullUpdate = true;
        }
        if (controlOptions == LevelUpdateBatch1ControlEnum.ClearBidAndAskFirst) {
            MDCnx.OrderBookBids.clear();
            MDCnx.OrderBookAsks.clear();
            doFullUpdate = true;
        }
        for (let i = 0; i < numOfItems; i++) {
            let itemDV = new DataView(l2UpdateBatch.slice(itemPos, itemPos + itemSize));
            let level2Item = User_MD_L2_LevelUpdateBatch1_Item.FromBytes(itemDV);
            if (level2Item.Side == OrderSideEnum.Buy) {
                if (level2Item.Quantity > 0) {
                    MDCnx.OrderBookBids.set(level2Item.Price, level2Item);
                }
                else {
                    MDCnx.OrderBookBids.delete(level2Item.Price);
                }
            }
            else if (level2Item.Side == OrderSideEnum.Sell) {
                if (level2Item.Quantity > 0) {
                    MDCnx.OrderBookAsks.set(level2Item.Price, level2Item);
                }
                else {
                    MDCnx.OrderBookAsks.delete(level2Item.Price);
                }
            }
            itemPos += itemSize;
        }
        if (this.favoredMarketDataConnection.MDConnection == sender) {
            if (doFullUpdate == true) {
                this.orderBookFullUpdateEvent.DispatchEvent(this, l2UpdateBatch);
                this.parentObj._md_orderBookFullUpdateEvent.DispatchEvent(this, l2UpdateBatch);
            }
            else {
                this.orderBookDeltaUpdateEvent.DispatchEvent(this, l2UpdateBatch);
                this.parentObj._md_orderBookDeltaUpdateEvent.DispatchEvent(this, l2UpdateBatch);
            }
        }
    }
    Subscribe(subscriberName) {
        this.subscribers.add(subscriberName);
        if (this.subscribers.size == 1) {
        }
    }
    UnSubscribe(subscriberName) {
        this.subscribers.delete(subscriberName);
        if (this.subscribers.size == 0) {
        }
    }
}
export class MDH_OHLCV_1MIN_DataEnumerator {
    constructor(parent) {
        this.lz4 = new LZ4();
        this.parent = parent;
        this.IsComplete = false;
        this.ErrorMessage = null;
        this.HasError = false;
        this.hasProcessedAnyData = false;
        this.initial404Count = 0;
        this.convertToCurrency = null;
    }
    addDays(date, days) {
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }
    addMinutes(date, minutes) {
        return new Date(date.getTime() + minutes * 60000);
    }
    init() {
        this.currentDay = new Date(Date.UTC(this.startTime.getUTCFullYear(), this.startTime.getUTCMonth(), this.startTime.getUTCDate()));
        this.donext(true);
    }
    next() {
        setTimeout(() => {
            this.donext(false);
        }, 0);
    }
    donext(firstRun = false) {
        if (this.HasError) {
            this.cb(this, []);
            return;
        }
        if (firstRun == false) {
            this.currentDay = this.addMinutes(this.currentDay, 1440);
        }
        if (this.currentDay.getTime() > this.endTime.getTime()) {
            this.IsComplete = true;
            this.cb(this, new Array());
            return;
        }
        let InsData = this.parent.InstrumentData.get(this.instrument_id);
        if (InsData) {
            let itemsCache = InsData.DayToItemsMap.get(this.currentDay.getTime());
            if (itemsCache) {
                if (this.convertToCurrency == null) {
                    this.cb(this, itemsCache);
                }
                else {
                    this.processFXAndCB(itemsCache);
                }
                return;
            }
        }
        let dt = this.currentDay;
        let useLz4 = false;
        let urlStr = `${this.parent.BaseFileServerUrl}/OHLCV_1MIN/${this.instrument_id}/${this.currentDay.valueOf()}.rtbin`;
        if (useLz4)
            urlStr += '.lz4';
        fetch(urlStr, {
            method: 'GET',
        })
            .then(response => {
            if (response.status == 404) {
                if (this.hasProcessedAnyData == false) {
                    this.initial404Count++;
                    if (this.initial404Count > 30) {
                        this.HasError = true;
                        this.ErrorMessage = 'data not found (404)';
                        this.cb(this, new Array());
                        return null;
                    }
                    this.next();
                }
                else {
                    this.IsComplete = true;
                    this.cb(this, new Array());
                }
                return null;
            }
            return response;
        })
            .then(ab => {
            if (ab == null) {
                return;
            }
            this.hasProcessedAnyData = true;
            ab.arrayBuffer().then((value) => {
                let resultData = null;
                if (useLz4) {
                    let srcBuffer = new Uint8Array(value);
                    let unCompressedLen = this.lz4.calcUncompressedLen(srcBuffer);
                    resultData = new Uint8Array(unCompressedLen);
                    let finalLen = this.lz4.uncompressBlock(srcBuffer, resultData);
                    if (finalLen < unCompressedLen) {
                        resultData = resultData.slice(0, finalLen);
                    }
                }
                else {
                    resultData = new Uint8Array(value);
                    ;
                }
                if (resultData.length != (User_MDH_BarItem_Type1_BinaryObject_Item_Offsets.MESSAGE_SIZE * 1440)) {
                    this.HasError = true;
                    this.ErrorMessage = "resultData.length != (User_MDH_BarItem_Type1_BinaryObject_Item_Offsets.MESSAGE_SIZE * 1440)";
                    this.cb(this, new Array());
                    return;
                }
                else {
                    let oneDayOfItems = new Array(1440);
                    for (let itemIndex = 0; itemIndex < 1440; itemIndex++) {
                        let itemOffset = (itemIndex * User_MDH_BarItem_Type1_BinaryObject_Item_Offsets.MESSAGE_SIZE);
                        let itemDV = new DataView(resultData.buffer, itemOffset, User_MDH_BarItem_Type1_BinaryObject_Item_Offsets.MESSAGE_SIZE);
                        let item = User_MDH_BarItem_Type1_BinaryObject_Item.FromBytes(itemDV);
                        oneDayOfItems[itemIndex] = item;
                    }
                    let InsData = this.parent.InstrumentData.get(this.instrument_id);
                    if (InsData == null) {
                        InsData = new UserAPI_GlobalInstrumentData_InstrumentData();
                        this.parent.InstrumentData.set(this.instrument_id, InsData);
                    }
                    InsData.DayToItemsMap.set(this.currentDay.getTime(), oneDayOfItems);
                    if (this.convertToCurrency == null) {
                        this.cb(this, oneDayOfItems);
                    }
                    else {
                        this.processFXAndCB(oneDayOfItems);
                    }
                }
            }).catch((error) => {
                console.log(error);
                if (this.HasError || this.IsComplete)
                    return;
                this.HasError = true;
                this.ErrorMessage = "fetch error: " + error;
                this.cb(this, []);
                return;
            });
        });
    }
    FormatDate(date_ob) {
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        return year.toString() + month.toString() + date.toString();
    }
    processFXAndCB(oneDayOfItems) {
        let rvItems = new Array();
        this.parent.Get_FX_USD_DAY_SERIES(this.convertToCurrency, (utcDayToConversionValue) => {
            let forattedDate = this.FormatDate(this.currentDay);
            let conversionValue = utcDayToConversionValue.get(parseFloat(forattedDate));
            if (conversionValue == null) {
                this.HasError = true;
                this.ErrorMessage = "Unable to get fx conversion value for day";
                this.cb(this, []);
                return;
            }
            else {
                for (let itemIndex = 0; itemIndex < 1440; itemIndex++) {
                    let item = oneDayOfItems[itemIndex];
                    let newItem = new User_MDH_BarItem_Type1_BinaryObject_Item();
                    newItem.Open = item.Open * conversionValue;
                    newItem.High = item.High * conversionValue;
                    newItem.Low = item.Low * conversionValue;
                    newItem.Close = item.Close * conversionValue;
                    newItem.Time = item.Time;
                    newItem.TradeVolumeValue = item.TradeVolumeValue;
                    newItem.TradesCount = item.TradesCount;
                    rvItems.push(newItem);
                }
                this.cb(this, rvItems);
            }
        });
    }
}
export class UserAPI_GlobalInstrumentData_InstrumentData {
    constructor() {
        this.LastUsedDate = Date.now();
        this.DayToItemsMap = new Map();
    }
}
export class UserAPI_GlobalInstrumentData_Connection {
    constructor(parent) {
        this._preferredExchange = 'BINANCE';
        this.parent = parent;
        this._baseFileServerUrl = null;
        this.InstrumentDataSummary = null;
        this.InstrumentData = new Map();
        this.Cached_FX_USD_DAY_SERIES = new Map();
        this._ohlcvTTL = 30000;
        this._rollingOHLCVMap = new Map();
        this.fxProductsToLoad = 0;
        this.fxLoadStarted = false;
        this.fxLoadedOKBool = false;
        this.loadFX();
        this.parent.ReadyState.StateChanged.SubscribeEvent((data) => {
            this.loadFX();
        });
    }
    get BaseFileServerUrl() {
        return this._baseFileServerUrl;
    }
    set BaseFileServerUrl(u) {
        if (this._baseFileServerUrl !== u) {
            this._baseFileServerUrl = u;
            this.get_InstrumentDataSummary();
        }
    }
    loadFX() {
        if (this.parent.ReadyState.InstanceConfigReady && !this.parent.ReadyState.PreviousInstanceConfigReady) {
            if (this.fxLoadStarted)
                return;
            this.fxLoadStarted = true;
            this.parent.APIState.ProductInfos.forEach((productInfo) => {
                if (productInfo.ProductType == ProductType.NATIONAL_CURRENCY) {
                    this.fxProductsToLoad++;
                }
            });
            this.parent.APIState.ProductInfos.forEach((productInfo) => {
                if (productInfo.ProductType == ProductType.NATIONAL_CURRENCY) {
                    this.Get_FX_USD_DAY_SERIES(productInfo.Product, (utcDayToConversionValue) => {
                        this.fxProductsToLoad -= 1;
                        if (this.fxProductsToLoad == 0) {
                            this.fxLoadedOK();
                        }
                    });
                }
            });
            setTimeout(() => {
                if (this.fxProductsToLoad > 0) {
                    console.log("## Warning: Not all FX producted cached on load. Please fix on server or instrument mappings.");
                }
                this.fxLoadedOK();
            }, 3000);
        }
    }
    fxLoadedOK() {
        if (this.fxLoadedOKBool)
            return;
        this.fxLoadedOKBool = true;
        this.parent.ReadyState.GlobalInstrumentDataFXReady = true;
    }
    Get_Rolling24HR_OHLCV(prod1, prod2, cb) {
        let currentOHLCV = this._rollingOHLCVMap.get(`${prod1}${prod2}`);
        if (currentOHLCV && (Date.now() - new Date(currentOHLCV.Time).getTime()) < this._ohlcvTTL) {
            cb(currentOHLCV);
        }
        else {
            if (prod1 === 'CAD') {
                cb(null);
                return;
            }
            let urlStr;
            if (this._preferredExchange === 'BINANCE') {
                urlStr = `${this._baseFileServerUrl}/Rolling_24HR_OHLCV/${this._preferredExchange}_SPOT_${prod1}_USDT.rol24hrbin?r=${Math.random()}`;
            }
            else {
                urlStr = `${this._baseFileServerUrl}/Rolling_24HR_OHLCV/${this._preferredExchange}_SPOT_${prod1}_USD.rol24hrbin?r=${Math.random()}`;
            }
            fetch(urlStr, {
                method: 'GET',
            })
                .then(response => {
                if (response.status == 404) {
                    return null;
                }
                return response.arrayBuffer();
            })
                .then((res) => {
                if (res) {
                    currentOHLCV = User_MDH_BarItem_Type1_BinaryObject_Item.FromBytes(new DataView(res));
                    currentOHLCV.Time = Date.now();
                    if (prod2 != "USD" && prod2 != "USDT" && prod2 != "USDC") {
                        this.Get_FX_USD_DAY_SERIES(prod2, (utcDayToConversionValue) => {
                            if (utcDayToConversionValue == null) {
                                cb(null);
                            }
                            else {
                                let conversionValue = utcDayToConversionValue.get(-1);
                                if (conversionValue == null) {
                                    cb(null);
                                }
                                else {
                                    currentOHLCV.Open *= conversionValue;
                                    currentOHLCV.High *= conversionValue;
                                    currentOHLCV.Low *= conversionValue;
                                    currentOHLCV.Close *= conversionValue;
                                    this._rollingOHLCVMap.set(`${prod1}${prod2}`, currentOHLCV);
                                    cb(currentOHLCV);
                                }
                            }
                        });
                    }
                    else {
                        this._rollingOHLCVMap.set(`${prod1}${prod2}`, currentOHLCV);
                        cb(currentOHLCV);
                    }
                }
                else {
                    cb(null);
                }
            }).catch((reason) => {
                cb(null);
            });
        }
    }
    Get_OHLCV_1MIN_Bars(instrument, startTime, endTime, cb) {
        let mdhData = new MDH_OHLCV_1MIN_DataEnumerator(this);
        mdhData.cb = cb;
        mdhData.instrument_id = instrument;
        mdhData.startTime = startTime;
        mdhData.endTime = endTime;
        mdhData.init();
    }
    Get_OHLCV_1MIN_Bars_FX(product1, product2, startTime, endTime, cb) {
        let mdhData = new MDH_OHLCV_1MIN_DataEnumerator(this);
        mdhData.cb = cb;
        mdhData.instrument_id = `${this._preferredExchange}_SPOT_${product1}_${this.parent.ReferenceData_USD_Symbol}`;
        mdhData.startTime = startTime;
        mdhData.endTime = endTime;
        if (product2 != this.parent.ReferenceData_USD_Symbol) {
            mdhData.convertToCurrency = product2;
        }
        mdhData.init();
    }
    Get_FX_USD_DAY_SERIES(currency, cb) {
        if (this.Cached_FX_USD_DAY_SERIES.has(currency)) {
            cb(this.Cached_FX_USD_DAY_SERIES.get(currency));
            return;
        }
        let curUrl = currency;
        if (curUrl == "USDT" || curUrl == "USDC") {
            curUrl = "USD";
        }
        let urlStr = `${this._baseFileServerUrl}/FX/USD_DAY_SERIES/${curUrl}.json`;
        fetch(urlStr, {
            method: 'GET',
        })
            .then(response => {
            if (response.status == 404) {
                return null;
            }
            return response.text();
        })
            .then((res) => {
            let rvObj = JSON.parse(res);
            let rv = new Map();
            for (let key in rvObj) {
                let val = Number(rvObj[key]);
                rv.set(Number(key), val);
                rv.set(-1, val);
            }
            this.Cached_FX_USD_DAY_SERIES.set(currency, rv);
            cb(rv);
        }).catch((reason) => {
            cb(null);
        });
    }
    get_InstrumentDataSummary() {
        if (this.InstrumentDataSummary === null) {
            let urlStr = `${this._baseFileServerUrl}/INSTRUMENTS/ExchangeInstrumentDataSummary.json`;
            fetch(urlStr, {
                method: 'GET',
            })
                .then(response => {
                return response.json();
            })
                .then((res) => {
                this.InstrumentDataSummary = res;
                this.parent.ReadyState.InstrumentDataSummaryReady = true;
            }).catch((reason) => {
                this.parent.ReadyState.InstrumentDataSummaryReady_Error = "Error getting: " + urlStr + ", " + JSON.stringify(reason);
                this.parent.ReadyState.InstrumentDataSummaryReady = false;
            });
        }
    }
    Get_InstrumentDataSummaryInstrument(productOne, productTwo) {
        if (productTwo != this.parent.ReferenceData_USD_Symbol) {
            let referenceInsDataSummary = Object.assign({}, this.Get_InstrumentDataSummaryInstrument(productOne, this.parent.ReferenceData_USD_Symbol));
            referenceInsDataSummary.Product2Name = productTwo;
            return referenceInsDataSummary;
        }
        if (this.InstrumentDataSummary) {
            return this.InstrumentDataSummary.Instruments.find((instrument) => {
                if (instrument.Product1Name === productOne) {
                    if (instrument.Product2Name === productTwo) {
                        return true;
                    }
                }
                return false;
            }) || null;
        }
        else {
            return null;
        }
    }
}
export class UserAPI_MarketDataHistoryService_Connection {
    constructor() {
        this.wsUrl = "wss://fg-staging1.cdnhop.net:9009/ws/mdhs";
        this.ws = null;
        this.active_OHLC_1MIN_Subscriptions = new Set();
        this.newOHLCV_1MIN_Event = new QuickEvent2();
        setInterval(() => { this.TryConnect(); }, 5000);
        this.TryConnect();
    }
    get NewOHLCV_1MIN_Event() { return this.newOHLCV_1MIN_Event.Expose(); }
    TryConnect() {
        if (this.ws != null && this.ws.readyState == WebSocket.OPEN) {
            return;
        }
        this.resetLocalWebsocket();
        this.ws = new WebSocket(this.wsUrl);
        this.ws.binaryType = 'arraybuffer';
        this.ws.onopen = this.onOpen.bind(this);
        this.ws.onmessage = this.onMessage.bind(this);
        this.ws.onclose = this.onClose.bind(this);
        this.ws.onerror = this.onError.bind(this);
    }
    IsConnecting() {
        if (!this.ws)
            return false;
        if (this.ws.readyState == this.ws.CONNECTING)
            return true;
        return false;
    }
    IsConnected() {
        if (!this.ws)
            return false;
        if (this.ws.readyState != this.ws.OPEN)
            return false;
        return true;
    }
    onOpen(event) {
        console.log('UserAPI_MarketDataHistoryService_Connection WS Connection Opened');
        for (let subStr of this.active_OHLC_1MIN_Subscriptions) {
            this.Subscribe_OHLCV_1MIN(subStr);
        }
    }
    onMessage(event) {
        let data = event.data;
        if (typeof data === 'string') {
            let parsedMsg = JSON.parse(data);
            this.newOHLCV_1MIN_Event.DispatchEvent(this, parsedMsg);
        }
    }
    Subscribe_OHLCV_1MIN(symbol) {
        console.log('MD OHLCV SUBSCRIBE: ', symbol);
        this.active_OHLC_1MIN_Subscriptions.add(symbol);
        this.SendMessage(JSON.stringify({
            mt: 'OHLCV_1MIN_Subscribe',
            symbol: symbol
        }));
    }
    Unsubscribe_OHLCV_1MIN(symbol) {
        console.log('MD OHLCV UNSUBSCRIBE: ', symbol);
        this.active_OHLC_1MIN_Subscriptions.delete(symbol);
        this.SendMessage(JSON.stringify({
            mt: 'OHLCV_1MIN_Unsubscribe',
            symbol: symbol
        }));
        let yo = 0;
    }
    onClose(event) {
        console.log('UserAPI_MarketDataHistoryService_Connection WS Connection Closed');
    }
    onError(event) {
        console.log('UserAPI_MarketDataHistoryService_Connection WS Connection Error', event);
    }
    resetLocalWebsocket() {
        try {
            if (this.ws !== null) {
                this.ws.onopen = null;
                this.ws.onmessage = null;
                this.ws.onclose = null;
                this.ws.onerror = null;
                this.ws.close();
                this.ws = null;
            }
        }
        catch (err) {
        }
    }
    Destroy() {
        try {
            this.resetLocalWebsocket();
        }
        catch (err) {
        }
    }
    SendMessage(data) {
        try {
            if (!this.ws)
                return;
            if (this.ws.readyState != this.ws.OPEN)
                return;
            this.ws.send(data);
        }
        catch (err) {
            console.log("Error in MarketData Connection SendBinaryMessage: " + this.wsUrl + err);
        }
    }
}
export class UserAPI_MarketData_Connection {
    constructor(parentObj, wsUrl) {
        this.isAuthed = false;
        this.wsUrl = wsUrl;
        this.ws = null;
        this.parentObj = parentObj;
        this.SymbolObj = Symbol("UserAPI_MarketData_Connection: " + wsUrl);
        this.onOpen = this.onOpen.bind(this);
        this.onMessage = this.onMessage.bind(this);
        this.onClose = this.onClose.bind(this);
        this.onError = this.onError.bind(this);
    }
    TryConnect() {
        this.resetLocalWebsocket();
        this.ws = new WebSocket(this.wsUrl);
        this.ws.binaryType = 'arraybuffer';
        this.ws.onopen = this.onOpen;
        this.ws.onmessage = this.onMessage;
        this.ws.onclose = this.onClose;
        this.ws.onerror = this.onError;
    }
    IsConnecting() {
        if (!this.ws)
            return false;
        if (this.ws.readyState == this.ws.CONNECTING)
            return true;
        return false;
    }
    IsConnected() {
        if (!this.ws)
            return false;
        if (this.ws.readyState != this.ws.OPEN)
            return false;
        if (!this.isAuthed)
            return false;
        return true;
    }
    onOpen(event) {
        console.log('UserAPI_MarketData_Connection WS Connection Opened');
        this.ws.send(JSON.stringify({
            MT: 'UserAuthPublic',
            InstanceId: this.parentObj.InstanceId,
            User: null,
            Password: null
        }));
    }
    GetInstrumentState(instrumentId) {
        return this.parentObj.APIState.GetInstrumentState(instrumentId);
    }
    onMessage(event) {
        let data = event.data;
        let serverMessageDV = null;
        if (typeof data === 'string') {
            if (!this.isAuthed) {
                let parsedMsg = JSON.parse(data);
                if (parsedMsg.MT && parsedMsg.MT == "UserAuthMessageResponse") {
                    if (parsedMsg.IsPublicMode) {
                        this.isAuthed = true;
                        this.parentObj.internalMarketDataConnectionReady(this);
                    }
                }
            }
        }
        else if (data instanceof ArrayBuffer) {
            serverMessageDV = new DataView(data);
        }
        if (serverMessageDV != null) {
            let userMsgType = User_InputMessageHeader.GetMessageType(serverMessageDV);
            let output = User_MessageType_ToInstanceHelper.User_MessageType_ToInstance(serverMessageDV);
            if (userMsgType == User_MessageType.User_MD_L2_LevelUpdateBatch1_Output) {
                let insState = this.GetInstrumentState(output.InstrumentId);
                insState._ProcessL2UpdateBatch(this, data);
            }
            else if (userMsgType == User_MessageType.User_MD_TradeUpdate_Output) {
                let insState = this.GetInstrumentState(output.InstrumentId);
                insState._ProcessNewMDTrade(output);
            }
        }
    }
    onClose(event) {
        console.log('UserAPI_MarketData_Connection WS Connection Closed');
        this.isAuthed = false;
        this.parentObj.internalMarketDataConnectionClosed(this);
    }
    onError(event) {
        console.log('UserAPI_MarketData_Connection WS Connection Error', event);
        this.isAuthed = false;
        this.parentObj.internalMarketDataConnectionClosed(this);
    }
    resetLocalWebsocket() {
        try {
            if (this.ws !== null) {
                this.ws.onopen = null;
                this.ws.onmessage = null;
                this.ws.onclose = null;
                this.ws.onerror = null;
                this.ws.close();
                this.ws = null;
            }
        }
        catch (err) {
        }
    }
    Destroy() {
        try {
            this.resetLocalWebsocket();
        }
        catch (err) {
        }
    }
    SendBinaryMessage(data) {
        try {
            if (!this.ws)
                return;
            if (this.ws.readyState != this.ws.OPEN)
                return;
            this.ws.send(data);
        }
        catch (err) {
            console.log("Error in MarketData Connection SendBinaryMessage: " + this.wsUrl + err);
        }
    }
}
