export class LZ4 {
    constructor() {
        this.errInvalidSource = new Error('invalid source');
        this.errShortBuffer = new Error('short buffer');
        this.minMatch = 4;
        this.winSizeLog = 16;
        this.winSize = 1 << this.winSizeLog;
        this.winMask = this.winSize - 1;
        this.hashSizeLog = 16;
        this.hashSize = 1 << this.hashSizeLog;
        this.hashShift = (this.minMatch * 8) - this.hashSizeLog;
        this.mfLimit = 8 + this.minMatch;
        this.skipStrength = 6;
        this.hasher = 2654435761 | 0;
        this.imul = Math.imul ? Math.imul : this.imulPolyfill;
    }
    imulPolyfill(a, b) {
        const ah = (a >>> 16) & 0xffff;
        const al = a & 0xffff;
        const bh = (b >>> 16) & 0xffff;
        const bl = b & 0xffff;
        return al * bl + (((ah * bl + al * bh) << 16) >>> 0) | 0;
    }
    ;
    getUint32(a, i) {
        return (a[i + 3]) | (a[i + 2] << 8) | (a[i + 1] << 16) | (a[i] << 24);
    }
    copy(dest, src, di, si, len) {
        for (let i = 0; i < len; ++i) {
            dest[di++] = src[si++];
        }
    }
    calcUncompressedLen(src) {
        const sn = src.length;
        if (sn === 0) {
            return 0;
        }
        for (let si = 0, di = 0;;) {
            let lLen = src[si] >> 4;
            let mLen = src[si] & 0xf;
            if (++si === sn) {
                throw this.errInvalidSource;
            }
            if (lLen > 0) {
                if (lLen === 0xf) {
                    while (src[si] === 0xff) {
                        lLen += 0xff;
                        if (++si === sn) {
                            throw this.errInvalidSource;
                        }
                    }
                    lLen += src[si];
                    if (++si === sn) {
                        throw this.errInvalidSource;
                    }
                }
                di += lLen;
                si += lLen;
                if (si >= sn) {
                    return di;
                }
            }
            si += 2;
            if (si >= sn) {
                throw this.errInvalidSource;
            }
            const offset = src[si - 2] | (src[si - 1] << 8);
            if (di - offset < 0 || offset === 0) {
                throw this.errInvalidSource;
            }
            if (mLen === 0xf) {
                while (src[si] === 0xff) {
                    mLen += 0xff;
                    if (++si === sn) {
                        throw this.errInvalidSource;
                    }
                }
                mLen += src[si];
                if (++si === sn) {
                    throw this.errInvalidSource;
                }
            }
            mLen += 4;
            for (; mLen >= offset; mLen -= offset) {
                di += offset;
            }
            di += mLen;
        }
    }
    uncompressBlock(src, dest) {
        const sn = src.length;
        const dn = dest.length;
        if (sn === 0) {
            return 0;
        }
        for (let si = 0, di = 0;;) {
            let lLen = src[si] >> 4;
            let mLen = src[si] & 0xf;
            if (++si === sn) {
                throw this.errInvalidSource;
            }
            if (lLen > 0) {
                if (lLen === 0xf) {
                    while (src[si] === 0xff) {
                        lLen += 0xff;
                        if (++si === sn) {
                            throw this.errInvalidSource;
                        }
                    }
                    lLen += src[si];
                    if (++si === sn) {
                        throw this.errInvalidSource;
                    }
                }
                if (dn - di < lLen || si + lLen > sn) {
                    throw this.errShortBuffer;
                }
                this.copy(dest, src, di, si, lLen);
                di += lLen;
                si += lLen;
                if (si >= sn) {
                    return di;
                }
            }
            si += 2;
            if (si >= sn) {
                throw this.errInvalidSource;
            }
            const offset = src[si - 2] | (src[si - 1] << 8);
            if (di - offset < 0 || offset === 0) {
                throw this.errInvalidSource;
            }
            if (mLen === 0xf) {
                while (src[si] === 0xff) {
                    mLen += 0xff;
                    if (++si === sn) {
                        throw this.errInvalidSource;
                    }
                }
                mLen += src[si];
                if (++si === sn) {
                    throw this.errInvalidSource;
                }
            }
            mLen += 4;
            if (dn - di <= mLen) {
                throw this.errShortBuffer;
            }
            for (; mLen >= offset; mLen -= offset) {
                this.copy(dest, dest, di, di - offset, offset);
                di += offset;
            }
            this.copy(dest, dest, di, di - offset, mLen);
            di += mLen;
        }
    }
    compressBlockBound(n) {
        return n + (n / 255 | 0) + 16;
    }
    compressBlock(src, dest, soffset) {
        const sn = src.length - this.mfLimit;
        const dn = dest.length;
        if (sn <= 0 || dn === 0 || soffset >= sn) {
            return 0;
        }
        let si = 0, di = 0;
        const hashTable = new Uint32Array(this.hashSize);
        while (si < soffset) {
            const h = this.imul(this.getUint32(src, si), this.hasher) >>> this.hashShift;
            hashTable[h] = ++si;
        }
        let anchor = si;
        let fma = 1 << this.skipStrength;
        while (si < sn - this.minMatch) {
            const h = this.imul(this.getUint32(src, si), this.hasher) >>> this.hashShift;
            const ref = hashTable[h] - 1;
            hashTable[h] = si + 1;
            if (ref < 0 ||
                (si - ref) >> this.winSizeLog > 0 ||
                src[ref] !== src[si] ||
                src[ref + 1] !== src[si + 1] ||
                src[ref + 2] !== src[si + 2] ||
                src[ref + 3] !== src[si + 3]) {
                si += fma >> this.skipStrength;
                ++fma;
                continue;
            }
            fma = 1 << this.skipStrength;
            const lLen = si - anchor;
            const offset = si - ref;
            si += this.minMatch;
            let mLen = si;
            while (si <= sn && src[si] === src[si - offset]) {
                si++;
            }
            mLen = si - mLen;
            if (mLen < 0xf) {
                dest[di] = mLen;
            }
            else {
                dest[di] = 0xf;
            }
            if (lLen < 0xf) {
                dest[di] |= lLen << 4;
            }
            else {
                dest[di] |= 0xf0;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
                let l = lLen - 0xf;
                for (; l >= 0xff; l -= 0xff) {
                    dest[di] = 0xff;
                    if (++di === dn) {
                        throw this.errShortBuffer;
                    }
                }
                dest[di] = l & 0xff;
            }
            if (++di === dn) {
                throw this.errShortBuffer;
            }
            if (di + lLen >= dn) {
                throw this.errShortBuffer;
            }
            this.copy(dest, src, di, anchor, lLen);
            di += lLen;
            anchor = si;
            di += 2;
            if (di >= dn) {
                throw this.errShortBuffer;
            }
            dest[di - 2] = offset;
            dest[di - 1] = offset >> 8;
            if (mLen >= 0xf) {
                for (mLen -= 0xf; mLen >= 0xff; mLen -= 0xff) {
                    dest[di] = 0xff;
                    if (++di === dn) {
                        throw this.errShortBuffer;
                    }
                }
                dest[di] = mLen;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
            }
        }
        if (anchor === 0) {
            return 0;
        }
        let lLen = src.length - anchor;
        if (lLen < 0xf) {
            dest[di] = lLen << 4;
        }
        else {
            dest[di] = 0xf0;
            if (++di === dn) {
                throw this.errShortBuffer;
            }
            for (lLen -= 0xf; lLen >= 0xff; lLen -= 0xff) {
                dest[di] = 0xff;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
            }
            dest[di] = lLen;
        }
        if (++di === dn) {
            throw this.errShortBuffer;
        }
        const lastLen = src.length - anchor;
        const n = di + lastLen;
        if (n > dn) {
            throw this.errShortBuffer;
        }
        else if (n >= sn) {
            return 0;
        }
        this.copy(dest, src, di, anchor, lastLen);
        di += lastLen;
        return di;
    }
    compressBlockHC(src, dest, soffset) {
        const sn = src.length - this.mfLimit;
        const dn = dest.length;
        if (sn <= 0 || dn === 0 || soffset >= sn) {
            return 0;
        }
        let si = 0, di = 0;
        const hashTable = new Uint32Array(this.hashSize);
        const chainTable = new Uint32Array(this.winSize);
        while (si < soffset) {
            const h = this.imul(this.getUint32(src, si), this.hasher) >>> this.hashShift;
            chainTable[si & this.winMask] = hashTable[h];
            hashTable[h] = ++si;
        }
        let anchor = si;
        while (si < sn - this.minMatch) {
            const h = this.imul(this.getUint32(src, si), this.hasher) >>> this.hashShift;
            let mLen = 0;
            let offset = 0;
            for (let next = hashTable[h] - 1; next > 0 && next > si - this.winSize; next = chainTable[next & this.winMask] - 1) {
                if (src[next + mLen] === src[si + mLen]) {
                    for (let ml = 0;; ++ml) {
                        if (src[next + ml] !== src[si + ml] || si + ml > sn) {
                            if (mLen < ml && ml >= this.minMatch) {
                                mLen = ml;
                                offset = si - next;
                            }
                            break;
                        }
                    }
                }
            }
            chainTable[si & this.winMask] = hashTable[h];
            hashTable[h] = si + 1;
            if (mLen === 0) {
                ++si;
                continue;
            }
            for (let si2 = si + 1, ml = si + mLen; si2 < ml;) {
                const h = this.imul(this.getUint32(src, si2), this.hasher) >>> this.hashShift;
                chainTable[si2 & this.winMask] = hashTable[h];
                hashTable[h] = ++si2;
            }
            const lLen = si - anchor;
            si += mLen;
            mLen -= this.minMatch;
            if (mLen < 0xf) {
                dest[di] = mLen;
            }
            else {
                dest[di] = 0xf;
            }
            if (lLen < 0xf) {
                dest[di] |= lLen << 4;
            }
            else {
                dest[di] |= 0xf0;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
                let l = lLen - 0xf;
                for (; l >= 0xff; l -= 0xff) {
                    dest[di] = 0xff;
                    if (++di === dn) {
                        throw this.errShortBuffer;
                    }
                }
                dest[di] = l & 0xff;
            }
            if (++di === dn) {
                throw this.errShortBuffer;
            }
            if (di + lLen >= dn) {
                throw this.errShortBuffer;
            }
            this.copy(dest, src, di, anchor, lLen);
            di += lLen;
            anchor = si;
            di += 2;
            if (di >= dn) {
                throw this.errShortBuffer;
            }
            dest[di - 2] = offset;
            dest[di - 1] = offset >> 8;
            if (mLen >= 0xf) {
                for (mLen -= 0xf; mLen >= 0xff; mLen -= 0xff) {
                    dest[di] = 0xff;
                    if (++di === dn) {
                        throw this.errShortBuffer;
                    }
                }
                dest[di] = mLen;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
            }
        }
        if (anchor === 0) {
            return 0;
        }
        let lLen = src.length - anchor;
        if (lLen < 0xf) {
            dest[di] = lLen << 4;
        }
        else {
            dest[di] = 0xf0;
            if (++di === dn) {
                throw this.errShortBuffer;
            }
            for (lLen -= 0xf; lLen >= 0xff; lLen -= 0xff) {
                dest[di] = 0xff;
                if (++di === dn) {
                    throw this.errShortBuffer;
                }
            }
            dest[di] = lLen;
        }
        if (++di === dn) {
            throw this.errShortBuffer;
        }
        const lastLen = src.length - anchor;
        const n = di + lastLen;
        if (n > dn) {
            throw this.errShortBuffer;
        }
        else if (n >= sn) {
            return 0;
        }
        this.copy(dest, src, di, anchor, lastLen);
        di += lastLen;
        return di;
    }
}
