export var AccountCredentialObject_AuthMethodEnum;
(function (AccountCredentialObject_AuthMethodEnum) {
    AccountCredentialObject_AuthMethodEnum[AccountCredentialObject_AuthMethodEnum["None"] = 0] = "None";
    AccountCredentialObject_AuthMethodEnum[AccountCredentialObject_AuthMethodEnum["UserNameAndPassword"] = 1] = "UserNameAndPassword";
    AccountCredentialObject_AuthMethodEnum[AccountCredentialObject_AuthMethodEnum["SessionToken"] = 2] = "SessionToken";
})(AccountCredentialObject_AuthMethodEnum || (AccountCredentialObject_AuthMethodEnum = {}));
export class MapSeqNumberWrapper {
    constructor() {
        this.SeqNumberVal = -1n;
    }
}
export var ProductType;
(function (ProductType) {
    ProductType["CRYPTO_CURRENCY"] = "CryptoCurrency";
    ProductType["NATIONAL_CURRENCY"] = "NationalCurrency";
})(ProductType || (ProductType = {}));
export var UserReportType;
(function (UserReportType) {
    UserReportType["TradeActivity"] = "TradeActivity";
    UserReportType["Transaction"] = "Transaction";
    UserReportType["Treasury"] = "Treasury";
})(UserReportType || (UserReportType = {}));
export var UserReportFrequency;
(function (UserReportFrequency) {
    UserReportFrequency["OnDemand"] = "onDemand";
    UserReportFrequency["Hourly"] = "Hourly";
    UserReportFrequency["Daily"] = "Daily";
    UserReportFrequency["Weekly"] = "Weekly";
    UserReportFrequency["Monthly"] = "Monthly";
    UserReportFrequency["Annually"] = "Annually";
})(UserReportFrequency || (UserReportFrequency = {}));
export var UserReportStatus;
(function (UserReportStatus) {
    UserReportStatus["Submitted"] = "Submitted";
    UserReportStatus["Validating"] = "Validating";
    UserReportStatus["Scheduled"] = "Scheduled";
    UserReportStatus["InProgress"] = "InProgress";
    UserReportStatus["Completed"] = "Completed";
    UserReportStatus["Aborting"] = "Aborting";
    UserReportStatus["Aborted"] = "Aborted";
    UserReportStatus["UserCancelled"] = "UserCancelled";
    UserReportStatus["SysRetired"] = "SysRetired";
    UserReportStatus["UserCancelPending"] = "UserCancelPending";
})(UserReportStatus || (UserReportStatus = {}));
