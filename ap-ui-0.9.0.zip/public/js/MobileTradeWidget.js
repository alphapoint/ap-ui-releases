import { NumberFormatType, ALanguageManager, AContainer, AMenuData, AMenuDataItem, ATextInput, AButtonBar, AButtonBarEvent, AButton, ASelect, AText, ALabel, AFormatManager, ADataGrid, ADataGridEvent, ASystemManager } from './a/index.js';
import { OrderSideEnum, OrderTIFEnum, OrderTypeEnum } from './BrowserSDK/UserAPI/index.js';
import { OrderBook } from './components/OrderBook.js';
import { OrderBookItemType } from './components/OrderBookItem.js';
import { TradingPanel } from './components/TradingPanel.js';
import { OrderBookEvent } from './events/OrderBookEvent.js';
import { TradingManager } from './managers/TradingManager.js';
import MobileTradeAccountOrdersDataGridRow from './renderers/MobileTradeAccountOrdersDataGridRow.js';
export class MobileTradeWidget extends TradingPanel {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._product1Symbol = null;
        this._product2Symbol = null;
        this._marketPrice = null;
        this._price = null;
        this._fee = null;
        this._total = null;
        this._net = null;
        this._orderTypes = [OrderTypeEnum.Market, OrderTypeEnum.Limit, OrderTypeEnum.StopMarket, OrderTypeEnum.StopLimit];
        this._selectedOrderType = OrderTypeEnum.Limit;
        this._orderContainer = new AContainer();
        this._orderContainer.addClass('order');
        this._panelContents.appendChild(this._orderContainer);
        this._orderTypeButtons = new AButtonBar();
        this._orderTypeButtons.addClass('order-type-buttons');
        this._orderTypeButtons.labels = ['Mkt', 'Lmt', 'Stp Mkt', 'Stp Lmt'];
        this._orderTypeButtons.selectedIndex = 1;
        this._orderContainer.appendChild(this._orderTypeButtons);
        this._orderSideButtons = new AButtonBar();
        this._orderSideButtons.addClass('order-side-buttons');
        this._orderSideButtons.labels = ['Buy', 'Sell'];
        this._orderSideButtons.selectedIndex = 0;
        this._orderContainer.appendChild(this._orderSideButtons);
        let formContainer = new AContainer();
        formContainer.addClass('form');
        this._orderContainer.appendChild(formContainer);
        this._priceInput = new ATextInput();
        this._priceInput.type = ATextInput.NUMBER;
        formContainer.appendChild(this._priceInput);
        this._quantityInput = new ATextInput();
        this._quantityInput.type = ATextInput.NUMBER;
        this._quantityInput.value = '1';
        formContainer.appendChild(this._quantityInput);
        this._quantityButtons = new AButtonBar();
        this._quantityButtons.addClass('quantity-buttons');
        this._quantityButtons.labels = ['25%', '50%', '75%', 'MAX'];
        this._quantityButtons.selectable = false;
        formContainer.appendChild(this._quantityButtons);
        this._quantityButtonQuantities = [.25, .5, .75, 1];
        this._stopPriceInput = new ATextInput();
        this._stopPriceInput.type = ATextInput.NUMBER;
        formContainer.appendChild(this._stopPriceInput);
        this._timeInForceSelect = new ASelect();
        this._timeInForceSelect.options = `<option value="${OrderTIFEnum.GTC}">GTC</option><option value="${OrderTIFEnum.IOC}">IOC</option><option value="${OrderTIFEnum.FOK}">FOK</option>`;
        formContainer.appendChild(this._timeInForceSelect);
        let infoContainer = new AContainer();
        infoContainer.addClass('info');
        this._orderContainer.appendChild(infoContainer);
        this._feeLabel = new ALabel();
        this._feeLabel.text = 'Fees';
        infoContainer.appendChild(this._feeLabel);
        this._feeText = new AText();
        infoContainer.appendChild(this._feeText);
        this._totalLabel = new ALabel();
        this._totalLabel.text = 'Total';
        infoContainer.appendChild(this._totalLabel);
        this._totalText = new AText();
        infoContainer.appendChild(this._totalText);
        this._netLabel = new ALabel();
        this._netLabel.text = 'Net';
        infoContainer.appendChild(this._netLabel);
        this._netText = new AText();
        infoContainer.appendChild(this._netText);
        this._sendOrderButton = new AButton();
        this._sendOrderButton.addClass('send-order-button');
        this._orderContainer.appendChild(this._sendOrderButton);
        this._orderBook = new OrderBook();
        this._orderBook.precision = null;
        this._panelContents.appendChild(this._orderBook);
        this._accountOrdersContainer = new AContainer();
        this._accountOrdersContainer.addClass('account-orders');
        this._panelContents.appendChild(this._accountOrdersContainer);
        this._accountOrderStatusButtons = new AButtonBar();
        this._accountOrderStatusButtons.selectedIndex = 0;
        this._accountOrdersContainer.appendChild(this._accountOrderStatusButtons);
        this._accountOrdersGrid = new ADataGrid();
        this._accountOrdersGrid.rowRenderer = MobileTradeAccountOrdersDataGridRow;
        this._accountOrdersGrid.selectable = true;
        this._accountOrdersContainer.appendChild(this._accountOrdersGrid);
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        let tm = TradingManager.instance;
        this._onProductsMarketDataChanged = this._onProductsMarketDataChanged.bind(this);
        tm.ProductsMarketDataChanged.SubscribeEvent(this._onProductsMarketDataChanged);
        this._onOrderBookSideSelected = this._onOrderBookSideSelected.bind(this);
        tm.OrderBookSideSelected.SubscribeEvent(this._onOrderBookSideSelected);
        this._onOrderBookPriceSelected = this._onOrderBookPriceSelected.bind(this);
        tm.OrderBookPriceSelected.SubscribeEvent(this._onOrderBookPriceSelected);
        this._orderTypeIndexChanged = this._orderTypeIndexChanged.bind(this);
        this._orderTypeButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._orderTypeIndexChanged);
        this._orderSideIndexChanged = this._orderSideIndexChanged.bind(this);
        this._orderSideButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._orderSideIndexChanged);
        this._onQuantityButtonClicked = this._onQuantityButtonClicked.bind(this);
        this._quantityButtons.addEventListener(AButtonBarEvent.BUTTON_CLICK, this._onQuantityButtonClicked);
        this._onInputCommitted = this._onInputCommitted.bind(this);
        this.addEventListener('change', this._onInputCommitted);
        this._onInputOrChange = this._onInputOrChange.bind(this);
        this.addEventListener('input', this._onInputOrChange);
        this._sendOrderClicked = this._sendOrderClicked.bind(this);
        this._sendOrderButton.addEventListener('click', this._sendOrderClicked);
        this._onOrderbookFullUpdate = this._onOrderbookFullUpdate.bind(this);
        tm.APIState.MD_OrderBookFullUpdateEvent.SubscribeEvent(this._onOrderbookFullUpdate);
        this._onOrderbookDeltaUpdate = this._onOrderbookDeltaUpdate.bind(this);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.SubscribeEvent(this._onOrderbookDeltaUpdate);
        this._onOrderBookItemClicked = this._onOrderBookItemClicked.bind(this);
        this._orderBook.addEventListener(OrderBookEvent.ITEM_CLICKED, this._onOrderBookItemClicked);
        this._onDataGridRowClicked = this._onDataGridRowClicked.bind(this);
        this._accountOrdersGrid.addEventListener(ADataGridEvent.ROW_CLICK, this._onDataGridRowClicked);
        this._onOrderStatusButtonsChanged = this._onOrderStatusButtonsChanged.bind(this);
        this._accountOrderStatusButtons.addEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onOrderStatusButtonsChanged);
        this._onOrderStateChanged = this._onOrderStateChanged.bind(this);
        tm.APIState.Account_OrderStateChangedEvent.SubscribeEvent(this._onOrderStateChanged);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let tm = TradingManager.instance;
        tm.ProductsMarketDataChanged.UnsubscribeEvent(this._onProductsMarketDataChanged);
        tm.OrderBookSideSelected.UnsubscribeEvent(this._onOrderBookSideSelected);
        tm.OrderBookPriceSelected.UnsubscribeEvent(this._onOrderBookPriceSelected);
        this._orderTypeButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._orderTypeIndexChanged);
        this._orderSideButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._orderSideIndexChanged);
        this._quantityButtons.removeEventListener(AButtonBarEvent.BUTTON_CLICK, this._onQuantityButtonClicked);
        this.removeEventListener('change', this._onInputCommitted);
        this.removeEventListener('input', this._onInputOrChange);
        this._sendOrderButton.removeEventListener('click', this._sendOrderClicked);
        tm.APIState.MD_OrderBookFullUpdateEvent.UnsubscribeEvent(this._onOrderbookFullUpdate);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.UnsubscribeEvent(this._onOrderbookDeltaUpdate);
        this._orderBook.removeEventListener(OrderBookEvent.ITEM_CLICKED, this._onOrderBookItemClicked);
        this._accountOrdersGrid.removeEventListener(ADataGridEvent.ROW_CLICK, this._onDataGridRowClicked);
        this._accountOrderStatusButtons.removeEventListener(AButtonBarEvent.SELECTED_INDEX_CHANGE, this._onOrderStatusButtonsChanged);
        tm.APIState.Account_OrderStateChangedEvent.UnsubscribeEvent(this._onOrderStateChanged);
    }
    _render() {
        if (super._render()) {
            let fm = AFormatManager.instance;
            if (this._selectedOrderType === OrderTypeEnum.Market) {
                this._priceInput.visible = true;
                this._priceInput.readonly = true;
                this._stopPriceInput.visible = false;
                this._timeInForceSelect.visible = false;
            }
            else if (this._selectedOrderType === OrderTypeEnum.Limit) {
                this._priceInput.visible = true;
                this._priceInput.readonly = false;
                this._stopPriceInput.visible = false;
                this._timeInForceSelect.visible = true;
            }
            else if (this._selectedOrderType === OrderTypeEnum.StopMarket) {
                this._priceInput.visible = false;
                this._priceInput.readonly = true;
                this._stopPriceInput.visible = true;
                this._timeInForceSelect.visible = false;
            }
            else if (this._selectedOrderType === OrderTypeEnum.StopLimit) {
                this._priceInput.visible = true;
                this._priceInput.readonly = false;
                this._stopPriceInput.visible = true;
                this._timeInForceSelect.visible = true;
            }
            let lm = ALanguageManager.instance;
            this.title = lm.get('MobileTradeWidget', 'Trade');
            this._orderTypeButtons.labels = [
                lm.get('MobileTradeWidget', 'Mkt'),
                lm.get('MobileTradeWidget', 'Lmt'),
                lm.get('MobileTradeWidget', 'Stp Mkt'),
                lm.get('MobileTradeWidget', 'Stp Lmt')
            ];
            this._orderSideButtons.labels = [
                lm.get('MobileTradeWidget', 'Buy'),
                lm.get('MobileTradeWidget', 'Sell')
            ];
            this._timeInForceSelect.options = `<option value="${OrderTIFEnum.GTC}">${lm.get('MobileTradeWidget', 'GTC')}</option><option value="${OrderTIFEnum.IOC}">${lm.get('MobileTradeWidget', 'IOC')}</option><option value="${OrderTIFEnum.FOK}">${lm.get('MobileTradeWidget', 'FOK')}</option>`;
            if (this._selectedOrderType === OrderTypeEnum.Market) {
                this._priceInput.value = this._marketPrice.toString();
                this._priceInput.label = `${lm.get('MobileTradeWidget', 'Mkt Price')}${this._product2Symbol !== null ? ' (' + this._product2Symbol + ')' : ''}`;
            }
            else {
                this._priceInput.label = `${lm.get('MobileTradeWidget', 'Lmt Price')}${this._product2Symbol !== null ? ' (' + this._product2Symbol + ')' : ''}`;
            }
            this._quantityInput.label = `${lm.get('MobileTradeWidget', 'Qty')}${this._product1Symbol !== null ? ' (' + this._product1Symbol + ')' : ''}`;
            this._timeInForceSelect.label = lm.get('MobileTradeWidget', 'TIF');
            this._stopPriceInput.label = `${lm.get('MobileTradeWidget', 'Stp Price')}${this._product2Symbol !== null ? ' (' + this._product2Symbol + ')' : ''}`;
            let orderTypeLabel = this._orderTypeButtons.labels[this._orderTypeButtons.selectedIndex];
            if (this._orderSideButtons.selectedIndex === OrderSideEnum.Buy) {
                this._sendOrderButton.label = `${lm.get('MobileTradeWidget', 'Send')} ${orderTypeLabel} ${lm.get('MobileTradeWidget', 'Buy')} ${lm.get('MobileTradeWidget', 'Order')}`;
            }
            else if (this._orderSideButtons.selectedIndex === OrderSideEnum.Sell) {
                this._sendOrderButton.label = `${lm.get('MobileTradeWidget', 'Send')} ${orderTypeLabel} ${lm.get('MobileTradeWidget', 'Sell')} ${lm.get('MobileTradeWidget', 'Order')}`;
            }
            this._feeLabel.text = `${this._product1Symbol} ${lm.get('MobileTradeWidget', 'Fee')}`;
            this._feeText.text = this._fee !== null ? fm.format(this.instrumentId, NumberFormatType.QUANTITY, this._fee) : '—';
            this._totalLabel.text = `${this._product2Symbol} ${lm.get('MobileTradeWidget', 'Total')}`;
            this._totalText.text = this._total !== null ? fm.format(this.instrumentId, NumberFormatType.PRICE, this._total) : '—';
            this._netLabel.text = `${this._product1Symbol} ${lm.get('MobileTradeWidget', 'Net')}`;
            this._netText.text = this._net !== null ? fm.format(this.instrumentId, NumberFormatType.QUANTITY, this._net) : '—';
            if (this._selectedOrderType === OrderTypeEnum.Market) {
                if ((parseFloat(this._quantityInput.value) || 0) > 0) {
                    this._sendOrderButton.enabled = true;
                }
                else {
                    this._sendOrderButton.enabled = false;
                }
            }
            else if (this._selectedOrderType === OrderTypeEnum.Limit) {
                if ((parseFloat(this._priceInput.value) || 0) > 0 && (parseFloat(this._quantityInput.value) || 0) > 0) {
                    this._sendOrderButton.enabled = true;
                }
                else {
                    this._sendOrderButton.enabled = false;
                }
            }
            else if (this._selectedOrderType === OrderTypeEnum.StopMarket) {
                if ((parseFloat(this._quantityInput.value) || 0) > 0 && (parseFloat(this._stopPriceInput.value) || 0) > 0) {
                    this._sendOrderButton.enabled = true;
                }
                else {
                    this._sendOrderButton.enabled = false;
                }
            }
            else if (this._selectedOrderType === OrderTypeEnum.StopLimit) {
                if ((parseFloat(this._priceInput.value) || 0) > 0 && (parseFloat(this._quantityInput.value) || 0) > 0 && (parseFloat(this._stopPriceInput.value) || 0) > 0) {
                    this._sendOrderButton.enabled = true;
                }
                else {
                    this._sendOrderButton.enabled = false;
                }
            }
            this._renderAccountOrders();
            return true;
        }
        else {
            this._sendOrderButton.enabled = false;
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this.requireAuthentication = true;
    }
    _onAccountIdChanged() {
        super._onAccountIdChanged();
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        this._orderBook.accountId = this.accountId;
        if (accountState && accountState.OpenOrderStates) {
            this._orderBook.openOrders = accountState.OpenOrderStates;
        }
        else {
            this._orderBook.openOrders = null;
        }
    }
    _onInstrumentIdChanged() {
        super._onInstrumentIdChanged();
        let instrumentInfo = TradingManager.instance.APIState.InstrumentInfos.get(this.instrumentId);
        if (instrumentInfo) {
            this._product1Symbol = instrumentInfo.Product1Symbol;
            this._product2Symbol = instrumentInfo.Product2Symbol;
        }
        else {
            this._product1Symbol = null;
            this._product2Symbol = null;
        }
        this._priceInput.min = String(instrumentInfo.MinimumPrice);
        this._priceInput.step = String(instrumentInfo.PriceIncrement);
        this._quantityInput.min = String(instrumentInfo.MinimumQuantity);
        this._quantityInput.step = String(instrumentInfo.QuantityIncrement);
        this._onProductsMarketDataChanged();
        this._onInputOrChange();
        this._orderBook.instrumentId = this.instrumentId;
    }
    _onProductsMarketDataChanged() {
        this.invalidate();
        TradingManager.instance.GlobalInstrumentData.Get_Rolling24HR_OHLCV(this._product1Symbol, this._product2Symbol, (ohlcv) => {
            if (ohlcv) {
                this._marketPrice = ohlcv.Close;
            }
            else {
                this._marketPrice = null;
            }
        });
    }
    _onMenuItemSelected(menuItem) {
        super._onMenuItemSelected(menuItem);
    }
    _onOrderBookSideSelected(side) {
        this._orderSideButtons.selectedIndex = side === OrderBookItemType.ASK ? 0 : 1;
        this._onInputOrChange();
    }
    _onOrderBookPriceSelected(price) {
        if (this._selectedOrderType === OrderTypeEnum.Market || this._selectedOrderType === OrderTypeEnum.StopMarket) {
            this.invalidate();
        }
        else {
            let priceString = AFormatManager.instance.format(this.instrumentId, NumberFormatType.PRICE, price);
            this._priceInput.value = priceString.replace(',', '');
        }
    }
    _orderTypeIndexChanged() {
        this._selectedOrderType = this._orderTypes[this._orderTypeButtons.selectedIndex];
        this.invalidate();
        this._onInputOrChange();
    }
    _orderSideIndexChanged() {
        this._onInputOrChange();
    }
    _onQuantityButtonClicked(event) {
        let percentage = this._quantityButtonQuantities[event.detail.index] || 0;
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let instrumentInfo = tm.APIState.InstrumentInfos.get(this.instrumentId);
        if (accountState && instrumentInfo) {
            let productState = accountState.AccountProductStates.get(instrumentInfo.Product1);
            if (productState) {
                let amount = Math.abs(productState.ProductAmount - productState.ProductHold);
                if (amount > 0) {
                    this._quantityInput.value = String(amount * percentage);
                    this._onInputOrChange();
                }
            }
        }
    }
    _sendOrderClicked() {
        let tm = TradingManager.instance;
        let side = this._orderSideButtons.selectedIndex;
        if (this._selectedOrderType === OrderTypeEnum.Market) {
            tm.SendMarketOrder(this.accountId, this.instrumentId, parseFloat(this._quantityInput.value), side);
        }
        else {
            let limitPrice = this._selectedOrderType === OrderTypeEnum.Limit || this._selectedOrderType === OrderTypeEnum.StopLimit ? parseFloat(this._priceInput.value) : 0;
            let stopPrice = this._selectedOrderType === OrderTypeEnum.StopLimit || this._selectedOrderType === OrderTypeEnum.StopMarket ? parseFloat(this._stopPriceInput.value) : 0;
            tm.SendOrderExtended(this.accountId, this.instrumentId, limitPrice, parseFloat(this._quantityInput.value), side, this._selectedOrderType, Number(this._timeInForceSelect.value), stopPrice);
        }
    }
    _onInputCommitted(event) {
        let instrumentInfo = TradingManager.instance.APIState.InstrumentInfos.get(this.instrumentId);
        if (instrumentInfo) {
            let p = parseFloat(this._priceInput.value) || 0;
            if (p > 0) {
                this._priceInput.value = p.toLocaleString('en-US', {
                    useGrouping: false,
                    maximumFractionDigits: AFormatManager.instance.getDecimalPlaceCount(instrumentInfo.PriceIncrement)
                });
            }
            let sp = parseFloat(this._stopPriceInput.value) || 0;
            if (sp > 0) {
                this._stopPriceInput.value = sp.toLocaleString('en-US', {
                    useGrouping: false,
                    maximumFractionDigits: AFormatManager.instance.getDecimalPlaceCount(instrumentInfo.PriceIncrement)
                });
            }
            let q = parseFloat(this._quantityInput.value) || 0;
            if (q > 0) {
                this._quantityInput.value = q.toLocaleString('en-US', {
                    useGrouping: false,
                    maximumFractionDigits: AFormatManager.instance.getDecimalPlaceCount(instrumentInfo.QuantityIncrement)
                });
            }
        }
    }
    _onInputOrChange(event = null) {
        let tm = TradingManager.instance;
        let instrumentInfo = tm.APIState.InstrumentInfos.get(this.instrumentId);
        if (instrumentInfo) {
            let price;
            if (this._selectedOrderType === OrderTypeEnum.Market || this._selectedOrderType === OrderTypeEnum.StopMarket) {
                price = 0 || 0;
            }
            else {
                price = parseFloat(this._priceInput.value) || 0;
            }
            this._price = price;
            let quantity = parseFloat(this._quantityInput.value) || 0;
            if (price > 0 && quantity > 0) {
                this._total = price * quantity;
                tm.GetOrderFee(this.accountId, this.instrumentId, this._selectedOrderType, this._orderSideButtons.selectedIndex, price, quantity, (fee) => {
                    if (fee !== null) {
                        this._fee = fee;
                        this._net = quantity - fee;
                    }
                    else {
                        this._fee = null;
                        this._net = quantity;
                    }
                    this.invalidate();
                });
                this.invalidate();
            }
            else {
                this._total = null;
                this._price = null;
                this._fee = null;
                this._net = null;
                this.invalidate();
            }
        }
    }
    _onOrderbookFullUpdate(sender, data) {
        if (sender.InstrumentId === this.instrumentId) {
            this._orderBook.invalidate();
        }
    }
    _onOrderbookDeltaUpdate(sender, data) {
        if (sender.InstrumentId === this.instrumentId) {
            this._orderBook.invalidate();
        }
    }
    _onOrderBookItemClicked(event) {
        let tm = TradingManager.instance;
        tm.SelectOrderBookSide(this._orderBook.activeOrderBookItem.type);
        tm.SelectOrderBookPrice(this._orderBook.activeOrderBookItem.price);
    }
    _renderAccountOrders() {
        let tm = TradingManager.instance;
        let lm = ALanguageManager.instance;
        this._accountOrdersGrid.removeAllItems();
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        if (!accountState) {
            this._accountOrderStatusButtons.labels = [
                lm.get('MobileTradeWidget', 'Open'),
                lm.get('MobileTradeWidget', 'Filled'),
                lm.get('MobileTradeWidget', 'Inactive')
            ];
            return;
        }
        let selectedOrderStatus = this._accountOrderStatusButtons.selectedIndex || 0;
        if (selectedOrderStatus === 0 || selectedOrderStatus === 1) {
            accountState.OpenOrderStates.forEach((orderState) => {
                if (orderState.InstrumentId === this.instrumentId && (selectedOrderStatus === 0 || (selectedOrderStatus === 1 && orderState.ExecutedQuantity > 0))) {
                    OrderSideEnum;
                    this._accountOrdersGrid.addItem([
                        orderState
                    ]);
                }
            });
        }
        if (selectedOrderStatus === 1 || selectedOrderStatus === 2) {
            accountState.ClosedOrderStates.forEach((orderState) => {
                if (orderState.InstrumentId === this.instrumentId && (selectedOrderStatus === 2 || (selectedOrderStatus === 1 && orderState.ExecutedQuantity > 0))) {
                    this._accountOrdersGrid.addItem([
                        orderState
                    ]);
                }
            });
        }
        this._accountOrderStatusButtons.labels = [
            `${lm.get('MobileTradeWidget', 'Open')}${accountState.OpenOrderStates.size > 0 ? '(' + accountState.OpenOrderStates.size + ')' : ''}`,
            `${lm.get('MobileTradeWidget', 'Filled')}`,
            `${lm.get('MobileTradeWidget', 'Inactive')}${accountState.ClosedOrderStates.length > 0 ? '(' + accountState.ClosedOrderStates.length + ')' : ''}`
        ];
    }
    _onDataGridRowClicked(event) {
        if (event.target.constructor === AButton) {
            let button = event.target;
            let orderID = this._accountOrdersGrid.getItemAt(event.detail.index)[0].OrderId;
            if (button.hasClass('cancel')) {
                this._cancelOrder(orderID);
            }
            else if (button.hasClass('execute-at-market')) {
                this._executeOrderAtMarket(orderID);
            }
            else if (button.hasClass('edit')) {
                this._editOrder(orderID);
            }
        }
    }
    _onOrderStatusButtonsChanged(event) {
        this.invalidate();
        this._accountOrdersGrid.selectedIndex = null;
        this._accountOrdersGrid.verticalScrollAmount = 0;
    }
    _onOrderStateChanged(sender, data) {
        this._renderAccountOrders();
    }
    _cancelOrder(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
            let dialog = ASystemManager.instance.showConfirmDialog(`Are you sure you want to cancel order ${Number(orderID)}?`, () => {
                tm.SendCancelOrderByServerOrderId(this.accountId, orderState.InstrumentId, orderID);
            }, null);
            dialog.title = 'Cancel Order';
            dialog.okLabel = 'Yes';
            dialog.cancelLabel = 'No';
        }
    }
    _executeOrderAtMarket(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
        }
    }
    _editOrder(orderID) {
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        let orderState = accountState.OpenOrderStates.get(orderID);
        if (accountState && orderState) {
        }
    }
}
window.customElements.define('a-mobile-trade-widget', MobileTradeWidget);
