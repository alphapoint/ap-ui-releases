import { AContainer, AFormatManager, AMenuData, AMenuDataItem, ARenderManager, ARenderManagerEvent, ASystemManager, AText, ALanguageManager } from './a/index.js';
import { TradingPanel } from './components/TradingPanel.js';
import { createChart } from './charts/index.js';
import { TradingManager } from './managers/TradingManager.js';
import { NumberFormatType } from './a/managers/AFormatManager.js';
export class ChartsWidget extends TradingPanel {
    constructor() {
        super();
        this._loadOHLCVChartDataInProgress = false;
    }
    _build() {
        super._build();
        this._internalInstrumentID = null;
        this._maxOrderBookDepth = 30;
        this._invalidateLegend = true;
        this._invalidateLayout = true;
        this._open = null;
        this._high = null;
        this._low = null;
        this._close = null;
        this._volume = null;
        this._candleUpdate = null;
        this._volumeUpdate = null;
        this._globalInstrument = null;
        this._productOneSymbol = null;
        this._minStartTime = null;
        this._orderLines = [];
        this._legendContainer = new AContainer();
        this._legendContainer.addClass('legend');
        this._panelContents.appendChild(this._legendContainer);
        this._openText = new AText();
        this._legendContainer.appendChild(this._openText);
        this._highText = new AText();
        this._highText.addClass('high');
        this._legendContainer.appendChild(this._highText);
        this._lowText = new AText();
        this._lowText.addClass('low');
        this._legendContainer.appendChild(this._lowText);
        this._closeText = new AText();
        this._legendContainer.appendChild(this._closeText);
        this._volumeText = new AText();
        this._legendContainer.appendChild(this._volumeText);
        this._ohlcvChartContainer = new AContainer();
        this._ohlcvChartContainer.addClass('ohlcv-chart');
        this._panelContents.appendChild(this._ohlcvChartContainer);
        this._ohlcvChart = createChart(this._ohlcvChartContainer, {
            crosshair: {
                mode: 0
            },
            rightPriceScale: {
                scaleMargins: {
                    top: .1,
                    bottom: 0.25,
                },
                borderVisible: true,
            },
            timeScale: {
                barSpacing: 1,
                visible: true,
                timeVisible: true,
                borderVisible: true
            },
            layout: {},
            grid: {},
        });
        this._candleData = [];
        this._volumeData = [];
        this._ohlcvChartCandleSeries = this._ohlcvChart.addCandlestickSeries({});
        this._ohlcvChartVolumeSeries = this._ohlcvChart.addHistogramSeries({
            priceFormat: {
                type: 'volume',
            },
            priceScaleId: '',
            scaleMargins: {
                top: 0.75,
                bottom: 0,
            },
        });
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        let tm = TradingManager.instance;
        this._onOrderbookFullUpdate = this._onOrderbookFullUpdate.bind(this);
        tm.APIState.MD_OrderBookFullUpdateEvent.SubscribeEvent(this._onOrderbookFullUpdate);
        this._onOrderbookDeltaUpdate = this._onOrderbookDeltaUpdate.bind(this);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.SubscribeEvent(this._onOrderbookDeltaUpdate);
        this._onVisibilityChange = this._onVisibilityChange.bind(this);
        ARenderManager.instance.addEventListener(ARenderManagerEvent.VISIBILITY_CHANGE, this._onVisibilityChange);
        this._onResizeObserved = this._onResizeObserved.bind(this);
        this._resizeObserver = new ResizeObserver(this._onResizeObserved);
        this._resizeObserver.observe(this, {
            box: 'border-box'
        });
        this._onThemeChanged = this._onThemeChanged.bind(this);
        tm.ThemeChanged.SubscribeEvent(this._onThemeChanged);
        this._onMDHOHLCUpdate = this._onMDHOHLCUpdate.bind(this);
        tm.LiveMDH.NewOHLCV_1MIN_Event.SubscribeEvent(this._onMDHOHLCUpdate);
        this._onChartClick = this._onChartClick.bind(this);
        this._ohlcvChart.subscribeClick(this._onChartClick);
        this._onOHLCVChartCrosshairChange = this._onOHLCVChartCrosshairChange.bind(this);
        this._ohlcvChart.subscribeCrosshairMove(this._onOHLCVChartCrosshairChange);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        let tm = TradingManager.instance;
        tm.APIState.MD_OrderBookFullUpdateEvent.UnsubscribeEvent(this._onOrderbookFullUpdate);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.UnsubscribeEvent(this._onOrderbookDeltaUpdate);
        ARenderManager.instance.removeEventListener(ARenderManagerEvent.VISIBILITY_CHANGE, this._onVisibilityChange);
        this._resizeObserver.unobserve(this);
        this._resizeObserver.disconnect();
        TradingManager.instance.ThemeChanged.UnsubscribeEvent(this._onThemeChanged);
        this._ohlcvChart.unsubscribeCrosshairMove(this._onOHLCVChartCrosshairChange);
    }
    _render() {
        if (super._render()) {
            if (this._invalidateLanguage) {
                let lm = ALanguageManager.instance;
                let tm = TradingManager.instance;
                let instrumentInfo = tm.APIState.InstrumentInfos.get(this._internalInstrumentID);
                this._invalidateLanguage = true;
                if (instrumentInfo) {
                    this.title = `${instrumentInfo.Symbol.toUpperCase()} ${lm.get('ChartsWidget', 'Global Chart')}`;
                }
                else {
                    this.title = `${lm.get('ChartsWidget', 'Global Chart')}`;
                }
                this._ohlcvChart.applyOptions({
                    localization: {
                        locale: ALanguageManager.instance.languageID,
                        priceFormatter: (price) => {
                            return AFormatManager.instance.format(this._internalInstrumentID, NumberFormatType.PRICE, price);
                        }
                    }
                });
                this._invalidateLanguage = false;
            }
            if (this._invalidateLegend) {
                if (this._open !== null && this._high !== null && this._low !== null && this._close !== null && this._volume !== null) {
                    let fm = AFormatManager.instance;
                    this._openText.text = `O: ${fm.format(this._internalInstrumentID, NumberFormatType.PRICE, this._open)}`;
                    this._highText.text = `H: ${fm.format(this._internalInstrumentID, NumberFormatType.PRICE, this._high)}`;
                    this._lowText.text = `L: ${fm.format(this._internalInstrumentID, NumberFormatType.PRICE, this._low)}`;
                    this._closeText.text = `C: ${fm.format(this._internalInstrumentID, NumberFormatType.PRICE, this._close)}`;
                    this._volumeText.text = `V: ${fm.format(this._internalInstrumentID, NumberFormatType.QUANTITY, this._volume)}`;
                }
                else {
                    this._openText.text = `O: —`;
                    this._highText.text = `H: —`;
                    this._lowText.text = `L: —`;
                    this._closeText.text = `C: —`;
                    this._volumeText.text = `V: —`;
                }
                this._invalidateLegend = false;
            }
            if (this._invalidateLayout) {
                this._ohlcvChart.resize(this._ohlcvChartContainer.offsetWidth, this._ohlcvChartContainer.offsetHeight);
                this._drawDepthChart();
                this._invalidateLayout = false;
            }
            if (this._candleUpdate !== null) {
                this._ohlcvChartCandleSeries.update(this._candleUpdate);
                this._candleUpdate = null;
            }
            if (this._volumeUpdate !== null) {
                this._ohlcvChartVolumeSeries.update(this._volumeUpdate);
                this._volumeUpdate = null;
            }
            return true;
        }
        else {
            return false;
        }
    }
    _finalizeInstantiation() {
        super._finalizeInstantiation();
        this._applyStyles();
        this._onInstrumentIdChanged();
    }
    _onLanguageChanged() {
        this._invalidateLanguage = true;
        super._onLanguageChanged();
    }
    _onVisibilityChange(event) {
        if (ARenderManager.instance.isVisible) {
            this.doLater(() => {
                this._setChartCandleData();
                this._setChartVolumeData();
                this._invalidateLayout = true;
                this.invalidate();
            });
        }
    }
    _onTradingManagerReadyStateChanged() {
        super._onTradingManagerReadyStateChanged();
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstrumentDataSummaryReady && !tm.ReadyState.PreviousInstrumentDataSummaryReady) {
            this._onInstrumentIdChanged();
        }
    }
    _selectGlobalInstrument(productOne = null, productTwo = null) {
        let tm = TradingManager.instance;
        if (this._globalInstrument !== null) {
            tm.LiveMDH.Unsubscribe_OHLCV_1MIN(this._globalInstrument.InstrumentId);
        }
        if (tm.ReadyState.InstrumentDataSummaryReady) {
            let summary = tm.GlobalInstrumentData.Get_InstrumentDataSummaryInstrument(productOne, productTwo);
            if (summary) {
                this._globalInstrument = summary;
                this._minStartTime = summary.DataStartTime_OHLCV_1MIN;
            }
            else {
                this._globalInstrument = null;
            }
        }
        else {
            this._globalInstrument = null;
        }
        this._loadOHLCVChartData();
    }
    _loadOHLCVChartData() {
        if (this._loadOHLCVChartDataInProgress) {
            return;
        }
        this._loadOHLCVChartDataInProgress = true;
        this._candleData = [];
        this._volumeData = [];
        let tm = TradingManager.instance;
        if (this._globalInstrument !== null) {
            tm.GlobalInstrumentData.Get_OHLCV_1MIN_Bars_FX(this._productOneSymbol, this._productTwoSymbol, new Date(Math.max(Date.now() - 864000000, this._minStartTime)), new Date(), (mdhData, data) => {
                if (mdhData.HasError) {
                    console.log('MDH ERROR', mdhData.ErrorMessage);
                    return;
                }
                let lastClose = 0;
                data.forEach((item) => {
                    if (item.Time !== 0) {
                        this._candleData.push({
                            time: (item.Time / 1000) | 0,
                            open: (item.Open !== 0 ? item.Open : lastClose),
                            high: (item.High !== 0 ? item.High : lastClose),
                            low: (item.Low !== 0 ? item.Low : lastClose),
                            close: (item.Close !== 0 ? item.Close : lastClose)
                        });
                        this._volumeData.push({
                            time: (item.Time / 1000) | 0,
                            value: item.TradeVolumeValue
                        });
                        if (item.Close != 0) {
                            lastClose = item.Close;
                        }
                    }
                });
                if (!mdhData.IsComplete) {
                    mdhData.next();
                }
                else {
                    this._loadOHLCVChartDataInProgress = false;
                    if (this._globalInstrument !== null) {
                        tm.LiveMDH.Subscribe_OHLCV_1MIN(this._globalInstrument.InstrumentId);
                    }
                    this._ohlcvChart.timeScale().resetTimeScale();
                    this._ohlcvChart.priceScale().applyOptions({
                        autoScale: true
                    });
                    this._setChartCandleData();
                    this._setChartVolumeData();
                    this._drawOpenOrders();
                    this._invalidateLegend = true;
                    this._invalidateLayout = true;
                    this.invalidate();
                }
            });
        }
        else {
            this._loadOHLCVChartDataInProgress = false;
            this._ohlcvChart.timeScale().resetTimeScale();
            this._ohlcvChart.priceScale().applyOptions({
                autoScale: true
            });
            this._setChartCandleData();
            this._setChartVolumeData();
        }
    }
    _drawDepthChart() {
    }
    _onAccountIdChanged() {
        super._onAccountIdChanged();
        this._drawOpenOrders();
    }
    _onInstrumentIdChanged() {
        super._onInstrumentIdChanged();
        let tm = TradingManager.instance;
        if (tm.ReadyState.InstrumentDataSummaryReady) {
            if (this.instrumentId !== null && this.instrumentId !== this._internalInstrumentID) {
                this._internalInstrumentID = this.instrumentId;
                this._loadOHLCVChartDataInProgress = false;
                let instrumentInfo = tm.APIState.InstrumentInfos.get(this._internalInstrumentID);
                let lm = ALanguageManager.instance;
                this._invalidateLanguage = true;
                if (instrumentInfo) {
                    this._productOneSymbol = instrumentInfo.Product1Symbol;
                    this._productTwoSymbol = instrumentInfo.Product2Symbol;
                    this._selectGlobalInstrument(instrumentInfo.Product1Symbol, instrumentInfo.Product2Symbol);
                }
                else {
                    this._productOneSymbol = null;
                    this._productTwoSymbol = null;
                    this._selectGlobalInstrument(null, null);
                }
                this._drawDepthChart();
            }
        }
    }
    _onResizeObserved(entries, observer) {
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].target === this) {
                this._invalidateLayout = true;
                this.invalidate();
                return;
            }
        }
    }
    _onOrderbookFullUpdate(sender, data) {
        if (this._internalInstrumentID === sender.InstrumentId) {
            this._drawDepthChart();
        }
    }
    _onOrderbookDeltaUpdate(sender, data) {
        if (this._internalInstrumentID === sender.InstrumentId) {
            this._drawDepthChart();
        }
    }
    _setChartCandleData() {
        this._candleData = this._candleData || [];
        if (this._candleData.length > 2880) {
            this._candleData = this._candleData.slice(this._candleData.length - 2880);
        }
        this._ohlcvChartCandleSeries.setData([]);
        this.doLater(() => {
            this._ohlcvChartCandleSeries.setData(this._candleData);
            if (this._candleData.length > 0) {
                let toTime = this._candleData[this._candleData.length - 1].time;
                this._ohlcvChart.timeScale().setVisibleRange({
                    from: toTime - (TradingManager.instance.UIConfig.ChartDefaultSpanMinutes * 60),
                    to: toTime,
                });
            }
        });
    }
    _setChartVolumeData() {
        this._volumeData = this._volumeData || [];
        if (this._volumeData.length > 2880) {
            this._volumeData = this._volumeData.slice(this._volumeData.length - 2880);
        }
        this._ohlcvChartVolumeSeries.setData([]);
        this.doLater(() => {
            this._ohlcvChartVolumeSeries.setData(this._volumeData);
        });
    }
    _forexOHLCV(item) {
        let tm = TradingManager.instance;
        if (this._productTwoSymbol === tm.ReferenceData_USD_Symbol) {
            return item;
        }
        else {
            let fxDate = new Date(item.time_period_start);
            let date = ("0" + fxDate.getDate()).slice(-2);
            let month = ("0" + (fxDate.getMonth() + 1)).slice(-2);
            let year = fxDate.getFullYear();
            let fxStartDate = Number(year.toString() + month.toString() + date.toString());
            try {
                let conversion = 1;
                let conversionMap = tm.GlobalInstrumentData.Cached_FX_USD_DAY_SERIES.get(this._productTwoSymbol);
                if (conversionMap.has(fxStartDate)) {
                    conversion = conversionMap.get(fxStartDate);
                }
                else {
                    conversion = conversionMap.get(-1);
                }
                if (conversion !== 1) {
                    item.price_open *= conversion;
                    item.price_high *= conversion;
                    item.price_low *= conversion;
                    item.price_close *= conversion;
                }
                return item;
            }
            catch (error) {
                return item;
            }
        }
    }
    _onMDHOHLCUpdate(sender, data) {
        if (!this._loadOHLCVChartDataInProgress && this._candleData.length > 0) {
            let lastCandleItem = this._candleData[this._candleData.length - 1];
            let lastVolumeItem = this._volumeData[this._volumeData.length - 1];
            if (data.constructor === Array) {
                let updateCandles = false;
                let updateVolume = false;
                for (let i = 0; i < data.length; i++) {
                    let item = this._forexOHLCV(data[i]);
                    let itemTime = new Date(item.time_period_start).getTime() / 1000 | 0;
                    if (itemTime > lastCandleItem.time) {
                        updateCandles = true;
                        this._candleData.push({
                            time: itemTime,
                            open: item.price_open,
                            high: item.price_high,
                            low: item.price_low,
                            close: item.price_close
                        });
                    }
                    if (itemTime > lastVolumeItem.time) {
                        updateVolume = true;
                        this._volumeData.push({
                            time: itemTime,
                            value: item.volume_traded
                        });
                    }
                }
                this._candleUpdate = null;
                this._volumeUpdate = null;
                if (updateCandles) {
                    this._setChartCandleData();
                }
                if (updateVolume) {
                    this._setChartVolumeData();
                }
            }
            else {
                let item = this._forexOHLCV(data);
                let itemTime = new Date(item.time_period_start).getTime() / 1000 | 0;
                let candleUpdate = {
                    time: itemTime,
                    open: item.price_open,
                    high: item.price_high,
                    low: item.price_low,
                    close: item.price_close
                };
                let volumeUpdate = {
                    time: itemTime,
                    value: item.volume_traded
                };
                this._candleUpdate = candleUpdate;
                if (candleUpdate.time > lastCandleItem.time) {
                    this._candleData.push(candleUpdate);
                }
                else {
                    this._candleData[this._candleData.length - 1] = candleUpdate;
                }
                this._volumeUpdate = volumeUpdate;
                if (volumeUpdate.time > lastVolumeItem.time) {
                    this._volumeData.push(volumeUpdate);
                }
                else {
                    this._volumeData[this._volumeData.length - 1] = volumeUpdate;
                }
                this.invalidate();
            }
        }
    }
    _applyStyles() {
        let chartStyle = window.getComputedStyle(this);
        let chartOptions = {
            rightPriceScale: {},
            timeScale: {},
            layout: {},
            grid: {
                vertLines: {},
                horzLines: {},
            }
        };
        if (chartStyle.getPropertyValue('--font-family') !== '') {
            console.log('Chart Font Family', chartStyle.getPropertyValue('--font-family').trim());
            chartOptions.layout.fontFamily = chartStyle.getPropertyValue('--font-family').trim();
        }
        if (chartStyle.getPropertyValue('--chart-background-color') !== '') {
            this._backgroundColor = chartStyle.getPropertyValue('--chart-background-color').trim();
            chartOptions.layout.backgroundColor = this._backgroundColor;
        }
        if (chartStyle.getPropertyValue('--chart-label-text-color') !== '') {
            this._primaryTextColor = chartStyle.getPropertyValue('--chart-label-text-color').trim();
            chartOptions.layout.textColor = this._primaryTextColor;
        }
        if (chartStyle.getPropertyValue('--chart-grid-color') !== '') {
            this._gridColor = chartStyle.getPropertyValue('--chart-grid-color').trim();
            chartOptions.grid.horzLines.color = chartOptions.grid.vertLines.color = this._gridColor;
            chartOptions.rightPriceScale.borderColor = chartOptions.timeScale.borderColor = this._gridColor;
        }
        let candleSeriesOptions = {};
        if (chartStyle.getPropertyValue('--chart-up-candle-color') !== '') {
            this._upCandleColor = candleSeriesOptions.borderUpColor = chartStyle.getPropertyValue('--chart-up-candle-color').trim();
            candleSeriesOptions.upColor = candleSeriesOptions.wickUpColor = this._upCandleColor;
        }
        if (chartStyle.getPropertyValue('--chart-down-candle-color') !== '') {
            this._downCandleColor = candleSeriesOptions.borderDownColor = chartStyle.getPropertyValue('--chart-down-candle-color').trim();
            candleSeriesOptions.downColor = candleSeriesOptions.wickDownColor = this._downCandleColor;
        }
        let volumeSeriesOptions = {};
        if (chartStyle.getPropertyValue('--chart-volume-color') !== '') {
            this._volumeColor = chartStyle.getPropertyValue('--chart-volume-color').trim();
            let volumeColor = this._volumeColor;
            this._volumeData.forEach((item) => {
                item.color = volumeColor;
            });
            volumeSeriesOptions.color = volumeColor;
            this._setChartVolumeData();
        }
        this._ohlcvChart.applyOptions(chartOptions);
        this._ohlcvChartCandleSeries.applyOptions(candleSeriesOptions);
        this._ohlcvChartVolumeSeries.applyOptions(volumeSeriesOptions);
        if (chartStyle.getPropertyValue('--chart-asks-border-color') !== '') {
            this._asksBorderColor = chartStyle.getPropertyValue('--chart-asks-border-color').trim();
        }
        if (chartStyle.getPropertyValue('--chart-asks-fill-color') !== '') {
            this._asksFillColor = chartStyle.getPropertyValue('--chart-asks-fill-color').trim();
        }
        if (chartStyle.getPropertyValue('--chart-bids-border-color') !== '') {
            this._bidsBorderColor = chartStyle.getPropertyValue('--chart-bids-border-color').trim();
        }
        if (chartStyle.getPropertyValue('--chart-bids-fill-color') !== '') {
            this._bidsFillColor = chartStyle.getPropertyValue('--chart-bids-fill-color').trim();
        }
        this._invalidateLayout = true;
        this._invalidateLegend = true;
        this.invalidate();
    }
    _onThemeChanged(themeClass) {
        this._applyStyles();
        this._setChartCandleData();
        this._setChartVolumeData();
    }
    _onOHLCVChartCrosshairChange(data) {
        if (data && data.point && !ASystemManager.instance.isShowingContextItem) {
        }
        let candleItem = data.seriesPrices.get(this._ohlcvChartCandleSeries);
        if (candleItem) {
            if (this._open !== candleItem.open) {
                this._open = candleItem.open;
                this._invalidateLegend = true;
            }
            if (this._high !== candleItem.high) {
                this._high = candleItem.high;
                this._invalidateLegend = true;
            }
            if (this._low !== candleItem.low) {
                this._low = candleItem.low;
                this._invalidateLegend = true;
            }
            if (this._close !== candleItem.close) {
                this._close = candleItem.close;
                this._invalidateLegend = true;
            }
        }
        else {
            if (this._open !== null || this._high !== null || this._low !== null || this._close !== null) {
                this._open = null;
                this._high = null;
                this._low = null;
                this._close = null;
                this._invalidateLegend = true;
            }
        }
        let volumeItem = data.seriesPrices.get(this._ohlcvChartVolumeSeries);
        if (volumeItem !== undefined) {
            if (this._volume !== volumeItem) {
                this._volume = volumeItem;
                this._invalidateLegend = true;
            }
        }
        else {
            if (this._volume !== null) {
                this._volume = null;
                this._invalidateLegend = true;
            }
        }
        if (this._invalidateLegend) {
            this.invalidate();
        }
    }
    _onChartClick(data) {
    }
    _drawOpenOrders() {
    }
}
window.customElements.define('a-charts-widget', ChartsWidget);
