import { ALanguageManager, AMenuData, AMenuDataItem, ASelect } from './a/index.js';
import { TradingManager } from './managers/TradingManager.js';
import { TradingPanel } from './components/TradingPanel.js';
import { OrderBook } from './components/OrderBook.js';
import { OrderBookEvent } from './events/OrderBookEvent.js';
export class OrderBookWidget extends TradingPanel {
    constructor() {
        super();
    }
    _build() {
        super._build();
        this._basePrecisions = `<option value="-">-</option><option value=".01">.01</option><option value=".1">.1</option><option value="1">1</option><option value="10">10</option><option value="100">100</option>`;
        this._precisionSelect = new ASelect();
        this._precisionSelect.options = this._basePrecisions;
        this._precisionSelect.value = '-';
        this._headerContents.appendChild(this._precisionSelect);
        this._orderBook = new OrderBook();
        this._orderBook.precision = null;
        this._panelContents.appendChild(this._orderBook);
        this.menuData = new AMenuData(null, null, [
            new AMenuDataItem(null, 'Option One', null),
            new AMenuDataItem(null, 'Option Two', null)
        ]);
        this.showMenu = false;
    }
    _registerListeners() {
        super._registerListeners();
        this._onPrecisionChanged = this._onPrecisionChanged.bind(this);
        this._precisionSelect.addEventListener('change', this._onPrecisionChanged);
        let tm = TradingManager.instance;
        this._onOrderbookFullUpdate = this._onOrderbookFullUpdate.bind(this);
        tm.APIState.MD_OrderBookFullUpdateEvent.SubscribeEvent(this._onOrderbookFullUpdate);
        this._onOrderbookDeltaUpdate = this._onOrderbookDeltaUpdate.bind(this);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.SubscribeEvent(this._onOrderbookDeltaUpdate);
        this._onOrderBookItemClicked = this._onOrderBookItemClicked.bind(this);
        this._orderBook.addEventListener(OrderBookEvent.ITEM_CLICKED, this._onOrderBookItemClicked);
    }
    _unregisterListeners() {
        super._unregisterListeners();
        this._precisionSelect.removeEventListener('change', this._onPrecisionChanged);
        let tm = TradingManager.instance;
        tm.APIState.MD_OrderBookFullUpdateEvent.UnsubscribeEvent(this._onOrderbookFullUpdate);
        tm.APIState.MD_OrderBookDeltaUpdateEvent.UnsubscribeEvent(this._onOrderbookDeltaUpdate);
        this._orderBook.removeEventListener(OrderBookEvent.ITEM_CLICKED, this._onOrderBookItemClicked);
    }
    _render() {
        if (super._render()) {
            this.title = ALanguageManager.instance.get('OrderBookWidget', 'Order Book');
            return true;
        }
        else {
            return false;
        }
    }
    _onLanguageChanged() {
        super._onLanguageChanged();
    }
    _onAccountIdChanged() {
        super._onAccountIdChanged();
        let tm = TradingManager.instance;
        let accountState = tm.APIState.AccountStates.get(this.accountId);
        this._orderBook.accountId = this.accountId;
        if (accountState && accountState.OpenOrderStates) {
            this._orderBook.openOrders = accountState.OpenOrderStates;
        }
        else {
            this._orderBook.openOrders = null;
        }
    }
    _onInstrumentIdChanged() {
        super._onInstrumentIdChanged();
        this._precisionSelect.options = this._basePrecisions;
        this._orderBook.instrumentId = this.instrumentId;
    }
    _onPrecisionChanged(event) {
        this._orderBook.precision = this._precisionSelect.value !== '-' ? parseFloat(this._precisionSelect.value) : null;
    }
    _onOrderbookFullUpdate(sender, data) {
        if (sender.InstrumentId === this.instrumentId) {
            this._orderBook.invalidate();
        }
    }
    _onOrderbookDeltaUpdate(sender, data) {
        if (sender.InstrumentId === this.instrumentId) {
            this._orderBook.invalidate();
        }
    }
    _onOrderBookItemClicked(event) {
        let tm = TradingManager.instance;
        tm.SelectOrderBookSide(this._orderBook.activeOrderBookItem.type);
        tm.SelectOrderBookPrice(this._orderBook.activeOrderBookItem.price);
    }
}
window.customElements.define('a-order-book-widget', OrderBookWidget);
