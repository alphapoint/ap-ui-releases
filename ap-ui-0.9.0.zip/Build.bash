#!/bin/bash

echo "Building Typescript"

tsc --project tsconfig.json

echo "Building SASS"

sass -q src/scss/index.scss:public/css/index.css
sass -q src/scss/layouts:public/css/layouts
sass -q src/scss/themes:public/css/themes

echo "Copying HTML Files"

cp src/index.html public/example_index.html
cp src/index_min.html public/example_index_min.html

echo "Build Complete"