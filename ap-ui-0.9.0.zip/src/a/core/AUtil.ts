export class AUtil extends Object {

    public static debounce(scope:any, fn:Function, wait:number, immediate:boolean):() => void {

        let timeout:number;

        return function() {
            var context = scope;
            var args = arguments;
            var later = () => {
                timeout = null;
                if (!immediate) {
                    fn.apply(context, args);
                }
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = window.setTimeout(later, wait);
            if (callNow) {
                fn.apply(context, args);
            }
        };

    }

    public static throttle(scope:any, fn:Function, threshhold:number = 250):() => void {

        let last:number;
        let deferTimer:number;

        return function () {
            var context = scope || this;

            var now = Date.now();
            var args = arguments;
            if (last && now < last + threshhold) {
                clearTimeout(deferTimer);
                deferTimer = window.setTimeout(function () {
                    last = now;
                    fn.apply(context, args);
                }, threshhold);
            } else {
                last = now;
                fn.apply(context, args);
            }
        };

    }

    public static hsvToRGBString(h:number, s:number, v:number):string {
        let r:number;
        let g:number;
        let b:number;
        let i:number = Math.floor(h * 6);
        let f:number = h * 6 - i;
        let p:number = v * (1 - s);
        let q:number = v * (1 - f * s);
        let t:number = v * (1 - (1 - f) * s);

        switch (i % 6) {
            case 0: r = v, g = t, b = p; break;
            case 1: r = q, g = v, b = p; break;
            case 2: r = p, g = v, b = t; break;
            case 3: r = p, g = q, b = v; break;
            case 4: r = t, g = p, b = v; break;
            case 5: r = v, g = p, b = q; break;
        }
        return `rgb(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)})`;
    }

    public static getUrlParameter(name:string):string {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? null : decodeURIComponent(results[1].replace(/\+/g, ' '));
    };

}