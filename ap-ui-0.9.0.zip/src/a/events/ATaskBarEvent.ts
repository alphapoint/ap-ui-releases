import { AEvent } from './AEvent.js';

export class ATaskBarEvent extends AEvent {

    public static SELECTED_WINDOW_CHANGED:string = 'taskBarSelectedWindowChange';
    
}