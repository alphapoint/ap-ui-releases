import { AEvent } from './AEvent.js';

export class AWebsocketEvent extends AEvent {

    public static OPEN:string = 'websocketOpen';
    public static CLOSE:string = 'websocketClose';
    public static MESSAGE:string = 'websocketMessage';
    public static ERROR:string = 'websocketError';

}