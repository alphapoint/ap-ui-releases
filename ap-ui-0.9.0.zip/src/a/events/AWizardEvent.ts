import { AEvent } from './AEvent.js';

export class AWizardEvent extends AEvent {

    public static ACTION:string = 'wizardAction';
    public static PREVIOUS_STEP:string = 'wizardPreviousStep';
    public static NEXT_STEP:string = 'wizardNextStep';
    public static CANCEL:string = 'wizardCancel';
    public static COMPLETE:string = 'wizardComplete';

}