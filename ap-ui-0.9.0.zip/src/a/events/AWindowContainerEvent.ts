import { AEvent } from './AEvent.js';

export class AWindowContainerEvent extends AEvent {

    public static WINDOW_ADDED:string = 'windowAdded';
    public static WINDOW_REMOVED:string = 'windowRemoved';
    public static WINDOW_FOCUSED:string = 'windowFocused';
    public static WINDOW_MINIMIZED:string = 'windowMinimized';
    public static WINDOW_MAXIMIZED:string = 'windowMaximized';
}