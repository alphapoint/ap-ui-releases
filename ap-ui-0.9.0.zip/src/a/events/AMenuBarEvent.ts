import { AEvent } from './AEvent.js';

export class AMenuBarEvent extends AEvent {

    public static CLOSED:string = 'menuBarClosed';
    public static ITEM_CLICKED:string = 'menuBarItemClicked';
    public static ITEM_MOUSED_OVER:string = 'menuBarItemMousedOver';
    public static ITEM_MOUSED_OUT:string = 'menuBarItemMousedOut';

}