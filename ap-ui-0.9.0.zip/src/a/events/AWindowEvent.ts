import { AEvent } from './AEvent.js';

export class AWindowEvent extends AEvent {

    public static DRAG_START:string = 'windowDragStart';
    public static DRAG:string = 'windowDrag';
    public static DRAG_END:string = 'windowDragEnd';

    public static RESIZE_START:string = 'windowResizeStart';
    public static RESIZE:string = 'windowResize';
    public static RESIZE_END:string = 'windowResizeEnd';

    public static DESTROYED:string = 'windowDestroyed';

    public static MINIMIZE_CLICKED:string = 'windowMinimizeClicked';
    public static MAXIMIZE_CLICKED:string = 'windowMaximizeClicked';
    public static CLOSE_CLICKED:string = 'windowCloseClicked';
    public static HEADER_DOUBLE_CLICKED:string = 'windowHeaderDoubleClicked';
    
}