import { AEvent } from './AEvent.js';

export class AWebsocketWorkerEvent extends AEvent {

    public static CONNECTED:string = 'websocketWorkerConnected';
    public static MESSAGE:string = 'websocketWorkerMessage';
    public static DISCONNECTED:string = 'websocketWorkerDisconnected';
    public static ERROR:string = 'websocketWorkerError';

}