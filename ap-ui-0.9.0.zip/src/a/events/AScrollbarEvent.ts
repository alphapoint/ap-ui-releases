import { AEvent } from './AEvent.js';

export class AScrollbarEvent extends AEvent {

    public static SCROLL:string = 'scroll';

}