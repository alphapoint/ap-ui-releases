import { AEvent } from './AEvent.js';

export class ATreeEvent extends AEvent {

    public static NODE_SELECTED:string = 'treeNodeSelected';

    public static NODE_CLICKED:string = 'treeNodeClicked';
    public static NODE_DOUBLE_CLICKED:string = 'treeNodeDoubleClicked';
    public static NODE_ACTION:string = 'treeNodeAction';

    public static NODE_OPENED:string = 'treeNodeOpened';
    public static NODE_CLOSED:string = 'treeNodeClosed';

}