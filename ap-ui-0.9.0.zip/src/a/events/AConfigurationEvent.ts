import { AEvent } from './AEvent.js';

export class AConfigurationEvent extends AEvent {

    public static LOADED:string = 'configurationLoaded';
    public static ERROR:string = 'configurationError';

}