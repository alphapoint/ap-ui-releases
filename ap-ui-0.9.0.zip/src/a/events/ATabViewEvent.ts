import { AEvent } from './AEvent.js';

export class ATabViewEvent extends AEvent {

    public static SELECTED_INDEX_CHANGE:string = 'tabViewSelectedIndexChange';

}