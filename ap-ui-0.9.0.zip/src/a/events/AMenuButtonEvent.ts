import { AEvent } from './AEvent.js';

export class AMenuButtonEvent extends AEvent {

    public static ITEM_SELECTED:string = 'menuButtonItemSelected';

}