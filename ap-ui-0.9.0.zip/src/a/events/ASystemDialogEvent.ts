import { AEvent } from './AEvent.js';

export class ASystemDialogEvent extends AEvent {

    public static OK:string = 'systemDialogOK';
    public static CANCEL:string = 'systemDialogCancel';

}