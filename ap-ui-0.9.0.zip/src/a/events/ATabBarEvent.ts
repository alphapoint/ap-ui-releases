import { AEvent } from './AEvent.js';

export class ATabBarEvent extends AEvent {

    public static SELECTED_INDEX_CHANGE:string = 'tabBarSelectedIndexChange';
    public static TAB_HOVER:string = 'tabBarTabHover';

}