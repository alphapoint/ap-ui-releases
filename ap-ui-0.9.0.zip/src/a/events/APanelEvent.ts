import { AEvent } from './AEvent.js';

export class APanelEvent extends AEvent {

    public static DRAG_START:string = 'panelDragStart';
    public static DRAG:string = 'panelDrag';
    public static DRAG_END:string = 'panelDragEnd';

    public static RESIZE_START:string = 'panelResizeStart';
    public static RESIZE:string = 'panelResize';
    public static RESIZE_END:string = 'panelResizeEnd';

    public static DESTROYED:string = 'panelDestroyed';

    public static MENU_ICON_CLICKED:string = 'panelMenuIconClicked';
    
}