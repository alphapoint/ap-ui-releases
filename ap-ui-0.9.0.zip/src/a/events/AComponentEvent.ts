import { AEvent } from './AEvent.js';

export class AComponentEvent extends AEvent {

    public static ATTACHED:string = 'attached';
    public static DETACHED:string = 'detached';
    public static ATTRIBUTE_CHANGED:string = 'attributeChanged';

    public static BUILD_COMPLETE:string = 'buildComplete';
    public static REGISTER_LISTENERS_COMPLETE:string = 'registerListenersComplete';
    public static UNREGISTER_LISTENERS_COMPLETE:string = 'unregisterListenersComplete';
    public static RENDER_COMPLETE:string = 'renderComplete';
    public static INSTANTIATION_COMPLETE:string = 'instantiationComplete';

    public static CHILD_APPENDED:string = 'childAppended';
    public static CHILD_APPENDED_AT:string = 'childAppendedAt';
    public static CHILD_REMOVED:string = 'childRemoved';
    public static CHILD_REMOVED_AT:string = 'childRemovedAt';
    public static ALL_CHILDREN_REMOVED:string = 'allChildrenRemoved';

    public static DESTROYED:string = 'destroyed';

}