import { AEvent } from './AEvent.js';

export class AButtonBarEvent extends AEvent {

    public static SELECTED_INDEX_CHANGE:string = 'buttonBarSelectedIndexChange';
    public static BUTTON_HOVER:string = 'buttonBarButtonHover';
    public static BUTTON_CLICK:string = 'buttonBarButtonClick';

}