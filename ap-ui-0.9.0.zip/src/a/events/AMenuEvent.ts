import { AEvent } from './AEvent.js';

export class AMenuEvent extends AEvent {

    public static ITEM_CLICKED:string = 'menuItemClicked';
    public static ITEM_MOUSED_OVER:string = 'menuItemMousedOver';
    public static ITEM_MOUSED_OUT:string = 'menuItemMousedOut';

}