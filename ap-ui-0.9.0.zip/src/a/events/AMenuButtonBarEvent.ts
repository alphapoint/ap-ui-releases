import { AEvent } from './AEvent.js';

export class AMenuButtonBarEvent extends AEvent {

    public static ITEM_CLICKED:string = 'menuButtonBarItemClicked';
    public static SELECTED_ITEM_CHANGE:string = 'menuButtonBarSelectedItemChange';

}