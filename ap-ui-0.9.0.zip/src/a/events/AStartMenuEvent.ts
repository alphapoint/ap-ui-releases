import { AEvent } from './AEvent.js';

export class AStartMenuEvent extends AEvent {

    public static ITEM_CLICKED:string = 'startMenuItemClicked';

}