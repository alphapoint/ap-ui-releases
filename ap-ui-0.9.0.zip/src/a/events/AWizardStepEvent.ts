import { AEvent } from './AEvent.js';

export class AWizardStepEvent extends AEvent {

    public static ACTION:string = 'wizardStepAction';
    public static CHANGE:string = 'wizardStepChange';

}