import { AEvent } from './AEvent.js';

export class ADataProviderEvent extends AEvent {

    public static ADD:string = 'dataProviderAdd';
    public static REMOVE:string = 'dataProviderRemove';
    public static CHANGE:string = 'dataProviderChange';

}