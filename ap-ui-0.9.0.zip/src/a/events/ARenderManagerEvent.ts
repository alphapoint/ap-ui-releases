import { AEvent } from './AEvent.js';

export class ARenderManagerEvent extends AEvent {

    public static RESIZE:string = 'renderManagerResize';
    public static RESIZE_END:string = 'renderManagerResizeEnd';

    public static VISIBILITY_CHANGE:string = 'renderManagerVisibilityChange';

    public static DIAGNOSTICS:string = 'renderManagerDiagnostics';

}