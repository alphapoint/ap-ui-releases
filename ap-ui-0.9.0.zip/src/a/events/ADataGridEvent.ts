import { AEvent } from './AEvent.js';

export class ADataGridEvent extends AEvent {

    public static ROW_RENDER:string = 'dataGridRowRender';
    public static SELECTED_INDEX_CHANGED:string = 'dataGridSelectedIndexChanged';
    public static ROW_CLICK:string = 'dataGridRowClick';
    public static ROW_DOUBLE_CLICK:string = 'dataGridRowDoubleClick';
    
}