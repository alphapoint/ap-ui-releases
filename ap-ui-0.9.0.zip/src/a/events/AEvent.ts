export class AEvent extends CustomEvent<any> {
}