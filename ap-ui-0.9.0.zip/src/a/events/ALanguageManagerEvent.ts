import { AEvent } from './AEvent.js';

export class ALanguageManagerEvent extends AEvent {

    public static BEFORE_LANGUAGE_CHANGED:string = 'languageManagerBeforeLanguageChanged';
    public static LANGUAGE_CHANGED:string = 'languageManagerLanguageChanged';

}