export class AEventDispatcher extends EventTarget {

}