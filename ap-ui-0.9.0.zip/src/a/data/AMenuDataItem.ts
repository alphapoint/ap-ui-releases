export class AMenuDataItem extends Object {

    private _icon:Array<string>;
    private _label:string;
    private _data:any;
    private _enabled:boolean;
    private _selected:boolean;
    
    public constructor(icon:Array<string> = null, label:string = '', data:any = null, enabled:boolean = true, selected:boolean = false) {
        super();
        
        this._icon = icon;
        this._label = label;
        this._data = data;
        this._enabled = enabled;
        this._selected = selected;
    }

    public get icon():Array<string> {
        return this._icon;
    }
    public set icon(i:Array<string>) {
        this._icon = i;
    }
    
    public get label():string {
        return this._label;
    }
    public set label(l:string) {
        if(this._label !== l){
            this._label = l;
        }
    }

    public get data():any {
        return this._data;
    }
    public set data(d:any) {
        if(this._data !== d){
            this._data = d;
        }
    }

    public get enabled():boolean {
        return this._enabled;
    }
    public set enabled(e:boolean) {
        this._enabled = e;
    }

    public get selected():boolean {
        return this._selected;
    }
    public set selected(s:boolean) {
        this._selected = s;
    }
}