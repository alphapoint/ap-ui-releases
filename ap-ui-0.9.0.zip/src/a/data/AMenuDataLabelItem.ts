export class AMenuDataLabelItem extends Object {

    private _label:string;
    
    public constructor(label:string = '') {
        super();
        
        this._label = label;
    }

    public get label():string {
        return this._label;
    }
    public set label(l:string) {
        if(this._label !== l){
            this._label = l;
        }
    }

}