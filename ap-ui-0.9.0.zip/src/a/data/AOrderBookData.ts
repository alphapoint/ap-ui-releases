import { AOrderBookDataMapItem } from './AOrderBookDataMapItem.js';
import { AOrderBookDataMap, AOrderBookDataMapDirection } from './AOrderBookDataMap.js';
import { AEventDispatcher } from '../events/AEventDispatcher.js';

type TYPE = 'ask' | 'bid';

export enum AOrderBookDataType {
    BID = 'bid',
    ASK = 'ask'
}

export class AOrderBookData extends AEventDispatcher {

    private _askData:AOrderBookDataMap;
    private _bidData:AOrderBookDataMap;

    private _aggregation:number;

    public constructor() {
        super();

        this._askData = new AOrderBookDataMap(AOrderBookDataMapDirection.ASCENDING);
        this._bidData = new AOrderBookDataMap(AOrderBookDataMapDirection.DESCENDING);

        this._aggregation = .01;
    }
    
    public parse(asks:Array<Array<number>>, bids:Array<Array<number>>):void {
        if(asks.length > 0){
            asks.forEach(element => {
                //if(element[1] === 0){
                //    this._askData.remove(element[0]);
                //} else {
                    this._askData.add(element[0], element[1]);
                //}
            });
        }

        if(bids.length > 0){
            bids.forEach(element => {
                //if(element[1] === 0){
                //    this._bidData.remove(element[0]);
                //} else {
                    this._bidData.add(element[0], element[1]);
                //}
            });
        }

        //this.dispatchEvent(DataEvent.PARSE_COMPLETE);
    }

    public add(type:AOrderBookDataType, price:number, quantity:number):void {
        //console.log(type, price, quantity);
        //type = 'ask' or 'bid'

        if(type === AOrderBookDataType.ASK){
            this._askData.add(price, quantity);
        } else if(type === AOrderBookDataType.BID){
            this._bidData.add(price, quantity);
        }

        //this.dispatchEvent(DataEvent.ADD_COMPLETE);
    }
    /*
    remove(type, price, quantity){
        //type = 'ask' or 'bid'

        if(type === 'ask'){
            this._askData.remove(price);
        } else if(type === 'bid'){
            this._bidData.remove(price);
        }

        this.dispatchEvent(DataEvent.REMOVE_COMPLETE);
    }
    */

    public getClosestItem(type:AOrderBookDataType, price:number):AOrderBookDataMapItem {
        if(type === AOrderBookDataType.ASK){
            return this._askData.getClosestItem(price);
        } else if(type === AOrderBookDataType.BID){
            return this._bidData.getClosestItem(price);
        }
        return null;
    }

    public destroy():void {
        this._askData.destroy();
        this._bidData.destroy();
    }

    public clearAll():void {
        this._askData.clearAll();
        this._bidData.clearAll();
    }

    public get aggregation():number {
        return this._aggregation;
    }
    public set aggregation(a:number){
        if(this._aggregation !== a){
            this._aggregation = a;
            this._askData.aggregation = a;
            this._bidData.aggregation = a;
        }
    }

    public get hasData():boolean {
        return this._askData.hasData && this._bidData.hasData;
    }

    public get askData():AOrderBookDataMap {
        return this._askData;
    }

    public get bidData():AOrderBookDataMap {
        return this._bidData;
    }

    public get lowerPriceBound():number {
        return this._bidData.lowerPriceBound;
    }
    public get upperPriceBound():number {
        return this._askData.upperPriceBound;
    }
    public get upperQuantityBound():number {
        return Math.max(this._askData.upperQuantityBound, this._bidData.upperQuantityBound);
    }

    public get spread():number {
        return this._askData.lowerPriceBound - this._bidData.upperPriceBound;
    }
}