export class AMenuDataDividerItem extends Object {

    public constructor() {
        super();
    }
}