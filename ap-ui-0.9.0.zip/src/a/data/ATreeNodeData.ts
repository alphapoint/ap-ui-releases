export class ATreeNodeData extends Object {

    private _id:string;
    private _parentID:string;
    private _childTreeData:Array<ATreeNodeData>;

    private _enabled:boolean;
    private _isOpen:boolean;
    private _iconBack:Array<string>;
    private _iconFront:Array<string>;
    private _label:string;
    private _actionText:string;

    public constructor(id:string, childTreeNodeData:Array<ATreeNodeData> = null) {
        super();

        this._id = id;
        this._childTreeData = childTreeNodeData !== null ? childTreeNodeData : [];

        this._enabled = true;
        this._isOpen = false;
        this._iconBack = null;
        this._iconFront = null;
        this._label = null;
        this._actionText = null;
    }

    public get ID():string {
        return this._id;
    }

    public get childTreeData():Array<ATreeNodeData> {
        return this._childTreeData;
    }
    public set childTreeData(c:Array<ATreeNodeData>) {
        this._childTreeData = c;
    }

    public get enabled():boolean {
        return this._enabled;
    }
    public set enabled(e:boolean) {
        this._enabled = e;
    }

    public get isOpen():boolean {
        return this._isOpen;
    }
    public set isOpen(i:boolean) {
        this._isOpen = i;
    }

    public get iconBack():Array<string> {
        return this._iconBack;
    }
    public set iconBack(i:Array<string>) {
        this._iconBack = i;
    }

    public get iconFront():Array<string> {
        return this._iconFront;
    }
    public set iconFront(i:Array<string>) {
        this._iconFront = i;
    }

    public get label():string {
        return this._label;
    }
    public set label(l:string) {
        this._label = l;
    }

    public get actionText():string {
        return this._actionText;
    }
    public set actionText(a:string) {
        this._actionText = a;
    }

}