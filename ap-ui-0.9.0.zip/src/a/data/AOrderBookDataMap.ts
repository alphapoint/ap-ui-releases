import { AOrderBookDataMapItem } from './AOrderBookDataMapItem.js';

export enum AOrderBookDataMapDirection {
    ASCENDING = 'ascending',
    DESCENDING = 'descending'
}

export class AOrderBookDataMap extends Object {

    private _data:Map<string, AOrderBookDataMapItem> = new Map();
    
    private _lowerPriceBound = Number.MAX_SAFE_INTEGER;
    private _upperPriceBound = 0;
    private _upperQuantityBound = 0;

    private _firstItem:AOrderBookDataMapItem;
    private _lastItem:AOrderBookDataMapItem
    private _currentItem:AOrderBookDataMapItem

    private _aggregation = .01;

    private _direction:AOrderBookDataMapDirection;

    constructor(dir:AOrderBookDataMapDirection = AOrderBookDataMapDirection.ASCENDING) {
        super();

        this._data = new Map();

        this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
        this._upperPriceBound = 0;
        this._upperQuantityBound = 0;

        this._firstItem = null;
        this._lastItem = null;
        this._currentItem = null;

        this._aggregation = .01;

        this._direction = dir;
    }

    private _updateItem(item:AOrderBookDataMapItem, quantity:number):void {
        item.quantity = quantity;

        this._currentItem = item;
    }

    private _insertItem(item:AOrderBookDataMapItem):void {
        //Start at currentItem
        let referenceItem = this._currentItem;
        //console.log(item.price, referenceItem.price);

        while(referenceItem !== item){

            if(item.price < referenceItem.price){
                //New item is before reference item

                if(referenceItem.previous !== null){
                    //Reference item has a previous sibling

                    if(item.price < referenceItem.previous.price){
                        //If new item's price is lesser than previous sibling's, continue descending

                        referenceItem = referenceItem.previous;
                        continue;
                    } else {
                        //Slot discovered, adjust nexts and previouses of new item, and reference item

                        item.previous = referenceItem.previous;
                        item.next = referenceItem;

                        referenceItem.previous.next = item;
                        referenceItem.previous = item;

                        this._currentItem = item;
                        return;
                    }

                } else {
                    //Since new item price is lesser than reference item and reference 
                    //item has no previous sibling, attach at the beginning and update this._firstItem

                    referenceItem.previous = item;
                    item.next = referenceItem;

                    this._firstItem = item;

                    this._currentItem = item;
                    return;
                }

            } else if(item.price > referenceItem.price){
                //New item is after reference item

                if(referenceItem.next !== null){
                    //Reference item has a next sibling

                    if(item.price > referenceItem.next.price){
                        //If new item's price is greater than next sibling's, continue ascending

                        referenceItem = referenceItem.next;
                        continue;
                    } else {
                        //Slot discovered, adjust nexts and previouses of new item, and reference item

                        item.previous = referenceItem;
                        item.next = referenceItem.next;

                        referenceItem.next.previous = item;
                        referenceItem.next = item;

                        this._currentItem = item;
                        return;
                    }

                } else {
                    //Since new item price is greater than reference item and reference 
                    //item has no next sibling, attach at the end and update this._lastItem

                    referenceItem.next = item;
                    item.previous = referenceItem;

                    this._lastItem = item;

                    this._currentItem = item;
                    return;
                }

            }

        }
    }

    private _deleteItem(item:AOrderBookDataMapItem):void {
        let key = item.price.toString();
        //When removing an item, this._currentItem should become this._currentItem.next, if it exists.
        //If not, then this._currentItem.previous

        if(this._data.has(key)){
            //Update item.previous and item.next references
            //We could use this._firstItem and this._lastItem here, but those are likely
            //only used for rendering

            let previousItem = item.previous;
            let nextItem = item.next;

            //item.next = null;
            //item.previous = null;

            if(previousItem !== null && nextItem !== null){
                //Item is in middle of the linked list

                previousItem.next = nextItem;
                nextItem.previous = previousItem;

                this._currentItem = previousItem;

            } else if(nextItem !== null) {
                //Item at the beginning of the linked list

                nextItem.previous = null;

                this._firstItem = nextItem;
                this._currentItem = nextItem;

            } else if(previousItem !== null){
                //Item at the end of the linked list

                previousItem.next = null;

                this._lastItem = previousItem;
                this._currentItem = previousItem;
            }

        }

        //Remove previous and next references on item for garbage collection
        item.next = null;
        item.previous = null;

        //Delete map association
        this._data.delete(key);

        if(this._data.size === 0){
            this._currentItem = null;
            this._firstItem = null;
            this._lastItem = null;

            this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
            this._upperPriceBound = 0;
            this._upperQuantityBound = 0;
        } else {
            //this._computeCumulatives();

            this._computeBounds();
        }
    }

    _computeBounds(){

        if(this._data.size > 0){

            this._lowerPriceBound = this._firstItem.price;
            this._upperPriceBound = this._lastItem.price;

            //This one is easy, it's always the last item's cumulativeQuantity
            this._upperQuantityBound = this._direction === AOrderBookDataMapDirection.ASCENDING ? this._lastItem.cumulativeQuantity : this._firstItem.cumulativeQuantity;
            
        } else {

            this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
            this._upperPriceBound = 0;
            this._upperQuantityBound = 0;

        }
    }

    /*
    _computeCumulatives(){

        if(this._data.size > 0){

            //Start at currentItem, always ascends
            let referenceItem = this._direction === OrderBookDataMap.ASCENDING ? this._firstItem : this._lastItem;

            while(referenceItem !== null){

                //Depending on cumulative quantity/cost direction, choose previous cumulative total
                let prevCumulativeItem = this._direction === OrderBookDataMap.ASCENDING ? referenceItem.previous : referenceItem.next;


                if(prevCumulativeItem !== null){
                    //New item cumulative total is previous total, plus current item quantity
                    referenceItem.cumulativeQuantity = prevCumulativeItem.cumulativeQuantity + referenceItem.quantity;
                    //console.log(referenceItem.cumulativeQuantity);
                    referenceItem.cumulativeCost = prevCumulativeItem.cumulativeCost + (referenceItem.quantity * referenceItem.price);
                } else {
                    //If it's null, we're at the beginning or end of the linked list
                    referenceItem.cumulativeQuantity = referenceItem.quantity;
                    referenceItem.cumulativeCost = referenceItem.quantity * referenceItem.price;
                }

                if(this._direction === OrderBookDataMap.ASCENDING){
                    //console.log(this._cumulativeTotalDirection, referenceItem.price, referenceItem.cumulativeQuantity);
                }

                //New reference item is next or previous, or null, to kill the loop
                referenceItem = (this._direction === OrderBookDataMap.ASCENDING ? referenceItem.next : referenceItem.previous);
            }

        }

    }
    */

    public add(price:number, quantity:number){
        //This method insert/updates into the linked list, as well as adds the item to the map
        //price = parseFloat(price);
        //quantity = parseFloat(quantity);

        let key = price.toString();
        let item;

        if(this._data.size === 0){
            //Map is empty, initialize vars

            let item = new AOrderBookDataMapItem(price, quantity, quantity);

            this._firstItem = item;
            this._lastItem = item;

            this._data.set(key, item);

            this._currentItem = item;

        } else {
            //Map is not empty, insert or update as appropriate
            //console.log(this._data.has(key), price, quantity);
            if(this._data.has(key)){
                
                let referenceItem = this._data.get(key);

                if(quantity > 0){
                    //console.log('update');
                    //Only update if necessary
                    if(referenceItem.quantity !== quantity){
                        this._updateItem(referenceItem, quantity);
                    }
                } else {
                    //console.log('remove');
                    //Remove if quantity is zero

                    this._deleteItem(referenceItem);
                }

            } else if(quantity > 0){
                //console.log('add');
                //Insert

                let item = new AOrderBookDataMapItem(price, quantity, quantity);

                this._data.set(key, item);
                this._insertItem(item);
            }

        }

        //this._computeCumulatives();

        this._computeBounds();
    }

    public getClosestItem(price:number):AOrderBookDataMapItem {
        if(this._data.has(price.toString())){
            //price is an item, return item
            this._data.get(price.toString());
        } else if(this._firstItem !== null && this._firstItem.price > price){
            //price is lesser than first item, return first
            return this._firstItem;
        } else if(this._lastItem !== null && this._lastItem.price < price){
            //price is greater than last item, return last
            return this._lastItem;
        } else {
            //Get to work finding one

            let fromFirst = this._firstItem;
            let fromLast = this._lastItem;

            while(fromFirst !== null && fromLast !== null){
                if(fromFirst.next !== null){
                    if(price > fromFirst.next.price){
                        fromFirst = fromFirst.next;
                    } else {
                        return Math.abs(fromFirst.next.price - price) > Math.abs(fromFirst.price - price) ? fromFirst : fromFirst.next;
                    }
                } else {
                    fromFirst = null;
                }

                if(fromLast.previous !== null){
                    if(price < fromLast.previous.price){
                        fromLast = fromLast.previous;
                    } else {
                        return Math.abs(fromLast.previous.price - price) > Math.abs(fromLast.price - price) ? fromLast : fromLast.previous;
                    }
                }else {
                    fromLast = null;
                }
            }

            return null;
        }
    }

    public destroy():void {
        this.clearAll();
    }

    public clearAll():void {
        this._data.clear();

        this._lowerPriceBound = Number.MAX_SAFE_INTEGER;
        this._upperPriceBound = 0;
        this._upperQuantityBound = 0;

        this._firstItem = null;
        this._lastItem = null;
        this._currentItem = null;
    }

    //We only need to compute cumulative quantities/cost when iterating through the book, for instance,
    //when we display an Order Book Depth chart
    public [Symbol.iterator]() {

        let direction:AOrderBookDataMapDirection = this._direction;
        let referenceItem:AOrderBookDataMapItem = direction === AOrderBookDataMapDirection.ASCENDING ? this._firstItem : this._lastItem;
        let cumulativeCost:number = 0;
        let cumulativeQuantity:number = 0;

        return {

            next: () => {

                if(referenceItem !== null){

                    let prevReferenceItem:AOrderBookDataMapItem = referenceItem;

                    cumulativeQuantity = cumulativeQuantity + prevReferenceItem.quantity;
                    cumulativeCost = prevReferenceItem.cumulativeCost + (prevReferenceItem.quantity * prevReferenceItem.price);

                    prevReferenceItem.cumulativeQuantity = cumulativeQuantity;
                    prevReferenceItem.cumulativeCost = cumulativeCost;

                    referenceItem = direction === AOrderBookDataMapDirection.ASCENDING ? referenceItem.next : referenceItem.previous;

                    return {value: prevReferenceItem.valueOf(), done: false};

                } else {

                    return {value: undefined, done: true};

                }

            }

        }

    };

    public get hasData():boolean {
        return this._data.size > 0;
    }

    public get length():number {
        return this._data.size;
    }

    public get firstItem():AOrderBookDataMapItem {
        return this._firstItem;
    }

    public get lastItem():AOrderBookDataMapItem {
        return this._lastItem;
    }

    public get aggregation():number {
        return this._aggregation;
    }
    public set aggregation(a:number) {
        if(this._aggregation !== a){
            this._aggregation = a;
        }
    }

    public get lowerPriceBound():number {
        return this._data.size > 0 ? this._lowerPriceBound : 0;
    }

    public get upperPriceBound():number {
        return this._data.size > 0 ? this._upperPriceBound : 0;
    }

    public get upperQuantityBound():number {
        return this._data.size > 0 ? this._upperQuantityBound : 0;
    }
}