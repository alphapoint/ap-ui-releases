import { AMenuDataItem } from './AMenuDataItem.js';
import { AMenuDataDividerItem } from './AMenuDataDividerItem.js';

export class AMenuData extends Object {

    private _icon:Array<string>;
    private _label:string;
    private _items:Array<AMenuDataItem | AMenuDataDividerItem>;
    private _data:any;
    private _enabled:boolean;

    public constructor(icon:Array<string> = null, label:string = '', items:Array<AMenuDataItem | AMenuDataDividerItem> = [], data:any = null, enabled:boolean = true) {
        super();

        this._icon = icon;
        this._label = label;
        this._items = items;
        this._data = data;
        this._enabled = enabled;
    }
    
    public get icon():Array<string> {
        return this._icon;
    }
    public set icon(i:Array<string>) {
        this._icon = i;
    }

    public get label():string {
        return this._label;
    }
    public set label(l:string) {
        this._label = l;
    }

    public get items():Array<AMenuDataItem | AMenuDataDividerItem> {
        return this._items || [];
    }
    public set items(i:Array<AMenuDataItem | AMenuDataDividerItem>) {
        if(this._items !== i){
            this._items = i || [];
        }
    }

    public get data():any {
        return this._data;
    }
    public set data(d:any) {
        this._data = d;
    }

    public get enabled():boolean {
        return this._enabled;
    }
    public set enabled(e:boolean) {
        this._enabled = e;
    }
}