export class AOrderBookDataMapItem extends Object {

    private _previous:AOrderBookDataMapItem;
    private _next:AOrderBookDataMapItem;

    private _price:number;
    private _quantity:number;
    private _cumulativeQuantity:number;
    private _cumulativeCost:number;

    public constructor(price:number = 0, quantity:number = 0, cumulativeQuantity:number = 0, cumulativeCost:number = 0) {
        super();

        this._previous = null;
        this._next = null;

        this._price = price;
        this._quantity = quantity;
        this._cumulativeQuantity = cumulativeQuantity;
        this._cumulativeCost = cumulativeCost;
    }

    public get previous():AOrderBookDataMapItem {
        return this._previous;
    }
    public set previous(p:AOrderBookDataMapItem) {
        this._previous = p;
    }

    public get next():AOrderBookDataMapItem {
        return this._next;
    }
    public set next(n:AOrderBookDataMapItem) {
        this._next = n;
    }

    public get price():number {
        return this._price;
    }
    public set price(p:number) {
        this._price = p;
    }

    public get quantity():number {
        return this._quantity;
    }
    public set quantity(c:number) {
        this._quantity = c;
    }

    public get cumulativeQuantity():number {
        return this._cumulativeQuantity;
    }
    public set cumulativeQuantity(c:number) {
        this._cumulativeQuantity = c;
    }

    public get cumulativeCost():number {
        return this._cumulativeCost;
    }
    public set cumulativeCost(c:number) {
        this._cumulativeCost = c;
    }
}