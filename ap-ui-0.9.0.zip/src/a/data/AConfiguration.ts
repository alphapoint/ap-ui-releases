import { AEventDispatcher, AConfigurationEvent } from '../events/index.js';

export class AConfiguration extends AEventDispatcher {

    private _uri:string = null;
    private _data:any = null;

    constructor(){
        super();
    }

    private _loadConfiguration():void {
        fetch(this._uri)
        .then((response:Response) => {
            return response.json();
        })
        .then((json:any) => {
            this._data = json;
            this.dispatchEvent(new AConfigurationEvent(AConfigurationEvent.LOADED));
        }).catch(() => {
            this._data = null;
            this.dispatchEvent(new AConfigurationEvent(AConfigurationEvent.ERROR));
        });
    }

    public get uri():string {
        return this._uri;
    }
    public set uri(uri:string){
        if(uri && this._uri !== uri){
            this._uri = uri;

            this._loadConfiguration();
        }
    }

    public get data():any {
        return this._data;
    }
}