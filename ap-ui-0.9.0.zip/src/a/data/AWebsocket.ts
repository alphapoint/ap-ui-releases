import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { AWebsocketEvent } from '../events/AWebsocketEvent.js';
import { ARenderManager } from '../managers/ARenderManager.js';

export class AWebsocket extends AEventDispatcher {
    
    private _uri:string;
    private _websocket:WebSocket;

    private _receiveQueue:Array<any>;

    // private _throttled:boolean;
    // private _suspended:boolean;
    // private _queueTimer:number;
    // private _queueTimeout:number;
    // private _throttledQueueTimeout:number;

    public constructor() {
        super();

        this._uri = null;
        this._websocket = null;

        // this._queueTimer = null;
        // this._queueTimeout = 4;
        // this._throttledQueueTimeout = 1001;
        this._receiveQueue = [];

        this._parseQueue = this._parseQueue.bind(this);
    }

    // private _startQueueTimer(){
    //     this._stopQueueTimer();

    //     this._queueTimer = window.setInterval(() => {
    //         this._executeQueueTimer();
    //     }, this._throttled ? this._throttledQueueTimeout : this._queueTimeout);

    // }

    // private _executeQueueTimer(){
    //     if(this._suspended){
    //         return;
    //     }
    //     while(this._receiveQueue.length > 0){
    //         this._onMessage(this._receiveQueue.shift());
    //     }
    // }

    private _parseQueue(){
        // if(this._suspended){
        //     return;
        // }
        while(this._receiveQueue.length > 0){
            this._onMessage(this._receiveQueue.shift());
        }
    }

    // private _stopQueueTimer(){
    //     if(this._queueTimer !== null){
    //         clearInterval(this._queueTimer);
    //         this._queueTimer = null;
    //     }
    // }

    protected _onOpen(event:Event){
        // this._startQueueTimer();

        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.OPEN, { detail: event }));
    }

    protected _onMessage(event:MessageEvent){
        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.MESSAGE, { detail: event }));
    }

    protected _onError(event:Event){
        this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.ERROR, { detail: event }));
    }

    protected _onClose(event:CloseEvent){
        // this._stopQueueTimer();

        if(event.code === 1006){
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.ERROR, { detail: event }));
        } else {
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.CLOSE, { detail: event }));
        }
    }

    public connect(uri:string):void {
        this.disconnect();

        this._uri = uri;
        try {
            this._websocket = new WebSocket(this._uri);
            
            this._websocket.binaryType = 'arraybuffer';

            this._websocket.onopen = (event:Event) => {
                this._onOpen(event);
            }
            this._websocket.onmessage = (event:MessageEvent) => {
                this._receiveQueue[this._receiveQueue.length] = event;
                ARenderManager.instance.requestAnimationFrame(this._parseQueue);
            }
            this._websocket.onerror = (event:Event) => {
                this._onError(event);
            }
            this._websocket.onclose = (event:CloseEvent) => {
                this._onClose(event);
            }
        } catch(error){
             console.log(error);
            // this.dispatchEvent(new APWebsocketEvent(APWebsocketEvent.ERROR, { detail: error }));
        }
    }

    public disconnect():void {
        if(this._websocket !== null){
            // this._stopQueueTimer();
            this.dispatchEvent(new AWebsocketEvent(AWebsocketEvent.CLOSE, { detail: event }));
            this._receiveQueue = [];

            this._websocket.onopen = null;
            this._websocket.onmessage = null;
            this._websocket.onerror = null;
            this._websocket.onclose = null;
            this._websocket.close();

            this._websocket = null;
        }
    }

    public reconnect():void {
        if(this.connected){
            this.disconnect();
        }

        this.connect(this._uri);
    }

    public send(data:string = null):void {
        if(this.connected && data !== null && data.length > 0){
            this._websocket.send(data);
        }
    }

    public destroy():void {
        this.disconnect();
    }

    public get connected():boolean {
        if(this._websocket){
            if(this._websocket.readyState === 1){
                return true;
            }
        }
        return false;
    }

    public get uri():string {
        return this._uri;
    }

    public get bufferedAmount():number {
        if(this._websocket){
            return this._websocket.bufferedAmount;
        }
        return 0;
    }

    // public get throttled():boolean {
    //     return this._throttled;
    // }
    // public set throttled(t:boolean) {
    //     if(this._throttled !== t){
    //         this._throttled = t;
    //         this._startQueueTimer();
    //     }
    // }

    // public get suspended():boolean {
    //     return this._suspended;
    // }
    // public set suspended(s:boolean) {
    //     this._suspended = s;
    // }
}