import { AEventDispatcher, ADataProviderEvent } from '../events/index.js';

export class ADataProvider extends AEventDispatcher {

    private _data:Array<Array<any>>;

    public constructor(data:Array<Array<any>> = null) {
        super();

        this._data = data || [];
    }

    public from(data:Array<Array<any>> | Array<any>):void {
        this._data = data || [];
        this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.ADD, { detail: { index: 0 } }));
    }

    public getItemAt(index:number):Array<any> {
        if(index >= 0 && index < this._data.length){
            return this._data[index];
        } else {
            return null;
        }
    }

    public addItem(item:Array<any>):void {
        this.addItemAt(this._data.length, item);
    }

    public addItemAt(index:number, item:Array<any>):boolean {

        if(index >= 0 && index <= this._data.length){

            this._data.splice(index, 0, item);

            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.ADD, { detail: { index: index } }));

            return true;
        }

        return false;

    }

    public removeItemAt(index:number):boolean {

        if(index >= 0 && index < this._data.length){

            this._data.splice(index, 1);

            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.REMOVE, { detail: { index: index } }));

            return true;
        }

        return false;

    }

    public removeAllItems():boolean {

        this._data = [];

        this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.REMOVE, { detail: { index: 0 } }));

        return true;
        
    }

    public setItemAt(index:number, item:Array<any>):void {

        //console.log(index, this._data.length);

        // console.log(this._data[index], item);

        //console.log(index, item);

        let isDirty:boolean = false;

        if(this._data.length <= index){
            while(this._data.length <= index){
                this._data.push([]);
            }
        }

        if(this._data[index] === undefined){

            this._data[index] = item;
            isDirty = true;

        } else if(index >= 0 && index < this._data.length){

            this._data[index] = item;
            isDirty = true;

            //console.log(this._data[index], item);

            // if(this._data[index] !== item){

            //     let dataItem:Array<any> = this._data[index];
            //     let len:number = Math.max(dataItem.length, item.length);

            //     for(let i:number = 0; i < len; i++){
                    
            //         if(dataItem[i] !== item[i]){

            //             dataItem[i] = item[i];
            //             isDirty = true;

            //         }
                
            //     }
                
            // }

        }

        //console.log(isDirty);

        if(isDirty){
            this.dispatchEvent(new ADataProviderEvent(ADataProviderEvent.CHANGE, { detail: { index: index } }));
        }

    }

    public findIndex(comparison:(value: Array<any>) => unknown):number {
        return this._data.findIndex(comparison);
    }

    public hasItemAt(index:number):boolean {
        return this._data[index] !== undefined;
    }

    public destroy():void {
        this._data = [];
    }

    public get length():number {
        return this._data.length;
    }
}