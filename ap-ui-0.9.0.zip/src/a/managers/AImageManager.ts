import { AEventDispatcher } from '../events/AEventDispatcher.js';

export class AImageManager extends AEventDispatcher {

    private static _instance:AImageManager;

    public static get instance():AImageManager {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new AImageManager();
        }
        return this._instance;
    }

    private _baseURI:string;
    private _imageMap:Map<string, string>;
    private _canvas:HTMLCanvasElement;

    private constructor() {
        super();

        this._baseURI = '';
        this._imageMap = new Map();
        this._canvas = document.createElement('canvas');
    }

    public get(url:string, fallbackURL:string = null):string {
        if(this._imageMap.has(url)){
            return this._imageMap.get(url);
        } else {
            let tries:number = 0;
            const img:HTMLImageElement = new Image();
            img.crossOrigin = 'anonymous';
            img.src = `${this._baseURI}${url}`;
            tries++;
            img.onload = () => {

                this._canvas.width = img.naturalWidth;
                this._canvas.height = img.naturalHeight;
                this._canvas.getContext('2d').drawImage(img, 0, 0);

                this._imageMap.set(url, this._canvas.toDataURL('image/png'));

                img.onload = null;
                img.onerror = null;

            }
            if(fallbackURL !== null){
                img.onerror = () => {
                    if(tries < 2){
                        img.src = `${this._baseURI}${fallbackURL}`;
                        tries++;
                    } else if(tries < 3){
                        img.src = `${this._baseURI}/images/fail.png`;
                        tries++;
                    } else {
                        img.onload = null;
                        img.onerror = null;
                    }
                }
            }
            return `${this._baseURI}${url}`;
        }
    }

    public get baseURI():string {
        return this._baseURI;
    }
    public set baseURI(u:string){
        this._baseURI = u;
    }
}