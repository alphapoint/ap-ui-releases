import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { ALanguageManagerEvent } from '../events/ALanguageManagerEvent.js';
import { ALanguageManager } from './ALanguageManager.js';

export enum NumberFormatType {
    PRICE = 'PRICE',
    QUANTITY = 'QUANTITY',
    PERCENT = 'PERCENT'
}

export interface NumberFormatter {
    minimumFractionDigits:number;
    maximumFractionDigits:number;
    languageCollection:Map<string, Map<NumberFormatType, Intl.NumberFormat>>;
}

export class AFormatManager extends AEventDispatcher {

    private static _instance:AFormatManager;

    public static get instance() {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new AFormatManager();
        }
        return this._instance;
    }

    public _numberFormatters:Map<any, NumberFormatter>;

    private constructor() {
        super();

        this._numberFormatters = new Map();

        // let lm:ALanguageManager = ALanguageManager.instance;
        // lm.addEventListener(ALanguageManagerEvent.LANGUAGE_CHANGED, ():void => {

        // });
    }

    public getDecimalPlaceCount(n:number):number {
        // Make sure it is a number and use the builtin number -> string.
        var s:string = '' + (+n);
        // Pull out the fraction and the exponent.
        var match:RegExpExecArray = /(?:\.(\d+))?(?:[eE]([+\-]?\d+))?$/.exec(s);
        // NaN or Infinity or integer.
        // We arbitrarily decide that Infinity is integral.
        if (!match) {
            return 0;
        }
        // Count the number of digits in the fraction and subtract the
        // exponent to simulate moving the decimal point left by exponent places.
        // 1.234e+2 has 1 fraction digit and '234'.length -  2 == 1
        // 1.234e-2 has 5 fraction digit and '234'.length - -2 == 5
        return Math.max(
            0,  // lower limit.
            (match[1] == '0' ? 0 : (match[1] || '').length)  // fraction length
            - (Number(match[2]) || 0));  // exponent
    }

    public registerNumberFormatter(key:any, type:NumberFormatType, minimumFractionDigits:number, maximumFractionDigits:number):void {
        
        let numberFormatter:NumberFormatter = this._numberFormatters.get(key);
        if(!numberFormatter){
            numberFormatter = {
                minimumFractionDigits: minimumFractionDigits,
                maximumFractionDigits: maximumFractionDigits,
                languageCollection: new Map()
            };
            this._numberFormatters.set(key, numberFormatter);
        }

        ALanguageManager.instance.languageIDs.forEach((languageID:string):void => {

            let formatCollection:Map<NumberFormatType, Intl.NumberFormat> = numberFormatter.languageCollection.get(languageID);
            if(!formatCollection){
                formatCollection = new Map();
                numberFormatter.languageCollection.set(languageID, formatCollection);
            }

            let numberFormat:Intl.NumberFormat = formatCollection.get(type);
            if(!numberFormat){

                let style:string;
                if(type === NumberFormatType.PRICE){
                    style = 'decimal';
                } else if(type === NumberFormatType.QUANTITY){
                    style = 'decimal';
                } else if(type === NumberFormatType.PERCENT){
                    style = 'percent';
                }

                numberFormat = new Intl.NumberFormat(languageID, { 
                    minimumFractionDigits: minimumFractionDigits, 
                    maximumFractionDigits: maximumFractionDigits,
                    style: style
                });
                formatCollection.set(type, numberFormat);
            }

        });

    }

    public format(key:any, type:NumberFormatType, value:number):string {

        let formatter:Intl.NumberFormat = this._numberFormatters.get(key)?.
        // languageCollection.get(ALanguageManager.instance.languageID)?.
        languageCollection.get('en-US')?.
        get(type);

        // let formatter:NumberFormatter = this._numberFormatters.get(key);

        // if(formatter){

        //     let languageMap:Map<NumberFormatType, Intl.NumberFormat> = formatter.languageCollection.get(ALanguageManager.instance.languageID);

        //     if(languageMap){

        //         let typeFormat:Intl.NumberFormat = languageMap.get(type);

        //         if(typeFormat){

        //             return typeFormat.format(value);

        //         }

        //     }
        // }

        if(formatter){

            if(!Object.is(value, NaN)){
                return formatter.format(value)
            } else {
                return '';
            }

        } else {
            return String(value);
        }
        
    }

}