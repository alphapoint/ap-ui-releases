import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { ALanguageManagerEvent } from '../events/ALanguageManagerEvent.js';

interface LanguageConfigurationEntry {
    Id:string;
    Name:string;
    File:string;
}

interface LanguageConfiguration {
    PreferredLanguageID:string;
    Languages: Array<LanguageConfigurationEntry>;
}

export class ALanguageManager extends AEventDispatcher {

    private static _instance:ALanguageManager;

    public static get instance():ALanguageManager {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ALanguageManager();
        }
        return this._instance;
    }

    private _configuration:Map<string, LanguageConfigurationEntry>;

    private _currentLanguageID:string;
    private _currentLanguageName:string;

    private _languages:Map<string, Map<string, Map<string, string>>>;

    private _languageIDs:Array<string>;
    private _languageNames:Array<string>;

    private constructor() {
        super();

        this._configuration = new Map();

        this._currentLanguageID = null;
        this._currentLanguageName = null;

        this._languages = new Map();

        this._languageIDs = [];
        this._languageNames = [];
    }

    private _processConfig(data:LanguageConfiguration):void {
        data.Languages.forEach((entry:LanguageConfigurationEntry):void => {

            this._configuration.set(entry.Id, entry);

            this._languageIDs.push(entry.Id);
            this._languageNames.push(entry.Name);

            if(data.PreferredLanguageID === entry.Id){
                this._loadLanguage(entry.Id);
            }
            
        });
    }
    // private _loadConfig():void {

    //     fetch(`./language/index.json`)
    //     .then(response => response.json())
    //     .then((data) => {

    //         this._processConfig(data);

    //     });

    // }

    private _loadLanguage(id:string):void {

        this._currentLanguageID = id;

        if(!this._languages.has(this._currentLanguageID)){

            fetch(`./language/${this._currentLanguageID}/index.json`)
            .then(response => response.json())
            .then((data) => {

                let languageMap:Map<string, Map<string, string>> = new Map();
                this._languages.set(this._currentLanguageID, languageMap);

                for(let i in data){

                    let namespaceMap:Map<string, string> = new Map();

                    for(let j = 0; j < data[i].length; j++){
                        namespaceMap.set(data[i][j][0], data[i][j][1]);
                    }

                    languageMap.set(i, namespaceMap);

                }

                this._languageLoaded();

            });

        } else {

            this._languageLoaded();

        }
    }

    private _languageLoaded():void {

        this._currentLanguageName = this._configuration.get(this._currentLanguageID).Name;

        this.dispatchEvent(new ALanguageManagerEvent(ALanguageManagerEvent.BEFORE_LANGUAGE_CHANGED));
        
        setTimeout(():void => {
            this.dispatchEvent(new ALanguageManagerEvent(ALanguageManagerEvent.LANGUAGE_CHANGED));
        });

    }

    public get(namespace:string, key:string):string {
        if(this._languages.has(this._currentLanguageID)){
            let l:Map<string, Map<string, string>> = this._languages.get(this._currentLanguageID);
            if(l.has(namespace)){
                let n:Map<string, string> = l.get(namespace);
                if(n.has(key)){
                    return n.get(key);
                }
            }
        }
        return '';
    }

    public setConfig(c:LanguageConfiguration):void {
        this._processConfig(c);
    }

    public get languageID():string {
        return this._currentLanguageID;
    }
    public set languageID(id:string){
        if(this._currentLanguageID !== id){
            this._loadLanguage(id);
        }
    }

    public get languageName():string {
        return this._currentLanguageName;
    }

    public get languageIDs():Array<string> {
        return this._languageIDs;
    }

    public get languageNames():Array<string> {
        return this._languageNames;
    }
}