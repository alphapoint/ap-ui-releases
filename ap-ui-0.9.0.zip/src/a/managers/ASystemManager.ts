import { AEventDispatcher } from '../events/AEventDispatcher.js';
import { AComponent, ADialogContainer, AContextItemContainer, IAComponent, AContextWidget, ACustomDialog } from '../components/index.js';
import { AMenuData, AMenuDataItem } from '../data/index.js';
import { AForgotPasswordDialog } from '../components/dialogs/AForgotPasswordDialog.js';
import { ANoticeDialog } from '../components/dialogs/ANoticeDialog.js';
import { AAlertDialog } from '../components/dialogs/AAlertDialog.js';
import { AConfirmDialog } from '../components/dialogs/AConfirmDialog.js';
import { APromptDialog } from '../components/dialogs/APromptDialog.js';
import { AAuthenticateUsernamePasswordDialog } from '../components/dialogs/AAuthenticateUsernamePasswordDialog.js';
import { ARegisterDialog } from '../components/dialogs/ARegisterDialog.js';
import { AAuthenticateTwoFADialog } from '../components/dialogs/AAuthenticateTwoFADialog.js';
import { ASetupTwoFADialog } from '../components/dialogs/ASetupTwoFADialog.js';

export class ASystemManager extends AEventDispatcher {

    private static _instance:ASystemManager;

    private _dialogContainer:ADialogContainer;
    private _contextItemContainer:AContextItemContainer;

    public AllowRegistration:boolean;
    public RegisterOverride:() => void;
    public ForgotPasswordOverride:() => void;

    public static get instance():ASystemManager {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ASystemManager();
        }
        return this._instance;
    }

    private constructor() {
        super();

        this._build();
    }

    private _build():void {
        this._dialogContainer = new ADialogContainer();
        document.body.appendChild(this._dialogContainer);

        this._contextItemContainer = new AContextItemContainer();
        document.body.appendChild(this._contextItemContainer);
    }

    public showNoticeDialog(message:string = ''):ANoticeDialog {
        return this._dialogContainer.showNoticeDialog(message);
    }

    public showAlertDialog(message:string, okCallback:() => void = null):AAlertDialog {
        return this._dialogContainer.showAlertDialog(message, okCallback);
    }

    public showConfirmDialog(message:string = '', okCallback:() => void = null, cancelCallback:() => void = null):AConfirmDialog {
        return this._dialogContainer.showConfirmDialog(message, okCallback, cancelCallback);
    }

    public showPromptDialog(message:string = '', inputLabel:string = null, okCallback:(output:string) => void = null, cancelCallback:() => void = null):APromptDialog {
        return this._dialogContainer.showPromptDialog(message, inputLabel, okCallback, cancelCallback);
    }

    public showAuthenticateUsernamePasswordDialog(okCallback:(username:string, password:string) => void = null, cancelCallback:() => void = null):AAuthenticateUsernamePasswordDialog {
        return this._dialogContainer.showAuthenticateUsernamePasswordDialog(okCallback, cancelCallback);
    }

    public showAuthenticateTwoFADialog(okCallback:(twoFACode:string) => void = null, cancelCallback:() => void = null):AAuthenticateTwoFADialog {
        return this._dialogContainer.showAuthenticateTwoFADialog(okCallback, cancelCallback);
    }

    public showSetupTwoFADialog(qrData:string, okCallback:(twoFACode:string) => void = null, cancelCallback:() => void = null):ASetupTwoFADialog {
        return this._dialogContainer.showSetupTwoFADialog(qrData, okCallback, cancelCallback);
    }

    public showRegisterDialog(okCallback:(username:string, email:string, password:string) => void = null, cancelCallback:() => void = null):ARegisterDialog {
        return this._dialogContainer.showRegisterDialog(okCallback, cancelCallback);
    }

    public showForgotPasswordDialog(okCallback:(username:string) => void = null, cancelCallback:() => void = null):AForgotPasswordDialog {
        return this._dialogContainer.showForgotPasswordDialog(okCallback, cancelCallback);
    }

    public showCustomDialog(content:AComponent = null, okCallback:() => void = null, cancelCallback:() => void = null):ACustomDialog {
        
        // this._dialogContainer.backgroundOverride = backgroundOverride;
        return this._dialogContainer.showCustomDialog(content, okCallback, cancelCallback);
    }

    public dismissDialog():void {
        this._dialogContainer.dismissDialog();
    }

    public dismissAllDialogs():void {
        this._dialogContainer.dismissAllDialogs();
    }

    public showMenu(x:number, y:number, menuData:AMenuData, selectedCallback:(item:AMenuDataItem) => void = null):void {
        this._contextItemContainer.showMenu(x, y, menuData, selectedCallback);
    }

    public registerContextMenu(targetComponent:IAComponent, menuData:AMenuData, selectedCallback:(item:AMenuDataItem) => void = null):void {
        this._contextItemContainer.registerContextMenu(targetComponent, menuData, selectedCallback);
    }

    public registerContextWidget(targetComponent:IAComponent, contextWidget:AContextWidget):void {
        this._contextItemContainer.registerContextWidget(targetComponent, contextWidget);
    }

    public unregisterContextItem(targetComponent:IAComponent):void {
        this._contextItemContainer.unregisterContextItem(targetComponent);
    }

    public get isShowingDialog():boolean {
        return this._dialogContainer.isShowingDialog;
    }

    public get isShowingContextItem():boolean {
        return this._contextItemContainer.isShowingContextItem;
    }
    
}
setTimeout(():void => {
    ASystemManager.instance;
});