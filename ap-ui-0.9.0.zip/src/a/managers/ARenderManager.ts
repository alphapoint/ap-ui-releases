import { AEventDispatcher, ARenderManagerEvent } from '../events/index.js';
import { AUtil } from '../core/AUtil.js';

export class ARenderManager extends AEventDispatcher {

    private static _instance:ARenderManager;

    public static get instance():ARenderManager {
        if (this._instance === null || this._instance === undefined) {
            this._instance = new ARenderManager();
        }
        return this._instance;
    }

    private _mutationObserver:MutationObserver;

    private _renderTimeout:number = 15;
    private _renderCalls:Array<() => any> = [];
    private _renderTimestamp:number = 0;

    private _isVisible:boolean = !document.hidden;

    private _isRendering:boolean = false;

    private _pixelRatio:number = window.devicePixelRatio;

    private constructor() {
        super();

        this._registerListeners();
    }

    private _registerListeners(){

        this._onMutationObserved = this._onMutationObserved.bind(this);
        this._mutationObserver = new MutationObserver(this._onMutationObserved);
        this._mutationObserver.observe(window.document.body, {
            attributes: false,
            childList: true,
            subtree: true
        });

        this._doAnimationFrame = this._doAnimationFrame.bind(this);

        if(window){

            this._onResize = AUtil.throttle(this, () => {
                this.requestAnimationFrame(() => {
                    this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE));
                });
            }, this._renderTimeout).bind(this);
            window.addEventListener('resize', this._onResize);

            this._onResizeEnd = AUtil.debounce(this, () => {
                this.requestAnimationFrame(() => {
                    this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE_END));
                });
            }, 100, false).bind(this);
            window.addEventListener('resize', this._onResizeEnd);

        }

        if(document){
            this._onVisibilityChange = this._onVisibilityChange.bind(this);
            document.addEventListener('visibilitychange', this._onVisibilityChange);
        }

    }

    private _onMutationObserved():void {
        window.requestAnimationFrame(this._doAnimationFrame);
        this._isRendering = true;
    }

    private _onResize():void {
    }
    private _onResizeEnd():void {
    }

    private _onVisibilityChange():void {
        this._isVisible = document.visibilityState === 'visible';
        this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.VISIBILITY_CHANGE));
    }

    public invalidate():void {
        this.requestAnimationFrame(() => {
            this.dispatchEvent(new ARenderManagerEvent(ARenderManagerEvent.RESIZE_END));
        });
    }

    public requestAnimationFrame(f:() => any = null):void {
        
        //Don't do strict equality, so it will avoid coercion
        if(f != null){
            this._renderCalls.push(f);
        }

        window.requestAnimationFrame(this._doAnimationFrame);

    }

    private _doAnimationFrame(time:number):void {
        if(this._renderCalls.length > 0){
            if((window.performance.now() - this._renderTimestamp) > this._renderTimeout){
                
                this._renderTimestamp = time;

                for(let i = 0; i < this._renderCalls.length; i++){
                    (this._renderCalls[i])();
                }
                this._renderCalls = [];
                
                this._isRendering = false;
            } else {
                window.requestAnimationFrame(this._doAnimationFrame);
            }
        }
        
    }

    public get renderTimeout():number {
        return this._renderTimeout;
    }
    public set renderTimeout(t:number) {
        this._renderTimeout = t;
    }

    public get isVisible():boolean {
        return this._isVisible;
    }

    public get pixelRatio():number {
        return this._pixelRatio;
    }

}