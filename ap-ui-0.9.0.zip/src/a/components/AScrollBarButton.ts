import { AButton } from './AButton.js';

export class AScrollBarButton extends AButton {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-scroll-bar-button', AScrollBarButton);