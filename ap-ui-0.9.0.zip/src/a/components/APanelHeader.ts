import { AContainer } from './AContainer.js';

export class APanelHeader extends AContainer {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-panel-header', APanelHeader);