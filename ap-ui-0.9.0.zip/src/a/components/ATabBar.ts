import { AContainer } from './AContainer.js';
import { ATabBarEvent } from '../events/ATabBarEvent.js';
import { AButton } from './AButton.js';

export class ATabBar extends AContainer {

    private _labels: Array<string> = [];
    private _icons: Array<Array<string>> = [];

    private _selectedIndex: number = 0;

    public constructor() {
        super();
    }

    protected _build(): void {
        super._build();
    }

    protected _registerListeners(): void {
        super._registerListeners();

        this._onMouseOver = this._onMouseOver.bind(this);
        this.addEventListener('mouseover', this._onMouseOver);

        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }

    protected _render():boolean {

        if(super._render()){

            let count: number = Math.max(this._labels.length, this._icons.length);

            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                } else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }

            for (let i = 0; i < count; i++) {
                let button: AButton = (this.getChildAt(i) as AButton);

                button.setAttribute('data-index', i.toString());
                button.icon = this._icons[i];
                button.label = this._labels[i];

                if (this._selectedIndex !== null && this._selectedIndex === i) {
                    button.addClass('selected');
                } else {
                    button.removeClass('selected');
                }
            }

            return true;
        } else {
            return false;
        }

    }

    private _setSelectedIndex(index: number): void {
        if (this._selectedIndex !== index && index > -1 && index < this._labels.length) {
            this._selectedIndex = index;
        } else if (index === null) {
            this._selectedIndex = null;
        }
        this.invalidate();
    }

    private _onMouseOver(event:MouseEvent):void {
        if(event.target.constructor === AButton){
            this._onButtonHover(event.target as AButton);
        }
    }

    private _onClick(event:MouseEvent):void {
        if(event.target.constructor === AButton){
            this._onButtonClick(event.target as AButton);
        }
    }

    private _onButtonClick(button: AButton): void {
        this._setSelectedIndex(Number(button.getAttribute('data-index')));
        this.dispatchEvent(new ATabBarEvent(ATabBarEvent.SELECTED_INDEX_CHANGE));
    }

    private _onButtonHover(element: HTMLElement): void {
        this.dispatchEvent(new ATabBarEvent(ATabBarEvent.TAB_HOVER, {detail: { index: Number(element.getAttribute('data-index'))}}));
    }

    public get icons(): Array<Array<string>> {
        return this._icons;
    }
    public set icons(d: Array<Array<string>>) {
        if(this._icons !== d){
            this._icons = d || [];
            this.invalidate();
        }
    }

    public get labels(): Array<string> {
        return this._labels;
    }
    public set labels(d: Array<string>) {
        if(this._labels !== d){
            this._labels = d || [];
            this.invalidate();
        }
    }

    public get selectedIndex(): number {
        return this._selectedIndex;
    }
    public set selectedIndex(i: number) {
        this._setSelectedIndex(i);
    }

}

window.customElements.define('a-tab-bar', ATabBar);