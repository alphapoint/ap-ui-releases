import { AContainer } from './AContainer.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

import { AHeader } from './AHeader.js';
import { AButton } from './AButton.js';
import { AFooter } from './AFooter.js';
import { ASystemDialogEvent } from '../events/index.js';

export class ADialog extends AContainer {

    private _header:AHeader;
    private _headerIcon:AFontAwesomeIcon;
    private _titleText:AText;
    private _xIcon:AFontAwesomeIcon;

    protected _content:AContainer;

    private _footer:AFooter;
    
    protected _okButton:AButton;
    protected _cancelButton:AButton;

    private _okCallback:() => void;
    private _cancelCallback:() => void;

    private _backgroundOverride:string;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._okCallback = null;
        this._cancelCallback = null;
        this._backgroundOverride = null;

        this._header = new AHeader();
        this.appendChild(this._header);

        let iconTitleContainer:AContainer = new AContainer();
        iconTitleContainer.addClass('icon-title');
        this._header.appendChild(iconTitleContainer);

        this._headerIcon = new AFontAwesomeIcon();
        iconTitleContainer.appendChild(this._headerIcon);

        this._titleText = new AText();
        iconTitleContainer.appendChild(this._titleText);

        this._xIcon = new AFontAwesomeIcon();
        this._xIcon.addClass('close');
        this._xIcon.value = ['fal', 'fa-times'];
        this._xIcon.visible = false;
        this._header.appendChild(this._xIcon);


        this._content = new AContainer();
        this.appendChild(this._content);


        this._footer = new AFooter();
        this.appendChild(this._footer);

        this._okButton = new AButton();
        this._okButton.addClass('ok');
        this._okButton.label = 'OK';
        this._footer.appendChild(this._okButton);

        this._cancelButton = new AButton();
        this._cancelButton.addClass('cancel');
        this._cancelButton.label = 'Cancel';
        this._footer.appendChild(this._cancelButton);
        
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._xIcon.addEventListener('click', this._cancelClicked);

        this._okClicked = this._okClicked.bind(this);
        this._okButton.addEventListener('click', this._okClicked);

        this._cancelClicked = this._cancelClicked.bind(this);
        this._cancelButton.addEventListener('click', this._cancelClicked);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._okButton.removeEventListener('click', this._okClicked);
        this._cancelButton.removeEventListener('click', this._cancelClicked);

    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();
    }

    protected _render():boolean {
        if(super._render()){

            this._footer.visible = this._okButton.visible || this._cancelButton.visible;

            return true;
        } else {
            return false;
        }
    }

    protected _okClicked(event:MouseEvent):void {
        this.dispatchEvent(new ASystemDialogEvent(ASystemDialogEvent.OK, {
            bubbles: true,
            detail: {
                dialog: this
            }
        }));
    }
    protected _cancelClicked(event:MouseEvent):void {
        this.dispatchEvent(new ASystemDialogEvent(ASystemDialogEvent.CANCEL, {
            bubbles: true,
            detail: {
                dialog: this
            }
        }));
    }

    public forceOkayClick():void {
        if(this._okButton.enabled){
            this._okClicked(null);
        }
    }

    public get icon():Array<string> {
        return this._headerIcon.value;
    }
    public set icon(i:Array<string>) {
        if(this._headerIcon.value !== i){
            this._headerIcon.value = i;
        }
    }

    public get title():string {
        return this._titleText.text;
    }
    public set title(t:string) {
        if(this._titleText.text !== t){
            this._titleText.text = t;
        }
    }

    public get showX():boolean {
        return this._xIcon.visible;
    }
    public set showX(s:boolean) {
        this._xIcon.visible = s;
    }

    public get showOK():boolean {
        return this._okButton.visible;
    }
    public set showOK(s:boolean) {
        this._okButton.visible = s;
        this.invalidate();
    }

    public get okLabel():string {
        return this._okButton.label;
    }
    public set okLabel(l:string) {
        this._okButton.label = l;
    }

    public get okCallback():() => void {
        return this._okCallback;
    }
    public set okCallback(c:() => void) {
        this._okCallback = c;
    }

    public get showCancel():boolean {
        return this._cancelButton.visible;
    }
    public set showCancel(s:boolean) {
        this._cancelButton.visible = s;
        this.invalidate();
    }

    public get cancelLabel():string {
        return this._cancelButton.label;
    }
    public set cancelLabel(l:string) {
        this._cancelButton.label = l;
    }

    public get cancelCallback():() => void {
        return this._cancelCallback;
    }
    public set cancelCallback(c:() => void) {
        this._cancelCallback = c;
    }

    public get backgroundOverride():string {
        return this._backgroundOverride;
    }
    public set backgroundOverride(b:string) {
        this._backgroundOverride = b;
    }

}

window.customElements.define('a-dialog', ADialog);