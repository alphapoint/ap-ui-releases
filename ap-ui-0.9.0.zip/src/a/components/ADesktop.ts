import { AMenuEvent } from '../events/AMenuEvent.js';
import { AMenuData } from '../data/AMenuData.js';
import { AMenuDataItem } from '../data/AMenuDataItem.js';
import { AConfigurationEvent, AStartMenuEvent, AWindowContainerEvent, ATaskBarEvent } from '../events/index.js';
import { AStartMenu } from './AStartMenu.js';
import { ATaskBar } from './ATaskBar.js';
import { AWindowContainer } from './AWindowContainer.js';
import { AFooter } from './AFooter.js';
import { AApplication, IAPApplicationConstructor } from './AApplication.js';
import { IAComponent } from './IAComponent.js';
import { AWindow } from './AWindow.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AWindowContents } from './AWindowContents.js';
import { AMenu } from './AMenu.js';

export class ADesktop extends AApplication {

    protected _buildDesktopComplete:boolean = false;
    protected _registerDesktopListenersComplete:Boolean = false;

    private _applicationRegistry:Map<IAPApplicationConstructor, AApplication>;

    protected _windowContainer:AWindowContainer;

    protected _footer:AFooter;
    protected _startMenu:AStartMenu;
    protected _taskBar:ATaskBar;
    protected _fullscreenIcon:AFontAwesomeIcon;
    protected _tileIcon:AFontAwesomeIcon;
    
    protected _contextMenu:AMenu;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._applicationRegistry = new Map();

        this._windowContainer = new AWindowContainer();
        this.appendChild(this._windowContainer);

        this._footer = new AFooter();
        this.appendChild(this._footer);

        this._startMenu = new AStartMenu();
        this._footer.appendChild(this._startMenu);

        this._taskBar = new ATaskBar();
        this._footer.appendChild(this._taskBar);

        this._fullscreenIcon = new AFontAwesomeIcon();
        this._fullscreenIcon.draggable = false;
        this._fullscreenIcon.value = document.fullscreenElement !== null ? ['fal', 'fa-compress-wide'] : ['fal', 'fa-expand-wide'];
        this._fullscreenIcon.title = 'Fullscreen';
        this._footer.appendChild(this._fullscreenIcon);

        this._tileIcon = new AFontAwesomeIcon();
        this._tileIcon.draggable = false;
        this._tileIcon.value = ['fal', 'fa-th-large'];
        this._tileIcon.title = 'Tile Windows';
        this._footer.appendChild(this._tileIcon);

        this._contextMenu = new AMenu();
        this._contextMenu.visible = false;
        this.appendChild(this._contextMenu);

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onWindowAdded = this._onWindowAdded.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_ADDED, this._onWindowAdded);

        this._onWindowRemoved = this._onWindowRemoved.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_REMOVED, this._onWindowRemoved);

        this._onWindowFocused = this._onWindowFocused.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_FOCUSED, this._onWindowFocused);

        this._onWindowMinimized = this._onWindowMinimized.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_MINIMIZED, this._onWindowMinimized);

        this._onWindowMaximized = this._onWindowMaximized.bind(this);
        this._windowContainer.addEventListener(AWindowContainerEvent.WINDOW_MAXIMIZED, this._onWindowMaximized);

        this._onStartMenuItemClicked = this._onStartMenuItemClicked.bind(this);
        this._startMenu.addEventListener(AStartMenuEvent.ITEM_CLICKED, this._onStartMenuItemClicked);

        this._onTaskBarSelectedWindowChanged = this._onTaskBarSelectedWindowChanged.bind(this);
        this._taskBar.addEventListener(ATaskBarEvent.SELECTED_WINDOW_CHANGED, this._onTaskBarSelectedWindowChanged);

        this._onContextMenuItemClicked = this._onContextMenuItemClicked.bind(this);
        this._contextMenu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onContextMenuItemClicked);

        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);

        this._onFullscreenIconClicked = this._onFullscreenIconClicked.bind(this);
        this._fullscreenIcon.addEventListener('click', this._onFullscreenIconClicked);

        this._onTileIconClicked = this._onTileIconClicked.bind(this);
        this._tileIcon.addEventListener('click', this._onTileIconClicked);

        this._onFullscreenChange = this._onFullscreenChange.bind(this);
        document.addEventListener('fullscreenchange', this._onFullscreenChange);

        // this._onContextMenu = this._onContextMenu.bind(this);
        // window.addEventListener('contextmenu', this._onContextMenu);
    }

    protected _onConfigurationError(event:AConfigurationEvent):void {
    }

    protected _onStartMenuItemClicked(event:AStartMenuEvent):void {
        let menuData:AMenuData = event.detail.menuData;
        let menuDataItem:AMenuDataItem = event.detail.menuDataItem;

        // this.openApplication(menuDataItem.data, menuDataItem.label);
    }

    protected _onTaskBarSelectedWindowChanged(event:ATaskBarEvent):void {
        if(this._taskBar.selectedWindow.minimizable && !this._taskBar.selectedWindow.minimized && this._taskBar.selectedWindow === this._windowContainer.focusedWindow){
            this._windowContainer.minimizeWindow(this._taskBar.selectedWindow);
        } else {
            this._windowContainer.focusedWindow = this._taskBar.selectedWindow;
        }
    }

    protected _onWindowAdded(event:AWindowContainerEvent):void {
        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }

    protected _onWindowRemoved(event:AWindowContainerEvent):void {

        let application:IAPApplicationConstructor = event.detail.contentClass as IAPApplicationConstructor;
        if(this._applicationRegistry.has(application)){
            this._applicationRegistry.delete(application);
        }

        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }

    protected _onWindowFocused(event:AWindowContainerEvent):void {
        this._taskBar.windows = this._windowContainer.windows;
        this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }

    protected _onWindowMinimized(event:AWindowContainerEvent):void {
        //this._taskBar.windows = this._windowContainer.windows;
        if(this._taskBar.selectedWindow === (event.detail.window as AWindow)){
            this._taskBar.selectedWindow = null;
        }
    }

    protected _onWindowMaximized(event:AWindowContainerEvent):void {
        // this._taskBar.windows = this._windowContainer.windows;
        // this._taskBar.selectedWindow = this._windowContainer.focusedWindow;
    }

    protected _onContextMenuItemClicked(event:AMenuEvent):void {
        if(event.detail.menuDataItem.data && event.detail.menuDataItem.data.call !== undefined){
            event.detail.menuDataItem.data.call();
        }

        this.hideContextMenu();
    }

    protected _onDocumentMouseDown(event:MouseEvent):void {
        this.hideContextMenu();
    }

    protected _onFullscreenIconClicked(event:MouseEvent):void {
        this._toggleFullscreen();
    }

    protected _onTileIconClicked(event:MouseEvent):void {
        this._windowContainer.tileWindows();
    }

    private _onFullscreenChange(event:Event):void {
        this._fullscreenIcon.value = document.fullscreenElement !== null ? ['fal', 'fa-compress-wide'] : ['fal', 'fa-expand-wide'];
    }

    protected _onContextMenu(event:MouseEvent):void {
        event.preventDefault();
        event.stopPropagation();
    }


    private _toggleFullscreen():void {
        if (!window.document.fullscreenElement){
            this.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }

    public openWindow(windowContent:AWindowContents = null, title:string = ''):void {
        if(windowContent !== null){
            this._windowContainer.addWindow(windowContent, title);
        }
    }

    public openApplication(applicationClass:IAPApplicationConstructor = null, title:string = ''):AApplication {
        if(applicationClass !== null && !this._applicationRegistry.has(applicationClass)){

            let application:AApplication = new applicationClass();
            this._applicationRegistry.set(applicationClass, application);

            this.openWindow(application, title);

            return application;
        } else {
            let application:AApplication = this._applicationRegistry.get(applicationClass);
            this._windowContainer.addWindow(application);
            return application;
        }
    }

    public showContextMenu(menuData:AMenuData, x:number, y:number):void {
        
        this._contextMenu.data = menuData;
        this._contextMenu.visible = true;

        let menuX:number = Math.min(x, this.offsetWidth - this._contextMenu.offsetWidth);
        let menuY:number = Math.min(y, this.offsetWidth - this._contextMenu.offsetWidth);

        this._contextMenu.style.left = `${menuX}px`;
        this._contextMenu.style.top = `${menuY}px`;

    }

    public hideContextMenu():void {

        this._contextMenu.data = null;
        this._contextMenu.visible = false;

    }

    public hasWindowTitle(title:string):boolean {
        return this._windowContainer.hasWindowTitle(title);
    }

    public getWindowByTitle(title:string):AWindow {
        return this._windowContainer.getWindowByTitle(title);
    }

    public get focusedWindow():AWindow {
        return this._windowContainer.focusedWindow;
    }
    public set focusedWindow(win:AWindow) {
        if(win !== null){
            this._windowContainer.focusedWindow = win;
        }
    }

    public get startIcon():Array<string> {
        return this._startMenu.startIcon;
    }
    public set startIcon(i:Array<string>) {
        this._startMenu.startIcon = i;
    }

    public get startMenuData():AMenuData {
        return this._startMenu.data;
    }
    public set startMenuData(d:AMenuData) {
        this._startMenu.data = d;
    }

    public get showStartMenu():boolean {
        return this._startMenu.visible;
    }
    public set showStartMenu(s:boolean) {
        this._startMenu.visible = s;
    }

    public get showFullScreen():boolean {
        return this._fullscreenIcon.visible;
    }
    public set showFullScreen(s:boolean) {
        this._fullscreenIcon.visible = s;
    }

}

window.customElements.define('a-desktop', ADesktop);