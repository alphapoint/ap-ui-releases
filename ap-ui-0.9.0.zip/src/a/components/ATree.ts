import { ATreeNode } from './ATreeNode.js';
import { ATreeEvent } from '../events/ATreeEvent.js';
import { AComponent } from './AComponent.js';
import { AContainer } from './AContainer.js';

export class ATree extends AContainer {

    private _selectable:boolean = false;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);

        this._onDoubleClick = this._onDoubleClick.bind(this);
        this.addEventListener('dblclick', this._onDoubleClick);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('click', this._onClick);

        this.removeEventListener('dblclick', this._onDoubleClick);
    }

    protected _render():boolean {
        if(super._render()){

            return true;
        } else {
            return false;
        }
    }

    private _onClick(event:MouseEvent):void {

        let target:AComponent = event.target as AComponent;
        let treeNode:ATreeNode = (event.target as HTMLElement).closest('a-tree-node') as ATreeNode;

        if(treeNode){

            if(target.hasClass('open-close')){

                if(!treeNode.isOpen){

                    treeNode.isOpen = true;

                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_OPENED, { bubbles: true, detail: { treeNode: treeNode } }));

                } else {

                    treeNode.isOpen = false;

                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLOSED, { bubbles: true, detail: { treeNode: treeNode } }));

                }

            } else if(target.hasClass('action-text')){

                this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_ACTION, { bubbles: true, detail: { treeNode: treeNode } }));

            } else if(!target.hasClass('child-nodes')) {

                this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLICKED, { bubbles: true, detail: { treeNode: treeNode } }));

                if(this._selectable){
                    // this._selectedTreeData = node.data;
                    this.invalidate();
                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_SELECTED, { bubbles: true, detail: { treeNode: treeNode } }));
                }

            }
        }
    }

    private _onDoubleClick(event:MouseEvent):void {

        let target:AComponent = event.target as AComponent;
        let treeNode:ATreeNode = target.closest('a-tree-node') as ATreeNode;

        if(treeNode){

            if(!target.hasClass('open-close') && !target.hasClass('action-text') && !target.hasClass('child-nodes')){

                // node.isOpen = !node.isOpen;
                if(!treeNode.hasChildTreeNodes){

                    this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_DOUBLE_CLICKED, { bubbles: true, detail: { treeNode: treeNode } }));
                    
                } else {

                    if(!treeNode.isOpen){

                        treeNode.isOpen = true;

                        this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_OPENED, { bubbles: true, detail: { treeNode: treeNode } }));

                    } else {

                        treeNode.isOpen = false;

                        this.dispatchEvent(new ATreeEvent(ATreeEvent.NODE_CLOSED, { bubbles: true, detail: { treeNode: treeNode } }));

                    }
                }

            }
        }

    }


    public addChildTreeNode(treeNode:ATreeNode):void {
        this.appendChild(treeNode);
    }

    public removeChildTreeNode(treeNode:ATreeNode):void {
        this.removeChild(treeNode);
    }

    public getTreeNodeByID(id:string):ATreeNode {
        let treeNode:ATreeNode = this.querySelector(`a-tree-node[data-id='${id}']`);

        return treeNode || null;
    }

    public get selectable():boolean {
        return this._selectable;
    }
    public set selectable(s:boolean) {
        if(this._selectable !== s){
            this._selectable = s;
            this.invalidate();
        }
    }

    public get hasChildTreeNodes():boolean {
        return this.childElementCount > 0;
    }

    // public get selectedTreeData():ATreeData {
    //     return this._selectedTreeData;
    // }
    // public set selectedTreeData(treeData:ATreeData) {
    //     if(this._selectedTreeData !== treeData){
    //         this._selectedTreeData = treeData;
    //         this.invalidate();
    //     }
    // }

}

window.customElements.define('a-tree', ATree);