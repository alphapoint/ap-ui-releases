import { AContainer } from './AContainer.js';

export class AFooter extends AContainer {

    public constructor(){
        super();
    }

}

window.customElements.define('a-footer', AFooter);