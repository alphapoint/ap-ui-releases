import { ARectangle } from '../geometry/ARectangle.js';

export interface IAComponentConstructor {

    new ():IAComponent;

}

export interface IAComponent extends HTMLElement {

    appendChild<T extends Node>(child:T):T;

    appendChildAt(index:number, child:HTMLElement):void;

    removeChild<T extends Node>(child:T):T;

    removeChildAt(index:number):void;

    removeAllChildren():void;

    invalidate(invalidateChildren?:boolean):void;

    doLater(task:Function):void;

    destroy():void;

    hasChild(child:Node):boolean;

    getChildAt(index:number):Node;

    addClass(className:string):void;

    addClasses(...classNames:Array<string>):void;

    removeClass(className:string):void;

    removeClasses(...classNames:Array<string>):void;

    hasClass(className:string):boolean;

    visible:boolean;

    enabled:boolean;

    hasFocus:boolean;

}