import { AContainer } from './AContainer.js';
import { AComponent } from './AComponent.js';
import { ATabViewEvent, ATabBarEvent } from '../events/index.js';
import { ADataGrid } from './ADataGrid.js';
import { ATabBar } from './ATabBar.js';

export class ATabView extends AContainer {

    private _tabBar:ATabBar;
    private _content:AContainer;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._tabBar = new ATabBar();
        this._tabBar.selectedIndex = 0;
        this.appendChild(this._tabBar);

        this._content = new AContainer();
        this.appendChild(this._content);
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onButtonBarChange = this._onButtonBarChange.bind(this);
        this._tabBar.addEventListener(ATabBarEvent.SELECTED_INDEX_CHANGE, this._onButtonBarChange);
    }

    protected _render():boolean {
        if(super._render()){

            if(this._tabBar.labels.length === 1){
                this._tabBar.visible = false;
            }

            for (var i = 0; i < this._content.childNodes.length; i++) {

                let child:AComponent = (this._content.childNodes[i] as AComponent);

                if(this._tabBar.selectedIndex === i){
                    child.removeClass('invisible');
                    child.invalidate();
                } else {
                    child.addClass('invisible');
                }
            }

            return true;
        } else {
            return false;
        }
    }

    private _onButtonBarChange(event:ATabBarEvent):void {
        this.invalidate();
        
        // this.doLater(() => {
            // this.querySelectorAll('a-data-grid').forEach((dataGrid:ADataGrid) => {
            //     dataGrid.invalidate();
            // });
        // });

        this.dispatchEvent(new ATabViewEvent(ATabViewEvent.SELECTED_INDEX_CHANGE));
    }

    public get icons():Array<Array<string>> {
        return this._tabBar.icons;
    }
    public set icons(i:Array<Array<string>>) {
        this._tabBar.icons = i;
    }

    public get labels():Array<string> {
        return this._tabBar.labels;
    }
    public set labels(l:Array<string>) {
        this._tabBar.labels = l;
    }

    public get selectedIndex():number {
        return this._tabBar.selectedIndex;
    }
    public set selectedIndex(i:number) {
        if(this._tabBar.selectedIndex !== i){
            this._tabBar.selectedIndex = i;
            this.invalidate();
        }
    }

    public get content():AContainer {
        return this._content;
    }

}

window.customElements.define('a-tab-view', ATabView);