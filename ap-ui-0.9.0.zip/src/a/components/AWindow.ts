import { AContainer } from './AContainer.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

import { AWindowEvent } from '../events/AWindowEvent.js';
import { AWindowResizeTargets } from './AWindowResizeTargets.js';
import { AWindowHeader } from './AWindowHeader.js';
import { ADataGrid } from './ADataGrid.js';
import { AMenuBar } from './AMenuBar.js';
import { AMenuData } from '../data/index.js';
import { AWindowContents } from './AWindowContents.js';
import { AMenuEvent } from '../events/index.js';
import { ARectangle } from '../geometry/index.js';

export class AWindow extends AContainer {

    private _header:AWindowHeader;
    private _menuBar:AMenuBar;
    private _icon:AFontAwesomeIcon;
    private _title:AText;
    private _minimize:AFontAwesomeIcon;
    private _maximize:AFontAwesomeIcon;
    private _close:AFontAwesomeIcon;
    private _content:AWindowContents;

    private _isDragging:boolean = false;
    private _isResizing:boolean = false;
    private _resizeDirection:string = '';
    private _isMaximized:boolean = false;
    private _isMinimized:boolean = false;
    private _isFocused:boolean = false;

    private _isDraggable:boolean = true;
    private _isResizable:boolean = true;
    private _isMaximizable:boolean = true;
    private _isMinimizable:boolean = true;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this.appendChild(new AWindowResizeTargets());

        this._header = new AWindowHeader();
        this.appendChild(this._header);

        this._menuBar = new AMenuBar();
        this._menuBar.visible = false;
        this._header.appendChild(this._menuBar);

        let iconTitleContainer:AContainer = new AContainer();
        iconTitleContainer.addClass('icon-title');
        this._header.appendChild(iconTitleContainer);

        this._icon = new AFontAwesomeIcon();
        iconTitleContainer.appendChild(this._icon);

        this._title = new AText();
        iconTitleContainer.appendChild(this._title);


        let windowControlsContainer:AContainer = new AContainer();
        windowControlsContainer.addClass('window-controls');
        this._header.appendChild(windowControlsContainer);

        this._minimize = new AFontAwesomeIcon();
        this._minimize.addClass('minimize');
        this._minimize.value = ['fal', 'fa-window-minimize'];
        windowControlsContainer.appendChild(this._minimize);

        this._maximize = new AFontAwesomeIcon();
        this._maximize.addClass('maximize');
        this._maximize.value = ['fal', 'fa-window-maximize'];
        windowControlsContainer.appendChild(this._maximize);

        this._close = new AFontAwesomeIcon();
        this._close.addClass('close');
        this._close.value = ['fal', 'fa-times'];
        windowControlsContainer.appendChild(this._close);

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onMouseDown = this._onMouseDown.bind(this);
        this.addEventListener('mousedown', this._onMouseDown);

        this._onMouseUp = this._onMouseUp.bind(this);
        document.addEventListener('mouseup', this._onMouseUp);

        this._onHeaderMouseDown = this._onHeaderMouseDown.bind(this);
        this._header.addEventListener('mousedown', this._onHeaderMouseDown);

        this._onHeaderDoubleClick = this._onHeaderDoubleClick.bind(this);
        this._header.addEventListener('dblclick', this._onHeaderDoubleClick);

        this._onMinimizeMouseDown = this._onMinimizeMouseDown.bind(this);
        this._minimize.addEventListener('mousedown', this._onMinimizeMouseDown);

        this._onMinimizeClicked = this._onMinimizeClicked.bind(this);
        this._minimize.addEventListener('click', this._onMinimizeClicked);

        this._onMaximizeMouseDown = this._onMaximizeMouseDown.bind(this);
        this._maximize.addEventListener('mousedown', this._onMaximizeMouseDown);

        this._onMaximizeClicked = this._onMaximizeClicked.bind(this);
        this._maximize.addEventListener('click', this._onMaximizeClicked);

        this._onCloseMouseDown = this._onCloseMouseDown.bind(this);
        this._close.addEventListener('mousedown', this._onCloseMouseDown);

        this._onCloseClicked = this._onCloseClicked.bind(this);
        this._close.addEventListener('click', this._onCloseClicked);

        this._onTransitionEnd = this._onTransitionEnd.bind(this);
        this.addEventListener('transitionend', this._onTransitionEnd);

        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('mousedown', this._onMouseDown);
        
        document.removeEventListener('mouseup', this._onMouseUp);

        this._header.removeEventListener('mousedown', this._onHeaderMouseDown);

        this._header.removeEventListener('dblclick', this._onHeaderDoubleClick);

        this._minimize.removeEventListener('mousedown', this._onMinimizeMouseDown);

        this._minimize.removeEventListener('click', this._onMinimizeClicked);

        this._maximize.removeEventListener('mousedown', this._onMaximizeMouseDown);

        this._maximize.removeEventListener('click', this._onMaximizeClicked);

        this._close.removeEventListener('mousedown', this._onCloseMouseDown);

        this._close.removeEventListener('click', this._onCloseClicked);

        this.removeEventListener('transitionend', this._onTransitionEnd);

        this.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

    }

    protected _render():boolean {
        if(super._render()){

            this._maximize.value = this._isMaximized ? ['fal', 'fa-window-restore'] : ['fal', 'fa-window-maximize'];
            
            if(this._content){
                if(this._content.icon){
                    this._icon.value = this._content.icon;
                }
                this._content.invalidate();
            }

            return true;
        } else {
            return false;
        }
    }

    private _onHeaderMouseDown(event:MouseEvent):void {
        if(this._isDraggable && !this._isMaximized){
            this._isDragging = true;
            this.addClass('dragging');

            this.dispatchEvent(new AWindowEvent(AWindowEvent.DRAG_START, {detail: {pageX: event.pageX, pageY: event.pageY, clientX: event.clientX, clientY: event.clientY}}));
        }
    }

    private _onHeaderDoubleClick(event:MouseEvent):void {
        this.dispatchEvent(new AWindowEvent(AWindowEvent.HEADER_DOUBLE_CLICKED));
    }

    private _onMinimizeMouseDown(event:MouseEvent):void {
        event.stopPropagation();
    }

    private _onMinimizeClicked(event:MouseEvent):void {
        event.stopPropagation();
        
        this.dispatchEvent(new AWindowEvent(AWindowEvent.MINIMIZE_CLICKED));
    }

    private _onMaximizeMouseDown(event:MouseEvent):void {
        event.stopPropagation();
    }

    private _onMaximizeClicked(event:MouseEvent):void {
        event.stopPropagation();
        
        this.dispatchEvent(new AWindowEvent(AWindowEvent.MAXIMIZE_CLICKED));
    }

    private _onCloseMouseDown(event:MouseEvent):void {
        event.stopPropagation();
    }

    private _onCloseClicked(event:MouseEvent):void {
        event.stopPropagation();
        
        this.dispatchEvent(new AWindowEvent(AWindowEvent.CLOSE_CLICKED));
    }
    
    private _onResizerMouseDown(event:MouseEvent, dir:string):void {
        if(this._isResizable && !this._isMaximized){
            this._isResizing = true;
            this._resizeDirection = dir;
            this.addClass('resizing');

            this.dispatchEvent(new AWindowEvent(AWindowEvent.RESIZE_START, {detail: {pageX: event.pageX, pageY: event.pageY, clientX: event.clientX, clientY: event.clientY}}));
        }
    }

    private _onMouseDown(event:MouseEvent):void {
        let element:HTMLElement = (event.target as HTMLElement);

        if(element.nodeName === 'B'){
            this._onResizerMouseDown(event, element.getAttribute('data-direction'));
        }
    }

    private _onMouseUp(event:MouseEvent):void {
        if(this._isDraggable && this._isDragging){
            this.dispatchEvent(new AWindowEvent(AWindowEvent.DRAG_END));

            this._isDragging = false;
        } else if(this._isResizable && this._isResizing){
            this.dispatchEvent(new AWindowEvent(AWindowEvent.RESIZE_END));

            this._isResizing = false;
        }

        this.removeClasses('dragging', 'resizing');
    }

    private _onTransitionEnd(event:TransitionEvent):void {
        this.doLater(() => {
            for(let grid of this.getElementsByTagName('a-data-grid')){
                (grid as ADataGrid).invalidate();
            }
        });
    }

    private _onMenuItemClicked(event:AMenuEvent):void {
        if(this.content && this.content.handleMenuItemClick){
            this.content.handleMenuItemClick(event);
        }
    }

    get icon():Array<string> {
        return this._content.icon || [];
    }

    public get menuData():Array<AMenuData> {
        return this._menuBar.data;
    }
    public set menuData(m:Array<AMenuData>){
        if(m !== null){
            this._menuBar.data = m;
            this._menuBar.visible = true;
        } else {
            this._menuBar.visible = false;
        }
    }

    get title():string {
        return this._title.text;
    }
    set title(t:string) {
        if(this._title){
            if(this._title.text !== t){
                this._title.text = t;
            }
        }
    }

    get content():AWindowContents {
        return this._content;
    }
    set content(component:AWindowContents) {

        if(this._content !== component && !this.hasChild(component)){

            if(this._content !== null && this.hasChild(this._content)){
                this.removeChild(this._content);
                // this._application.window = null;
            }

            this._content = component;
            this._content.window = this;
            this.menuData = this._content.menuData;

            this.appendChild(this._content);

        }

    }

    get isDragging():boolean {
        return this._isDragging;
    }
    get isResizing():boolean {
        return this._isResizing;
    }
    get resizeDirection():string {
        return this._resizeDirection;
    }

    get draggable():boolean {
        return this._isDraggable;
    }
    set draggable(d:boolean) {
        if(this._isDraggable !== d){
            this._isDraggable = d;

            if(d){
                this.removeClass('non-draggable');
            } else {
                this.addClass('non-draggable');
            }
        }
    }

    get resizable():boolean {
        return this._isResizable;
    }
    set resizable(r:boolean) {
        if(this._isResizable !== r){
            this._isResizable = r;

            if(r){
                this.removeClass('non-resizeable');
            } else {
                this.addClass('non-resizeable');
            }
        }
    }

    get minimizable():boolean {
        return this._isMinimizable;
    }
    set minimizable(m:boolean) {
        if(this._isMinimizable !== m){
            this._isMinimizable = m;

            if(m){
                this.removeClass('non-minimizable');
            } else {
                this.addClass('non-minimizable');
            }

            if(!m){
                this.removeClass('minimized');
            }
        }
    }

    get minimized():boolean {
        return this._isMinimized;
    }
    set minimized(m:boolean) {
        if(this._isMinimized !== m){
            this._isMinimized = m;

            if(m){
                this.addClass('minimized');
            } else {
                this.removeClass('minimized');
            }

            this.invalidate();
        }
    }

    get maximizable():boolean {
        return this._isMaximizable;
    }
    set maximizable(m:boolean) {
        if(this._isMaximizable !== m){
            this._isMaximizable = m;

            if(m){
                this.removeClass('non-maximizable');
            } else {
                this.addClass('non-maximizable');
            }

            if(!m){
                this.removeClass('maximized');
            }
        }
    }

    get maximized():boolean {
        return this._isMaximized;
    }
    set maximized(m:boolean) {
        if(this._isMaximized !== m){
            this._isMaximized = m;

            if(m){
                this.addClass('maximized');
            } else {
                this.removeClass('maximized');
            }

            this.invalidate();
        }
    }

    public get focused():boolean {
        return this._isFocused;
    }
    public set focused(f:boolean) {
        //if(this._isFocused !== f){
            if(f){
                this.addClass('focused');
            } else {
                this.removeClass('focused');
            }
        //}
    }

    public get dimensions():ARectangle {
        let r:ARectangle = new ARectangle();

        r.x = this.offsetLeft;// * ARenderManager.instance.pixelRatio;
        r.y = this.offsetTop;// * ARenderManager.instance.pixelRatio;
        r.width = this.offsetWidth;// * ARenderManager.instance.pixelRatio;
        r.height = this.offsetHeight;// * ARenderManager.instance.pixelRatio;
        
        return r;
    }

}

window.customElements.define('a-window', AWindow);