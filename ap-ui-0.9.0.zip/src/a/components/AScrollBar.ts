import { AComponent } from './AComponent.js';
import { AScrollBarButton } from './AScrollBarButton.js';
import { AScrollBarTrack } from './AScrollBarTrack.js';
import { AScrollBarHandle } from './AScrollBarHandle.js';
import { AScrollbarEvent } from '../events/AScrollbarEvent.js';

export class AScrollBar extends AComponent {

    public static VERTICAL:symbol = Symbol('vertical');
    public static HORIZONTAL:symbol = Symbol('horizontal');

    private _upIcon:Array<string>;
    private _downIcon:Array<string>;
    private _leftIcon:Array<string>;
    private _rightIcon:Array<string>;

    private _upLeftButton:AScrollBarButton;
    private _downRightButton:AScrollBarButton;

    private _scrollTrack:AScrollBarTrack;
    private _scrollTrackWidth:number;
    private _scrollTrackHeight:number;

    private _scrollHandle:AScrollBarHandle;
    private _scrollHandleWidth:number;
    private _scrollHandleHeight:number;
    private _isScrollHandleDown:boolean;
    private _scrollHandlePointerOffset:number;

    private _orientation:symbol;

    private _contentRatio:number;
    private _scrollAmount:number;
    private _scrollIncrement:number;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._upIcon = ['fas', 'fa-caret-up'];
        this._downIcon = ['fas', 'fa-caret-down'];
        this._leftIcon = ['fas', 'fa-caret-left'];
        this._rightIcon = ['fas', 'fa-caret-right'];

        this._upLeftButton = new AScrollBarButton();
        this._upLeftButton.addClasses('up-left');
        this.appendChild(this._upLeftButton);


        this._scrollTrack = new AScrollBarTrack();
        this.appendChild(this._scrollTrack);

        this._scrollHandle = new AScrollBarHandle();
        this._scrollTrack.appendChild(this._scrollHandle);


        this._downRightButton = new AScrollBarButton();
        this._downRightButton.addClasses('down-right');
        this.appendChild(this._downRightButton);
        
        this._scrollTrackWidth = 1;
        this._scrollTrackHeight = 1;

        this._scrollHandleWidth = 1;
        this._scrollHandleHeight = 1;
        this._isScrollHandleDown = false;

        this.orientation = AScrollBar.VERTICAL;
        this._contentRatio = .25;
        this._scrollAmount = 0;
        this._scrollIncrement = .01;

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onUpLeftClicked = this._onUpLeftClicked.bind(this);
        this._upLeftButton.addEventListener('click', this._onUpLeftClicked);

        this._onDownRightClicked = this._onDownRightClicked.bind(this);
        this._downRightButton.addEventListener('click', this._onDownRightClicked);

        this._onTrackClicked = this._onTrackClicked.bind(this);
        this._scrollTrack.addEventListener('click', this._onTrackClicked);

        this._onHandleDown = this._onHandleDown.bind(this);
        this._scrollHandle.addEventListener('mousedown', this._onHandleDown);

        this._onHandleUp = this._onHandleUp.bind(this);
        document.addEventListener('mouseup', this._onHandleUp);

        this._onHandleMove = this._onHandleMove.bind(this);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._upLeftButton.removeEventListener('click', this._onUpLeftClicked);

        this._downRightButton.removeEventListener('click', this._onDownRightClicked);

        this._scrollTrack.removeEventListener('click', this._onTrackClicked);

        this._scrollHandle.removeEventListener('mousedown', this._onHandleDown);

        document.removeEventListener('mouseup', this._onHandleUp);

        document.removeEventListener('mousemove', this._onHandleMove);
    }

    protected _render():boolean {
        if(super._render()){

            let track:AScrollBarTrack = this._scrollTrack;
            let handle:AScrollBarHandle = this._scrollHandle;
            let handleStyle:CSSStyleDeclaration = handle.style;

            if(this._orientation === AScrollBar.VERTICAL){

                let trackHeight:number = track.offsetHeight;
                let handleHeight:number = trackHeight * this._contentRatio;

                handleStyle.height = `${handleHeight}px`;
                handleStyle.top = `${(trackHeight - handleHeight) * this._scrollAmount}px`;
                handleStyle.left = '0px';

            } else if(this._orientation === AScrollBar.HORIZONTAL){

                let trackWidth:number = track.offsetWidth;
                let handleWidth:number = trackWidth * this._contentRatio;

                handleStyle.width = `${handleWidth}px`;
                handleStyle.left = `${(trackWidth - handleWidth) * this._scrollAmount}px`;
                handleStyle.top = '0px';

            }

            return true;
        } else {
            return false;
        }
    }

    private _onUpLeftClicked():void {

        let scrollAmount:number = this._scrollAmount - this._scrollIncrement;

        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);

        if(this._scrollAmount !== scrollAmount){

            this._scrollAmount = scrollAmount;

            this.invalidate();

            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));

        }

    }

    private _onDownRightClicked():void {

        let scrollAmount:number = this._scrollAmount + this._scrollIncrement;

        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);

        if(this._scrollAmount !== scrollAmount){

            this._scrollAmount = scrollAmount;

            this.invalidate();

            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));

        }

    }

    private _onTrackClicked(event:MouseEvent):void {
        event.stopPropagation();
        event.stopImmediatePropagation();
    }

    private _onHandleDown(event:MouseEvent):void {

        event.stopPropagation();
        event.stopImmediatePropagation();

        this._scrollTrackWidth = this._scrollTrack.offsetWidth;
        this._scrollTrackHeight = this._scrollTrack.offsetHeight;

        this._scrollHandleWidth = this._scrollHandle.offsetWidth;
        this._scrollHandleHeight = this._scrollHandle.offsetHeight;

        this._isScrollHandleDown = true;

        if(this._orientation === AScrollBar.VERTICAL){
            this._scrollHandlePointerOffset = event.clientY - this._scrollHandle.offsetTop;
        } else if(this._orientation === AScrollBar.HORIZONTAL) {
            this._scrollHandlePointerOffset = event.clientX - this._scrollHandle.offsetLeft;
        }

        document.addEventListener('mousemove', this._onHandleMove);

    }

    private _onHandleMove(event:MouseEvent):void {

        let scrollAmount:number = 0;

        if(this._orientation === AScrollBar.VERTICAL){

            let top:number = event.clientY - this._scrollHandlePointerOffset;
            let height:number = this._scrollTrackHeight - this._scrollHandleHeight;

            scrollAmount = top / height;

        } else if(this._orientation === AScrollBar.HORIZONTAL) {

            let left:number = event.clientX - this._scrollHandlePointerOffset;
            let width:number = this._scrollTrackWidth - this._scrollHandleWidth;

            scrollAmount = left / width;

        }

        //Snap to nearest increment
        //scrollAmount = (Math.round((scrollAmount * 1000) / (this._scrollIncrement * 1000)) * (this._scrollIncrement * 1000)) / 1000;

        //Clamp between 0 - 1
        scrollAmount = Math.max(Math.min(scrollAmount, 1), 0);

        if(this._scrollAmount !== scrollAmount){

            this._scrollAmount = scrollAmount;

            this.invalidate();

            this.dispatchEvent(new AScrollbarEvent(AScrollbarEvent.SCROLL));

        }
    }

    private _onHandleUp(event:MouseEvent):void {
        if(this._isScrollHandleDown){
            this._isScrollHandleDown = false;

            document.removeEventListener('mousemove', this._onHandleMove);
        }
    }

    public get orientation():symbol {
        return this._orientation;
    }
    public set orientation(orientation:symbol) {
        if(this._orientation !== orientation && (orientation === AScrollBar.VERTICAL || orientation === AScrollBar.HORIZONTAL)){
            this._orientation = orientation;

            if(this._orientation === AScrollBar.VERTICAL){

                this.removeClass('horizontal');
                this.addClass('vertical');

                this._upLeftButton.removeClasses(...this._leftIcon);
                this._upLeftButton.addClasses(...this._upIcon);
                this._downRightButton.removeClasses(...this._rightIcon);
                this._downRightButton.addClasses(...this._downIcon);

            } else if(this._orientation === AScrollBar.HORIZONTAL){

                this.removeClass('vertical');
                this.addClass('horizontal');

                this._upLeftButton.removeClasses(...this._upIcon);
                this._upLeftButton.addClasses(...this._leftIcon);
                this._downRightButton.removeClasses(...this._downIcon);
                this._downRightButton.addClasses(...this._rightIcon);

            }

            this.invalidate();
        }
    }

    public get contentRatio():number {
        return this._contentRatio;
    }
    public set contentRatio(r:number) {
        r = Math.max(Math.min(r, 1), 0);
        if(this._contentRatio !== r){
            this._contentRatio = r;
            this.invalidate();
        }
    }

    public get scrollIncrement():number {
        return this._scrollIncrement;
    }
    public set scrollIncrement(i:number) {
        i = Math.max(Math.min(i, 1), 0);
        if(this._scrollIncrement !== i){
            this._scrollIncrement = i;
        }
    }

    public get scrollAmount():number {
        return this._scrollAmount;
    }
    public set scrollAmount(a:number) {
        a = Math.max(Math.min(a, 1), 0);
        if(this._scrollAmount !== a){
            this._scrollAmount = a;
            this.invalidate();
        }
    }

}

window.customElements.define('a-scroll-bar', AScrollBar);