import { AButton } from './AButton.js';

export class AScrollBarHandle extends AButton {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-scroll-bar-handle', AScrollBarHandle);