import { AContainer } from './AContainer.js';
import { AButtonBarEvent } from '../events/AButtonBarEvent.js';
import { AButton } from './AButton.js';

export class AButtonBar extends AContainer {

    private _labels: Array<string> = [];
    private _icons: Array<Array<string>> = [];

    private _selectable:boolean;
    private _selectedIndex: number;

    public constructor() {
        super();
    }

    protected _build(): void {
        super._build();

        this._selectable = true;
        this._selectedIndex = null;
    }

    protected _registerListeners(): void {
        super._registerListeners();

        this._onMouseOver = this._onMouseOver.bind(this);
        this.addEventListener('mouseover', this._onMouseOver);

        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }

    protected _unregisterListeners(): void {
        super._unregisterListeners();

        this.removeEventListener('mouseover', this._onMouseOver);

        this.removeEventListener('click', this._onClick);
    }

    protected _render():boolean {

        if(super._render()){

            let count: number = Math.max(this._labels.length, this._icons.length);

            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                } else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }

            for (let i = 0; i < count; i++) {
                let button: AButton = (this.getChildAt(i) as AButton);

                button.setAttribute('data-index', i.toString());
                button.icon = this._icons[i];
                button.label = this._labels[i];

                if (this._selectable && this._selectedIndex !== null && i > -1 && i < this._labels.length && this._selectedIndex === i) {
                    button.addClass('selected');
                } else {
                    button.removeClass('selected');
                }
            }

            return true;
        } else {
            return false;
        }

    }

    private _setSelectedIndex(index: number): void {
        if(this._selectedIndex !== index){
            if (this._selectable){// && index > -1 && index < this._labels.length) {
                this._selectedIndex = index;
            } else {
                this._selectedIndex = null;
            }
        }
        this.invalidate();
    }

    private _onMouseOver(event:MouseEvent):void {
        if(event.target.constructor === AButton){
            this._onButtonHover(event.target as AButton);
        }
    }

    private _onClick(event:MouseEvent):void {
        if(event.target.constructor === AButton){
            this._onButtonClick(event.target as AButton);
        }
    }

    private _onButtonClick(button: AButton): void {
        this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.BUTTON_CLICK, { detail: { index: Number(button.getAttribute('data-index')) } }));
        if(this._selectable){
            this._setSelectedIndex(Number(this._selectable ? button.getAttribute('data-index') : null));
            this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.SELECTED_INDEX_CHANGE));
        }
    }

    private _onButtonHover(element: HTMLElement): void {
        this.dispatchEvent(new AButtonBarEvent(AButtonBarEvent.BUTTON_HOVER, {detail: { index: Number(element.getAttribute('data-index'))}}));
    }

    public get icons(): Array<Array<string>> {
        return this._icons;
    }
    public set icons(d: Array<Array<string>>) {
        if(this._icons !== d){
            this._icons = d || [];
            this.invalidate();
        }
    }

    public get labels(): Array<string> {
        return this._labels;
    }
    public set labels(d: Array<string>) {
        if(this._labels !== d){
            this._labels = d || [];
            this.invalidate();
        }
    }

    public get selectable(): boolean {
        return this._selectable;
    }
    public set selectable(s: boolean) {
        if(this._selectable !== s){
            this._selectable = s;
            this.invalidate();
        }
    }

    public get selectedIndex(): number {
        return this._selectedIndex !== null && this._selectedIndex > -1 && this._selectedIndex < this._labels.length ? this._selectedIndex : null;
    }
    public set selectedIndex(i: number) {
        this._setSelectedIndex(i);
    }

}

window.customElements.define('a-button-bar', AButtonBar);