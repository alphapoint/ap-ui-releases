import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AText } from './AText.js';
import { AImage } from './AImage.js';

export class AButton extends AComponent {

    private _image:AImage;
    private _icon:AFontAwesomeIcon;
    private _label:AText;

    private _iconValue:Array<string>;
    private _imageValue:string;
    private _labelText:string;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._iconValue = null;
        this._imageValue = null;
        this._labelText = null;

        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);

        this._image = new AImage();
        this.appendChild(this._image);

        this._label = new AText();
        this.appendChild(this._label);

        this._iconValue = null;
        this._labelText = null;

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._imageError = this._imageError.bind(this);
        this._image.addEventListener('error', this._imageError);

        this._imageLoad = this._imageLoad.bind(this);
        this._image.addEventListener('load', this._imageLoad);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._image.removeEventListener('error', this._imageError);
    }

    protected _render():boolean {

        if(super._render()){

            if(this._iconValue !== null){
                this._icon.value = this._iconValue;
                this._icon.visible = true;
            } else {
                this._icon.visible = false;
            }
    
            if(this._imageValue !== null){
                this._image.visible = true;
            } else {
                this._image.visible = false;
            }
    
            if(this._labelText !== null){
                this._label.text = this._labelText;
                this._label.visible = true;
            } else {
                this._label.visible = false;
            }

            return true;

        } else {
            return false
        }

    }


    private _imageError(event:Event):void {
        this._imageValue = null;
        this.invalidate();
    }
    private _imageLoad(event:Event):void {
        this.invalidate();
    }

    public get icon():Array<string> {
        return this._iconValue;
    }
    public set icon(i:Array<string>) {
        if(this._iconValue !== i){

            if(i === undefined){
                i = null;
            }

            this._iconValue = i;

            this.invalidate();
        }
    }

    public get image():string {
        return this._imageValue;
    }
    public set image(i:string) {
        if(this._imageValue !== i){

            if(i === undefined){
                i = null;
            }

            this._imageValue = i;
            this._image.src = i;
        }
    }

    public get label(){
        return this._labelText;
    }
    public set label(l:string){
        if(this._labelText != l){
            this._labelText = l;

            this.invalidate();
        }
    }

}

window.customElements.define('a-button', AButton);