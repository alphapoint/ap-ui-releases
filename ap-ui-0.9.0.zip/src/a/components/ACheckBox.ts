import { AComponent } from './AComponent.js';
import { AText } from './AText.js';

export class ACheckBox extends AComponent {

    private _checkbox:HTMLInputElement;
    private _label:AText;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._checkbox = document.createElement('input');
        this._checkbox.setAttribute('is', 'a-checkbox-input');
        this._checkbox.setAttribute('type', 'checkbox');
        this.appendChild(this._checkbox);

        this._label = new AText();
        this.appendChild(this._label);
    }

    public get type():string {
        return this.getAttribute('type');
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onClicked = this._onClicked.bind(this);
        this.addEventListener('click', this._onClicked);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('click', this._onClicked);
    }

    protected _render():boolean {
        if(super._render()){

            

            return true;
        } else {
            return false;
        }
    }

    private _onClicked(event:MouseEvent):void {
        if(event.target !== this._checkbox){
            this.checked = !this.checked;
        }
    }

    public get checked():boolean {
        return this._checkbox.checked;
    }
    public set checked(c:boolean) {
        this._checkbox.checked = c;
    }

    public get label():string {
        return this._label.text;
    }
    public set label(l:string) {
        this._label.text = l;        
    }
}

window.customElements.define('a-checkbox', ACheckBox);