import { ARectangle } from '../geometry/ARectangle.js';
import { AComponent } from './AComponent.js';
import { AContainer } from './AContainer.js';
import { APanel } from './APanel.js';
import { APanelEvent } from '../events/APanelEvent.js';

export class APanelContainer extends AContainer {

    private _ghost:AComponent;

    private _transformingPanel:APanel = null;
    private _transformingPanelStartDimensions:ARectangle = null;

    private _pointerDragStartX:number = 0;
    private _pointerDragStartY:number = 0;
    private _pointerDragDistanceX:number = 0;
    private _pointerDragDistanceY:number = 0;

    private _snapDistance:number;
    private _width:number;
    private _height:number;
    private _snapRects:Array<ARectangle>;

    private _zIndex: number = 100;
    private _arePanelsLocked:boolean = true;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();
        
        this._ghost = new AComponent();
        this._ghost.addClass('ghost');
        this._ghost.visible = false;
        this.appendChild(this._ghost);

        this.invalidateLayout();
    }

    protected _onMouseMove(event:MouseEvent):void {
        if(this._transformingPanel !== null){
            this._pointerDragDistanceX = Math.round(event.pageX - this._pointerDragStartX);
            this._pointerDragDistanceY = Math.round(event.pageY - this._pointerDragStartY);

            this._transformPanel();
        }
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onMouseMove = this._onMouseMove.bind(this);

        //Throttle this
        // this._onRenderManagerResize = this._onRenderManagerResize.bind(this);
        // APRenderManager.instance.addEventListener(APRenderManagerEvent.RESIZE, this._onRenderManagerResize);
    }

    private _registerPanelListeners(panel:APanel):void {

        this._onPanelTransformEnd = this._onPanelTransformEnd.bind(this);

        this._onPanelClick = this._onPanelClick.bind(this);
        panel.addEventListener('click', this._onPanelClick);

        this._onPanelDragStart = this._onPanelDragStart.bind(this);
        this._onPanelDragEnd = this._onPanelDragEnd.bind(this);
        panel.addEventListener(APanelEvent.DRAG_START, this._onPanelDragStart);
        panel.addEventListener(APanelEvent.DRAG_END, this._onPanelDragEnd);

        this._onPanelResizeStart = this._onPanelResizeStart.bind(this);
        this._onPanelResizeEnd = this._onPanelResizeEnd.bind(this);
        panel.addEventListener(APanelEvent.RESIZE_START, this._onPanelResizeStart);
        panel.addEventListener(APanelEvent.RESIZE_END, this._onPanelResizeEnd);

    }

    private _unregisterPanelListeners(panel:APanel):void {
        panel.removeEventListener('click', this._onPanelClick);

        panel.removeEventListener(APanelEvent.DRAG_START, this._onPanelDragStart);
        panel.removeEventListener(APanelEvent.DRAG_END, this._onPanelDragEnd);

        panel.removeEventListener(APanelEvent.RESIZE_START, this._onPanelResizeStart);
        panel.removeEventListener(APanelEvent.RESIZE_END, this._onPanelResizeEnd);
    }

    public destroy():void {
        super.destroy();

        this._transformingPanel = null;
        this._transformingPanelStartDimensions = null;
    }

    private _onPanelClick(event:MouseEvent):void {

        var panel:APanel = (event.target as AComponent).closest('a-panel') as APanel;

        if(panel !== null){
            panel.style.zIndex = (this._zIndex++).toString();
        }
    }

    private _onPanelDragStart(event:APanelEvent):void {
        this._onPanelTransformStart(event);
    }

    private _onPanelDragEnd(event:APanelEvent):void {
        this._onPanelTransformEnd(event);
    }

    private _onPanelResizeStart(event:APanelEvent):void {
        this._onPanelTransformStart(event);
    }

    private _onPanelResizeEnd(event:APanelEvent):void {
        this._onPanelTransformEnd(event);
    }

    private _onPanelTransformStart(event:APanelEvent):void {

        window.addEventListener('mousemove', this._onMouseMove);

        let panel:APanel = event.target as APanel;

        this._pointerDragStartX = event.detail.pageX;
        this._pointerDragStartY = event.detail.pageY;
        this._pointerDragDistanceX = 0;
        this._pointerDragDistanceY = 0;

        this._width = this.offsetWidth;
        this._height = this.offsetHeight;
        this._snapRects = [new ARectangle(0, 0, this._width, this._height)];
        this.childNodes.forEach((node:ChildNode):void => {
            if(APanel.prototype.isPrototypeOf(node) && node !== event.target){
                let panel:APanel = node as APanel;
                this._snapRects.push(new ARectangle(panel.offsetLeft, panel.offsetTop, panel.offsetWidth, panel.offsetHeight));
            }
        });

        this._snapDistance = parseInt(getComputedStyle(this).getPropertyValue('--panel-container-snap-distance').trim() || '12px');

        this._transformingPanel = panel;
        this._transformingPanelStartDimensions = panel.dimensions;

        this._ghost.style.zIndex = (this._zIndex++).toString();
        this._ghost.visible = true;

        panel.addClass('transforming');
        panel.style.zIndex = (this._zIndex++).toString();

        this._transformPanel();
    }

    private _onPanelTransformEnd(event:APanelEvent):void {

        window.removeEventListener('mousemove', this._onMouseMove);

        let panel:APanel = event.target as APanel;

        if(this._transformingPanel === panel){

            this._transformingPanel.removeClasses('transforming', 'maximized');

            let ghostRect:ARectangle = new ARectangle(this._ghost.offsetLeft, this._ghost.offsetTop, this._ghost.offsetWidth, this._ghost.offsetHeight);
            
            panel.removeAttribute('style');

            panel.style.setProperty('--top', `${((ghostRect.top / this._height) * 100).toFixed(2)}%`);
            panel.style.setProperty('--right', `${((1 - (ghostRect.right / this._width)) * 100).toFixed(2)}%`);
            panel.style.setProperty('--bottom', `${((1 - (ghostRect.bottom / this._height)) * 100).toFixed(2)}%`);
            panel.style.setProperty('--left', `${((ghostRect.left / this._width) * 100).toFixed(2)}%`);
            panel.style.zIndex = (this._zIndex++).toString();

            this._ghost.visible = false;
            this._ghost.removeAttribute('style');

            this._transformingPanel = null;
            this._transformingPanelStartDimensions = null;

            this.invalidateLayout();

        }

    }

    private _transformPanel():void {

        let panel:APanel = this._transformingPanel;

        let panelX:number = this._transformingPanelStartDimensions.x;
        let panelY:number = this._transformingPanelStartDimensions.y;
        let panelXOffset:number = 0;
        let panelYOffset:number = 0;
        let panelWidth:number = this._transformingPanelStartDimensions.width;
        let panelHeight:number = this._transformingPanelStartDimensions.height;
        let panelWidthOffset:number = 0;
        let panelHeightOffset:number = 0;

        if(panel.isDragging){

            panelXOffset = this._pointerDragDistanceX;
            panelYOffset = this._pointerDragDistanceY;

        } else if(panel.isResizing){

            let dir:string = panel.resizeDirection;

            if(dir.indexOf('n') > -1){
                panelYOffset = this._pointerDragDistanceY;
                panelHeightOffset = -this._pointerDragDistanceY;
            }
            if(dir.indexOf('s') > -1){
                panelHeightOffset = this._pointerDragDistanceY;
            }
            if(dir.indexOf('w') > -1){
                panelXOffset = this._pointerDragDistanceX;
                panelWidthOffset = -this._pointerDragDistanceX;
            }
            if(dir.indexOf('e') > -1){
                panelWidthOffset = this._pointerDragDistanceX;
            }

        }

        let newPanelWidth = panelWidth + panelWidthOffset;
        let newPanelHeight = panelHeight + panelHeightOffset;
        let newPanelX = panelX + panelXOffset;
        let newPanelY = panelY + panelYOffset;

        let startX = Math.min(Math.max(newPanelX, 0), this._width - newPanelWidth);
        let endX = startX + newPanelWidth;
        let startY = Math.min(Math.max(newPanelY, 0), this._height - newPanelHeight);
        let endY = startY + newPanelHeight;

        this._snapRects.forEach((rect:ARectangle, index:number):void => {
            //Index 0 is always the grid container
            if(index === 0){
                if(startX < this._snapDistance){
                    startX = rect.x;
                    if(panel.isDragging){
                        endX = startX + newPanelWidth;
                    }
                }
                if(rect.right - endX < this._snapDistance){
                    endX = rect.right;
                    if(panel.isDragging){
                        startX = endX - newPanelWidth;
                    }
                }
                if(startY < this._snapDistance){
                    startY = rect.y;
                    if(panel.isDragging){
                        endY = startY + newPanelHeight;
                    }
                }
                if(rect.bottom - endY < this._snapDistance){
                    endY = rect.bottom;
                    if(panel.isDragging){
                        startY = endY - newPanelHeight;
                    }
                }
            } else {
                if(Math.max(startX, rect.right) - Math.min(startX, rect.right) < this._snapDistance){
                    if(panel.isDragging){
                        endX = rect.right + newPanelWidth;
                    }
                    startX = rect.right;
                }
                if(Math.max(rect.x, endX) - Math.min(rect.x, endX) < this._snapDistance){
                    endX = rect.x;
                    if(panel.isDragging){
                        startX = endX - newPanelWidth;
                    }
                }
                if(Math.max(startY, rect.bottom) - Math.min(startY, rect.bottom) < this._snapDistance){
                    if(panel.isDragging){
                        endY = rect.bottom + newPanelHeight;
                    }
                    startY = rect.bottom;
                }
                if(Math.max(rect.y, endY) - Math.min(rect.y, endY) < this._snapDistance){
                    endY = rect.y;
                    if(panel.isDragging){
                        startY = endY - newPanelHeight;
                    }
                }
            }

        });

        panel.style.top = `${newPanelY}px`;
        panel.style.right = `calc(100% - ${newPanelX + newPanelWidth}px)`;
        panel.style.bottom = `calc(100% - ${newPanelY + newPanelHeight}px)`;
        panel.style.left = `${newPanelX}px`;


        this._ghost.style.top = `${((startY / this._height) * 100).toFixed(2)}%`;
        this._ghost.style.right = `${((1 - (endX / this._width)) * 100).toFixed(2)}%`;
        this._ghost.style.bottom = `${((1 - (endY / this._height)) * 100).toFixed(2)}%`;
        this._ghost.style.left = `${((startX / this._width) * 100).toFixed(2)}%`;
        
    }

    public addPanel(panel:APanel):void {
        panel.resizable = panel.maximizable = panel.draggable = !this._arePanelsLocked;
        panel.panelGrid = this;
        this.appendChild(panel);

        this._registerPanelListeners(panel);
    }

    public removePanel(panel:APanel):void {
        super.removeChild(panel);

        panel.panelGrid = null;

        this._unregisterPanelListeners(panel);
    }

    public removeAllPanels():void {
        for (let i = 0; i < this.childElementCount; i++) {
            let panel:APanel = (this.getChildAt(i) as APanel);
            this.removePanel(panel);
        }
    }

    public invalidateLayout():void {
        this.doLater(() => {

            for (let i = 0; i < this.childElementCount; i++) {

                let panel:APanel = (this.getChildAt(i) as APanel);

                panel.style.removeProperty('top');
                panel.style.removeProperty('right');
                panel.style.removeProperty('bottom');
                panel.style.removeProperty('left');

                let s:CSSStyleDeclaration = window.getComputedStyle(panel);

                panel.style.top = s.getPropertyValue('--top');
                panel.style.right = s.getPropertyValue('--right');
                panel.style.bottom = s.getPropertyValue('--bottom');
                panel.style.left = s.getPropertyValue('--left');

                panel.invalidate(true);
            }
        });
    }

    public invalidatePanels():void {
        for (let i = 0; i < this.childElementCount; i++) {
            let panel:APanel = (this.getChildAt(i) as APanel);

            panel.resizable = panel.maximizable = panel.draggable = !this._arePanelsLocked;
            panel.invalidate(true);
        }
    }

    public getNextZIndex():number {
        this._zIndex++
        return this._zIndex;
    }

    public get arePanelsLocked():boolean {
        return this._arePanelsLocked;
    }
    public set arePanelsLocked(l:boolean){
        if(this._arePanelsLocked !== l){
            this._arePanelsLocked = l;

            this.invalidatePanels();
        }
    }

}

window.customElements.define('a-panel-container', APanelContainer);