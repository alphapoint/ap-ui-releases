import { IAComponent } from './IAComponent.js';

export interface IADataGridRow extends IAComponent {

    index:number;

    order:number;

    data:any;

    selected:boolean;

}

export interface IADataGridRowConstructor {

    new ():IADataGridRow;

}