import { AComponent } from './AComponent.js';

export class ADataGridRowItem extends AComponent {

    public constructor(){
        super();
    }

}

window.customElements.define('a-data-grid-row-item', ADataGridRowItem);