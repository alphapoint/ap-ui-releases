import { AContainer } from './AContainer.js';
import { AMenu } from './AMenu.js';
import { AMenuEvent } from '../events/AMenuEvent.js';
import { AMenuData } from '../data/AMenuData.js';
import { AMenuDataItem } from '../data/AMenuDataItem.js';
import { AButton } from './AButton.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AMenuButtonEvent } from '../events/index.js';

export class AMenuButton extends AContainer {

    private _menuButton:AButton;
    private _data:AMenuData;
    private _menu:AMenu;

    private _selectable:boolean;
    private _defaultText:string;
    private _selectedMenuDataItem:AMenuDataItem;

    private _closeTimer:number;
    private _closeTimeout:number;

    public constructor(){
        super();

        this._defaultText = 'Select...';
    }

    protected _build():void {
        super._build();

        this._menuButton = new AButton();

        let menuButtonDownIcon:AFontAwesomeIcon = new AFontAwesomeIcon();
        menuButtonDownIcon.addClass('down');
        menuButtonDownIcon.value = ['fal', 'fa-angle-down'];

        this._menuButton.appendChild(menuButtonDownIcon);

        this.appendChild(this._menuButton);


        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);

        this._selectable = true;
        this._selectedMenuDataItem = null;

        this._data = null;
        this._closeTimer = null;
        this._closeTimeout = 1000;
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onMenuButtonClicked = this._onMenuButtonClicked.bind(this);
        this._menuButton.addEventListener('click', this._onMenuButtonClicked);

        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);

        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);

        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._menuButton.removeEventListener('click', this._onMenuButtonClicked);

        this.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

        document.removeEventListener('mousedown', this._onDocumentMouseDown);

        this.removeEventListener('mouseleave', this._onMouseLeave);

        this.removeEventListener('mouseenter', this._onMouseEnter);   
    }
    
    protected _render():boolean {
        if(super._render()){

            // let labels:Array<string> = this._data.map((item:AMenuData) => item.label);
            // let icons:Array<Array<string>> = this._data.map((item:AMenuData) => item.icon);

            if(this._selectable){
                this.removeClass('unselectable');
            } else {
                this.addClass('unselectable');
            }

            if(this._data !== null && this._selectedMenuDataItem !== null){
                this._menuButton.icon = this._selectedMenuDataItem.icon;
                this._menuButton.label = this._selectedMenuDataItem.label;
            } else if(this._data !== null){
                this._menuButton.icon = null;
                this._menuButton.label = this._defaultText;
            } else {
                this._menuButton.icon = null;
                this._menuButton.label = '';
            }

            return true;
        }
        
        return false;
    }

    private _onMouseLeave(event:MouseEvent):void {
        if(this._menu.visible){
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }

    private _onMouseEnter(event:MouseEvent):void {
        if(this._menu.visible){
            window.clearTimeout(this._closeTimer);
        }
    }

    private _openMenu():void {
        //window.requestAnimationFrame(() => {

            this._menu.data = this._data;
            this._menu.style.left = this._menuButton.offsetLeft + 'px';
            this._menu.visible = true;

        //});
    }

    private _closeMenu():void {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
    }

    private _onMenuButtonClicked(event:MouseEvent):void {
        if(this._selectable){
            if(!this._menu.visible){
                this._openMenu();
            } else {
                this._closeMenu();
            }
        }
    }

    private _onMenuItemClicked(event:AMenuEvent):void {
        this._closeMenu();
        if(this._selectedMenuDataItem !== event.detail.menuDataItem){
            this._selectedMenuDataItem = event.detail.menuDataItem;
            this.dispatchEvent(new AMenuButtonEvent(AMenuButtonEvent.ITEM_SELECTED, { bubbles: true, detail: { menuDataItem: event.detail.menuDataItem}}));
            this.invalidate();
        }
    }

    private _onDocumentMouseDown(event:MouseEvent):void {
        this._closeMenu();
    }

    public get selectable():boolean {
        return this._selectable;
    }
    public set selectable(s:boolean){
        if(this._selectable !== s){
            this._selectable = s;
            this.invalidate();
        }
    }

    public get data():AMenuData {
        return this._data;
    }
    public set data(data:AMenuData){
        if(this._data !== data){
            this._data = data || null;
            this._selectedMenuDataItem = null;
            this.invalidate();
        }
    }

    public get defaultText():string {
        return this._defaultText;
    }
    public set defaultText(d:string) {
        if(this._defaultText !== d){
            this._defaultText = d;
            this.invalidate();
        }
    }

    public get selectedItem():AMenuDataItem {
        return this._selectedMenuDataItem;
    }
    public set selectedItem(i:AMenuDataItem){
        if(this._selectedMenuDataItem !== i){
            this._selectedMenuDataItem = i || null;
            this.invalidate();
        }
    }

}

window.customElements.define('a-menu-button', AMenuButton);