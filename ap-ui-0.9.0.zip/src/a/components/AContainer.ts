import { AComponent } from './AComponent.js';

export class AContainer extends AComponent {

    constructor() {
        super();
    }

}

window.customElements.define('a-container', AContainer);