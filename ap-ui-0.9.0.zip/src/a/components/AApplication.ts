import { AContainer } from './AContainer.js';
import { AWindowContents } from './AWindowContents.js';

export interface IAPApplicationConstructor {

    new ():AApplication;

}

export class AApplication extends AWindowContents {

    public constructor(){
        super();
    }

}

window.customElements.define('a-application', AApplication);