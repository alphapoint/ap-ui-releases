import { IADataGridRow } from './IADataGridRow.js';
import { AComponent } from './AComponent.js';
import { ADataGridRowItem } from './ADataGridRowItem.js';

export class ADataGridRow extends AComponent implements IADataGridRow {

    protected _index:number = null;
    protected _order:number = null;
    protected _data:Array<any> = null;
    protected _selected:boolean = false;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._updateRowItem = this._updateRowItem.bind(this);
    }

    protected _render():boolean {
        if(super._render()){
    
            if(this._data !== null){

                while(this.childElementCount !== this._data.length){
                    
                    if(this.childElementCount < this._data.length){
    
                        let item:ADataGridRowItem = new ADataGridRowItem();
                        this.appendChild(item);
    
                    } else if(this.childElementCount > this._data.length) {
    
                        this.removeChildAt(this.childElementCount - 1);
    
                    }
    
                }
    
                this._data.forEach(this._updateRowItem);
    
            }

            return true;
        } else {
            return false;
        }
    }

    private _updateRowItem(itemData:any, index:number):void {
    
            itemData = String(itemData);

            let rowItem:ADataGridRowItem = this.getChildAt(index) as ADataGridRowItem;

            if(rowItem !== null){
                if(rowItem.innerHTML !== itemData){
                    rowItem.innerHTML = itemData;
                    rowItem.title = itemData;
                }
            }
    }

    public get index():number {
        return this._index;
    }
    public set index(i:number) {
        if(this._index !== i){
            this._index = i;
        }
    }

    public get order():number {
        return this._order;
    }
    public set order(o:number) {
        if(this._order !== o){
            this._order = o;
            this.style.order = o.toString();
        }
    }
    
    public get data():Array<any> {
        return this._data;
    }
    public set data(d:Array<any>){
        // console.log(d);
        if(this._data !== d){
            
            this._data = d || [];

            this.invalidate();

        }
    }

    public get selected():boolean {
        return this._selected;
    }
    public set selected(s:boolean) {
        if(this._selected !== s){
            this._selected = s;

            if(s){
                this.addClass('selected');
            } else {
                this.removeClass('selected');
            }
        }
    }

}

window.customElements.define('a-data-grid-row', ADataGridRow);