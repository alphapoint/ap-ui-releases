import { AScrollbarEvent } from '../events/index.js';
import { ADataGridEvent } from '../events/ADataGridEvent.js';
import { AContainer } from './AContainer.js';
import { ADataGridRowsContainer } from './ADataGridRowsContainer.js';
import { ADataGridHeader } from './ADataGridHeader.js';
import { AScrollBar } from './AScrollBar.js';
import { ADataGridRow } from './ADataGridRow.js';
import { IADataGridRow, IADataGridRowConstructor } from './IADataGridRow.js';
import { ATextInput } from './ATextInput';
import { ADataGridHeaderItem } from './ADataGridHeaderItem.js';
import { AComponent } from './AComponent.js';

export enum ADataGridSortDirection {
    NONE = 'NONE',
    ASCENDING = 'ASCENDING',
    DESCENDING = 'DESCENDING'
}

export class ADataGrid extends AContainer {

    private _resizeObserver:ResizeObserver;

    protected _data:Array<Array<any>>;
    protected _filteredSortedData:Array<Array<any>>;

    protected _selectable:boolean = true;
    protected _selectedIndex:number = null;

    protected _header:ADataGridHeader;
    protected _rowLabel:ADataGridHeader;
    protected _rowContainer:ADataGridRowsContainer;
    protected _verticalScrollbar:AScrollBar;
    protected _verticallyScrollable:boolean;
    protected _verticalScrollAmount:number;
    protected _horizontalScrollbar:AScrollBar;
    protected _horizontallyScrollable:boolean;
    protected _horizontalScrollAmount:number;

    protected _rowRenderer:IADataGridRowConstructor = ADataGridRow;

    protected _isTouching:boolean;
    protected _touchStartY:number;
    protected _touchStartScrollOffset:number;

    protected _viewHeight:number;
    protected _visibleRows:number;
    protected _rowCount:number;
    protected _visibleRowsHeight:number;
    protected _allRowsHeight:number;
    protected _additionalScrollingRows:number;
    protected _rowHeight:number;
    protected _dataScrollOffset:number;
    protected _rowsDraggable:boolean;

    protected _inverted:boolean;
    protected _sortable:boolean;
    protected _sortDirection:ADataGridSortDirection;
    protected _sortColumnIndex:number;
    protected _filterTextInput:ATextInput;
    protected _filterText:string;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._data = [];
        this._filteredSortedData = [];

        this._header = new ADataGridHeader();
        this.appendChild(this._header);

        this._rowContainer = new ADataGridRowsContainer();
        this.appendChild(this._rowContainer);

        this._verticalScrollbar = new AScrollBar();
        this._verticalScrollbar.orientation = AScrollBar.VERTICAL;
        this.appendChild(this._verticalScrollbar);
        this._verticallyScrollable = true;
        this._verticalScrollAmount = 0;

        this._horizontalScrollbar = new AScrollBar();
        this._horizontalScrollbar.orientation = AScrollBar.HORIZONTAL;
        this.appendChild(this._horizontalScrollbar);
        this._horizontallyScrollable = false;
        this._horizontalScrollAmount = 0;

        this._filterTextInput = null;

        this._viewHeight = 0;
        this._rowCount = 0;
        this._visibleRows = 0;
        this._allRowsHeight = 0;
        this._visibleRowsHeight = 0;
        this._additionalScrollingRows = 4;
        this._rowHeight = 0;
        this._dataScrollOffset = 0;

        this._inverted = false;
        this._sortable = false;
        this._sortDirection = ADataGridSortDirection.NONE;
        this._sortColumnIndex = -1;
        this._filterText = null;

        this._rowsDraggable = false;

        this.addClass('hide-horizontal-scrollbar');
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onResizeObserved = this._onResizeObserved.bind(this);
        this._resizeObserver = new ResizeObserver(this._onResizeObserved);
        this._resizeObserver.observe(this, {
            box: 'border-box'
        });

        this._onMouseWheel = this._onMouseWheel.bind(this);
        this.addEventListener('mousewheel', this._onMouseWheel);

        this._onVerticalScroll = this._onVerticalScroll.bind(this);
        this._verticalScrollbar.addEventListener(AScrollbarEvent.SCROLL, this._onVerticalScroll);

        this._onHorizontalScroll = this._onHorizontalScroll.bind(this);
        this._horizontalScrollbar.addEventListener(AScrollbarEvent.SCROLL, this._onHorizontalScroll);

        this._onHeaderClick = this._onHeaderClick.bind(this);
        this._header.addEventListener('click', this._onHeaderClick);

        this._onRowContainerClick = this._onRowContainerClick.bind(this);
        this._rowContainer.addEventListener('click', this._onRowContainerClick);

        this._onRowContainerDoubleClick = this._onRowContainerDoubleClick.bind(this);
        this._rowContainer.addEventListener('dblclick', this._onRowContainerDoubleClick);

        this._onFilterTextInputChange = this._onFilterTextInputChange.bind(this);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._resizeObserver.unobserve(this);
        this._resizeObserver.disconnect();

        this.removeEventListener('mousewheel', this._onMouseWheel);

        this._verticalScrollbar.removeEventListener(AScrollbarEvent.SCROLL, this._onVerticalScroll);

        this._horizontalScrollbar.removeEventListener(AScrollbarEvent.SCROLL, this._onHorizontalScroll);

        this._header.removeEventListener('click', this._onHeaderClick);

        this._rowContainer.removeEventListener('click', this._onRowContainerClick);

        this._rowContainer.removeEventListener('dblclick', this._onRowContainerDoubleClick);

        if(this._filterTextInput !== null){
            this._filterTextInput.removeEventListener('input', this._onFilterTextInputChange);
        }
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._rowHeight = parseFloat(getComputedStyle(this).getPropertyValue('--row-height')) * parseFloat(getComputedStyle(document.documentElement).fontSize);
    }

    protected _render():boolean {

        if(super._render()){

            if(this._header.columnLabels.length > 0){
                this.removeClass('hide-header');

                if(this._sortable){
                    let headerLen:number = this._header.childNodes.length;
                    for(let i = 0; i < headerLen; i++){
                        let headerItem:ADataGridHeaderItem = this._header.getChildAt(i) as ADataGridHeaderItem;
                        if(this._sortColumnIndex === i){
                            headerItem.sortDirection = this._sortDirection;
                        } else {
                            headerItem.sortDirection = ADataGridSortDirection.NONE;
                        }
                    }
                }
                
            } else {
                this.addClass('hide-header');
            }
    
            let dataLength:number = this._filteredSortedData.length;

            this._viewHeight = Math.max(this._rowContainer.offsetHeight, 1);
            this._visibleRows = Math.ceil(this._viewHeight / this._rowHeight);
            this._rowCount = this._visibleRows;
            this._allRowsHeight = dataLength * this._rowHeight;
            this._visibleRowsHeight = this._visibleRows * this._rowHeight;

            let willVerticalScroll:boolean = false;

            if(this._verticallyScrollable && this._allRowsHeight > this._viewHeight){
            // if(dataLength > this._visibleRows){
                this._rowCount = this._visibleRows + Math.max(Math.min(this._additionalScrollingRows, dataLength - this._visibleRows), 1);
                willVerticalScroll = true;
            } else {
                this._verticalScrollAmount = 0;
            }

            let verticalScrollAmount:number = this.verticalScrollAmount;
            let additionalRows:number = this._rowCount - this._visibleRows;
            let additionalRowsHeight:number = additionalRows * this._rowHeight;



            //Add remove rows as needed
            while(this._rowContainer.childElementCount !== this._rowCount){
                
                if(this._rowContainer.childElementCount < this._rowCount){
    
                    this._addRow();
    
                } else if(this._rowContainer.childElementCount > this._rowCount) {
    
                    this._removeRow();
    
                }
    
            }

            let dataScrollOffset:number = 0;
            let scrollMargin:number = 0;

            if(willVerticalScroll){

                let scrollOffset:number = (verticalScrollAmount * (this._allRowsHeight - this._viewHeight)) / additionalRowsHeight;

                dataScrollOffset = Math.floor(scrollOffset) * additionalRows;

                scrollMargin = (scrollOffset > 1 ? scrollOffset % 1 : scrollOffset) * additionalRowsHeight;

                if(scrollMargin > additionalRowsHeight){
                    scrollMargin = scrollMargin - additionalRowsHeight;
                }

            }

            this._dataScrollOffset = dataScrollOffset;

            for (let i = 0; i < this._rowContainer.childElementCount; i++) {

                let row:ADataGridRow = this._rowContainer.getChildAt(i) as ADataGridRow;

                let dataIndex:number = this._dataScrollOffset + i;

                // console.log(dataIndex, this._data.length, this._data[dataIndex]);

                // console.log('Setting data on row', this._data[dataIndex], row);

                row.data = this._filteredSortedData[dataIndex];
                row.index = i;
                row.selected = dataIndex === this._selectedIndex;
                row.draggable = this._rowsDraggable;

                row.style.transform = `translateY(${willVerticalScroll ? -scrollMargin : 0}px)`;

            }
    
            // Vertical scroll stuff
            if(this._verticallyScrollable && willVerticalScroll){

                this._verticalScrollbar.scrollIncrement = this._rowHeight / (this._allRowsHeight - this._viewHeight);
                this._verticalScrollbar.scrollAmount = this._verticalScrollAmount;
                this._verticalScrollbar.contentRatio = this._viewHeight / this._allRowsHeight;
                
                this.removeClass('hide-vertical-scrollbar');
            } else {
                this.addClass('hide-vertical-scrollbar');
            }


            // Horizontal scroll stuff
            if(this._horizontallyScrollable && (this._header.scrollWidth > this.offsetWidth || this._rowContainer.scrollWidth > this.offsetWidth)){

                let scrollWidth:number = Math.max(this._header.scrollWidth, this._rowContainer.scrollWidth);
                let visibleWidth:number = Math.max(this._header.offsetWidth, this._rowContainer.offsetWidth);
                let totalHorizontalScroll:number = scrollWidth - visibleWidth;

                this._horizontalScrollbar.scrollIncrement = 1 / (scrollWidth - visibleWidth);
                this._horizontalScrollbar.scrollAmount = this._horizontalScrollAmount;
                this._horizontalScrollbar.contentRatio = visibleWidth / scrollWidth;
                this._header.scrollLeft = this._horizontalScrollbar.scrollAmount * totalHorizontalScroll;
                this._rowContainer.scrollLeft = this._horizontalScrollbar.scrollAmount * totalHorizontalScroll;

                this.removeClass('hide-horizontal-scrollbar');
            } else {
                this.addClass('hide-horizontal-scrollbar');
            }


            return true;
        } else {
            return false;
        }
    }

    private _addRow():IADataGridRow {

        let row:IADataGridRow = new this._rowRenderer();
        
        row.index = this._rowContainer.childElementCount;

        this._rowContainer.appendChild(row);

        return row;

    }

    private _removeRow():void {

        let index:number = this._rowContainer.childElementCount - 1;

        let row:IADataGridRow = this._rowContainer.getChildAt(index) as IADataGridRow;

        this._rowContainer.removeChildAt(index);

        row.destroy();

    }

    
    private _setSort(columnIndex:number = null):void {
        if(columnIndex === -1){
            this._sortColumnIndex = -1;
            this._sortDirection = ADataGridSortDirection.NONE;
        } else if(this._sortColumnIndex !== columnIndex){
            this._sortColumnIndex = columnIndex;
            this._sortDirection = ADataGridSortDirection.DESCENDING;
        } else {
            if(this._sortDirection === ADataGridSortDirection.DESCENDING){
                this._sortDirection = ADataGridSortDirection.ASCENDING;
            } else if(this._sortDirection === ADataGridSortDirection.ASCENDING){
                this._sortColumnIndex = -1;
                this._sortDirection = ADataGridSortDirection.NONE;
            } else if(this._sortDirection === ADataGridSortDirection.NONE){
                this._sortDirection = ADataGridSortDirection.DESCENDING;
            }
        }

        this._filterAndSortData();
    }

    private _setFilterText(filterText:string = null):void {
        this._filterText = filterText;
        this._filterAndSortData();
    }

    private _filterAndSortData():void {

        // console.log(this._sortColumnIndex, this._sortDirection, this._filterText);
        
        if(((!this._sortable || this._sortColumnIndex === -1) && this._filterText === null) || this._data.length === 0){
            if(this._filteredSortedData !== this._data){
                this._filteredSortedData = this._data;
            }
        } else {

            let output:Array<any> = JSON.parse(JSON.stringify(this._data));

            if(this._filterText !== null){
                output = output.filter((rowData:Array<any>):boolean => {
                    return String(rowData).toLowerCase().includes(this._filterText);
                });
            }

            if(this._sortColumnIndex !== null && this._sortDirection !== ADataGridSortDirection.NONE){

                output.sort((one:Array<any>, two:Array<any>):number => {

                    let oneRaw:number | string = one[this._sortColumnIndex];
                    let itemOne:number | string = oneRaw.constructor === String ? String(oneRaw).toLowerCase() : Number(oneRaw);
                    let twoRaw:number | string = two[this._sortColumnIndex];
                    let itemTwo:number | string = twoRaw.constructor === String ? String(twoRaw).toLowerCase() : Number(twoRaw);

                    // console.log(itemOne, itemTwo);

                    if (itemOne < itemTwo) {
                        return this._sortDirection === ADataGridSortDirection.DESCENDING ? -1 : 1;
                    } else if (itemOne > itemTwo) {
                        return this._sortDirection === ADataGridSortDirection.DESCENDING ? 1 : -1;
                    } else {
                        return 0;
                    }

                });

            }

            // console.log(output);

            this._filteredSortedData = output;
        }

        if(this._filteredSortedData.length === 0){
            this._selectedIndex = null;
        }
    }

    private _onResizeObserved(entries: ReadonlyArray<ResizeObserverEntry>, observer: ResizeObserver):void {
        for (let i = 0; i < entries.length; i++) {
            if(entries[i].target === this){
                this.invalidate();
                return;
            }
        }
    }

    private _onVerticalScroll(event:AScrollbarEvent):void {
        this.verticalScrollAmount = (event.target as AScrollBar).scrollAmount;
    }

    private _onHorizontalScroll(event:AScrollbarEvent):void {
        this.horizontalScrollAmount = (event.target as AScrollBar).scrollAmount;
    }

    private _onMouseWheel(event:WheelEvent):void {
        event.preventDefault();

        if(event.deltaY > 0){

            this.verticalScrollAmount = this._verticalScrollbar.scrollAmount + this._verticalScrollbar.scrollIncrement;

        } else if(event.deltaY < 0) {

            this.verticalScrollAmount = this._verticalScrollbar.scrollAmount - this._verticalScrollbar.scrollIncrement;

        }
    }

    private _onHeaderClick(event:MouseEvent):void {

        if(this._sortable){

            let columnIndex:number = -1;

            let headerItem:ADataGridHeaderItem = (event.target as AComponent).closest('a-data-grid-header-item');
            if(headerItem.constructor === ADataGridHeaderItem){

                let len:number = this._header.childNodes.length;
                for(let i = 0; i < len; i++){
                    if(this._header.getChildAt(i) === headerItem){
                        columnIndex = i;
                        break;
                    }
                }

            }

            this._setSort(columnIndex);

        }

    }

    private _onRowContainerClick(event:MouseEvent):void {

        let path:Array<EventTarget> = event.composedPath();

        for(let i = 0; i < path.length; i++){
            if(this._rowRenderer.prototype.isPrototypeOf(path[i])){
                this._onRowClick(event.target as HTMLElement, path[i] as IADataGridRow);
                break;
            }
        }

    }

    private _onRowContainerDoubleClick(event:MouseEvent):void {

        let path:Array<EventTarget> = event.composedPath();

        for(let i = 0; i < path.length; i++){
            if(this._rowRenderer.prototype.isPrototypeOf(path[i])){
                this._onRowDoubleClick(event.target as HTMLElement, path[i] as IADataGridRow);
                break;
            }
        }
        
    }

    private _onRowClick(src:HTMLElement, row:IADataGridRow):void {

        if(row.index >= 0 && row.index < this._rowContainer.childElementCount){

            let newDataIndex = this._dataScrollOffset + row.index;

            src.dispatchEvent(new ADataGridEvent(ADataGridEvent.ROW_CLICK, { bubbles: true, detail: { index: newDataIndex } }));

            if(this._selectable){

                let oldDataIndex = this._selectedIndex;

                if(oldDataIndex !== newDataIndex){
                    this._selectedIndex = newDataIndex;
                    this.invalidate();
                    this.dispatchEvent(new ADataGridEvent(ADataGridEvent.SELECTED_INDEX_CHANGED));
                }
            }
        }

    }

    private _onRowDoubleClick(src:HTMLElement, row:IADataGridRow):void {

        //Update to above
        // if(row.index >= 0 && row.index < this._rowContainer.childElementCount){
        //     this.dispatchEvent(new ADataGridEvent(ADataGridEvent.ROW_DOUBLE_CLICK, { detail: { index: row.index, data: row.data } }));
        // }

    }

    private _onFilterTextInputChange(event:InputEvent):void {
        let t:string = (event.target as ATextInput).value.trim();
        this._setFilterText(t.length > 0 ? t.toLowerCase() : null);
    }

    public getRowAt(index:number):IADataGridRow {
        return this._rowContainer.getChildAt(index) as IADataGridRow;
    }

    public getItemAt(index:number):Array<any> {
        if(index >= 0 && index < this._data.length){
            return this._data[index];
        } else {
            return null;
        }
    }

    public addItem(item:Array<any>):void {
        this.addItemAt(this._data.length, item);
    }

    public addItemAt(index:number, item:Array<any>):void {

        if(index >= 0 && index <= this._data.length){

            this._data.splice(index, 0, item);

            this._filterAndSortData();

            this.invalidate();

        }

    }

    public removeItemAt(index:number):void {

        if(index >= 0 && index < this._data.length){
            this._data.splice(index, 1);

            this._filterAndSortData();
            
            this.invalidate();
        }

    }

    public removeAllItems():void {
        this._data = [];

        this._filterAndSortData();

        this.invalidate();
    }

    public setItems(data:Array<Array<any>>):void {
        this._data = data || [];

        this._filterAndSortData();

        this.invalidate();
    }

    public setItemAt(index:number, item:Array<any>):void {
        
        if(index >= 0 && index <= this._data.length){

            this._data[index] = item;
            
            if(index >= this._dataScrollOffset && index <= this._dataScrollOffset + this._rowCount){
                
                let row:IADataGridRow = (this._rowContainer.getChildAt(index - this._dataScrollOffset) as IADataGridRow);
                
                row.data = this._data[index];
                
            }

            this._filterAndSortData();

        }

    }

    public get rowCount():number {
        return this._rowCount;
    }

    public get length():number {
        return this._data.length;
    }

    public get selectable():boolean {
        return this._selectable;
    }
    public set selectable(s:boolean){
        if(this._selectable !== s){
            this._selectedIndex = null;
            this._selectable = s;
            this.invalidate();
        }
    }

    public get selectedIndex():number {
        return this._selectedIndex !== null && this._selectedIndex >= 0 && this._selectedIndex < this._data.length ? this._selectedIndex : null;
    }
    public set selectedIndex(i:number) {
        if((this._selectedIndex !== i && i >= 0 && i < this._data.length) || i === null){
            this._selectedIndex = i;
            this.invalidate();
        }
    }

    public get selectedItem():Array<any> {
        return this._data[this._selectedIndex] || null;
    }

    public get columnLabels():Array<string> {
        return this._header.columnLabels;
    }
    public set columnLabels(c:Array<string>) {
        if(this._header.columnLabels !== c){
            this._header.columnLabels = c;
            this.invalidate();
        }
    }

    public get rowRenderer():IADataGridRowConstructor {
        return this._rowRenderer;
    }

    public set rowRenderer(renderer:IADataGridRowConstructor) {
        if(this._rowRenderer !== renderer){
            this._rowRenderer = renderer;
            this.invalidate();
        }
    }

    public get inverted():boolean {
        return this._inverted;
    }

    public set inverted(i:boolean){
        if(this._inverted !== i){
            this._inverted = i;
            this.invalidate();
        }
    }

    public get verticallyScrollable():boolean {
        return this._verticallyScrollable;
    }

    public set verticallyScrollable(s:boolean){
        if(this._verticallyScrollable !== s){
            this._verticallyScrollable = s;
            this.invalidate();
        }
    }
    
    public get verticalScrollAmount():number {
        return this._verticalScrollAmount;
    }

    public set verticalScrollAmount(amount:number){
        amount = Math.max(Math.min(amount, 1), 0);
        if(this._verticalScrollAmount !== amount){
            this._verticalScrollAmount = amount;
            this._render();
        }
    }

    public get horizontallyScrollable():boolean {
        return this._horizontallyScrollable;
    }

    public set horizontallyScrollable(s:boolean){
        if(this._horizontallyScrollable !== s){
            this._horizontallyScrollable = s;
            this.invalidate();
        }
    }

    public get horizontalScrollAmount():number {
        return this._horizontalScrollAmount;
    }

    public set horizontalScrollAmount(amount:number){
        amount = Math.max(Math.min(amount, 1), 0);
        if(this._horizontalScrollAmount !== amount){
            this._horizontalScrollAmount = amount;
            this._render();
        }
    }

    public get sortable():boolean {
        return this._sortable;
    }
    public set sortable(s:boolean){
        if(this._sortable !== s){
            this._sortable = s;
            this.invalidate();
        }
    }

    public get rowsDraggable():boolean {
        return this._rowsDraggable;
    }
    public set rowsDraggable(d:boolean){
        if(this._rowsDraggable !== d){
            this._rowsDraggable = d;
            this.invalidate();
        }
    }

    public get filterTextInput():ATextInput {
        return this._filterTextInput;
    }

    public set filterTextInput(t:ATextInput) {
        if(this._filterTextInput !== t){

            if(this._filterTextInput !== null){
                this._filterTextInput.removeEventListener('input', this._onFilterTextInputChange);
            } else {
                this._onFilterTextInputChange = this._onFilterTextInputChange.bind(this);
            }

            this._filterTextInput = t;

            this._filterTextInput.addEventListener('input', this._onFilterTextInputChange);
        }
    }
}

window.customElements.define('a-data-grid', ADataGrid);