import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { ALabel } from './ALabel.js';

export class ASelect extends AComponent {

    private _label:ALabel;
    private _select:HTMLSelectElement;
    private _icon:AFontAwesomeIcon;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._label = new ALabel();
        this.appendChild(this._label);

        this._select = document.createElement('select');
        this._select.size = 1;
        this.appendChild(this._select);

        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);
        
    }

    protected _registerListeners():void {
        super._registerListeners();

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();
    }

    protected _render():boolean {
        if(super._render()){

            this._label.visible = Boolean(this._label.text);
            this._icon.visible = this._icon.value !== null && this._icon.value.length > 0;

        } else {
            return false;
        }
    }

    public focus():void {
        this._select.focus();
    }

    public get value():string {
        return this._select.value;
    }
    public set value(v:string){
        if(this._select.value !== v){
            this._select.value = v;
            this.invalidate();
        }
    }

    public get options():string {
        return this._select.innerHTML;
    }
    public set options(o:string){
        if(this._select.innerHTML !== o){
            this._select.innerHTML = o;
            this.invalidate();
        }
    }

    public get label():string {
        return this._label.text;
    }
    public set label(l:string){
        if(this._label.text !== l){
            this._label.text = l;
            this.invalidate();
        }
    }

    public get icon():Array<string> {
        return this._icon.value;
    }
    public set icon(i:Array<string>){
        if(this._icon.value !== i){
            this._icon.value = i;
            this.invalidate();
        }
    }

}

window.customElements.define('a-select', ASelect);