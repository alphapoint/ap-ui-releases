import { AContainer } from './AContainer.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

import { AHeader } from './AHeader.js';
import { AButton } from './AButton.js';
import { AFooter } from './AFooter.js';
import { ASystemDialogEvent } from '../events/index.js';
import { IAComponent } from './IAComponent.js';
import { AComponent } from './AComponent.js';
import { ADialog } from './ADialog.js';

export class ACustomDialog extends ADialog {

    private _innerContent:AComponent;

    public constructor(){
        super();
    }

    public get innerContent():AComponent {
        return this._innerContent;
    }
    public set innerContent(c:AComponent) {
        if(this._innerContent !== c){
            this._content.removeAllChildren();
            this._content.appendChild(c);
            this._innerContent = c;
        }
    }

}

window.customElements.define('a-custom-dialog', ACustomDialog);