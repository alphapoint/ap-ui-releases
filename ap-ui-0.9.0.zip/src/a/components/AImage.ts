import { AComponent } from './AComponent.js';

export class AImage extends AComponent {

    private _img:HTMLImageElement;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._img = document.createElement('img');
        this.appendChild(this._img);
    }

    protected _registerListeners():void {
        super._registerListeners();
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();
    }

    protected _render():boolean {
        if(super._render()){


            return true;

        } else {
            return false
        }
    }

    public get src():string {
        return this._img.src;
    }
    public set src(s:string){
        this._img.src = s;
    }

    public get onload():(event: Event) => any {
        return this._img.onload;
    }
    public set onload(loadHandler:(event: Event) => any) {
        this._img.onload = loadHandler
    }

    public get onerror():OnErrorEventHandlerNonNull {
        return this._img.onerror;
    }
    public set onerror(errorHandler:OnErrorEventHandlerNonNull) {
        this._img.onerror = errorHandler
    }

    public get img():HTMLImageElement {
        return this._img;
    }

}

window.customElements.define('a-image', AImage);