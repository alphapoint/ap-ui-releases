import { AContainer } from './AContainer.js';
import { AWindow } from './AWindow.js';
import { AMenuData } from '../data/index.js';
import { AMenuEvent } from '../events/index.js';

export class AWindowContents extends AContainer {

    public icon:Array<string> = null;

    private _window:AWindow;

    private _menuData:Array<AMenuData>;

    public constructor(){
        super();

        this.handleMenuItemClick = this.handleMenuItemClick.bind(this);
    }

    public handleMenuItemClick(event:AMenuEvent):void {
        // console.log(event);
    }

    public get window():AWindow {
        return this._window as AWindow;
    }
    public set window(w:AWindow) {
        if(this._window !== w){
            this._window = w;
            this._window.menuData = this._menuData;
        }
    }

    public get menuData():Array<AMenuData> {
        return this._menuData;
    }
    public set menuData(m:Array<AMenuData>){
        if(this._menuData !== m){
            this._menuData = m;

            if(this._window !== undefined && this._window !== null){
                this._window.menuData = this._menuData;
            }
        }
    }
    
}

window.customElements.define('a-window-contents', AWindowContents);