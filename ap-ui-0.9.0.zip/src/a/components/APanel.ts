import { AContainer } from './AContainer.js';
import { APanelHeader } from './APanelHeader.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

import { APanelEvent } from '../events/APanelEvent.js';
import { APanelContentsContainer } from './APanelContentsContainer.js';
import { APanelResizeTargets } from './APanelResizeTargets.js';
import { APanelContainer } from './APanelContainer.js';
import { ARectangle } from '../geometry/index.js';
import { AMenuData, AMenuDataItem } from '../data/index.js';
import { ASystemManager } from '../managers/index.js';

export class APanel extends AContainer {

    private _panelGrid:APanelContainer;

    private _resizeTargets:APanelResizeTargets;
    private _header:APanelHeader;
    private _menuData:AMenuData;
    private _titleText:AText;
    protected _headerContents:AContainer;
    private _menuIcon:AFontAwesomeIcon;
    protected _panelContents:APanelContentsContainer;

    private _showHeader:boolean;
    private _showMenu:boolean;
    private _showTitle:boolean;

    private _isDragging:boolean;
    private _isResizing:boolean;
    private _resizeDirection:string;
    private _isMaximized:boolean;

    private _isDraggable:boolean;
    private _isResizable:boolean;
    private _isMaximizable:boolean;

    public constructor(){
        super();
        this._panelGrid = null;
    }

    protected _build():void {
        super._build();

        this._showHeader = true;
        this._showMenu = true;
        this._showTitle = true;

        this._isDragging = false;
        this._isResizing = false;
        this._resizeDirection = '';
        this._isMaximized = false;

        this._isDraggable = true;
        this._isResizable = true;
        this._isMaximizable = true;

        this._resizeTargets = new APanelResizeTargets();
        this.appendChild(this._resizeTargets);

        this._header = new APanelHeader();
        this.appendChild(this._header);

        this._menuIcon = new AFontAwesomeIcon();
        this._menuIcon.value = ['far', 'fa-ellipsis-v'];
        this._header.appendChild(this._menuIcon);

        this._titleText = new AText();
        this._header.appendChild(this._titleText);

        this._headerContents = new AContainer();
        this._header.appendChild(this._headerContents);

        this._panelContents = new APanelContentsContainer();
        this.appendChild(this._panelContents);
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._resizeTargets.ondragstart = () => { return false; };
        
        this._onMouseDown = this._onMouseDown.bind(this);
        this.addEventListener('mousedown', this._onMouseDown);

        this._onMouseUp = this._onMouseUp.bind(this);
        document.addEventListener('mouseup', this._onMouseUp);

        this._onHeaderMouseDown = this._onHeaderMouseDown.bind(this);
        this._header.addEventListener('mousedown', this._onHeaderMouseDown);

        this._onMenuIconMouseDown = this._onMenuIconMouseDown.bind(this);
        this._menuIcon.addEventListener('mousedown', this._onMenuIconMouseDown);

        this._onMenuIconClicked = this._onMenuIconClicked.bind(this);
        this._menuIcon.addEventListener('click', this._onMenuIconClicked);

        this._onMenuItemSelected = this._onMenuItemSelected.bind(this);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this._resizeTargets.ondragstart = null;

        this.removeEventListener('mousedown', this._onMouseDown);
        
        document.removeEventListener('mouseup', this._onMouseUp);

        this._header.removeEventListener('mousedown', this._onHeaderMouseDown);

        this._menuIcon.removeEventListener('mousedown', this._onMenuIconMouseDown);

        this._menuIcon.removeEventListener('click', this._onMenuIconClicked);

    }

    protected _render():boolean {
        if(super._render()){

            this._header.visible = this._showHeader;
            this._menuIcon.visible = this._showHeader && this._showMenu;
            this._titleText.visible = this._showHeader && this._showTitle;

            return true;
        } else {
            return false;
        }
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this.doLater(() => {
            let gridArea:string = window.getComputedStyle(this).getPropertyValue('--grid-area');
            if(gridArea !== ''){
                this.style.gridArea = gridArea;
            }
        });
    }

    private _onHeaderMouseDown(event:MouseEvent):void {
        if(this._isDraggable){
            this._isDragging = true;

            this.dispatchEvent(new APanelEvent(APanelEvent.DRAG_START, {detail: {pageX: event.pageX, pageY: event.pageY}}));
        }
    }
    
    private _onResizerMouseDown(event:MouseEvent, dir:string):void {
        if(this._isResizable){
            this._isResizing = true;
            this._resizeDirection = dir;

            this.dispatchEvent(new APanelEvent(APanelEvent.RESIZE_START, {detail: {pageX: event.pageX, pageY: event.pageY}}));
        }
    }

    private _onMouseDown(event:MouseEvent):void {
        let element:HTMLElement = (event.target as HTMLElement);

        if(element.nodeName === 'B'){
            this._onResizerMouseDown(event, element.getAttribute('data-direction'));
        }
    }

    private _onMouseUp(event:MouseEvent):void {
        if(this._isDraggable && this._isDragging){
            this.dispatchEvent(new APanelEvent(APanelEvent.DRAG_END));

            this._isDragging = false;
        } else if(this._isResizable && this._isResizing){
            this.dispatchEvent(new APanelEvent(APanelEvent.RESIZE_END));

            this._isResizing = false;
        }
    }

    private _onMenuIconMouseDown(event:MouseEvent):void {
        event.stopPropagation();
    }

    private _onMenuIconClicked(event:MouseEvent):void {
        event.stopPropagation();

        ASystemManager.instance.showMenu(event.pageX, event.pageY, this._menuData, this._onMenuItemSelected);
    
    }

    protected _onMenuItemSelected(item:AMenuDataItem):void {
    }

    public destroy():void {
        super.destroy();
        this._panelGrid = null;
    }

    public get panelGrid():APanelContainer {
        return this._panelGrid;
    }
    public set panelGrid(p:APanelContainer) {
        this._panelGrid = p;
    }

    public get menuData():AMenuData {
        return this._menuData || null;
    }
    public set menuData(d:AMenuData) {
        if(this._menuData !== d){
            this._menuData = d || null;
        }
    }

    public get title():string {
        return this._titleText.text;
    }
    public set title(t:string) {
        // if(this._titleText){
            if(this._titleText.text !== t){
                this._titleText.text = t;
            }
        // }
    }

    public get showHeader():boolean {
        return this._showHeader;
    }
    public set showHeader(s:boolean){
        if(this._showHeader !== s){
            this._showHeader = s;
            this.invalidate();
        }
    }

    public get showMenu():boolean {
        return this._showMenu;
    }
    public set showMenu(s:boolean){
        if(this._showMenu !== s){
            this._showMenu = s;
            this.invalidate();
        }
    }

    public get showTitle():boolean {
        return this._showTitle;
    }
    public set showTitle(s:boolean){
        if(this._showTitle !== s){
            this._showTitle = s;
            this.invalidate();
        }
    }

    public get isDragging():boolean {
        return this._isDragging;
    }
    public get isResizing():boolean {
        return this._isResizing;
    }
    public get resizeDirection():string {
        return this._resizeDirection;
    }

    public get draggable():boolean {
        return this._isDraggable;
    }
    public set draggable(d:boolean) {
        if(this._isDraggable !== d){
            this._isDraggable = d;

            if(d){
                this.removeClass('non-draggable');
            } else {
                this.addClass('non-draggable');
            }
        }
    }

    public get resizable():boolean {
        return this._isResizable;
    }
    public set resizable(r:boolean) {
        if(this._isResizable !== r){
            this._isResizable = r;

            if(r){
                this.removeClass('non-resizeable');
            } else {
                this.addClass('non-resizeable');
            }
        }
    }

    public get maximizable():boolean {
        return this._isMaximizable;
    }
    public set maximizable(m:boolean) {
        if(this._isMaximizable !== m){
            this._isMaximizable = m;

            if(m){
                this.removeClass('non-maximizable');
            } else {
                this.addClass('non-maximizable');
            }

            if(!m){
                this.removeClass('maximized');
            }
        }
    }

    public get maximized():boolean {
        return this._isMaximized;
    }
    public set maximized(m:boolean) {
        if(this._isMaximized !== m){
            this._isMaximized = m;

            if(m){
                this.addClass('maximized');
            } else {
                this.removeClass('maximized');
            }

            this.invalidate();
        }
    }

    public get dimensions():ARectangle {
        let r:ARectangle = new ARectangle();
        
        r.x = this.offsetLeft;// * ARenderManager.instance.pixelRatio;
        r.y = this.offsetTop;// * ARenderManager.instance.pixelRatio;
        r.width = this.offsetWidth;// * ARenderManager.instance.pixelRatio;
        r.height = this.offsetHeight;// * ARenderManager.instance.pixelRatio;
        
        return r;
    }

}

window.customElements.define('a-panel', APanel);