import { ASystemDialogEvent } from '../events/index.js';
import { AComponent } from './AComponent.js';
import { AContainer } from './AContainer.js';
import { ACustomDialog } from './ACustomDialog.js';
import { ADialog } from './ADialog.js';
import { AAlertDialog } from './dialogs/AAlertDialog.js';
import { AAuthenticateTwoFADialog } from './dialogs/AAuthenticateTwoFADialog.js';
import { ASetupTwoFADialog } from './dialogs/ASetupTwoFADialog.js';
import { AAuthenticateUsernamePasswordDialog } from './dialogs/AAuthenticateUsernamePasswordDialog.js';
import { AConfirmDialog } from './dialogs/AConfirmDialog.js';
import { AForgotPasswordDialog } from './dialogs/AForgotPasswordDialog.js';
import { ANoticeDialog } from './dialogs/ANoticeDialog.js';
import { APromptDialog } from './dialogs/APromptDialog.js';
import { ARegisterDialog } from './dialogs/ARegisterDialog.js';

export class ADialogContainer extends AContainer {

    private _mask:AContainer;
    private _dialogs:Array<ADialog>;

    public constructor(){
        super();

        this._dialogs = [];
    }

    protected _build():void {
        super._build();

        this._mask = new AContainer();
        this.appendChild(this._mask);
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);

        this._okClicked = this._okClicked.bind(this);
        this.addEventListener(ASystemDialogEvent.OK, this._okClicked);

        this._cancelClicked = this._cancelClicked.bind(this);
        this.addEventListener(ASystemDialogEvent.CANCEL, this._cancelClicked);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        document.removeEventListener('keydown', this._onKeyDown);

        this.removeEventListener(ASystemDialogEvent.OK, this._okClicked);
        this.removeEventListener(ASystemDialogEvent.CANCEL, this._cancelClicked);

    }

    protected _render():boolean {
        if(super._render()){

            if(this._dialogs.length > 0){

                let topDialog:ADialog = this._dialogs[this._dialogs.length - 1];

                if(topDialog.backgroundOverride !== null){
                    this._mask.style.setProperty('background-color', topDialog.backgroundOverride);
                } else {
                    this._mask.style.removeProperty('background-color');
                }

                this.appendChild(this._mask);
                this.appendChild(topDialog);

                this.visible = true;
            } else {
                this.visible = false;
            }

            return true;
        } else {
            return false;
        }
    }

    private _onKeyDown(event:KeyboardEvent):void {
        // console.log('Key', event);
        if(this._dialogs.length > 0){
            let topDialog:ADialog = this._dialogs[this._dialogs.length - 1];
            if(event.key === 'Enter' && topDialog.showOK){
                topDialog.forceOkayClick();
            } else if(event.key === 'Escape'){
                this.dismissDialog();
            }
        }
    }

    private _okClicked(event:ASystemDialogEvent):void {

        let dialog:ADialog | ACustomDialog = event.detail.dialog;
        let okCallback:((output?:string) => void) | ((username?:string, password?:string) => void) | ((twoFACode?:string) => void) = dialog.okCallback;

        if(dialog && okCallback){
        //     if(dialog.constructor === ADialog){
        //         if(dialog.type === ADialogType.PROMPT){
        //             okCallback(dialog.inputValue);
        //         } else if(dialog.type === ADialogType.AUTHENTICATE_USERNAME_PASSWORD){
        //             okCallback(dialog.usernameInputValue, dialog.passwordInputValue);
        //         } else if(dialog.type === ADialogType.AUTHENTICATE_TWOFA){
        //             okCallback(dialog.twoFAInputValue);
        //         } else {
        //             okCallback();
        //         }
        //     } else {
                okCallback();
        //     }
        }
        this.dismissDialog();
    }

    private _cancelClicked(event:ASystemDialogEvent):void {
        let dialog:ADialog | ACustomDialog = event.detail.dialog;
        let cancelCallback:() => void = dialog.cancelCallback;
        if(dialog && cancelCallback){
            cancelCallback();
        }
        this.dismissDialog();
    }

    public showNoticeDialog(message:string = ''):ANoticeDialog {
        let dialog:ANoticeDialog = new ANoticeDialog();
        dialog.message = message;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showAlertDialog(message:string = '', okCallback:() => void = null):AAlertDialog {
        let dialog:AAlertDialog = new AAlertDialog();
        dialog.message = message;
        
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback();
            }
        }

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showConfirmDialog(message:string = '', okCallback:() => void = null, cancelCallback:() => void = null):AConfirmDialog {
        let dialog:AConfirmDialog = new AConfirmDialog();
        dialog.message = message;
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback();
            }
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showPromptDialog(message:string = '', inputLabel:string = null, okCallback:(output:string) => void = null, cancelCallback:() => void = null):APromptDialog {
        let dialog:APromptDialog = new APromptDialog();
        dialog.message = message;
        dialog.inputLabel = inputLabel;
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.inputValue);
            }
        }
        dialog.cancelCallback = cancelCallback;
        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showAuthenticateUsernamePasswordDialog(okCallback:(username:string, password:string) => void = null, cancelCallback:() => void = null):AAuthenticateUsernamePasswordDialog {
        let dialog:AAuthenticateUsernamePasswordDialog = new AAuthenticateUsernamePasswordDialog();
        
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.usernameInputValue, dialog.passwordInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showAuthenticateTwoFADialog(okCallback:(twoFACode:string) => void = null, cancelCallback:() => void = null):AAuthenticateTwoFADialog {
        let dialog:AAuthenticateTwoFADialog = new AAuthenticateTwoFADialog();
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.twoFACodeInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showSetupTwoFADialog(qrData:string, okCallback:(twoFACode:string) => void = null, cancelCallback:() => void = null):ASetupTwoFADialog {
        let dialog:ASetupTwoFADialog = new ASetupTwoFADialog();
        dialog.qrData = qrData;
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.twoFACodeInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showRegisterDialog(okCallback:(username:string, email:string, password:string) => void = null, cancelCallback:() => void = null):ARegisterDialog {
        let dialog:ARegisterDialog = new ARegisterDialog();
        
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.usernameInputValue, dialog.emailInputValue, dialog.passwordInputValue);
            };
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showForgotPasswordDialog(okCallback:(username:string) => void = null, cancelCallback:() => void = null):AForgotPasswordDialog {
        let dialog:AForgotPasswordDialog = new AForgotPasswordDialog();
        if(okCallback){
            dialog.okCallback = ():void => {
                okCallback(dialog.usernameInputValue);
            }
        }
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public showCustomDialog(content:AComponent = null, okCallback:() => void = null, cancelCallback:() => void = null):ACustomDialog {
        let dialog:ACustomDialog = new ACustomDialog();
        if(content !== null){
            dialog.innerContent = content;
        }
        dialog.okCallback = okCallback;
        dialog.cancelCallback = cancelCallback;

        this.appendChild(dialog);

        this._dialogs.push(dialog);

        this.invalidate();

        return dialog;
    }

    public dismissDialog():void {

        if(this._dialogs.length > 0){

            let dialog:ADialog | ACustomDialog = this._dialogs.pop();

            this.doLater(():void => {
                this.removeChild(dialog);
                dialog.destroy();
                this.invalidate();
            });

        }

    }

    public dismissAllDialogs():void {

        while(this._dialogs.length > 0){
            let dialog:ADialog | ACustomDialog = this._dialogs.pop();
            this.removeChild(dialog);
            dialog.destroy();
        }

        this.invalidate();

    }

    public get isShowingDialog():boolean {
        return this.visible;
    }

}

window.customElements.define('a-dialog-container', ADialogContainer);