import { AContainer } from './AContainer.js';

export class AHeader extends AContainer {

    public constructor(){
        super();
    }

}

window.customElements.define('a-header', AHeader);