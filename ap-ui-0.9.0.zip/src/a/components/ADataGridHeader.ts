import { AContainer } from './AContainer.js';
import { ADataGridHeaderItem } from './ADataGridHeaderItem.js';
import { ADataGridSortDirection } from './ADataGrid.js';

export class ADataGridHeader extends AContainer {

    private _columnLabels:Array<string> = [];

    private _sortColumnIndex:number;
    private _sortDirection:ADataGridSortDirection;

    public constructor(){
        super();
    }

    protected _render():boolean {

        if(super._render()){

            let count: number = this._columnLabels.length;

            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new ADataGridHeaderItem());
                } else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }

            for (let i = 0; i < count; i++) {
                let headerItem:ADataGridHeaderItem = (this.getChildAt(i) as ADataGridHeaderItem);
                headerItem.index = i;
                headerItem.text = this._columnLabels[i];
                headerItem.title = this._columnLabels[i];

                if(this._sortColumnIndex === i){
                    headerItem.sortDirection = this._sortDirection;
                } else {
                    headerItem.sortDirection = ADataGridSortDirection.NONE;
                }
            }

            return true;
        } else {
            return false;
        }

    }

    public setSort(index:number = -1, direction:ADataGridSortDirection = ADataGridSortDirection.NONE):void {
        if(this._sortColumnIndex !== index || this._sortDirection !== direction){
            this._sortColumnIndex = index;
            this._sortDirection = direction;

            this.invalidate();
        }
    }

    public get columnLabels(): Array<string> {
        return this._columnLabels;
    }
    public set columnLabels(l: Array<string>) {
        if(this._columnLabels !== l){
            this._columnLabels = l || [];
            this.invalidate();
        }
    }
    
}

window.customElements.define('a-data-grid-header', ADataGridHeader);