import { AContainer } from './AContainer.js';
import { AButton } from './AButton.js';
import { AWindow } from './AWindow.js';
import { ATaskBarEvent } from '../events/ATaskBarEvent.js';

export class ATaskBar extends AContainer {

    private _windows: Array<AWindow> = [];

    private _selectedWindow: AWindow = null;

    public constructor() {
        super();
    }

    protected _build(): void {
        super._build();
    }

    protected _registerListeners(): void {
        super._registerListeners();

        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);
    }

    protected _render():boolean {

        if(super._render()){

            let count: number = this._windows.length;

            while (this.childElementCount !== count) {
                if (this.childElementCount < count) {
                    this.appendChild(new AButton());
                } else if (this.childElementCount > count) {
                    this.removeChild(this.getChildAt(this.childElementCount - 1));
                }
            }

            for (let i = 0; i < count; i++) {
                let win:AWindow = this._windows[i];
                let button: AButton = (this.getChildAt(i) as AButton);

                button.setAttribute('data-index', i.toString());
                button.icon = win.icon;
                button.label = win.title;

                if (this._selectedWindow !== null && this._selectedWindow === win) {
                    button.addClass('selected');
                } else {
                    button.removeClass('selected');
                }
            }

            return true;
        } else {
            return false;
        }

    }

    private _onClick(event:MouseEvent):void {
        if(event.target.constructor === AButton){
            this._onButtonClick(event.target as AButton);
        }
    }

    private _onButtonClick(button: AButton): void {
        this._selectedWindow = this._windows[Number(button.getAttribute('data-index'))] || null;
        this.invalidate();
        this.dispatchEvent(new ATaskBarEvent(ATaskBarEvent.SELECTED_WINDOW_CHANGED));
    }

    public get windows(): Array<AWindow> {
        return this._windows;
    }
    public set windows(wins: Array<AWindow>) {
        if(this._windows !== wins){
            this._windows = wins || [];
            this.invalidate();
        }
    }

    public get selectedWindow(): AWindow {
        return this._selectedWindow;
    }
    public set selectedWindow(win:AWindow) {
        if(this._selectedWindow !== win){
            this._selectedWindow = win;
            this.invalidate();
        }
    }

}

window.customElements.define('a-task-bar', ATaskBar);