import { ADialog } from '../ADialog.js';
import { AText } from '../AText.js';

export class AAlertDialog extends ADialog {

    private _messageText:AText;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._messageText = new AText();
        this._content.appendChild(this._messageText);

        this.icon = ['fal', 'fa-exclamation'];

        this.showCancel = false;
    }

    public get message():string {
        return this._messageText.text;
    }
    public set message(t:string) {
        if(this._messageText.text !== t){
            this._messageText.text = t;
        }
    }

}

window.customElements.define('a-alert-dialog', AAlertDialog);