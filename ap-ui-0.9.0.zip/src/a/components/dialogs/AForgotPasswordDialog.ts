import { ADialog } from '../ADialog.js';
import { ATextInput } from '../ATextInput.js';
import { ALabel } from '../ALabel.js';
import { AText } from '../AText.js';
import {ALanguageManager} from '../../managers/ALanguageManager.js';

export class AForgotPasswordDialog extends ADialog {

    private _messageText:AText;
    private _usernameInput:ATextInput;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this.icon = ['fal', 'fa-unlock'];

        this._messageText = new AText();
        this._content.appendChild(this._messageText);

        this._usernameInput = new ATextInput();
        this._content.appendChild(this._usernameInput);
    }

    protected _render():boolean {
        if(super._render()){

            let lm:ALanguageManager = ALanguageManager.instance;

            this.title = lm.get('ForgotPasswordDialog', 'Recover Password');
            
            this._messageText.text = lm.get('ForgotPasswordDialog', 'Please enter your username to receive an\nemail with password reset instructions');
            this._usernameInput.label = lm.get('ForgotPasswordDialog', 'Username');

            this._okButton.label = lm.get('ForgotPasswordDialog', 'OK');
            this._cancelButton.label = lm.get('ForgotPasswordDialog', 'Cancel');

            return true;
        } else {
            return false;
        }
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._usernameInput.focus();
    }

    public get message():string {
        return this._messageText.text;
    }
    public set message(t:string) {
        if(this._messageText.text !== t){
            this._messageText.text = t;
        }
    }

    public get usernameLabel():string {
        return this._usernameInput.label;
    }
    public set usernameLabel(l:string) {
        this._usernameInput.label = l;
    }

    public get usernameInputValue():string {
        return this._usernameInput.value;
    }
    public set usernameInputValue(v:string) {
        this._usernameInput.value = v;
    }

}

window.customElements.define('a-forgot-password-dialog', AForgotPasswordDialog);