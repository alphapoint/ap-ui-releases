import { AText } from '../AText.js';
import { ATextInput } from '../ATextInput.js';
import { ALanguageManager, ASystemManager } from '../../managers/index.js';
import { ADialog } from '../ADialog.js';
import { AFontAwesomeIcon } from '../AFontAwesomeIcon.js';

export class ARegisterDialog extends ADialog {

    private _formIsValid:boolean;

    private _usernameInput:ATextInput;
    private _emailInput:ATextInput;
    private _passwordInput:ATextInput;
    private _passwordTwoInput:ATextInput;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._formIsValid = false;

        // let decoration:AFontAwesomeIcon = new AFontAwesomeIcon();
        // decoration.addClass('decoration');
        // decoration.value = ['fal', 'fa-user-plus'];
        // this._content.appendChild(decoration);

        this._usernameInput = new ATextInput();
        // this._usernameInput.value = 'UserTest';
        this._content.appendChild(this._usernameInput);

        this._emailInput = new ATextInput();
        // this._emailInput.value = 'userTest@email.com';
        this._emailInput.type = ATextInput.EMAIL;
        this._content.appendChild(this._emailInput);

        this._passwordInput = new ATextInput();
        // this._passwordInput.value = '1234';
        this._passwordInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordInput);

        this._passwordTwoInput = new ATextInput();
        // this._passwordTwoInput.value = '1234';
        this._passwordTwoInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordTwoInput);

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('input', this._onInput);

    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._usernameInput.focus();
        this._usernameInput.select();
    }

    protected _render():boolean {
        if(super._render()){

            let lm:ALanguageManager = ALanguageManager.instance;

            this.title = lm.get('RegisterDialog', 'Register');

            this._usernameInput.label = lm.get('RegisterDialog', 'Username');
            this._emailInput.label = lm.get('RegisterDialog', 'Email');
            this._passwordInput.label = lm.get('RegisterDialog', 'Password');
            this._passwordTwoInput.label = lm.get('RegisterDialog', 'Re-type Password');

            this._okButton.label = lm.get('RegisterDialog', 'OK');
            this._cancelButton.label = lm.get('RegisterDialog', 'Cancel');

            this._okButton.enabled = this._formIsValid;

            return true;
        } else {
            return false;
        }
    }

    private _onInput(event:Event):void {
        if(this._usernameInput.value.length > 0 && this._emailInput.value.match(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) && this._passwordInput.value.length > 0 && this._passwordInput.value === this._passwordTwoInput.value){
            this._formIsValid = true;
        } else {
            this._formIsValid = false;
        }
        this.invalidate();
    }

    public get usernameLabel():string {
        return this._usernameInput.label;
    }
    public set usernameLabel(l:string) {
        this._usernameInput.label = l;
    }

    public get usernameInputValue():string {
        return this._usernameInput.value;
    }
    public set usernameInputValue(v:string) {
        this._usernameInput.value = v;
    }

    public get emailLabel():string {
        return this._emailInput.label;
    }
    public set emailLabel(l:string) {
        this._emailInput.label = l;
    }

    public get emailInputValue():string {
        return this._emailInput.value;
    }
    public set emailInputValue(v:string) {
        this._emailInput.value = v;
    }

    public get passwordLabel():string {
        return this._passwordInput.label;
    }
    public set passwordLabel(l:string) {
        this._passwordInput.label = l;
    }

    public get passwordInputValue():string {
        return this._passwordInput.value;
    }
    public set passwordInputValue(v:string) {
        this._passwordInput.value = v;
    }

    public get passwordTwoLabel():string {
        return this._passwordTwoInput.label;
    }
    public set passwordTwoLabel(l:string) {
        this._passwordTwoInput.label = l;
    }

    public get passwordTwoInputValue():string {
        return this._passwordTwoInput.value;
    }
    public set passwordTwoInputValue(v:string) {
        this._passwordTwoInput.value = v;
    }

}

window.customElements.define('a-register-dialog', ARegisterDialog);