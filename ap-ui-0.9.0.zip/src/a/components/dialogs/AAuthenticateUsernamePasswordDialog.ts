import { AText } from '../AText.js';
import { ATextInput } from '../ATextInput.js';
import { ALanguageManager, ASystemManager } from '../../managers/index.js';
import { ADialog } from '../ADialog.js';
import { AFontAwesomeIcon } from '../AFontAwesomeIcon.js';

export class AAuthenticateUsernamePasswordDialog extends ADialog {

    private _formIsValid:boolean;

    private _usernameInput:ATextInput;
    private _passwordInput:ATextInput;
    private _forgotPasswordText:AText;
    private _registerText:AText;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._formIsValid = false;

        // let decoration:AFontAwesomeIcon = new AFontAwesomeIcon();
        // decoration.addClass('decoration');
        // decoration.value = ['fal', 'fa-user-unlock'];
        // this._content.appendChild(decoration);

        this._usernameInput = new ATextInput();
        this._content.appendChild(this._usernameInput);

        this._passwordInput = new ATextInput();
        this._passwordInput.type = ATextInput.PASSWORD;
        this._content.appendChild(this._passwordInput);

        this._forgotPasswordText = new AText();
        this._forgotPasswordText.addClass('forgot-password');
        this._content.appendChild(this._forgotPasswordText);

        this._registerText = new AText();
        this._registerText.addClass('register');
        this._content.appendChild(this._registerText);

    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);

        this._forgotPasswordClicked = this._forgotPasswordClicked.bind(this);
        this._forgotPasswordText.addEventListener('click', this._forgotPasswordClicked);

        this._registerClicked = this._registerClicked.bind(this);
        this._registerText.addEventListener('click', this._registerClicked);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('input', this._onInput);

        this._forgotPasswordText.removeEventListener('click', this._forgotPasswordClicked);

        this._registerText.removeEventListener('click', this._registerClicked);
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._usernameInput.focus();
        this._usernameInput.select();

        this._okButton.enabled = false;
    }

    protected _render():boolean {
        if(super._render()){

            let lm:ALanguageManager = ALanguageManager.instance;

            this.title = lm.get('AuthenticateDialog', 'Authenticate');

            this._usernameInput.label = lm.get('AuthenticateDialog', 'Username');
            this._passwordInput.label = lm.get('AuthenticateDialog', 'Password');
            this._forgotPasswordText.text = lm.get('AuthenticateDialog', 'Forgot password?');
            this._registerText.text = lm.get('AuthenticateDialog', 'Register');

            this._okButton.label = lm.get('AuthenticateDialog', 'OK');
            this._cancelButton.label = lm.get('AuthenticateDialog', 'Cancel');

            this._registerText.visible = ASystemManager.instance.AllowRegistration;

            this._okButton.enabled = this._formIsValid;

            return true;
        } else {
            return false;
        }
    }

    private _onInput(event:Event):boolean {
        if(this._usernameInput.value.length > 0 && this._passwordInput.value.length > 0){
            this._formIsValid = true;
        } else {
            this._formIsValid = false;
        }
        this.invalidate();
        return true;
    }

    private _forgotPasswordClicked(event:MouseEvent):void {
        let sm:ASystemManager = ASystemManager.instance;

        if(sm.ForgotPasswordOverride){
            sm.ForgotPasswordOverride();
        } else {
            sm.showForgotPasswordDialog();
        }
    }

    private _registerClicked():void {
        let sm:ASystemManager = ASystemManager.instance;

        if(sm.RegisterOverride){
            sm.RegisterOverride();
        } else {
            sm.showRegisterDialog();
        }
    }

    public get usernameLabel():string {
        return this._usernameInput.label;
    }
    public set usernameLabel(l:string) {
        this._usernameInput.label = l;
    }

    public get usernameInputValue():string {
        return this._usernameInput.value;
    }
    public set usernameInputValue(v:string) {
        this._usernameInput.value = v;
    }

    public get passwordLabel():string {
        return this._passwordInput.label;
    }
    public set passwordLabel(l:string) {
        this._passwordInput.label = l;
    }

    public get passwordInputValue():string {
        return this._passwordInput.value;
    }
    public set passwordInputValue(v:string) {
        this._passwordInput.value = v;
    }

}

window.customElements.define('a-authenticate-username-password-dialog', AAuthenticateUsernamePasswordDialog);