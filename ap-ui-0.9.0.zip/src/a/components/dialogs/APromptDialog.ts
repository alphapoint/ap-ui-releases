import { ADialog } from '../ADialog.js';
import { ATextInput } from '../ATextInput.js';
import { ALabel } from '../ALabel.js';
import { AText } from '../AText.js';

export class APromptDialog extends ADialog {

    private _messageText:AText;
    private _input:ATextInput;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._messageText = new AText();
        this._content.appendChild(this._messageText);

        this._input = new ATextInput();
        this._content.appendChild(this._input);

        this.icon = ['fal', 'fa-comment-alt-edit'];
        
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._input.focus();
    }

    public get message():string {
        return this._messageText.text;
    }
    public set message(t:string) {
        if(this._messageText.text !== t){
            this._messageText.text = t;
        }
    }

    public get inputLabel():string {
        return this._input.label;
    }
    public set inputLabel(l:string) {
        this._input.label = l;
    }

    public get inputValue():string {
        return this._input.value;
    }
    public set inputValue(v:string) {
        this._input.value = v;
    }

}

window.customElements.define('a-prompt-dialog', APromptDialog);