import { ADialog } from '../ADialog.js';
import { AFontAwesomeIcon } from '../AFontAwesomeIcon.js';
import { AText } from '../AText.js';
import { AQRCode, ATextInput } from '../index.js';

export class ASetupTwoFADialog extends ADialog {

    private _formIsValid:boolean;

    private _qrData:string;

    private _twoFAInput:ATextInput;

    private _qrCode:AQRCode;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this.title = '2FA Setup';

        this._formIsValid = false;

        this._qrData = null;

        // let decoration:AFontAwesomeIcon = new AFontAwesomeIcon();
        // decoration.addClass('decoration');
        // decoration.value = ['fal', 'fa-user-shield'];
        // this._content.appendChild(decoration);

        let instruction:AText = new AText();
        instruction.text = `1. Download a Two-Factor Authentication app to\nyour phone such as Authy or Google Authenticator.\n
        2. Use the app to scan QR code.\n
        3. Type in code from your phone.`;
        this._content.appendChild(instruction);

        this._qrCode = new AQRCode();
        this._content.appendChild(this._qrCode);

        this._twoFAInput = new ATextInput();
        this._twoFAInput.label = '2FA Code';
        this._content.appendChild(this._twoFAInput);
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onInput = this._onInput.bind(this);
        this.addEventListener('input', this._onInput);
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        this.removeEventListener('input', this._onInput);
    }

    protected _render():boolean {
        if(super._render()){

            this._okButton.enabled = this._formIsValid;

            return true;
        } else {
            return false;
        }
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        this._twoFAInput.focus();
        this._twoFAInput.select();

        this._okButton.enabled = false;
    }

    private _onInput(event:Event):void {
        if(this._twoFAInput.value.length > 0){
            this._formIsValid = true;
        } else {
            this._formIsValid = false;
        }
        this.invalidate();
    }

    public get qrData():string {
        return this._qrData;
    }
    public set qrData(c:string) {
        if(this._qrData !== c){
            this._qrData = c;
            this._qrCode.data = this._qrData;
        }
    }

    public get twoFACodeInputValue():string {
        return this._twoFAInput.value;
    }
    public set twoFACodeInputValue(v:string) {
        this._twoFAInput.value = v;
    }

}

window.customElements.define('a-setup-twofa-dialog', ASetupTwoFADialog);