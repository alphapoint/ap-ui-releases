import { AText } from './AText.js';

export class ALabel extends AText {
}

window.customElements.define('a-label', ALabel);