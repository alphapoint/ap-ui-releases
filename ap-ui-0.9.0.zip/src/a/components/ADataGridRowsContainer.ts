import { AContainer } from './AContainer.js';

export class ADataGridRowsContainer extends AContainer {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-data-grid-rows-container', ADataGridRowsContainer);