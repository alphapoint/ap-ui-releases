import { AMenuData, AMenuDataItem } from '../data/index.js';
import { AMenuEvent } from '../events/index.js';
import { AContainer } from './AContainer.js';
import { AContextWidget } from './AContextWidget.js';
import { AMenu } from './AMenu.js';
import { IAComponent } from './IAComponent.js';

export enum ContextItemType {
    MENU = 'MENU',
    WIDGET = 'WIDGET'
}

interface ContextItemRegistration {
    type:ContextItemType;
    targetComponent:IAComponent;
    menuData?:AMenuData;
    contextWidget?:AContextWidget;
    selectedCallback?:(menuDataItem:AMenuDataItem) => void;
}

export class AContextItemContainer extends AContainer {

    private _menu:AMenu;

    private _contextItemRegistrations:Map<IAComponent, ContextItemRegistration>;
    private _currentContextItemRegistration:ContextItemRegistration;
    private _singleMenuSelectedCallback:(menuDataItem:AMenuDataItem) => void;

    public constructor(){
        super();

        this._contextItemRegistrations = new Map();
        this._currentContextItemRegistration = null;
    }

    protected _build():void {
        super._build();

        this._menu = new AMenu();
        this.appendChild(this._menu);
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onContextMenu = this._onContextMenu.bind(this);
        document.oncontextmenu = this._onContextMenu;

        this._onMouseDown = this._onMouseDown.bind(this);
        // document.addEventListener('mousedown', this._onMouseDown);

        this._onKeyDown = this._onKeyDown.bind(this);
        document.addEventListener('keydown', this._onKeyDown);

        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();

        // document.oncontextmenu = null;

        document.removeEventListener('mousedown', this._onMouseDown);

        document.removeEventListener('keydown', this._onKeyDown);

        this._menu.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);
    }

    protected _render():boolean {
        if(super._render()){


            return true;
        } else {
            return false;
        }
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();
        this.visible = false;
    }

    private _onContextMenu(event:MouseEvent):boolean {

        if((event.target as HTMLElement).closest('a-system-context-item-container') === this){
            return false;
        }

        this._menu.visible = false;
        this._contextItemRegistrations.forEach((contextRegistration:ContextItemRegistration):void => {
            if(contextRegistration.type === ContextItemType.WIDGET){
                contextRegistration.contextWidget.visible = false;
            }
        });

        let component:IAComponent = event.target as IAComponent;
        let hasRegistration:boolean = false;

        while(component.parentElement && component.parentElement !== document.body){
            if(this._contextItemRegistrations.has(component)){
                hasRegistration = true;
                break;
            } else {
                component = component.parentElement as IAComponent;
            }
        }
            
        if(hasRegistration){

            event.preventDefault();
            event.stopPropagation();

            this._handleContextItem(component, event.clientX, event.clientY);

            return false;

        } else {

            this.dismiss();

            return true;

        }

    }

    private _handleContextItem(component:IAComponent, x:number, y:number):void {

        this._currentContextItemRegistration = this._contextItemRegistrations.get(component);

        this.visible = true;

        let contextItem:IAComponent = null;

        if(this._currentContextItemRegistration.type === ContextItemType.MENU && this._currentContextItemRegistration.menuData && this._currentContextItemRegistration.menuData.items.length > 0){

            this._menu.data = this._currentContextItemRegistration.menuData || new AMenuData();

            contextItem = this._menu;

        } else if(this._currentContextItemRegistration.type === ContextItemType.WIDGET && this._currentContextItemRegistration.contextWidget.isViewable){
            
            this._currentContextItemRegistration.contextWidget.invalidate();

            contextItem = this._currentContextItemRegistration.contextWidget;
        } else {
            this.dismiss();
            return;
        }

        contextItem.visible = true;

        contextItem.style.left = `${x}px`;
        contextItem.style.top = `${y}px`;

        contextItem.invalidate();

        this.doLater(():void => {
            let contextItemWidth:number = contextItem.offsetWidth;
            let contextItemHeight:number = contextItem.offsetHeight;
            if(x + contextItemWidth > this.offsetWidth){
                contextItem.style.left = `${x - contextItemWidth}px`;
            }
            if(y + contextItemHeight > this.offsetHeight){
                contextItem.style.top = `${y - contextItemHeight}px`;
            }
        })

        //This is a cheat, but prevents having a click handler running always
        document.addEventListener('mousedown', this._onMouseDown);
    }

    private _onMouseDown(event:MouseEvent):void {
        if((event.target as HTMLElement).closest('a-context-item-container') !== this){
            this.dismiss();
        }
    }

    private _onKeyDown(event:KeyboardEvent):void {
        if(event.key === 'Escape' && this._menu !== null){
            this.dismiss();
        }
    }

    private _onMenuItemClicked(event:AMenuEvent):void {
        if(this._currentContextItemRegistration !== null){
            if(this._currentContextItemRegistration.selectedCallback){
                this._currentContextItemRegistration.selectedCallback(event.detail.menuDataItem);
            }
        } else if(this._singleMenuSelectedCallback){
            this._singleMenuSelectedCallback(event.detail.menuDataItem);
        }
        this.dismiss();
    }

    public dismiss():void {
        this.visible = false;
        this._menu.visible = false;
        this._contextItemRegistrations.forEach((contextRegistration: ContextItemRegistration):void => {
            if(contextRegistration.type === ContextItemType.WIDGET){
                contextRegistration.contextWidget.visible = false;
            }
        });
        this._currentContextItemRegistration = null;
        this._singleMenuSelectedCallback = null;
        //This is a cheat, but prevents having a click handler running always
        document.removeEventListener('mousedown', this._onMouseDown);
    }

    public showMenu(x:number, y:number, menuData:AMenuData = null, selectedCallback:(item:AMenuDataItem) => void = null):void {
        if(menuData && selectedCallback){
            this._singleMenuSelectedCallback = selectedCallback;

            this.visible = true;
            
            this._menu.data = menuData;
            this._menu.visible = true;

            this._menu.style.left = `${x}px`;
            this._menu.style.top = `${y}px`;

            this._menu.invalidate();

            //This is a cheat, but prevents having a click handler running always
            document.addEventListener('mousedown', this._onMouseDown);
        }
    }

    public registerContextMenu(targetComponent:IAComponent, menuData:AMenuData, selectedCallback:(item:AMenuDataItem) => void = null):void {
        this._contextItemRegistrations.set(targetComponent, {
            type: ContextItemType.MENU,
            targetComponent: targetComponent,
            menuData: menuData,
            selectedCallback: selectedCallback
        });
    }

    public registerContextWidget(targetComponent:IAComponent, contextWidget:AContextWidget):void {
        contextWidget.visible = false;
        this._contextItemRegistrations.set(targetComponent, {
            type: ContextItemType.WIDGET,
            targetComponent: targetComponent,
            contextWidget: contextWidget
        });
        if(!this.hasChild(contextWidget)){
            this.appendChild(contextWidget);
        }
    }

    public unregisterContextItem(targetComponent:IAComponent):void {
        let registration:ContextItemRegistration = this._contextItemRegistrations.get(targetComponent);
        if(registration){
            registration.targetComponent = undefined;
            registration.menuData = undefined;
            registration.selectedCallback = undefined;
            if(registration.type === ContextItemType.WIDGET && this.hasChild(registration.contextWidget)){
                this.removeChild(registration.contextWidget);
            }
            registration.contextWidget = undefined;
            this._contextItemRegistrations.delete(targetComponent);
        }
    }

    public hasContextItemRegistered(targetComponent:IAComponent):boolean {
        return this._contextItemRegistrations.has(targetComponent);
    }

    public get isShowingContextItem():boolean {
        return this.visible;
    }

    /*
    ASystemManager.instance.registerContextMenu(this._time, new AMenuData(null, 'Test', [
        new AMenuDataItem(null, 'Time Context Menu', null),
        new AMenuDataDividerItem(),
        new AMenuDataItem(null, 'AlphaPoint 2020', null, false)]), 
        (menuDataItem:AMenuDataItem):void => {
            console.log(menuDataItem);
        }
    );
    //ASystemManager.instance.unregisterContextMenu(this._time)
    ASystemManager.instance.registerContextWidget(lastPriceContainer, new TestContextWidget());
    */

}

window.customElements.define('a-context-item-container', AContextItemContainer);