import { AComponent } from './AComponent.js';

export class AText extends AComponent {

    private _text:string = '';

    constructor() {
        super();
    }

    protected _render():boolean{
        if(super._render()){
            this.innerText = this._text;
            return true;
        } else {
            return false;
        }
    }

    get text():string {
        return this._text;
    }
    set text(t:string){
        if(this._text !== t){
            this._text = t;
            this.invalidate();
        }
    }

}

window.customElements.define('a-text', AText);