import { AContainer } from './AContainer.js';
import { ARectangle } from '../geometry/index.js';
import { AComponent } from './AComponent.js';
import { ADataGrid } from './ADataGrid.js';
import { AWindow } from './AWindow.js';
import { AWindowEvent, AWindowContainerEvent } from '../events/index.js';
import { IAComponent } from './IAComponent.js';
import { AWindowContents } from './AWindowContents.js';

// export interface IAPWindowContentConstructor {

//     new ():APWindowContents;

// }

export class AWindowContainer extends AContainer {

    private _windowRegistry:Map<IAComponent, AWindow>;

    private _transformingWindow:AWindow = null;
    private _transformingWindowStartDimensions:ARectangle = null;
    private _lastWindowDimensions:ARectangle = new ARectangle(11, 11, 640, 320);

    private _focusedWindow:AWindow = null;
    private _focusOrder:Set<AWindow> = new Set();

    private _pointerDragStartX:number = 0;
    private _pointerDragStartY:number = 0;
    private _pointerX:number = 1;
    private _pointerY:number = 1;
    private _pointerDragDistanceX:number = 0;
    private _pointerDragDistanceY:number = 0;

    private _zIndex: number = 100;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._windowRegistry = new Map();
    }

    protected _onMouseMove(event:MouseEvent):void {
        if(this._transformingWindow !== null){
            this._pointerX = event.pageX;
            this._pointerY = event.pageY;
            this._pointerDragDistanceX = Math.round(this._pointerX - this._pointerDragStartX);
            this._pointerDragDistanceY = Math.round(this._pointerY - this._pointerDragStartY);

            this._transformWindow();
        }
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onMouseMove = this._onMouseMove.bind(this);

    }

    private _registerWindowListeners(window:AWindow):void {

        this._onWindowTransformEnd = this._onWindowTransformEnd.bind(this);

        this._onWindowMouseDown = this._onWindowMouseDown.bind(this);
        window.addEventListener('mousedown', this._onWindowMouseDown);

        this._onWindowMinimizeClicked = this._onWindowMinimizeClicked.bind(this);
        window.addEventListener(AWindowEvent.MINIMIZE_CLICKED, this._onWindowMinimizeClicked);

        this._onWindowMaximizeClicked = this._onWindowMaximizeClicked.bind(this);
        window.addEventListener(AWindowEvent.MAXIMIZE_CLICKED, this._onWindowMaximizeClicked);

        this._onWindowCloseClicked = this._onWindowCloseClicked.bind(this);
        window.addEventListener(AWindowEvent.CLOSE_CLICKED, this._onWindowCloseClicked);

        this._onWindowHeaderDoubleClicked = this._onWindowHeaderDoubleClicked.bind(this);
        window.addEventListener(AWindowEvent.HEADER_DOUBLE_CLICKED, this._onWindowHeaderDoubleClicked);

        this._onWindowDragStart = this._onWindowDragStart.bind(this);
        this._onWindowDragEnd = this._onWindowDragEnd.bind(this);
        window.addEventListener(AWindowEvent.DRAG_START, this._onWindowDragStart);
        window.addEventListener(AWindowEvent.DRAG_END, this._onWindowDragEnd);

        this._onWindowResizeStart = this._onWindowResizeStart.bind(this);
        this._onWindowResizeEnd = this._onWindowResizeEnd.bind(this);
        window.addEventListener(AWindowEvent.RESIZE_START, this._onWindowResizeStart);
        window.addEventListener(AWindowEvent.RESIZE_END, this._onWindowResizeEnd);

    }

    private _unregisterWindowListeners(window:AWindow):void {
        window.removeEventListener('mousedown', this._onWindowMouseDown);

        window.removeEventListener(AWindowEvent.MINIMIZE_CLICKED, this._onWindowMinimizeClicked);
        window.removeEventListener(AWindowEvent.MAXIMIZE_CLICKED, this._onWindowMaximizeClicked);
        window.removeEventListener(AWindowEvent.CLOSE_CLICKED, this._onWindowCloseClicked);
        window.removeEventListener(AWindowEvent.HEADER_DOUBLE_CLICKED, this._onWindowHeaderDoubleClicked);

        window.removeEventListener(AWindowEvent.DRAG_START, this._onWindowDragStart);
        window.removeEventListener(AWindowEvent.DRAG_END, this._onWindowDragEnd);

        window.removeEventListener(AWindowEvent.RESIZE_START, this._onWindowResizeStart);
        window.removeEventListener(AWindowEvent.RESIZE_END, this._onWindowResizeEnd);

    }

    protected _render():boolean {
        if(super._render()){

            for (var i = 0; i < this.childNodes.length; i++) {
                let win:AWindow = this.childNodes[i] as AWindow;
                
                win.focused = this._focusedWindow === win;
            }

            return true;
        } else {
            return false;
        }
    }

    private _onWindowMouseDown(event:MouseEvent):void {

        let win:AWindow = (event.target as AComponent).closest('a-window') as AWindow;

        if(win !== null){
            win.style.zIndex = (this._zIndex++).toString();
        }

        this.focusedWindow = win;

        // this.doLater(() => {
        //     this.dispatchEvent(new APWindowContainerEvent(APWindowContainerEvent.WINDOW_FOCUSED, { detail: { window: win } } ));
        // });
    }

    private _onWindowMinimizeClicked(event:AWindowEvent):void {
        this.minimizeWindow(event.target as AWindow);
    }

    private _onWindowMaximizeClicked(event:AWindowEvent):void {
        let win:AWindow = event.target as AWindow;
        this.focusedWindow = win;
        this.maximizeWindow(win);
    }

    private _onWindowCloseClicked(event:AWindowEvent):void {
        this.removeWindow(event.target as AWindow);
    }

    private _onWindowHeaderDoubleClicked(event:AWindowEvent):void {
        let win:AWindow = event.target as AWindow;

        if(win.maximizable){
            win.maximized = !win.maximized;
        }
    }

    private _onWindowDragStart(event:AWindowEvent):void {
        this._onWindowTransformStart(event);
    }

    private _onWindowDragEnd(event:AWindowEvent):void {
        this._onWindowTransformEnd(event);
    }

    private _onWindowResizeStart(event:AWindowEvent):void {
        this._onWindowTransformStart(event);
    }

    private _onWindowResizeEnd(event:AWindowEvent):void {
        this._onWindowTransformEnd(event);
    }

    private _onWindowTransformStart(event:AWindowEvent):void {

        window.addEventListener('mousemove', this._onMouseMove);

        let win:AWindow = event.target as AWindow;

        this._pointerX = event.detail.pageX;
        this._pointerY = event.detail.pageY;
        this._pointerDragStartX = event.detail.pageX;
        this._pointerDragStartY = event.detail.pageY;
        this._pointerDragDistanceX = 0;
        this._pointerDragDistanceY = 0;

        this._transformingWindow = win;
        this._transformingWindowStartDimensions = win.dimensions;

        win.addClass('transforming');
        win.style.zIndex = (this._zIndex++).toString();

        this._transformWindow();

        this.focusedWindow = win;

        this.addClass('window-transforming');

        this.doLater(() => {
            this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED));
        });
    }

    private _onWindowTransformEnd(event:AWindowEvent):void {

        window.removeEventListener('mousemove', this._onMouseMove);

        let win:AWindow = event.target as AWindow;

        if(this._transformingWindow === win){

            this._transformingWindow.removeClasses('transforming', 'maximized', 'outbound');
            
            this._transformingWindow = null;
            this._transformingWindowStartDimensions = null;

            this.removeClass('window-transforming');

            win.invalidate(true);

        }

    }

    private _transformWindow():void {

        let win:AWindow = this._transformingWindow;

        let windowX:number = this._transformingWindowStartDimensions.x;
        let windowY:number = this._transformingWindowStartDimensions.y;
        let windowXOffset:number = 0;
        let windowYOffset:number = 0;
        let windowWidth:number = this._transformingWindowStartDimensions.width;
        let windowHeight:number = this._transformingWindowStartDimensions.height;
        let windowWidthOffset:number = 0;
        let windowHeightOffset:number = 0;

        // let leftBound:number = this.offsetLeft;
        // let topBound:number = this.offsetTop;
        // let rightBound:number = this.offsetLeft + this.offsetWidth;
        // let bottomBound:number = this.offsetTop + this.offsetHeight;

        let offsetLeft: number = this.parentElement.offsetLeft;
        let offsetTop: number = this.parentElement.offsetTop;
        let offsetWidth: number = this.offsetWidth;
        let offsetHeight: number = this.offsetHeight;

        let leftBound:number = offsetLeft;
        let topBound:number = offsetTop;
        let rightBound:number = offsetLeft + offsetWidth;
        let bottomBound:number = offsetTop + offsetHeight;

        if(win.isDragging){

            windowXOffset = this._pointerDragDistanceX;
            windowYOffset = this._pointerDragDistanceY;

            if(this._pointerX <= leftBound || this._pointerX >= rightBound || this._pointerY <= topBound || this._pointerY >= bottomBound){

                win.addClass('outbound');

                leftBound = leftBound + (offsetWidth / 4);
                topBound = topBound + (offsetHeight / 4);
                rightBound = rightBound - (offsetWidth / 4);
                bottomBound = bottomBound - (offsetHeight / 4);

                if(this._pointerX <= leftBound || this._pointerX >= rightBound){

                    if(this._pointerX <= leftBound){
                        windowXOffset = -windowX;
                    } else if(this._pointerX >= rightBound){
                        windowXOffset = (offsetWidth / 2) - windowX;
                    }
                    
                    windowWidthOffset = (offsetWidth / 2) - windowWidth;

                } else {
                    windowXOffset = -windowX;
                    windowWidthOffset = offsetWidth - windowWidth;
                }

                if(this._pointerY <= topBound || this._pointerY >= bottomBound){

                    if(this._pointerY <= topBound){
                        windowYOffset = -windowY;
                    } else if(this._pointerY >= bottomBound){
                        windowYOffset = (this.offsetHeight / 2) - windowY;
                    }
                    
                    windowHeightOffset = (offsetHeight / 2) - windowHeight;
                } else {
                    windowYOffset = -windowY;
                    windowHeightOffset = offsetHeight - windowHeight;
                }

            } else {
                win.removeClass('outbound');
            }

        } else if(win.isResizing){

            let dir:string = win.resizeDirection;

            if(dir.indexOf('n') > -1){
                windowYOffset = this._pointerDragDistanceY;
                windowHeightOffset = -this._pointerDragDistanceY;
            }
            if(dir.indexOf('s') > -1){
                windowHeightOffset = this._pointerDragDistanceY;
            }
            if(dir.indexOf('w') > -1){
                windowXOffset = this._pointerDragDistanceX;
                windowWidthOffset = -this._pointerDragDistanceX;
            }
            if(dir.indexOf('e') > -1){
                windowWidthOffset = this._pointerDragDistanceX;
            }

        }

        let newWindowWidth = windowWidth + windowWidthOffset;
        let newWindowHeight = windowHeight + windowHeightOffset;
        let newWindowX = windowX + windowXOffset;
        let newWindowY = windowY + windowYOffset;

        win.style.left = `${newWindowX}px`;
        win.style.top = `${newWindowY}px`;
        win.style.width = `${newWindowWidth}px`;
        win.style.height = `${newWindowHeight}px`;

        this._lastWindowDimensions = new ARectangle(newWindowX, newWindowY, newWindowWidth, newWindowHeight);

        if(win.isResizing || (win.isDragging && win.hasClass('outbound'))){
            win.querySelectorAll('a-data-grid').forEach((dataGrid:ADataGrid) => {
                dataGrid.invalidate();
            });
        }
        
    }

    private _focusWindow(win:AWindow):void {

        if(win.minimized){
            win.minimized = false;
        }

        this._focusedWindow = win;
        this._focusedWindow.style.zIndex = (this._zIndex++).toString();
        this._focusOrder.add(win);

        this.invalidate();

        this.doLater(() => {
            this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED, { detail: { window: win } } ));
        });
    }

    public addWindow(component:AWindowContents, title:string = null, cssClass:string = null, singleInstance:boolean = false):void {
        if(!this._windowRegistry.has(component)){
            let win:AWindow = new AWindow();
            if(cssClass !== null){
                win.addClass(cssClass);
            }
            win.title = title;
            win.content = component;

            this.appendChild(win);

            this._registerWindowListeners(win);

            this._windowRegistry.set(component, win);

            this._lastWindowDimensions.x += 11;
            this._lastWindowDimensions.y += 11;

            //console.log(this._lastWindowDimensions.x, this._lastWindowDimensions.y, this._lastWindowDimensions.width, this._lastWindowDimensions.height);
            
            win.style.left = `${this._lastWindowDimensions.x + 11}px`;
            win.style.top = `${this._lastWindowDimensions.y + 11}px`;
            win.style.width = `${this._lastWindowDimensions.width}px`;
            win.style.height = `${this._lastWindowDimensions.height}px`;
            win.style.zIndex = (this._zIndex++).toString();

            this.focusedWindow = win;

            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_ADDED, { detail: { window: win } } ));
            });

        } else {
            let win:AWindow = this._windowRegistry.get(component);
            if(title !== null){
                win.title = title;
            }
            win.style.zIndex = (this._zIndex++).toString();

            this.focusedWindow = win;

            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_FOCUSED, { detail: { window: win } } ));
            });
            
        }
    }

    public removeWindow(win:AWindow):void {
        this._windowRegistry.forEach((win:AWindow, component:IAComponent) => {
            if(event.target as AWindow === win){
                this._windowRegistry.delete(component);
                this._unregisterWindowListeners(win);
                win.destroy();
                win.remove();

                this._focusOrder.delete(win);

                if(this._focusedWindow === win){
                    let wins:Array<AWindow> = Array.from(this._focusOrder.values());
                    this.focusedWindow = wins[wins.length - 1] || null;
                }
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_REMOVED, { detail: { contentClass: component.constructor} }));
            }
        });
    }

    public minimizeWindow(win:AWindow):void {
        if(win.minimizable){
            win.minimized = true;

            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_MINIMIZED, { detail: { window: win } } ));
            });
        }
    }

    public maximizeWindow(win:AWindow):void {
        if(win.maximizable){
            win.maximized = !win.maximized;

            this.doLater(() => {
                this.dispatchEvent(new AWindowContainerEvent(AWindowContainerEvent.WINDOW_MAXIMIZED, { detail: { window: win } } ));
            });
        }
    }

    public hasWindowContent(component:IAComponent):boolean {
        return this._windowRegistry.has(component);
    }

    public hasWindowTitle(title:string):boolean {
        let hasWindow:boolean = false;
        this._windowRegistry.forEach((win:AWindow):void => {
            if(win.title === title){
                hasWindow = true;
            }
        });
        return hasWindow;
    }

    public getWindowByTitle(title:string):AWindow {
        let window:AWindow = null;
        this._windowRegistry.forEach((win:AWindow):void => {
            if(win.title === title){
                window = win;
            }
        });
        return window;
    }

    public invalidateLayout():void {
        this.doLater(() => {
            let children:NodeList = this.childNodes;
            for (var i = 0; i < children.length; i++) {
                const child:AWindow = children[i] as AWindow;
                child.style.removeProperty('grid-area');

                let gridArea:string = window.getComputedStyle(child).getPropertyValue('--grid-area');
                if(gridArea !== ''){
                    child.style.gridArea = gridArea;
                }

                child.invalidate(true);
            }
        });
    }

    public invalidateWindows():void {
        for (let i = 0; i < this.childElementCount; i++) {
            let win:AWindow = (this.getChildAt(i) as AWindow);

            win.invalidate(true);
        }
    }

    public tileWindows():void {
        let containerWidth:number = this.offsetWidth;
        let containerHeight:number = this.offsetHeight;

        let wins:Array<AWindow> = Array.from(this._windowRegistry.values());
        let numberOfWindows:number = wins.length;

        let winWidth:number = 0;
        let winHeight:number = 0;
        
        let done:boolean = false;
        let rows = 1;
        let columns = 1;
        while(!done){

            winHeight = containerHeight / rows;
            winWidth = winHeight * 1.5;

            if(winWidth * Math.floor(numberOfWindows / rows) <= containerWidth){
                columns = Math.ceil(numberOfWindows / rows);
                done = true;
            }

            if(rows > 20){
                done = true;
                return;
            } else {
                rows++;
            }
        }

        let winIndex:number = 0;
        winWidth = containerWidth / columns;
        for(let y = 0; y < rows; y++){
            for(let x = 0; x < columns; x++){
                let win:AWindow = wins[winIndex];
                if(win){
                    win.style.left = `${x * winWidth}px`;
                    win.style.top = `${y * winHeight}px`;
                    win.style.width = `${winWidth}px`;
                    win.style.height = `${winHeight}px`;
                    winIndex++;
                }
            }
        }
    }

    public getNextZIndex():number {
        this._zIndex++
        return this._zIndex;
    }

    public get windows():Array<AWindow> {
        return Array.from(this._windowRegistry.values());
    }

    public get focusedWindow():AWindow {
        return this._focusedWindow;
    }
    public set focusedWindow(win:AWindow) {
        if(/*this._focusedWindow !== win && */win !== null){
            this._focusWindow(win);
        }
    }

}

window.customElements.define('a-window-container', AWindowContainer);