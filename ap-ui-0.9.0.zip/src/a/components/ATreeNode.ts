import { AComponent } from './AComponent.js';
import { AContainer } from './AContainer.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { AText } from './AText.js';

export class ATreeNode extends AComponent {

    private _node:AContainer;
    private _openCloseIcon:AFontAwesomeIcon;
    private _iconIcon:AFontAwesomeIcon;
    private _labelText:AText;
    private _actionTextText:AText;

    private _childNodeContainer:AContainer;

    private _id:string;
    private _isOpen:boolean;
    private _icon:Array<string>;
    private _label:string;
    private _actionText:string;
    private _isSelected:boolean;

    public constructor(id:string, icon:Array<string> = null, label:string, actionText:string = null){
        super();

        this._id = id;
        this.dataset.id = id;
        this._icon = icon;
        this._label = label;
        this._actionText = actionText;
    }

    protected _build():void {
        super._build();

        this._isSelected = false;
        this._isOpen = false;

        this._node = new AContainer();
        this._node.addClass('node');
        this.appendChild(this._node);

        this._openCloseIcon = new AFontAwesomeIcon();
        this._openCloseIcon.addClass('open-close');
        this._node.appendChild(this._openCloseIcon);

        this._iconIcon = new AFontAwesomeIcon();
        this._iconIcon.addClass('icon');
        this._iconIcon.visible = false;
        this._node.appendChild(this._iconIcon);

        this._labelText = new AText();
        this._labelText.addClass('label');
        this._node.appendChild(this._labelText);

        this._actionTextText = new AText();
        this._actionTextText.addClass('action-text');
        this._actionTextText.visible = false;
        this._node.appendChild(this._actionTextText);


        this._childNodeContainer = new AContainer();
        this._childNodeContainer.addClass('child-nodes');
        this._childNodeContainer.visible = false;
        this.appendChild(this._childNodeContainer);

    }

    protected _registerListeners():void {
        super._registerListeners();
    }

    protected _render():boolean {
        if(super._render()){

            this._openCloseIcon.visible = this._childNodeContainer.childElementCount > 0;
            this._openCloseIcon.value = this._isOpen ? ['fas', 'fa-chevron-down'] : ['fas', 'fa-chevron-right'];

            this._iconIcon.visible = this._icon !== null;
            this._iconIcon.value = this._icon;

            this._labelText.text = this._label;

            this._actionTextText.visible = this._actionText !== null;
            this._actionTextText.text = this._actionText;


            if(this._isSelected){
                if(!this.hasClass('selected')){
                    this.addClass('selected');
                }
            } else {
                if(this.hasClass('selected')){
                    this.removeClass('selected');
                }
            }

            this._childNodeContainer.visible = this._isOpen && this._childNodeContainer.childElementCount > 0;

            return true;
        } else {
            return false;
        }
    }

    public addChildTreeNode(treeNode:ATreeNode):void {
        this._childNodeContainer.appendChild(treeNode);
        this.invalidate();
    }

    public removeChildTreeNode(treeNode:ATreeNode):void {
        this._childNodeContainer.removeChild(treeNode);
        this.invalidate();
    }

    public get isSelected():boolean {
        return this._isSelected;
    }
    public set isSelected(isSelected:boolean) {
        if(this._isSelected !== isSelected){
            this._isSelected = isSelected;
            this.invalidate();
        }
    }

    public get hasChildTreeNodes():boolean {
        return this._childNodeContainer.childElementCount > 0;
    }

    public get id():string {
        return this._id;
    }

    public get isOpen():boolean {
        return this._isOpen;
    }
    public set isOpen(i:boolean) {
        if(this._isOpen !== i){
            this._isOpen = i;
            this.invalidate();
        }
    }

    public get icon():Array<string> {
        return this._icon;
    }
    public set icon(i:Array<string>) {
        if(this._icon !== i){
            this._icon = i;
            this.invalidate();
        }
    }

    public get label():string {
        return this._label;
    }
    public set label(l:string) {
        if(this._label !== l){
            this._label = l;
            this.invalidate();
        }
    }

    public get actionText():string {
        return this._actionText;
    }
    public set actionText(a:string) {
        if(this._actionText !== a){
            this._actionText = a;
            this.invalidate();
        }
    }

}

window.customElements.define('a-tree-node', ATreeNode);