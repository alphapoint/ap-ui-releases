import { AContainer } from './AContainer.js';

export class AWindowHeader extends AContainer {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-window-header', AWindowHeader);