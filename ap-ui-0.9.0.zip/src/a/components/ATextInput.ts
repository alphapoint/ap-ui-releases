import { AComponent } from './AComponent.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { ALabel } from './ALabel.js';

export class ATextInput extends AComponent {

    public static NUMBER:string = 'number';
    public static DATE:string = 'date';
    public static TIME:string = 'time';
    public static DATETIME:string = 'datetime-local';
    public static URL:string = 'url';
    public static TEXT:string = 'text';
    public static TELEPHONE:string = 'tel';
    public static EMAIL:string = 'email';
    public static PASSWORD:string = 'password';
    public static COLOR:string = 'color';

    private _label:ALabel;
    private _textInput:HTMLInputElement;
    private _icon:AFontAwesomeIcon;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._label = new ALabel();
        this.appendChild(this._label);

        this._textInput = document.createElement('input');
        this._textInput.type = 'text';
        // this._textInput.size = 1;
        this.appendChild(this._textInput);

        this._icon = new AFontAwesomeIcon();
        this.appendChild(this._icon);
        
    }

    protected _registerListeners():void {
        super._registerListeners();

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();
    }

    protected _render():boolean {
        if(super._render()){

            this._label.visible = Boolean(this._label.text);
            this._icon.visible = this._icon.value !== null && this._icon.value.length > 0;

        } else {
            return false;
        }
    }

    public select():void {
        this._textInput.select();
    }

    public focus():void {
        this._textInput.focus();
    }

    public get type():string {
        return this._textInput.type;
    }
    public set type(t:string){
        this._textInput.type = t;
        if(t === ATextInput.PASSWORD){
            this._textInput.name = t;
        }
    }

    public get inputMode():string {
        return this._textInput.inputMode;
    }
    public set inputMode(m:string){
        this._textInput.inputMode = m;
    }

    public get placeholder():string {
        return this._textInput.placeholder;
    }
    public set placeholder(p:string){
        this._textInput.placeholder = p;
    }

    public get value():string {
        return this._textInput.value;
    }
    public set value(v:string){
        if(this._textInput.value !== v){
            this._textInput.value = v;
            this.invalidate();
        }
    }

    public get label():string {
        return this._label.text;
    }
    public set label(l:string){
        if(this._label.text !== l){
            this._label.text = l;
            this.invalidate();
        }
    }

    public get icon():Array<string> {
        return this._icon.value;
    }
    public set icon(i:Array<string>){
        if(this._icon.value !== i){
            this._icon.value = i;
            this.invalidate();
        }
    }

    public get readonly():boolean {
        return this._textInput.readOnly;
    }
    public set readonly(r:boolean){
        this._textInput.readOnly = r;
    }

    public get min():string {
        return this._textInput.min;
    }
    public set min(m:string){
        this._textInput.min = m;
    }

    public get max():string {
        return this._textInput.max;
    }
    public set max(m:string){
        this._textInput.max = m;
    }

    public get step():string {
        return this._textInput.step;
    }
    public set step(s:string){
        this._textInput.step = s;
    }
}

window.customElements.define('a-text-input', ATextInput);