import { AContainer } from './AContainer.js';

export class AIFrame extends AContainer {

    private _uri:string;
    private _iframe:HTMLIFrameElement;

    public constructor(uri:string = null){
        super();

        this._uri = uri;
    }

    protected _build(){
        super._build();

        this._iframe = document.createElement('iframe');
        this._iframe.setAttribute('allowtransparency', 'true');

        this.appendChild(this._iframe);

    }

    protected _registerListeners():void {
        super._registerListeners();

    }

    protected _unregisterListeners():void {
        super._unregisterListeners();
    }

    protected _finalizeInstantiation():void {
        super._finalizeInstantiation();

        if(this._uri !== null){
            this.uri = this._uri;
        }
    }

    public reload():void {
        this._iframe.contentDocument.location.reload(true);
    }

    public get contentDocument():Document {
        return this._iframe.contentDocument;
    }

    public get uri():string {
        return this._uri;
    }
    public set uri(u:string){
        if(this._uri !== u){
            this._uri = u;
            this._iframe.src = this._uri;
        }
    }

}

window.customElements.define('a-iframe', AIFrame);