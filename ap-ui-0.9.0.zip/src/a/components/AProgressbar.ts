import { AComponent } from './AComponent.js';

export class AProgressbar extends AComponent {

    private _progressbar:HTMLProgressElement;

    constructor() {
        super();
    }

    protected _build():void {
        super._build();

        this._progressbar = document.createElement('progress');
        this.appendChild(this._progressbar);
    }

    public set value(val:number) {
        this._progressbar.value = val;
    }

    public get type():string {
        return this.getAttribute('type');
    }

    protected _registerListeners():void {
        super._registerListeners();
    }

    protected _unregisterListeners():void {
        super._unregisterListeners();
    }

    protected _render():boolean {
        if(super._render()){

            

            return true;
        } else {
            return false;
        }
    }
}

window.customElements.define('a-progress-bar', AProgressbar);