import { AComponent } from './AComponent.js';

export class AContextWidget extends AComponent {

    public constructor(){
        super();
    }

    public get isViewable():boolean {
        return true;
    }

}

window.customElements.define('a-context-widget', AContextWidget);