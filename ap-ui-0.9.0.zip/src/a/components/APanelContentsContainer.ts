import { AContainer } from './AContainer.js';

export class APanelContentsContainer extends AContainer {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-panel-contents-container', APanelContentsContainer);