import { AContainer } from './AContainer.js';
import { AMenuButtonBarEvent } from '../events/AMenuButtonBarEvent.js';
import { AButton } from './AButton.js';
import { AMenuData, AMenuDataItem } from '../data/index.js';
import { AMenu } from './AMenu.js';
import { AMenuEvent } from '../events/index.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

export class AMenuButtonBar extends AContainer {

    private _data:Array<AMenuData | AMenuDataItem>;

    private _menu:AMenu;

    private _closeTimer:number;
    private _closeTimeout:number;

    private _selectable:boolean;
    private _selectedMenuDataItem:AMenuDataItem;

    public constructor() {
        super();
    }

    protected _build(): void {
        super._build();

        this._data = [];

        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);

        this._closeTimer = null;
        this._closeTimeout = 1000;

        this._selectable = true;
        this._selectedMenuDataItem = null;
    }

    protected _registerListeners(): void {
        super._registerListeners();

        this._onClick = this._onClick.bind(this);
        this.addEventListener('click', this._onClick);

        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);

        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);

        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);
    }

    protected _unregisterListeners(): void {
        super._unregisterListeners();

        this.removeEventListener('click', this._onClick);

        this.removeEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

        document.removeEventListener('mousedown', this._onDocumentMouseDown);

        this.removeEventListener('mouseleave', this._onMouseLeave);

        this.removeEventListener('mouseenter', this._onMouseEnter);
    }

    protected _render():boolean {

        if(super._render()){

            let count: number = this._data ? this._data.length : 0;

            let buttons:NodeListOf<AButton> = this.querySelectorAll('a-button');
            if (buttons.length !== count) {
                if (buttons.length < count) {

                    for(let i = 0; i < count - buttons.length; i++){
                        this.appendChild(new AButton());
                    }

                } else if (buttons.length > count) {

                    for(let i = 0; i < buttons.length - count; i++){
                        this.removeChild(this.querySelector('a-button'));
                    }

                }
            }

            buttons = this.querySelectorAll('a-button');

            for (let i = 0; i < count; i++) {

                let button: AButton = buttons.item(i);
                button.dataset.index = i.toString();

                let downIcon:AFontAwesomeIcon = button.querySelector('a-font-awesome-icon.down');

                let data:AMenuData | AMenuDataItem = this._data[i];
                if(data.constructor === AMenuData){

                    if(!downIcon){
                        downIcon = new AFontAwesomeIcon();
                        downIcon.addClass('down');
                        downIcon.value = ['fal', 'fa-angle-down'];
                        button.appendChild(downIcon);
                    }

                    if(this._selectable){
                        if(data.items.includes(this._selectedMenuDataItem)){
                            button.label = this._selectedMenuDataItem.label;
                            button.addClass('selected');
                        } else {
                            button.label = data.label;
                            button.removeClass('selected');
                        }
                    } else {
                        button.label = data.label;
                        button.removeClass('selected');
                    }

                } else if(data.constructor === AMenuDataItem){
                    button.label = data.label;
                    if(downIcon){
                        button.removeChild(downIcon);
                    }
                    if(this._selectable && this._selectedMenuDataItem === data){
                        button.addClass('selected');
                    } else {
                        button.removeClass('selected');
                    }
                }

            }

            return true;
        } else {
            return false;
        }

    }

    private _openMenu(x:number, data:AMenuData):void {
        //window.requestAnimationFrame(() => {

            this._menu.data = data;
            this._menu.style.left = `${x}px`;
            this._menu.visible = true;

        //});
    }

    private _closeMenu():void {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
    }

    private _onClick(event:MouseEvent):void {

        let button:AButton = (event.target as HTMLElement).closest('a-button');

        if(button){

            let data:AMenuData | AMenuDataItem = this._data[parseInt(button.dataset.index)];

            if(data.constructor === AMenuData){
                if(!this._menu.visible){
                    this._openMenu(button.offsetLeft, data);
                } else {
                    this._closeMenu();
                }
            } else if(data.constructor === AMenuDataItem){

                this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.ITEM_CLICKED, { bubbles: true, detail: { menuDataItem: data }}));
                
                if(this._selectable){
                    this._selectedMenuDataItem = data;
                    this.invalidate();
                    this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, { bubbles: true, detail: { menuDataItem: data }}));
                }

            }
        }

    }

    private _onMenuItemClicked(event:AMenuEvent):void {
        this._closeMenu();

        this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.ITEM_CLICKED, { bubbles: true, detail: { menuDataItem: event.detail.menuDataItem }}));
        
        if(this._selectable){
            this._selectedMenuDataItem = event.detail.menuDataItem;
            this.invalidate();
            this.dispatchEvent(new AMenuButtonBarEvent(AMenuButtonBarEvent.SELECTED_ITEM_CHANGE, { bubbles: true, detail: { menuDataItem: event.detail.menuDataItem }}));
        }
    }

    private _onDocumentMouseDown(event:MouseEvent):void {
        this._closeMenu();
    }

    private _onMouseLeave(event:MouseEvent):void {
        if(this._menu.visible){
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }

    private _onMouseEnter(event:MouseEvent):void {
        if(this._menu.visible){
            window.clearTimeout(this._closeTimer);
        }
    }


    public get data():Array<AMenuData | AMenuDataItem> {
        return this._data;
    }
    public set data(data:Array<AMenuData | AMenuDataItem>){
        if(this._data !== data){
            this._data = data || null;
            this._selectedMenuDataItem = null;
            this.invalidate();
        }
    }

    public get selectable(): boolean {
        return this._selectable;
    }
    public set selectable(s: boolean) {
        if(this._selectable !== s){
            this._selectable = s;
            this.invalidate();
        }
    }

    public get selectedMenuDataItem():AMenuDataItem {
        return this._selectedMenuDataItem;
    }
    public set selectedMenuDataItem(i:AMenuDataItem){
        if(this._selectedMenuDataItem !== i){
            this._selectedMenuDataItem = i || null;
            this.invalidate();
        }
    }

}

window.customElements.define('a-menu-button-bar', AMenuButtonBar);