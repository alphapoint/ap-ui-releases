import { AContainer } from './AContainer.js';
import { AMenu } from './AMenu.js';
import { AMenuEvent } from '../events/AMenuEvent.js';
import { AMenuData } from '../data/AMenuData.js';
import { AStartMenuEvent } from '../events/AStartMenuEvent.js';
import { AMenuDataItem } from '../data/AMenuDataItem.js';
import { AImageManager } from '../managers/AImageManager.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';

export class AStartMenu extends AContainer {

    private _startIcon:AFontAwesomeIcon;
    private _data:AMenuData;
    private _menu:AMenu;

    private _closeTimer:number;
    private _closeTimeout:number;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();

        this._startIcon = new AFontAwesomeIcon();
        this._startIcon.title = 'Start';
        this.appendChild(this._startIcon);

        this._menu = new AMenu();
        this._menu.visible = false;
        this.appendChild(this._menu);

        this._data = null;
        this._closeTimer = null;
        this._closeTimeout = 1000;
    }

    protected _registerListeners():void {
        super._registerListeners();

        this._onStartIconClick = this._onStartIconClick.bind(this);
        this._startIcon.draggable = false;
        this._startIcon.addEventListener('click', this._onStartIconClick);

        this._onMenuItemClicked = this._onMenuItemClicked.bind(this);
        this._menu.addEventListener(AMenuEvent.ITEM_CLICKED, this._onMenuItemClicked);

        this._onDocumentMouseDown = this._onDocumentMouseDown.bind(this);
        document.addEventListener('mousedown', this._onDocumentMouseDown);

        this._onMouseEnter = this._onMouseEnter.bind(this);
        this.addEventListener('mouseenter', this._onMouseEnter);

        this._onMouseLeave = this._onMouseLeave.bind(this);
        this.addEventListener('mouseleave', this._onMouseLeave);
        
    }
    
    protected _render():boolean {
        if(super._render()){



            return true;
        }
        
        return false;
    }

    private _openMenu():void {
        this._menu.data = this._data;
        this._menu.style.bottom = `${this.offsetHeight}px`;
        this._menu.style.left = `${this._startIcon.offsetLeft + 1}px`;
        this._menu.visible = true;
    }

    private _closeMenu():void {
        this._menu.visible = false;
        this._menu.data = new AMenuData();
    }

    private _onStartIconClick(event:MouseEvent):void {
        if(!this._menu.visible){
            this._openMenu();
        } else {
            this._closeMenu();
        }
    }

    private _onMenuItemClicked(event:AMenuEvent):void {
        this.dispatchEvent(new AStartMenuEvent(AStartMenuEvent.ITEM_CLICKED, { bubbles: true, detail: { menuData: this._menu.data, menuDataItem: event.detail.menuDataItem}}));
        this._closeMenu();
    }

    private _onDocumentMouseDown():void {
        this._closeMenu();
        window.clearTimeout(this._closeTimer);
    }

    private _onMouseEnter(event:MouseEvent):void {
        if(this._menu.visible){
            window.clearTimeout(this._closeTimer);
        }
    }

    private _onMouseLeave(event:MouseEvent):void {
        if(this._menu.visible){
            this._closeTimer = window.setTimeout(() => {
                this._closeMenu();
            }, this._closeTimeout);
        }
    }


    public get data():AMenuData {
        return this._data;
    }
    public set data(data:AMenuData){
        if(this._data !== data){
            this._data = data || null;
            this.invalidate();
        }
    }

    public get startIcon():Array<string> {
        return this._startIcon.value;
    }
    public set startIcon(i:Array<string>) {
        this._startIcon.value = i;
    }

}

window.customElements.define('a-start-menu', AStartMenu);