import { AComponent } from './AComponent.js';
import { AText } from './AText.js';
import { AFontAwesomeIcon } from './AFontAwesomeIcon.js';
import { ADataGridSortDirection } from './ADataGrid.js';

export class ADataGridHeaderItem extends AComponent {

    private _text:AText;
    private _sortArrow:AFontAwesomeIcon;
    private _sortDirection:ADataGridSortDirection;
    public index:number;

    public constructor(){
        super();
    }

    protected _build():void {
        super._build();
        
        this._text = new AText();
        this.appendChild(this._text);

        this._sortArrow = new AFontAwesomeIcon();
        this.appendChild(this._sortArrow);

        this._sortDirection = ADataGridSortDirection.ASCENDING;
    }

    protected _render():boolean {
        if(super._render()){

            if(this._sortDirection !== ADataGridSortDirection.NONE){

                if(this._sortDirection === ADataGridSortDirection.ASCENDING){
                    this._sortArrow.value = ['fal', 'fa-chevron-up'];
                } else if(this._sortDirection === ADataGridSortDirection.DESCENDING){
                    this._sortArrow.value = ['fal', 'fa-chevron-down'];
                }

                this._sortArrow.visible = true;
            } else {
                this._sortArrow.visible = false;
            }
            
            return true;
        } else {
            return false;
        }
    }

    public get text():string {
        return this._text.text;
    }
    public set text(t:string) {
        if(this._text.text !== t){
            this._text.text = t;
        }
    }

    public get sortDirection():ADataGridSortDirection {
        return this._sortDirection;
    }
    public set sortDirection(s:ADataGridSortDirection) {
        if(this._sortDirection !== s){
            this._sortDirection = s;
            this.invalidate();
        }
    }
    
}

window.customElements.define('a-data-grid-header-item', ADataGridHeaderItem);