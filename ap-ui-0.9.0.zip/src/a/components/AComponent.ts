import  { IAComponent } from './IAComponent.js';
import { ARenderManager } from '../managers/ARenderManager.js';

export class AComponent extends HTMLElement implements IAComponent {

    protected _visible:boolean = true;
    protected _enabled:boolean = true;
    protected _buildComplete:boolean = false;
    protected _registerListenersComplete:boolean = false;
    protected _instantiationComplete:boolean = false;
    protected _renderIsPending:boolean = false;

    constructor() {
        super();

        //this.doLater(() => {

            this.addClass('instantiating');
            this._build();

        //});
    }

    protected _build():void {

        this._visible = true;
        this._enabled = true;
        
        this.doLater(() => {

            this._buildComplete = true;
            this._registerListeners();

        });
    }

    protected _registerListeners():void {
        
        this.doLater(() => {

            this._registerListenersComplete = true;
            this._finalizeInstantiation();

        });
    }

    protected _unregisterListeners():void {
    }

    protected _finalizeInstantiation():void {

        this.doLater(() => {

            this._instantiationComplete = true;

            this._render();
            this.removeClass('instantiating');

        });

    }

    protected _render():boolean {
        this._renderIsPending = false;

        return this._buildComplete && this._registerListenersComplete && this._instantiationComplete;
    }

    public invalidate(invalidateChildren:boolean = false):void {
        if(!this._renderIsPending){
            this._renderIsPending = true;
            this.doLater(() => {
                this._render();

                if(invalidateChildren){

                    for (var i = 0; i < this.childNodes.length; i++) {

                        let child:AComponent = (this.childNodes[i] as AComponent);

                        if(child.invalidate){
                            child.invalidate(invalidateChildren);
                        }
                    }
                }
            });
        }
    }

    public doLater(task:() => any):void {
        ARenderManager.instance.requestAnimationFrame(task);
    }

    public appendChildAt(index:number, child:Node):Node {
        index = Math.max(0, Math.min(this.childElementCount - 1, index));

        this.insertBefore(child, this.getChildAt(index));

        return child;
    }

    public removeChildAt(index:number):Node {
        if(index > -1 && index < this.childElementCount){
            let child:HTMLElement = this.childNodes[index] as HTMLElement;

            if(child){
                this.removeChild(child);
            }

            return child as Node || null;
        }
    }

    public removeAllChildren():void {

        let children:NodeList = this.childNodes;

        for (var i = 0; i < children.length; i++) {
            this.removeChild(children[i]);
        }

    }

    public destroy():void {
        this._unregisterListeners();

        let children:NodeList = this.childNodes;

        for (var i = 0; i < children.length; i++) {
            const child:AComponent = children[i] as AComponent;
            if(child.destroy){
                child.destroy();
            }
            this.removeChild(child);
        }

    }

    public destroyAllChildren():void {
        let children:NodeList = this.childNodes;

        for (var i = 0; i < children.length; i++) {
            const child:AComponent = children[i] as AComponent;
            if(child.destroy){
                child.destroy();
            }
            this.removeChild(child);
        }
    }

    public hasChild(child:HTMLElement):boolean {
        return child && child.parentElement === this;
    }

    public getChildAt(i:number):HTMLElement {
        return this.children[i] as HTMLElement || null;
    }

    public addClass(className:string):void {
        this.classList.add(className);
    }

    public addClasses(...classNames:Array<string>):void {
        this.classList.add(...classNames);
    }

    public removeClass(className:string):void {
        this.classList.remove(className);
    }

    public removeClasses(...classNames:Array<string>):void {
        this.classList.remove(...classNames);
    }

    public hasClass(className:string):boolean {
        return this.classList.contains(className);
    }

    public get visible():boolean {
        return this._visible;
    }
    public set visible(v:boolean) {
        // if(this._visible !== v){
            this._visible = v;
            if(v){
                this.classList.remove('invisible');
            } else {
                this.classList.add('invisible');
            }
        // }
    }

    public get enabled():boolean {
        return this._enabled;
    }
    public set enabled(e:boolean) {
        if(this._enabled !== e){
            this._enabled = e;
            if(e){
                this.classList.remove('disabled');
            } else {
                this.classList.add('disabled');
            }
        }
    }

    public get hasFocus():boolean {
        return document.activeElement === this;
    }

}

window.customElements.define('a-component', AComponent);