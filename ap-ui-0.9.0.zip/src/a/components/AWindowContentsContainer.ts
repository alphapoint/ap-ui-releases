import { AContainer } from './AContainer.js';

export class AWindowContentsContainer extends AContainer {

    public constructor(){
        super();
    }
    
}

window.customElements.define('a-window-contents-container', AWindowContentsContainer);