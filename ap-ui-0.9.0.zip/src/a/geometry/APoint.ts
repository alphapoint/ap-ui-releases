export class APoint {

    public x:number;
    public y:number;

    public constructor(x:number = 0, y:number = 0){
        this.x = x;
        this.y = y;
    }

    public clone() {
        return new APoint(this.x, this.y);
    }
}