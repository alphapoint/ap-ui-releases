import { APoint } from './APoint.js';

export class ARectangle {

    private _topLeft:APoint;
    private _bottomRight:APoint;

    public constructor(x:number = 0, y:number = 0, w:number = 1, h:number = 1){
        this._topLeft = new APoint(x, y);
        this._bottomRight = new APoint(x + w, y + h);
    }

    public clone() {
        return new ARectangle(this._topLeft.x, this._topLeft.y, this._bottomRight.x - this._topLeft.x, this._bottomRight.y - this._topLeft.y);
    }

    public isEmpty() {
        return this._topLeft.x >= this._bottomRight.x || this._topLeft.y >= this._bottomRight.y;
    }

    public translate(x:number, y:number) {

        this._topLeft.x += x;
        this._bottomRight.x += x;

        this._topLeft.y += y;
        this._bottomRight.y += y;

        return this;

    }

    public scale(xScale:number, yScale:number) {

        this._topLeft.x *= xScale;
        this._bottomRight.x *= xScale;

        this._topLeft.y *= yScale;
        this._bottomRight.y *= yScale;

        return this;

    }

    public contains(rect:ARectangle) {
        return (rect.left >= this._topLeft.x && rect.right <= this._bottomRight.x && rect.top >= this._topLeft.y && rect.bottom <= this._bottomRight.y);
    }

    public intersects(rect:ARectangle) {
    
        let x1 = Math.max(this._topLeft.x, rect.left);
        let x2 = Math.min(this._bottomRight.x, rect.right);
        let y1 = Math.max(this._topLeft.y, rect.top);
        let y2 = Math.min(this._bottomRight.y, rect.bottom);

        return x1 < x2 && y1 < y2;

    }

    get x():number {
        return this._topLeft.x;
    }
    set x(x:number) {
        let w:number = this.width;

        this._topLeft.x = x;
        this._bottomRight.x = x + w;
    }

    get y():number {
        return this._topLeft.y;
    }
    set y(y:number) {
        let h:number = this.height;

        this._topLeft.y = y;
        this._bottomRight.y = y + h;
    }

    get width():number {
        return this._bottomRight.x - this._topLeft.x;
    }
    set width(w:number) {
        this._bottomRight.x = this._topLeft.x + w;
    }

    get height():number {
        return this._bottomRight.y - this._topLeft.y;
    }
    set height(h:number) {
        this._bottomRight.y = this._topLeft.y + h;
    }

    get top():number {
        return this.y;
    }
    set top(t:number) {
        this.y = t;
    }

    get right():number {
        return this._bottomRight.x;
    }
    set right(r:number) {
        this._bottomRight.x = r;
    }

    get bottom():number {
        return this._bottomRight.y;
    }
    set bottom(b:number) {
        this._bottomRight.x = b;
    }

    get left():number {
        return this.x;
    }
    set left(l:number) {
        this.x = l;
    }

    get center():APoint {
        return new APoint(this._topLeft.x + (this._bottomRight.x - this._topLeft.x) / 2, this._topLeft.y + (this._bottomRight.y - this._topLeft.y) / 2);
    }

}